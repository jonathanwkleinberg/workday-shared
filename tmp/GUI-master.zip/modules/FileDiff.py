import tkinter as tk
from tkinter import ttk, messagebox, filedialog
# from tkinter.filedialog import askopenfilename
from pathlib import Path
import sys, json
import threading
import webbrowser 

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import DifflibParser, DiffCode, TextLineNumbers, InterceptorWidget
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import DifflibParser, DiffCode, TextLineNumbers, InterceptorWidget

class App(ttk.Frame):

  # Colors
  whiteColor = '#ffffff'
  redColor = '#ff9494'
  darkredColor = '#ff0000'
  grayColor = '#cccccc'
  lightGrayColor = '#eeeeee'
  greenColor = '#94ffaf'
  darkgreenColor = '#269141'
  yellowColor = '#f0f58c'

  change_list = []
  current_change = -1

  def __init__(self, parent, left_file=None, right_file=None, minimum=False):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.grid_rowconfigure(2, weight=1)
    self.grid_columnconfigure(0, weight=0) # Left Line Numbers
    self.grid_columnconfigure(1, weight=1) # Left Text Area
    self.grid_columnconfigure(2, weight=0) # Right Line Numbers
    self.grid_columnconfigure(3, weight=1) # Right Text Area
    self.grid_columnconfigure(4, weight=0) # Scroll Bar

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=0, column=0, columnspan=99, padx=5, pady=5, sticky=tk.NSEW)

    self.TitleLabel = InterceptorWidget(self.config_frame, text="File Diff", font=("-size", 15, "-weight", "bold"))
    if not minimum: self.TitleLabel.grid(row=1, column=0)

    self.next_button = ttk.Button(self.config_frame, text='↓', width=3, command=self.next_change)
    self.next_button.grid(row=2, column=0)
    self.prev_button = ttk.Button(self.config_frame, text='↑', width=3, command=self.previous_change)
    self.prev_button.grid(row=2, column=1)

    self.changes_var = tk.StringVar(value='0 of 0 Differences')
    self.changes_label = ttk.Label(self.config_frame, textvariable=self.changes_var)
    self.changes_label.grid(row=2, column=2, padx=20, pady=5)

    self.close_button = ttk.Button(self.config_frame, text='Close', command=self.destroy)
    self.close_button.grid(row=2, column=3, padx=20, pady=5)

    # -------------
    # | File Data |
    # -------------
    self.leftFile = tk.StringVar(value=left_file)
    self.rightFile = tk.StringVar(value=right_file)
    self.leftFile.trace_add('write', lambda *x:self.filesChanged())
    self.rightFile.trace_add('write', lambda *x:self.filesChanged())

    # ---------------------------
    # | File Comboboxes/Entries |
    # ---------------------------
    self.leftFileEntry = ttk.Combobox(self, textvariable=self.leftFile, postcommand=lambda:[self.load_file('left'), self.after(1, lambda: self.leftFileEntry.event_generate('<Escape>'))])
    if not minimum: self.leftFileEntry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
    self.rightFileEntry = ttk.Combobox(self, textvariable=self.rightFile, postcommand=lambda:[self.load_file('right'), self.after(1, lambda: self.rightFileEntry.event_generate('<Escape>'))])
    if not minimum: self.rightFileEntry.grid(row=1, column=3, padx=5, pady=5, sticky=tk.EW)

    # --------------
    # | Text Areas |
    # --------------
    self.leftFileTextArea = tk.Text(self, padx=5, pady=5, width=1, height=1) #, bg=self.grayColor)
    self.leftFileTextArea.grid(row=2, column=1, sticky=tk.NSEW)
    # self.leftFileTextArea.config(wrap='none')

    self.rightFileTextArea = tk.Text(self, padx=5, pady=5, width=1, height=1) #, bg=self.grayColor)
    self.rightFileTextArea.grid(row=2, column=3, sticky=tk.NSEW)
    # self.rightFileTextArea.config(wrap='none')

    # configuring highlight tags
    self.leftFileTextArea.tag_configure('red', background=self.redColor, foreground="#000000")
    self.leftFileTextArea.tag_configure('darkred', background=self.darkredColor, foreground="#000000")
    self.leftFileTextArea.tag_configure('gray', background=self.grayColor, foreground="#000000")
    self.rightFileTextArea.tag_configure('green', background=self.greenColor, foreground="#000000")
    self.rightFileTextArea.tag_configure('darkgreen', background=self.darkgreenColor, foreground="#000000")
    self.rightFileTextArea.tag_configure('gray', background=self.grayColor, foreground="#000000")
    self.leftFileTextArea.tag_raise("sel")
    self.rightFileTextArea.tag_raise("sel")

    # disable the text areas
    self.leftFileTextArea.config(state=tk.DISABLED)
    self.rightFileTextArea.config(state=tk.DISABLED)

    # ---------------------
    # | Text Line Numbers |
    # ---------------------
    # self.leftLinenumbers = tk.Text(self, width=3, padx=5, pady=5, height=1) #, bg=self.lightGrayColor)
    # self.leftLinenumbers.tag_configure('line', justify='right')
    self.leftLinenumbers = TextLineNumbers(self, width=30)
    self.leftLinenumbers.attach(self.leftFileTextArea)
    self.leftLinenumbers.grid(row=2, column=0, sticky=tk.NS)
    self.leftFileTextArea.bind("<<Modified>>", lambda e: self.leftLinenumbers.redraw()) # <<Change>>
    self.leftFileTextArea.bind("<Configure>", lambda e: self.leftLinenumbers.redraw())

    # self.rightLinenumbers = tk.Text(self, width=3, padx=5, pady=5, height=1) #, bg=self.lightGrayColor)
    # self.rightLinenumbers.tag_configure('line', justify='right')
    self.rightLinenumbers = TextLineNumbers(self, width=30)
    self.rightLinenumbers.attach(self.rightFileTextArea)
    self.rightLinenumbers.grid(row=2, column=2, sticky=tk.NS)
    self.rightFileTextArea.bind("<<Modified>>", lambda e: self.rightLinenumbers.redraw()) # <<Change>>
    self.rightFileTextArea.bind("<Configure>", lambda e: self.rightLinenumbers.redraw())

    self.TitleLabel.attach_line_numbers(self.leftLinenumbers, self.rightLinenumbers)

    # disable the line numbers
    # self.leftLinenumbers.config(state=tk.DISABLED)
    # self.rightLinenumbers.config(state=tk.DISABLED)

    # --------------
    # | Scrollbars |
    # --------------
    self.uniScrollbar = ttk.Scrollbar(self)
    self.uniScrollbar.grid(row=2, column=4, sticky=tk.NS)
    self.uniScrollbar.config(command=self.scrollBoth)
    # self.leftFileTextArea.config(yscrollcommand=self.updateScroll)
    self.leftFileTextArea.bind('<MouseWheel>', self.updateBindScroll)
    # self.rightFileTextArea.config(yscrollcommand=self.updateScroll)
    self.rightFileTextArea.bind('<MouseWheel>', self.updateBindScroll)
    self.bind_all("<MouseWheel>", self.updateBindScroll)
    # self.leftLinenumbers.config(yscrollcommand=self.updateScroll)
    # self.rightLinenumbers.config(yscrollcommand=self.updateScroll)

    leftHorizontalScrollbar = ttk.Scrollbar(self, orient=tk.HORIZONTAL)
    leftHorizontalScrollbar.grid(row=3, column=1, sticky=tk.EW)
    leftHorizontalScrollbar.config(command=self.leftFileTextArea.xview)
    self.leftFileTextArea.config(xscrollcommand=leftHorizontalScrollbar.set)

    rightHorizontalScrollbar = ttk.Scrollbar(self, orient=tk.HORIZONTAL)
    rightHorizontalScrollbar.grid(row=3, column=3, sticky=tk.EW)
    rightHorizontalScrollbar.config(command=self.rightFileTextArea.xview)
    self.rightFileTextArea.config(xscrollcommand=rightHorizontalScrollbar.set)

    self.uniScrollbar.set(*self.leftFileTextArea.yview())

  def next_change(self):
    if not self.change_list: return
    self.current_change = (self.current_change + 1) if not ((self.current_change + 1) >= len(self.change_list)) else 0
    self.move_to_change()
    self.changes_var.set(F'{self.current_change + 1 if self.current_change > 0 else 1} of {len(self.change_list)} Differences')

  def previous_change(self):
    if not self.change_list: return
    lin_num = self.leftFileTextArea.index("@0,0 linestart")
    if self.change_list[self.current_change] >= float(lin_num):
      self.current_change = (self.current_change - 1) if not ((self.current_change - 1) < 0) else len(self.change_list) - 1
    self.move_to_change()
    self.changes_var.set(F'{self.current_change + 1 if self.current_change > 0 else 1} of {len(self.change_list)} Differences')

  def set_previous_change(self, line_num=None):
    if not self.change_list: return
    if not line_num:
      self.current_change = -1
    else:
      self.current_change = next(i for i, x in enumerate(self.change_list) if x >= line_num)-1
    self.changes_var.set(F'{self.current_change + 1 if self.current_change > 0 else 1} of {len(self.change_list)} Differences')

  def move_to_change(self):
    # self.leftFileTextArea.see(tk.END)
    # self.rightFileTextArea.see(tk.END)

    text_line = F"{self.change_list[self.current_change] if self.change_list else '1'}.0"
    bd = int(self.leftFileTextArea.cget("borderwidth")) # should be same for both

    self.leftFileTextArea.see(text_line)
    lineinfo=self.leftFileTextArea.dlineinfo(text_line)
    self.leftFileTextArea.yview_scroll(lineinfo[1] - bd - 2, 'pixels' )
    # print('LEFTCHANGE:', text_line, bd, lineinfo)

    self.rightFileTextArea.see(text_line)
    lineinfo=self.rightFileTextArea.dlineinfo(text_line)
    self.rightFileTextArea.yview_scroll(lineinfo[1] - bd - 2, 'pixels' )
    # print('RIGHTCHANGE:', text_line, bd, lineinfo)

    self.leftLinenumbers.redraw()
    self.rightLinenumbers.redraw()
    # print("CHANGE:", self.current_change, self.change_list[self.current_change] if self.change_list else 1)

  def filesChanged(self):
    # self.leftLinenumbers.grid_remove()
    # self.rightLinenumbers.grid_remove()
    if self.leftFile.get() == None or self.rightFile.get() == None:
      # self.leftFileTextArea.config(background=self.grayColor)
      # self.rightFileTextArea.config(background=self.grayColor)
      return
    if not Path(self.leftFile.get()).is_file() or not Path(self.rightFile.get()).is_file():
      return
    # self.leftFileLabel.config(text=self.leftFile.get())
    # self.rightFileLabel.config(text=self.rightFile.get())
    # self.leftFileTextArea.config(background=self.whiteColor)
    # self.rightFileTextArea.config(background=self.whiteColor)
    # self.leftLinenumbers.grid()
    # self.rightLinenumbers.grid()
    self.diff_files_into_text_areas()

  def diff_files_into_text_areas(self, leftFileContents=None, rightFileContents=None):
    if not leftFileContents: leftFileContents = open(self.leftFile.get()).read()
    if not rightFileContents: rightFileContents = open(self.rightFile.get()).read()

    diff = DifflibParser(leftFileContents.splitlines(), rightFileContents.splitlines())

    # enable text area edits so we can clear and insert into them
    self.leftFileTextArea.config(state=tk.NORMAL)
    self.rightFileTextArea.config(state=tk.NORMAL)
    # self.leftLinenumbers.config(state=tk.NORMAL)
    # self.rightLinenumbers.config(state=tk.NORMAL)
    # self.leftFileTextArea.unbind("<<Change>>")
    # self.leftFileTextArea.unbind("<Configure>")
    # self.rightFileTextArea.unbind("<<Change>>")
    # self.rightFileTextArea.unbind("<Configure>")
    self.leftFileTextArea.pause_change = True
    self.rightFileTextArea.pause_change = True

    # clear all text areas
    self.leftFileTextArea.delete(1.0, tk.END)
    self.rightFileTextArea.delete(1.0, tk.END)
    # self.leftLinenumbers.delete(1.0, tk.END)
    # self.rightLinenumbers.delete(1.0, tk.END)

    self.change_list = []
    self.current_change = -1

    for lineno, line in enumerate(diff, 1):
      if line['code'] == DiffCode.SIMILAR:
        self.leftFileTextArea.insert('end', line['line'] + '\n')
        self.rightFileTextArea.insert('end', line['line'] + '\n')
      elif line['code'] == DiffCode.RIGHTONLY:
        self.leftFileTextArea.insert('end', '\n', 'gray')
        self.rightFileTextArea.insert('end', line['line'] + '\n', 'green')
        self.change_list.append(lineno)
      elif line['code'] == DiffCode.LEFTONLY:
        self.leftFileTextArea.insert('end', line['line'] + '\n', 'red')
        self.rightFileTextArea.insert('end', '\n', 'gray')
        self.change_list.append(lineno)
      elif line['code'] == DiffCode.CHANGED:
        for (i,c) in enumerate(line['line']):
          self.leftFileTextArea.insert('end', c, 'darkred' if i in line['leftchanges'] else 'red')
        for (i,c) in enumerate(line['newline']):
          self.rightFileTextArea.insert('end', c, 'darkgreen' if i in line['rightchanges'] else 'green')
        self.leftFileTextArea.insert('end', '\n')
        self.rightFileTextArea.insert('end', '\n')
        self.change_list.append(lineno)
      # self.leftLinenumbers.insert('end', str(lineno) + '\n', 'line')
      # self.rightLinenumbers.insert('end', str(lineno) + '\n', 'line')
        
    self.changes_var.set(F'1 of {len(self.change_list)} Differences')

    # calc width of line numbers texts and set it
    width = len(str(lineno))
    self.leftLinenumbers.config(width=width*8)
    self.rightLinenumbers.config(width=width*8)

    # disable text areas to prevent further editing
    self.leftFileTextArea.config(state=tk.DISABLED)
    self.rightFileTextArea.config(state=tk.DISABLED)
    # self.leftLinenumbers.config(state=tk.DISABLED)
    # self.rightLinenumbers.config(state=tk.DISABLED)

    # self.leftLinenumbers.redraw()
    # self.rightLinenumbers.redraw()

    # self.leftFileTextArea.bind("<<Change>>", lambda e: self.leftLinenumbers.redraw())
    # self.leftFileTextArea.bind("<Configure>", lambda e: self.leftLinenumbers.redraw())
    # self.rightFileTextArea.bind("<<Change>>", lambda e: self.rightLinenumbers.redraw())
    # self.rightFileTextArea.bind("<Configure>", lambda e: self.rightLinenumbers.redraw())
    self.leftFileTextArea.pause_change = False
    self.rightFileTextArea.pause_change = False

  def scrollBoth(self, action, position, type=None):
    # print(action, position, type)
    if action == 'moveto':
      self.leftFileTextArea.yview_moveto(position)
      self.sync_left()
      # self.rightFileTextArea.yview_moveto(position)
      self.sync_right_to_left()
    elif action == 'scroll':
      # h = self.rightFileTextArea.winfo_height()
      self.leftFileTextArea.yview_scroll(position, type)
      self.sync_left()
      # self.rightFileTextArea.yview_scroll(position, type)
      self.sync_right_to_left()
    # self.leftLinenumbers.yview_moveto(position)
    # self.rightLinenumbers.yview_moveto(position)
    self.uniScrollbar.set(*self.leftFileTextArea.yview())

  def updateBindScroll(self, event):
    # print(event.widget)
    # print(event.delta)
    up_down = event.delta // -120 # get + or - 1 (2 or 3 possibly) 
    # self.leftFileTextArea.yview_scroll(up_down, "pages")
    idx = self.leftFileTextArea.index("@0,0 linestart")
    new_idx = float(idx) + up_down
    self.sync_left(new_idx)
    self.sync_right_to_left(new_idx)
    # print("BINDSCROLL:", event.delta, idx, new_idx, self.leftFileTextArea.yview())
    self.uniScrollbar.set(*self.leftFileTextArea.yview())
    return 'break' # will still scroll if nothing returned.

  def updateScroll(self, first, last, type=None):
    # print(first, last, type)
    # print(self.leftFileTextArea.yview())
    self.leftFileTextArea.yview_moveto(first)
    self.sync_left()
    self.sync_right_to_left()
    self.uniScrollbar.set(*self.leftFileTextArea.yview())

  def sync_left(self, idx=None):
    idx = idx or self.leftFileTextArea.index("@0,0 linestart")
    self.set_previous_change(float(idx))
    bd = int(self.leftFileTextArea.cget("borderwidth")) # should be same for both
    self.leftFileTextArea.see(idx)
    lineinfo=self.leftFileTextArea.dlineinfo(idx)
    # print('LEFT:', idx, bd, lineinfo)
    # print('LEFTYVIEWBEFORE:', self.leftFileTextArea.yview())
    if lineinfo: self.leftFileTextArea.yview_scroll(lineinfo[1] - bd - 2, 'pixels' )
    # print('LEFTYVIEWBEFORE:', self.leftFileTextArea.yview())
    self.leftLinenumbers.redraw()

  def sync_right_to_left(self, idx=None):
    idx = idx or self.leftFileTextArea.index("@0,0 linestart")
    bd = int(self.rightFileTextArea.cget("borderwidth")) # should be same for both
    self.rightFileTextArea.see('1.0')
    self.rightFileTextArea.see(idx)
    lineinfo=self.rightFileTextArea.dlineinfo(idx)
    # print('RIGHT:', idx, bd, lineinfo)
    # print('RIGHTYVIEWBEFORE:', self.rightFileTextArea.yview())
    if lineinfo: self.rightFileTextArea.yview_scroll(lineinfo[1] - bd - 2, 'pixels' )
    # print('RIGHTYVIEWAFTER:', self.rightFileTextArea.yview())
    self.rightLinenumbers.redraw()

  def load_file(self, pos):
        fname = filedialog.askopenfilename()
        if fname:
            if pos == 'left':
                self.leftFile.set(fname)
            else:
                self.rightFile.set(fname)
            return fname
        else:
            return None

if __name__ == "__main__":
  root = tk.Tk()
  root.title("File Diff")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()