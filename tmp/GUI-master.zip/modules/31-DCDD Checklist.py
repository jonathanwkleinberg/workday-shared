import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import sys
import threading
import webbrowser
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import CheckboxTreeview, SmartsheetLib, Smartsheet_Picker, StyledHovertip
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import CheckboxTreeview, SmartsheetLib, Smartsheet_Picker, StyledHovertip

template_sheet_id = 2246540011038596  # DO NOT CHANGE THIS - SOURCE CHECKLIST TEMPLATE in DTOE Workspace
tracking_sheet_id = 6535507065759620  # DO NOT CHANGE THIS - DCDD TRACKING SHEET
dcdds_folder_id = 8393978237216644    # DO NOT CHANGE THIS - DCDDs Folder ID # /_DTOE/_DCDDs ; Workspaces > _DTOE > _DCDDs
tracking_column_name = 'DCDD'         # DO NOT CHANGE THIS - Column name of the DCDD Name List
category_column_names = ['category', 'workstream']

class App(ttk.Frame):

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(0, weight=1)
    self.columnconfigure(1, weight=2)
    self.rowconfigure(7, weight=1)

    # Label
    self.label = ttk.Label(self, text="DCDD Project Checklist Creator", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, padx=10, pady=10, sticky=tk.NW)

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=1, column=0, padx=(0,5), pady=5, sticky=tk.NW)

    # Workspace Name
    self.workspaces = []
    self.workspace_name = tk.StringVar(value='Workspace Name')
    self.workspace_name.trace_add('write', lambda *e: [self.workspace_name.set((self.workspace_name.get() or '')[:33]) if len(self.workspace_name.get() or '') > 33 else None])
    self.workspace_name_label = ttk.Label(self.config_frame, text="Name: DCDD Checklist -")
    self.workspace_name_label.grid(row=0, column=0, padx=(5,0), pady=5)
    self.workspace_name_entry = ttk.Combobox(self.config_frame, textvariable=self.workspace_name, values=self.workspaces)
    self.workspace_name_entry.grid(row=0, column=1, padx=(0, 5), pady=5, sticky=tk.NW)
    checklist_help_text = ' -- The name of the new checklist sheet will be \n    "DCDD Checklist - [entered text or workspace name]"\n    (if not using an existing checklist sheet) -- '
    StyledHovertip(self.workspace_name_label, checklist_help_text)
    StyledHovertip(self.workspace_name_entry, checklist_help_text)

    self.ws_refresh_button = ttk.Button(self.config_frame, text="↻", width=2, command=lambda:[self.background(self.get_workspaces)])
    self.ws_refresh_button.grid(row=0, column=2, padx=2, pady=5, sticky=tk.NSEW)

    if self.root.vars.get('ss_token') and self.root.vars['ss_token'].get():
      self.background(self.get_workspaces)

    # Config Frame 3
    self.config_frame3 = ttk.Frame(self)
    self.config_frame3.grid(row=2, column=0, padx=(0,5), pady=5, sticky=tk.NW)

    # Project DCDD Folder ID
    self.dcdd_folder_id = tk.StringVar()
    self.dcdd_folder_id_label = ttk.Label(self.config_frame3, text="Project's DCDD Folder ID: ")
    self.dcdd_folder_id_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
    # self.dcdd_folder_id_entry = ttk.Entry(self.config_frame3, textvariable=self.dcdd_folder_id)
    self.dcdd_folder_id_entry = ttk.Combobox(self.config_frame3, textvariable=self.dcdd_folder_id, postcommand=lambda:self.pick_smartsheet_folder(self.dcdd_folder_id_entry))
    self.dcdd_folder_id_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
    dcdd_help_text = ' -- This folder should contain sub folders of workstreams /\n    functional areas (HCM, Payroll, etc.) with their related DCDDs.\n    The folder itself should not contain the DCDD sheets! -- '
    StyledHovertip(self.dcdd_folder_id_label, dcdd_help_text)
    StyledHovertip(self.dcdd_folder_id_entry, dcdd_help_text)
    self.dcdd_folder_id_url = tk.StringVar()
    self.dcdd_folder_id_url_label = ttk.Label(self.config_frame3, cursor="hand1", style="Link.TLabel")
    self.dcdd_folder_id_url_label.grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
    self.dcdd_folder_id_url_tip = StyledHovertip(self.dcdd_folder_id_url_label, text=self.dcdd_folder_id_url.get())
    self.dcdd_folder_id_url_label.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", lambda event:[ 
      self.copy_open_menu(event, self.dcdd_folder_id_url.get())
    ] )
    self.dcdd_folder_id_url_label.bind("<ButtonRelease-1>", lambda event:[
      webbrowser.open_new_tab(self.dcdd_folder_id_url.get()) if self.dcdd_folder_id_url.get() else None
    ] )
    self.dcdd_folder_id.trace_add('write', lambda *e: [
      self.dcdd_folder_id_url_label.config(text=''),
      self.background(self.get_folder_url_from_id, (self.dcdd_folder_id_url_label, self.dcdd_folder_id_url, self.dcdd_folder_id_url_tip, self.dcdd_folder_id.get())),
    ])

    # Config Frame 4
    self.config_frame4 = ttk.Frame(self)
    self.config_frame4.grid(row=3, column=0, padx=(0,5), pady=5, sticky=tk.NW)

    # Existing Checklist ID
    self.existing_checklist_id = tk.StringVar()
    self.existing_checklist_id_label = ttk.Label(self.config_frame4, text="OPTIONAL - Existing Target Checklist ID: ")
    self.existing_checklist_id_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
    self.existing_checklist_id_entry = ttk.Combobox(self.config_frame4, textvariable=self.existing_checklist_id, postcommand=lambda:self.pick_smartsheet_sheet(self.existing_checklist_id_entry))
    self.existing_checklist_id_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
    existing_help_text = ' -- If left blank, a new checklist will be created in the DCDD folder above -- '
    StyledHovertip(self.existing_checklist_id_label, existing_help_text)
    StyledHovertip(self.existing_checklist_id_entry, existing_help_text)
    self.existing_checklist_id_url = tk.StringVar()
    self.existing_checklist_id_url_label = ttk.Label(self.config_frame4, cursor="hand1", style="Link.TLabel")
    self.existing_checklist_id_url_label.grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
    self.existing_checklist_id_url_tip = StyledHovertip(self.existing_checklist_id_url_label, text=self.existing_checklist_id_url.get())
    self.existing_checklist_id_url_label.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", lambda event:[
      self.copy_open_menu(event, self.existing_checklist_id_url.get())
    ] )
    self.existing_checklist_id_url_label.bind("<ButtonRelease-1>", lambda event:[
      webbrowser.open_new_tab(self.existing_checklist_id_url.get()) if self.existing_checklist_id_url.get() else None
    ] )
    self.existing_checklist_id.trace_add('write', lambda *e: [
      self.existing_checklist_id_url_label.config(text=''),
      self.background(self.get_sheet_url_from_id, (self.existing_checklist_id_url_label, self.existing_checklist_id_url, self.existing_checklist_id_url_tip, self.existing_checklist_id.get())),
    ])

    # Config Frame 2
    self.config_frame2 = ttk.Frame(self)
    self.config_frame2.grid(row=4, column=0, padx=(0,5), pady=5, sticky=tk.NW)

    # Category Filter
    self.categories = []
    self.cat_filter = tk.StringVar()
    self.cat_filter_label = ttk.Label(self.config_frame2, text="Category Filter:")
    self.cat_filter_label.grid(row=0, column=0, padx=5, pady=5)
    self.cat_filter_entry = ttk.Combobox(self.config_frame2, textvariable=self.cat_filter)
    self.cat_filter_entry.grid(row=0, column=1, padx=5, pady=5)
    help_text = ' -- Choose a single value from the picklist or enter your own - case insensitive and partial word matching -- '
    StyledHovertip(self.cat_filter_label, help_text)
    StyledHovertip(self.cat_filter_entry, help_text)

    if self.root.vars.get('ss_token') and self.root.vars['ss_token'].get():
      self.background(self.get_categories)

    self.cat_refresh_button = ttk.Button(self.config_frame2, text="↻", width=2, command=lambda:[self.background(self.get_categories)])
    self.cat_refresh_button.grid(row=0, column=2, padx=2, pady=5, sticky=tk.NW)
    StyledHovertip(self.cat_refresh_button, 'Refresh from Smartsheet Tracking Sheet')

    self.switch = ttk.Checkbutton(self, text="Remove Duplicate and Unmatched Category Rows", style="Switch.TCheckbutton")
    self.switch.grid(row=5, column=0, padx=5, pady=(5,15), sticky=tk.NW)
    self.switch.state(['selected'])

    self.create_checklist_button = ttk.Button(self, text='Create Checklist', command=lambda:[self.background(self.create_checklist)])
    self.create_checklist_button.grid(row=6, column=0, padx=5, pady=5, sticky=tk.NW)

    # Add a tabbed notebook
    self.notebook = ttk.Notebook(self)
    self.notebook.grid(row=1, column=1, rowspan=6, padx=5, pady=5, sticky=tk.NSEW)

    # Add a tab for the Help
    self.tab1 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab1, text="Expected Folder/Sheet Layout")

    # Help Label
    help_label = ttk.Label(self.tab1, justify="left", text="""Customer ABC (Workspace Folder / Name):
    ↳ Build or Data Conversion Area / Folder
        ↳ DCDDs (Project DCDD Folder):
            ↳ HCM (Workstream / Functional Area Folder):
                ↳ Add_Additional_Job_DCDD (DCDD Sheet)
                ↳ ...
            ↳ Payroll (Workstream / Functional Area Folder):
                ↳ AddUpdate_Employee_Pay_Group_Assignment_DCDD (DCDD Sheet)
                ↳ ...
            ↳ DCDD Checklist - Customer ABC (New or Existing Checklist Sheet)               
""")
    help_label.grid(row=0, column=0, padx=10, pady=10, sticky=tk.NW)
    # help_label.grid(row=1, column=1, rowspan=4, padx=10, pady=10, sticky=tk.NW)

    # Add an advanced settings tab
    self.tab2 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab2, text="Advanced Settings")

    advanced_tab_row = 0

    # Label Warning
    self.warning_label = ttk.Label(self.tab2, text="WARNING: Only change these settings if you know what you are doing!", style="Warning.TLabel")
    self.warning_label.grid(row=advanced_tab_row, column=0, columnspan=3, padx=5, pady=5, sticky=tk.W)
    
    advanced_tab_row += 1

    # SS Picker ComboBox for Smartsheet template sheet ID
    self.template_sheet_id = tk.StringVar()
    self.template_sheet_id_label = ttk.Label(self.tab2, text="Template Sheet ID:")
    self.template_sheet_id_label.grid(row=advanced_tab_row, column=0, padx=5, pady=5, sticky=tk.W)
    self.template_sheet_id_entry = ttk.Combobox(self.tab2, textvariable=self.template_sheet_id, postcommand=lambda:self.pick_smartsheet_sheet(self.template_sheet_id_entry)) # ttk.Entry(self.tab2, textvariable=self.template_sheet_id)
    self.template_sheet_id_entry.grid(row=advanced_tab_row, column=1, padx=5, pady=5, sticky=tk.W)
    self.template_sheet_id_url = tk.StringVar()
    self.template_sheet_id_url_label = ttk.Label(self.tab2, cursor="hand1", style="Link.TLabel")
    self.template_sheet_id_url_label.grid(row=advanced_tab_row, column=2, padx=5, pady=5, sticky=tk.W)
    self.template_sheet_id_url_tip = StyledHovertip(self.template_sheet_id_url_label, text=self.template_sheet_id_url.get())
    self.template_sheet_id_url_label.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", lambda event:[
      self.copy_open_menu(event, self.template_sheet_id_url.get())
    ] )
    self.template_sheet_id_url_label.bind("<ButtonRelease-1>", lambda event:[
      webbrowser.open_new_tab(self.template_sheet_id_url.get()) if self.template_sheet_id_url.get() else None
    ] )
    self.template_sheet_id.trace_add('write', lambda *e: [
      self.template_sheet_id_url_label.config(text=''),
      self.background(self.get_sheet_url_from_id, (self.template_sheet_id_url_label, self.template_sheet_id_url, self.template_sheet_id_url_tip, self.template_sheet_id.get())),
    ])
    self.template_sheet_id.set(template_sheet_id)

    advanced_tab_row += 1
    
    # Entry for Smartsheet tracking sheet ID
    self.tracking_sheet_id = tk.StringVar()
    self.tracking_sheet_id_label = ttk.Label(self.tab2, text="Tracking Sheet ID:")
    self.tracking_sheet_id_label.grid(row=advanced_tab_row, column=0, padx=5, pady=5, sticky=tk.W)
    self.tracking_sheet_id_entry = ttk.Combobox(self.tab2, textvariable=self.tracking_sheet_id, postcommand=lambda:self.pick_smartsheet_sheet(self.tracking_sheet_id_entry)) # ttk.Entry(self.tab2, textvariable=self.tracking_sheet_id)
    self.tracking_sheet_id_entry.grid(row=advanced_tab_row, column=1, padx=5, pady=5, sticky=tk.W)
    self.tracking_sheet_id_url = tk.StringVar()
    self.tracking_sheet_id_url_label = ttk.Label(self.tab2, cursor="hand1", style="Link.TLabel")
    self.tracking_sheet_id_url_label.grid(row=advanced_tab_row, column=2, padx=5, pady=5, sticky=tk.W)
    self.tracking_sheet_id_url_tip = StyledHovertip(self.tracking_sheet_id_url_label, text=self.tracking_sheet_id_url.get())
    self.tracking_sheet_id_url_label.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", lambda event:[
      self.copy_open_menu(event, self.tracking_sheet_id_url.get())
    ] )
    self.tracking_sheet_id_url_label.bind("<ButtonRelease-1>", lambda event:[
      webbrowser.open_new_tab(self.tracking_sheet_id_url.get()) if self.tracking_sheet_id_url.get() else None
    ] )
    self.tracking_sheet_id.trace_add('write', lambda *e: [
      self.tracking_sheet_id_url_label.config(text=''),
      self.background(self.get_sheet_url_from_id, (self.tracking_sheet_id_url_label, self.tracking_sheet_id_url, self.tracking_sheet_id_url_tip, self.tracking_sheet_id.get())),
    ])
    self.tracking_sheet_id.set(tracking_sheet_id)

    advanced_tab_row += 1

    # Entry for Smartsheet DCDDs folder ID
    self.dcdds_folder_id = tk.StringVar()
    self.dcdds_folder_id_label = ttk.Label(self.tab2, text="DCDDs Folder ID:")
    self.dcdds_folder_id_label.grid(row=advanced_tab_row, column=0, padx=5, pady=5, sticky=tk.W)
    self.dcdds_folder_id_entry = ttk.Combobox(self.tab2, textvariable=self.dcdds_folder_id, postcommand=lambda:self.pick_smartsheet_folder(self.dcdds_folder_id_entry)) # ttk.Entry(self.tab2, textvariable=self.dcdds_folder_id)
    self.dcdds_folder_id_entry.grid(row=advanced_tab_row, column=1, padx=5, pady=5, sticky=tk.W)
    self.dcdds_folder_id_url = tk.StringVar()
    self.dcdds_folder_id_url_label = ttk.Label(self.tab2, cursor="hand1", style="Link.TLabel")
    self.dcdds_folder_id_url_label.grid(row=advanced_tab_row, column=2, padx=5, pady=5, sticky=tk.W)
    self.dcdds_folder_id_url_tip = StyledHovertip(self.dcdds_folder_id_url_label, text=self.dcdds_folder_id_url.get())
    self.dcdds_folder_id_url_label.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", lambda event:[
      self.copy_open_menu(event, self.dcdds_folder_id_url.get())
    ] )
    self.dcdds_folder_id_url_label.bind("<ButtonRelease-1>", lambda event:[
      webbrowser.open_new_tab(self.dcdds_folder_id_url.get()) if self.dcdds_folder_id_url.get() else None
    ] )
    self.dcdds_folder_id.trace_add('write', lambda *e: [
      self.dcdds_folder_id_url_label.config(text=''),
      self.background(self.get_folder_url_from_id, (self.dcdds_folder_id_url_label, self.dcdds_folder_id_url, self.dcdds_folder_id_url_tip, self.dcdds_folder_id.get())),
    ])
    self.dcdds_folder_id.set(dcdds_folder_id)

    # ----------------------

    self.text_log = ttk.LabelFrame(self, text="Log", style="Bold.TLabelframe")
    self.text_log.grid(row=7, column=0, columnspan=2, padx=5, pady=(5,0), sticky=tk.NSEW)
    self.text_log.columnconfigure(0, weight=1)
    self.text_log.rowconfigure(0, weight=1)
    self.textbox = tk.Text(self.text_log, height=3, wrap="word", state="disabled", relief='flat') # width=50, 
    self.textbox.grid(column=0, row=0, sticky=tk.NSEW, padx=5, pady=5)
    self.text_scroll = tk.ttk.Scrollbar(self, command=self.textbox.yview)
    self.text_scroll.grid(row=7, column=99, pady=(12,5), sticky=tk.NSEW)
    self.textbox['yscrollcommand'] = self.text_scroll.set
    self.textbox.tag_configure("stderr", foreground="#b22222")
    self.textbox.tag_configure("messages", foreground="#22b222")
    self.textbox.bind("<1>", lambda event: self.textbox.focus_set())

    # self.write('this', 'is', 'a', 'test')
    # print('this', 'is', 'a', 'test')


  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()

  def write(self, *args, tag=None, end='\n'):
    string = ' '.join([str(x) for x in args]) + end
    widget = self.textbox
    widget.configure(state=tk.NORMAL)
    move = widget.yview()[1] >= 1
    widget.insert(tk.END, string, "stdout" if not tag else tag)
    if move: widget.see(tk.END)
    # if int(float(widget.index(tk.END))) > 1000:
    #   widget.delete( 1.0, float(int(float(widget.index(tk.END))) - 1000)  )
    widget.configure(state=tk.DISABLED)

  def get_workspaces(self):
    workspaces = []
    if self.root.vars.get('ss_token') and self.root.vars['ss_token'].get():
      try:
        ss = SmartsheetLib(self.root.vars['ss_token'].get())
        workspaces = [x.name.replace("_", " ").strip() for x in ss.client.Workspaces.list_workspaces(include_all=True).data if not x.name.startswith('_')]
        # print('Workspaces:', workspaces)
      except Exception as e: 
        self.write(e)
    else:
      messagebox.showerror("Error", "Missing the Smartsheet Token!")
    self.workspaces = workspaces
    self.workspace_name_entry.config(values=workspaces)

  def get_categories(self):
    categories = []
    if self.root.vars.get('ss_token') and self.root.vars['ss_token'].get():
      try:
        ss = SmartsheetLib(self.root.vars['ss_token'].get())
        ss.get_tracking_sheet(self.tracking_sheet_id.get() or tracking_sheet_id)
        categories = list(set(c for r in ss.tracking_sheet_rows if r[ss.tracking_sheet_column_names['CAT_COL']] for c in r[ss.tracking_sheet_column_names['CAT_COL']].split(', ')))
        categories.sort()
        categories.insert(0, 'Everything')
        categories.insert(0,'')
        # self.write('Categories:', categories)
      except Exception as e: 
        self.write(e)
    else:
      messagebox.showerror("Error", "Missing the Smartsheet Token!")
    self.categories = categories
    self.cat_filter_entry.config(values=categories)

  def get_folder_url_from_id(self, label_widget, url_widget, tip_widget, id):
    tip_widget.text = ''
    if not id:
      return
    try:
      ss = SmartsheetLib(self.root.vars.get('ss_token').get())
      ss.client.errors_as_exceptions()
      folder = ss.client.Folders.get_folder(id)
      if not hasattr(folder, 'permalink'):
        return
      url_widget.set(folder.permalink)
      label_widget.config(text='Link to Folder')
      tip_widget.text = folder.permalink 
    except Exception as e:
      # messagebox.showerror("Error", F"An error occurred while retrieving the folder URL:\n{e}")
      return
    
  def get_sheet_url_from_id(self, label_widget, url_widget, tip_widget, id):
    tip_widget.text = ''
    if not id:
      return
    try:
      ss = SmartsheetLib(self.root.vars.get('ss_token').get())
      ss.client.errors_as_exceptions()
      sheet = ss.client.Sheets.get_sheet(id)
      if not hasattr(sheet, 'permalink'):
        return
      url_widget.set(sheet.permalink)
      label_widget.config(text='Link to Sheet')
      tip_widget.text = sheet.permalink 
    except Exception as e:
      # messagebox.showerror("Error", F"An error occurred while retrieving the sheet URL:\n{e}")
      return

  def copy_open_menu(self, event, url):
    if not url:
      return
    widget = event.widget
    menu = tk.Menu(widget)
    menu.add_command(label=F"Open Link", command=lambda:[webbrowser.open_new_tab(url)])
    menu.add_command(label=F"Copy Link", command=lambda:[
      widget.clipboard_clear(), 
      widget.clipboard_append(url)
    ])
    menu.post(event.x_root, event.y_root)

  def create_checklist(self):
    if not self.root.vars.get('ss_token') or not self.root.vars['ss_token'].get():
      messagebox.showerror("Error", "Missing the Smartsheet Token!")
      return
    ss = SmartsheetLib(self.root.vars['ss_token'].get())
    smartsheet = ss_client = ss.client
    ss_client.errors_as_exceptions()
    if not self.dcdd_folder_id.get():
      messagebox.showerror("Error", "Missing the DCDD Folder ID!")
      return
    dcdd_folder_id = int(self.dcdd_folder_id.get())

    # Disable the button
    self.create_checklist_button.config(state='disabled')

    self.write("Creating Checklist...")

    new_name = F"DCDD Checklist - {self.workspace_name.get() or ''}"
    category_picklist_item = self.cat_filter.get()

    # Global try block to catch any SS exceptions
    try:
    
      # get list of subfolders
      self.write(F"Getting DCDDs in project folder ...")
      folders = ss_client.Folders.list_folders(dcdd_folder_id).data
      full_file_list = []  # Initialize an empty list to store the file information
      # Iterate through each subfolder
      for folder in folders:
          if not folder.name.startswith("_"):      # only go into folders that don't have an underscore!
              subfolder = ss_client.Folders.get_folder(folder.id)
              # Iterate through each file
              for file in subfolder._sheets:
                  if "DCDD" in file.name.upper(): 
                      # self.write("Capturing DCDD Name:", file.name, "and workstream", subfolder.name)
                      full_file_list.append({'Workstream': subfolder.name, 'File Name': file.name, 'Hyperlink': file.permalink, 'SheetID': file.id})

      self.write(F""" -- {[F'{x["Workstream"]}: {x["File Name"]}' for x in full_file_list]} -- """)

      # copy sheet as a template to the target folder, if there are DCDDs
      if len(full_file_list) > 0:
          try:
            if self.existing_checklist_id.get():
              self.write(F'Using existing checklist sheet: "{self.existing_checklist_id.get()}" ...')
              new_full_sheet_id = self.existing_checklist_id.get()
            else:
              self.write(F'Creating new checklist sheet: "{new_name}" ...')
              new_full_sheet = ss_client.Sheets.copy_sheet(
                  self.template_sheet_id.get() or template_sheet_id,
                  ss_client.models.ContainerDestination({
                  "destination_type": "folder",
                  "destination_id": dcdd_folder_id,
                  "new_name": new_name}),
                  include=["attachments", "format", "filters"]
              )
              new_full_sheet_id = new_full_sheet.result.id
              self.existing_checklist_id.set(new_full_sheet_id)
          
            new_full_sheet = ss_client.Sheets.get_sheet(int(new_full_sheet_id)) # retrieve the existing or newly created sheet
            
            # self.existing_checklist_id_url.set(new_full_sheet.permalink)
          except Exception as e:
            messagebox.showerror("Error", F'Failed to {"get existing" if self.existing_checklist_id.get() else "copy template"} checklist sheet!: {e}')
            self.write(F'Failed to {"get existing" if self.existing_checklist_id.get() else "copy template"} checklist sheet!: {e}', tag='stderr')
            self.create_checklist_button.config(state='normal')
            return

          self.write("Compiling Tracking Sheet rows ...")

          # Get all sheet data at once
          tracking_sheet = ss_client.Sheets.get_sheet(self.tracking_sheet_id.get() or tracking_sheet_id)

          # Get names and IDs of all DCDDs in the tracking sheet
          DCDDs = {x.id:x.name for x in ss_client.Folders.get_folder(self.dcdds_folder_id.get() or dcdds_folder_id).sheets}

          # Initialize the IDs as None
          category_column_id = None
          dcdd_column_id = None
          priority_column_id = None
          description_column_id = None

          # Find all columns in a single loop
          for column in tracking_sheet.columns:
              if column.title.lower() in category_column_names:
                  category_column_id = column.id
              elif column.title.lower() in ['dcdd','file name']:
                  dcdd_column_id = column.id
              elif "priority" in column.title.lower():
                  priority_column_id = column.id
              elif "description" in column.title.lower():
                  description_column_id = column.id

          if category_column_id is None:
              messagebox.showerror("Error", "None of the expected category column names were found. Please check the column names.")
              self.write("None of the expected category column names were found. Please check the column names.", tag='stderr')
              return

          # Loop over all tracking sheet rows
          filtered_rows = []
          for row in tracking_sheet.rows:
              category_cell = next((cell for cell in row.cells if cell.column_id == category_column_id), None)
              dcdd_cell = next((cell for cell in row.cells if cell.column_id == dcdd_column_id), None)
              priority_cell = next((cell for cell in row.cells if cell.column_id == priority_column_id), None)
              description_cell = next((cell for cell in row.cells if cell.column_id == description_column_id), None)

              # Continue to next row if dcdd cell is None or has no value
              if dcdd_cell is None or not dcdd_cell.value:
                  continue

              priority_value = priority_cell.value if priority_cell else "No Priority Value"
              dcdd_value = dcdd_cell.value
              category_value = category_cell.value if category_cell else "No Category Value"
              desciption_value = description_cell.value if description_cell else "No Description Value"

              # self.write(f"Tracking Sheet DCDD: {dcdd_value}, Priority: {priority_value}, Category Item: {category_picklist_item}, Category Value: {category_value}, Description: {desciption_value}")

              # only if there is a category defined...
              if category_cell is not None: # and category_cell.value is not None:
                  category_lower = category_cell.value.lower() if category_cell.value else ''
                  include_row = False
                  category_picklist_item_lower = category_picklist_item.lower() if category_picklist_item else ''

                  if category_picklist_item_lower in ["all", "everything", ""]: # filter off
                      include_row = True
                  else: # match
                      include_row = category_picklist_item_lower in category_lower

                  if include_row == False:
                      include_row = category_lower in category_picklist_item_lower

                  if include_row:
                      if dcdd_cell.hyperlink is not None:
                          dcdd_cell_sheet_id = dcdd_cell.hyperlink.sheet_id or dcdd_cell.hyperlink.url.split('/')[-1].split('?')[0]
                          if dcdd_cell.value:
                              # target_sheet_name = ss_client.Sheets.get_sheet(dcdd_cell_sheet_id).name  # Get sheet name only as it might not match DCDD name
                              target_sheet_name = DCDDs.get(dcdd_cell_sheet_id, dcdd_cell.value)
                              filtered_row = {'Category': category_cell.value, 'Workstream / FA': row.cells[1].value, 'DCDD Name': target_sheet_name, 'Priority': priority_value, 'Description': desciption_value}
                              filtered_rows.append(filtered_row)
                      # elif dcdd_cell.value:
                      #     filtered_row = {'Category': category_cell.value, 'Workstream / FA': row.cells[1].value, 'DCDD Name': dcdd_cell.value, 'Priority': priority_value, 'Description': desciption_value}
                      #     filtered_rows.append(filtered_row)

          new_rows = []
          # response = ss_client.Sheets.get_columns(new_full_sheet.id, include_all=True)
          # columns = response.data
          columns = new_full_sheet.columns
          new_priority_column_id = next((x.id for x in columns if 'priority' in x.title.lower()), None)

          # for file in full_file_list:
          #     self.write(f"Full file list item - Workstream: {file['Workstream']}, File Name: {file['File Name']}")

          # for row in filtered_rows:
          #     self.write(f"Filtered row - DCDD: {row['DCDD Name']}, Priority: {row['Priority']}, Category: {row['Category']}, Description: {row['Description']}")

          for row in full_file_list:
              dcdd_name = row['File Name']
              self.write(f"Processing: {dcdd_name}")
              if (filtered_rows and row['File Name'] in [x['DCDD Name'] for x in filtered_rows]): #or not filtered_rows:
                  matching_filtered_rows = [filtered_row for filtered_row in filtered_rows if filtered_row['DCDD Name'] == dcdd_name]
                  if matching_filtered_rows:
                      for matching_filtered_row in matching_filtered_rows:
                          self.write(f"  Matched DCDD: {dcdd_name}, Priority: {matching_filtered_row['Priority']}, Category Value: {matching_filtered_row['Category']}, Description: {matching_filtered_row['Description']}")
                          row['Category'] = matching_filtered_row['Category']
                          row['Priority'] = matching_filtered_row['Priority']
                          row['Description'] = matching_filtered_row['Description']

              new_row = smartsheet.models.Row()
              new_row.to_top = True
              for column in columns:
                  if 'Workstream' in column.title and column.version == 2:    #Workstream column
                      new_cell = smartsheet.models.Cell({
                          'column_id': column.id,
                          'strict': False,
                          'object_value': smartsheet.models.MultiPicklistObjectValue({ # Multi-Select
                              'values':  row['Workstream'].replace("_DCDD", "")
                              }),
                          })
                      new_row.cells.append(new_cell)
                      wrkstrm_column_id_to_sort_for_full = new_cell.column_id   # ID of the column to sort by
                  elif 'DCDD' in column.title and column.version == 0:     #DCDD Name column
                      new_cell = smartsheet.models.Cell({
                              'column_id': column.id,
                              'value': row['File Name'],
                              'strict': False,
                              'hyperlink': smartsheet.models.Hyperlink({'sheet_id': row['SheetID']})
                          })
                      new_row.cells.append(new_cell)
                      dcdd_column_id_to_sort_for_full = new_cell.column_id   # ID of the column to sort by
                      dcdd_column_id = new_cell.column_id
                  elif 'File Name' in column.title and column.version == 0:     #DCDD Name column
                      new_cell = smartsheet.models.Cell({
                              'column_id': column.id,
                              'value': row['File Name'],
                              'strict': False,
                              'hyperlink': smartsheet.models.Hyperlink({'sheet_id': row['SheetID']})
                          })
                      new_row.cells.append(new_cell)
                      dcdd_column_id_to_sort_for_full = new_cell.column_id   # ID of the column to sort by
                      dcdd_column_id = new_cell.column_id
                  elif 'Priority' in column.title and column.version == 0 and 'Priority' in row and row['Priority']:
                      self.write(f"  Inserting Priority into DCDD: {row['File Name']}, Priority: {matching_filtered_row['Priority']}")
                      new_cell = smartsheet.models.Cell({
                          'column_id': column.id,
                          'value': row['Priority'],
                          'strict': False
                          })
                      new_row.cells.append(new_cell)
                      priority_column_id = new_cell.column_id   # ID of the column to sort by
                  elif 'CATEGORY' in column.title.upper() and column.version == 2 and 'Category' in row and row['Category']:
                      self.write(f"  Inserting Category into DCDD: {row['File Name']}, Category Value: {matching_filtered_row['Category']}")
                      new_cell = smartsheet.models.Cell({
                          'column_id': column.id,
                          'strict': False,
                          'object_value': smartsheet.models.MultiPicklistObjectValue({ # Multi-Select
                              'values':  row['Category'].split(", ")
                              }),
                          })
                      new_row.cells.append(new_cell)
                      category_column_id = new_cell.column_id
                  elif 'Description' in column.title and column.version == 0 and 'Description' in row and row['Description']:
                      self.write(f"  Inserting Description into DCDD: {row['File Name']}, Description: {matching_filtered_row['Description']}")
                      new_cell = smartsheet.models.Cell({
                          'column_id': column.id,
                          'value': row['Description'],
                          'strict': False
                          })
                      new_row.cells.append(new_cell)
                      description_column_id = new_cell.column_id
                  # else:
                  #     new_cell = smartsheet.models.Cell({
                  #             'column_id': column.id,
                  #             'value': ""
                  #         })
                  #     new_row.cells.append(new_cell)
              new_rows.append(new_row)

          if len(new_rows) > 0:
              self.write(F"\nAdding {len(new_rows)} rows to {new_full_sheet.name}: ", end="")
              ss_client.errors_as_exceptions(False)
              updated_rows = ss_client.Sheets.add_rows(new_full_sheet.id,new_rows)  #update rows
              ss_client.errors_as_exceptions()
              self.write(F"{updated_rows.message}\n", tag='messages' if updated_rows.message == "SUCCESS" else 'stderr')
              if updated_rows.message != "SUCCESS":
                self.write([r.to_dict() for r in new_rows])
                raise(Exception(F"Failed to add rows! {updated_rows}"))
              # Refresh local copy with updates
              new_full_sheet = ss_client.Sheets.get_sheet(new_full_sheet.id)
          else:
              self.write("\nThere are no rows of data found to add.\n")
              # ss_client.Sheets.delete_sheet(new_full_sheet.id)
              raise(Exception("No rows to add!"))

          rows_to_update = []
          if category_picklist_item_lower and "workset" in category_picklist_item_lower:
              self.write("Parsing the 'Category' values and removing any non-'Workset' matches from category column")
              existing_sheet =  new_full_sheet # ss_client.Sheets.get_sheet(new_full_sheet.id)
              existing_sheet.rows = [row for row in existing_sheet.rows if 'workset' in str(next((cell.value for cell in row.cells if cell.column_id == category_column_id), '')).lower().split()]  # Filter the rows to contain 'workset'

              for row in existing_sheet.rows:
                  category_cell = next((cell for cell in row.cells if cell.column_id == category_column_id), None)
                  
                  if category_cell is not None and category_cell.value is not None:
                      values_list = category_cell.value.split(", ")
                      updated_values_list = [value for value in values_list if "workset" in value.lower().split()]
                      
                      if len(updated_values_list) != len(values_list): # Check if there's a change in the values
                          new_cell = smartsheet.models.Cell({
                              'column_id': category_cell.column_id,
                              'strict': False,
                              'object_value': smartsheet.models.MultiPicklistObjectValue({
                                  'values': updated_values_list,
                              }),
                          })

                          new_row = smartsheet.models.Row({
                              'id': row.id,
                              'cells': [new_cell],
                          })
                          
                          rows_to_update.append(new_row)

              if rows_to_update:
                  ss_client.errors_as_exceptions(False)
                  updated_rows = ss_client.Sheets.update_rows(new_full_sheet.id, rows_to_update)
                  ss_client.errors_as_exceptions()
                  self.write(f"\nUpdating {len(rows_to_update)} rows by removing non-'Workset' values in 'Category': ", end="")
                  self.write(F"{updated_rows.message}\n", tag='messages' if updated_rows.message == "SUCCESS" else 'stderr')
                  if updated_rows.message == "SUCCESS":
                    new_full_sheet = ss_client.Sheets.get_sheet(new_full_sheet.id)
                  else:
                    self.write(F"Failed to update rows: {updated_rows}", tag='stderr')
              else:
                  self.write(f"No rows were updated to remove non-'Workset' values in 'Category'")
          elif category_picklist_item_lower and "launch" in category_picklist_item_lower:    
              self.write("Parsing the 'Category' values and removing any non-'Launch' matches from category column")
              existing_sheet = new_full_sheet # ss_client.Sheets.get_sheet(new_full_sheet.id)
              existing_sheet.rows = [row for row in existing_sheet.rows if 'launch' in str(next((cell.value for cell in row.cells if cell.column_id == category_column_id), '')).lower()]   # Filter the rows to contain 'launch'
              self.write(f"Number of rows after filtering: {len(existing_sheet.rows)}")  # Debug line

              for row in existing_sheet.rows:
                  category_cell = next((cell for cell in row.cells if cell.column_id == category_column_id), None)
                  
                  if category_cell is not None and category_cell.value is not None:
                      values_list = category_cell.value.split(", ")
                      updated_values_list = [value for value in values_list if "launch" in value.lower().split()]
                      
                      if len(updated_values_list) != len(values_list): # Check if there's a change in the values
                          new_cell = smartsheet.models.Cell({
                              'column_id': category_cell.column_id,
                              'strict': False,
                              'object_value': smartsheet.models.MultiPicklistObjectValue({
                                  'values': updated_values_list,
                              }),
                          })

                          new_row = smartsheet.models.Row({
                              'id': row.id,
                              'cells': [new_cell],
                          })
                          
                          rows_to_update.append(new_row) 

              if rows_to_update:
                  ss_client.errors_as_exceptions(False)
                  updated_rows = ss_client.Sheets.update_rows(new_full_sheet.id, rows_to_update)
                  ss_client.errors_as_exceptions()
                  self.write(f"\nUpdating {len(rows_to_update)} rows by removing non-'Launch' values in 'Category': ", end="")
                  self.write(F"{updated_rows.message}\n", tag='messages' if updated_rows.message == "SUCCESS" else 'stderr')
                  if updated_rows.message == "SUCCESS":
                    new_full_sheet = ss_client.Sheets.get_sheet(new_full_sheet.id)
                  else:
                    self.write(F"Failed to update rows: {updated_rows}", tag='stderr')
              else:
                  self.write(f"No rows were updated to remove non-'Launch' values in 'Category'")
          else:
              self.write(f'Neither "Launch" nor "Workset" were found in the category filter: "{category_picklist_item_lower}" (lowercase)')  # Debug line


          # delete duplicate rows and filtered out rows
          self.write("Checking for duplicate rows and filtered-out categories ...")
          existing_sheet = new_full_sheet # ss_client.Sheets.get_sheet(new_full_sheet.id)
          values_dict = {}
          rows_to_remove = []
          
          for row in existing_sheet.rows:
              file_name_cell = next((cell for cell in row.cells if cell.column_id == dcdd_column_id), None)
              remove_row = False

              # Assuming the category value is in the same row as the file_name_cell
              category_cell = next((cell for cell in row.cells if cell.column_id == category_column_id), None)
              
              if category_cell is not None and category_cell.value:
                  category_lower = category_cell.value.lower()
                  # self.write(f" +++ Category found: {category_lower}, Category Input: {category_picklist_item_lower}")
              else:
                  category_lower = ""

              file_name_value = file_name_cell.value if file_name_cell else ""

              # handle duplicates
              if file_name_cell is not None:
                  if file_name_value in values_dict:
                      existing_row, existing_category = values_dict[file_name_value]
                      if category_lower and not existing_category:
                          remove_row = True
                          self.write(f" *-*-* Duplicate row found on row # {row.id}, File Name: {file_name_value}")
                          values_dict[file_name_value] = (row, category_lower)
                      elif existing_category and not category_lower:
                          remove_row = True
                          self.write(f" *-*-* Duplicate row found on row # {existing_row.id}, File Name: {file_name_value}")
                      else:
                          remove_row = True
                          self.write(f" *-*-* Duplicate row found on row # {row.id}, File Name: {file_name_value}")
                  else:
                      values_dict[file_name_value] = (row, category_lower)

              if not remove_row: # skip if already a duplicate
                if not category_picklist_item_lower or category_picklist_item_lower in 'none':
                  continue
                elif category_picklist_item_lower in 'launch':
                  category_lower_list = [item.strip() for item in category_lower.split(',')]
                  if not any('launch' in item for item in category_lower_list):
                    remove_row = True
                    self.write(f"Didn't find LAUNCH category in row {row.id}: {category_lower_list}, File Name: {file_name_value}")
                elif category_picklist_item_lower in 'workset':
                  category_lower_list = [item.strip() for item in category_lower.split(',')]
                  if not any('workset' in item for item in category_lower_list):
                    remove_row = True
                    self.write(f"Didn't find WORKSET category in row {row.id}: {category_lower_list}, File Name: {file_name_value}")
                elif (not category_lower or category_lower == None) and len(category_picklist_item_lower) > 0:
                  remove_row = True
                  self.write(f" !!! Found empty category in row, but a filter is present in row {row.id}: {category_lower}, File Name: {file_name_cell.value}")
                elif category_picklist_item_lower in ["all", "everything"]:
                  continue

              if remove_row:
                rows_to_remove.append(row)
                # self.write(f"::::: Duplicate or filtered-out category found in row {row.id}: {category_lower}, File Name: {file_name_value}")

          if len(rows_to_remove) > 0:
            self.write("The following rows have been marked for removal:")
            for row in rows_to_remove:
              dcdd_name_cell = next((cell for cell in row.cells if cell.column_id == dcdd_column_id), None)
              dcdd_name = dcdd_name_cell.value if dcdd_name_cell is not None else ""
              self.write(f"Row ID: {row.id}, DCDD Name: {dcdd_name}")

            # user_input = input("Do you want to remove these rows? (y/n): ")
            user_input = 'y' if self.switch.instate(['selected']) else 'n'
            if user_input.lower() == 'y':
              self.write("\nRemoving rows : ", end="")
              # Remove rows here
              ss_client.errors_as_exceptions(False)
              remove_result = ss_client.Sheets.delete_rows(existing_sheet.id, [row.id for row in rows_to_remove])
              ss_client.errors_as_exceptions()
              self.write(F"{remove_result.message}\n", tag='messages' if remove_result.message == "SUCCESS" else 'stderr')
              if remove_result.message != "SUCCESS":
                self.write(F"Failed to remove rows: {remove_result}", tag='stderr') 
            else:
              self.write("You chose not to remove rows.")
          else:
            self.write("No duplicates or filtered-out rows by category found to remove.")


          # sort the sheet
          try:
            # self.write(wrkstrm_column_id_to_sort_for_full , dcdd_column_id_to_sort_for_full , new_priority_column_id)
            if wrkstrm_column_id_to_sort_for_full and dcdd_column_id_to_sort_for_full and new_priority_column_id:
              sort_specifier = smartsheet.models.SortSpecifier({
                'sort_criteria': [
                  smartsheet.models.SortCriterion({
                    'column_id': wrkstrm_column_id_to_sort_for_full,
                    'direction': 'ASCENDING'
                  }),
                  smartsheet.models.SortCriterion({
                    'column_id': new_priority_column_id,
                    'direction': 'ASCENDING'
                  }),
                  smartsheet.models.SortCriterion({
                    'column_id': dcdd_column_id_to_sort_for_full,
                    'direction': 'ASCENDING'
                  })
                ]
              })
              sort_response = ss_client.Sheets.sort_sheet(new_full_sheet.id, sort_specifier)
          except Exception as e:
            self.write(f"An error occurred while sorting: {e}")
      else:
        self.write("No folders / files found in the selected DCDD folder.", tag='stderr')
    except Exception as e:
      self.write(F"(ERROR) {type(e).__name__}: {e}", tag='stderr')
    finally:
      self.write("Create Checklist Process Ended!\n")
      self.create_checklist_button.config(state='normal')

  def pick_smartsheet_folder(self, widget):
    ssp = Smartsheet_Picker(self.root, x_y=(widget.winfo_rootx(), widget.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      widget.setvar(widget.cget('textvariable'), ssp.result['id'])
      # print(ssp.result)
    self.after(1, lambda: widget.event_generate('<Escape>'))

  def pick_smartsheet_sheet(self, widget):
    ssp = Smartsheet_Picker(self.root, ss_type='sheet', x_y=(widget.winfo_rootx(), widget.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      widget.setvar(widget.cget('textvariable'), ssp.result['id'])
      # print(ssp.result)
    self.after(1, lambda: widget.event_generate('<Escape>'))


if __name__ == "__main__":
  root = tk.Tk()
  root.title("Checklists")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ss_token':tk.StringVar(value=dict_config.get('ss_token')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()