import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import sys, time
import threading
import webbrowser
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import CheckboxTreeview, SmartsheetLib, Smartsheet_Picker, InterceptorWidget
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import CheckboxTreeview, SmartsheetLib, Smartsheet_Picker, InterceptorWidget

class App(ttk.Frame):

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(0, weight=1)
    self.rowconfigure(2, weight=1)
    self.rowconfigure(3, weight=1)

    # Label
    self.label = ttk.Label(self, text="DCDD Folder Copy", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, columnspan=99, padx=10, pady=10, sticky=tk.NW)

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=1, column=0, columnspan=99, padx=5, pady=5, sticky=tk.NW)

    # Source Folder ID
    self.source_folder_id = tk.StringVar(value=2415296435775364)
    self.source_folder_type = tk.StringVar(value='Workspace')
    # self.source_folder_id_label = ttk.Label(self.config_frame, text="Source Workspace/Folder ID\n(Usually no need to update)")
    self.source_folder_id_label = tk.Text(self.config_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.source_folder_id_label.configure(selectbackground=self.source_folder_id_label.cget('bg'), inactiveselectbackground=self.source_folder_id_label.cget('bg'))
    self.source_folder_id_label.grid(row=0, column=0, columnspan=2, padx=5, pady=(0,2), sticky=tk.NSEW)

    self.source_folder_id_label.insert(tk.END, 'Source')
    self.source_folder_type_label = ttk.Label(self.config_frame, textvariable=self.source_folder_type, cursor='hand1', style='Link.TLabel')
    self.source_folder_id_label.window_create(tk.END, window=self.source_folder_type_label, padx=2)
    self.source_folder_id_label.insert(tk.END, 'ID (Usually no need to update)')

    # self.source_folder_id_entry = ttk.Entry(self.config_frame, textvariable=self.source_folder_id)
    self.source_folder_id_entry = ttk.Combobox(self.config_frame, textvariable=self.source_folder_id, postcommand=lambda:self.pick_smartsheet_folder(self.source_folder_id_entry))
    self.source_folder_id_entry.id_type = tk.StringVar(value='workspace')
    self.source_folder_id_entry.type_var = self.source_folder_type
    # self.source_folder_id_entry.config(state='readonly')
    self.source_folder_id_entry.grid(row=1, column=0, padx=5, pady=5, sticky=tk.NW)
    self.source_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", self.get_folder_url_from_id)

    def source_type_menu(event):
      type_menu = tk.Menu(self.source_folder_type_label, tearoff=0)
      type_menu.add_command(label='Workspace', command=lambda: [
        self.source_folder_type.set(value='Workspace'),
        self.source_folder_id_entry.id_type.set('workspace'),
      ])
      type_menu.add_command(label='Folder', command=lambda: [
        self.source_folder_type.set(value='Folder'),
        self.source_folder_id_entry.id_type.set('folder'),
      ])
      type_menu.add_command(label='Home', command=lambda: [
        self.source_folder_type.set(value='Home'),
        self.source_folder_id_entry.id_type.set('home'),
      ])
      type_menu.post(event.x_root, event.y_root)

    self.source_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', source_type_menu)
    self.source_folder_type_label.bind("<ButtonRelease-1>", source_type_menu)

    # Refresh Button
    self.refresh_button = ttk.Button(self.config_frame, text='Refresh Source List', command=lambda: self.background(self.refresh_source))
    self.refresh_button.grid(row=1, column=1, padx=5, pady=5, sticky=tk.NW)

    separator = ttk.Separator(self.config_frame, orient='vertical')
    separator.grid(row=0, column=2, rowspan=2, padx=5, pady=5, sticky=tk.NSEW)

    # Target Folder ID
    self.target_folder_id = tk.StringVar()
    self.target_folder_id_label = ttk.Label(self.config_frame, text="Target Folder ID (not a Workspace ID)")
    self.target_folder_id_label.grid(row=0, column=3, columnspan=3, padx=5, pady=(0,2), sticky=tk.NW)
    # self.target_folder_id_entry = ttk.Entry(self.config_frame, textvariable=self.target_folder_id)
    self.target_folder_id_entry = ttk.Combobox(self.config_frame, textvariable=self.target_folder_id, postcommand=lambda:self.pick_smartsheet_folder(self.target_folder_id_entry))
    self.target_folder_id_entry.grid(row=1, column=3, padx=5, pady=5, sticky=tk.NW)
    self.target_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", self.get_folder_url_from_id)

    # Copy Button
    self.copy_button = ttk.Button(self.config_frame, text='Copy Selected Folder(s)', command=lambda: self.background(self.copy_folders))
    self.copy_button.grid(row=1, column=4, padx=5, pady=5, sticky=tk.NW)

    self.overwrite_check_var = tk.BooleanVar(value=False)
    self.overwrite_check = ttk.Checkbutton(self.config_frame, text="Overwrite Existing Sheets", variable=self.overwrite_check_var)
    self.overwrite_check.grid(row=1, column=5, padx=5, pady=5, sticky=tk.NW)

    # Dir Scrollbar
    dir_tree_scrollbar = ttk.Scrollbar(self)
    dir_tree_scrollbar.grid(row=2, column=99, padx=5, pady=5, sticky=tk.NSEW)

    # Dir Treeview
    self.dir_tree = CheckboxTreeview(self, yscrollcommand=dir_tree_scrollbar.set, columns=(1, 2, 3), height=10) # , selectmode="browse", padding=[-15,0,0,0]
    self.dir_tree.grid(row=2, column=0, columnspan=98, padx=5, pady=5, sticky=tk.NSEW)
    iw = InterceptorWidget(self)
    iw.attach_treeview(self.dir_tree)
    dir_tree_scrollbar.config(command=self.dir_tree.yview)

    # Dir Treeview columns
    self.dir_tree.column("#0", anchor="w", width=200)
    self.dir_tree.column(1, anchor="w", width=200)
    self.dir_tree.column(2, anchor="w", width=200)
    self.dir_tree.column(3, anchor="w", width=200)
    
    # Dir Treeview headings
    self.dir_tree.heading("#0", text="Folder", anchor="center")
    self.dir_tree.heading(1, text="Status", anchor="center")
    self.dir_tree.heading(2, text="ID", anchor="center")
    self.dir_tree.heading(3, text="Link", anchor="center")

    # Binding
    self.dir_tree.bind('<ButtonRelease-1>', self.open_link, add="+")
    self.dir_tree.bind("<Motion>", self.hand1_cursor_on)
    self.dir_tree.bind("<Leave>", self.cursor_off)
    self.dir_tree.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", self.tree_right_click)
    self.dir_tree.bind("<Control-ButtonRelease-1>", self.tree_right_click)
    self.dir_tree.bind('<Control-a>', lambda e:[self.select_all_tree(e.widget)])
    self.dir_tree.bind('<Control-c>', lambda e:[self.copy_tree_selection_to_clipboard(e.widget)])

    self.text_log = ttk.LabelFrame(self, text="Log", style="Bold.TLabelframe")
    self.text_log.grid(row=3, column=0, columnspan=98, padx=5, pady=(5,0), sticky=tk.NSEW)
    self.text_log.columnconfigure(0, weight=1)
    self.text_log.rowconfigure(0, weight=1)
    self.textbox = tk.Text(self.text_log, height=3, wrap="word", state="disabled", relief='flat') # width=50, 
    self.textbox.grid(column=0, row=0, sticky=tk.NSEW, padx=5, pady=5)
    self.text_scroll = tk.ttk.Scrollbar(self, command=self.textbox.yview)
    self.text_scroll.grid(row=3, column=99, pady=(12,5), sticky=tk.NSEW)
    self.textbox['yscrollcommand'] = self.text_scroll.set
    self.textbox.tag_configure("stderr", foreground="#b22222")
    self.textbox.tag_configure("messages", foreground="#22b222")
    self.textbox.bind("<1>", lambda event: self.textbox.focus_set())

    self.background(self.refresh_source)


  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()

  def write(self, *args, tag=None, end='\n'):
    string = ' '.join(str(x) for x in args) + end
    widget = self.textbox
    widget.configure(state=tk.NORMAL)
    move = widget.yview()[1] >= 1
    widget.insert(tk.END, string, "stdout" if not tag else tag)
    if move: widget.see(tk.END)
    # if int(float(widget.index(tk.END))) > 1000:
    #   widget.delete( 1.0, float(int(float(widget.index(tk.END))) - 1000)  )
    widget.configure(state=tk.DISABLED)

  def hand1_cursor_on(self, event):
    tree = event.widget  # get the treeview widget
    if tree.identify_region(event.x, event.y) != 'cell':
      tree.config(cursor='')
      return
    if tree.identify_column(event.x) != "#3":
      tree.config(cursor='')
      return
    values = tree.item(tree.identify('item', event.x, event.y))['values']
    if len(values) > 0 and values[2]:
      tree.config(cursor='hand1')
    else:
      tree.config(cursor='')

  def cursor_off(self, event):
    event.widget.config(cursor='')

  def open_link(self, event):
    tree = event.widget  # get the treeview widget
    if tree.identify_region(event.x, event.y) == 'cell' and tree.identify_column(event.x) == "#3":
      values = tree.item(tree.identify('item', event.x, event.y))['values']
      if len(values) > 0 and values[2]:
        webbrowser.open_new_tab(values[2])  # open the link in a browser tab

  def tree_right_click(self, event):
    tree = event.widget
    if tree.identify_region(event.x, event.y) not in ['tree', 'cell']:
      return
    item = tree.identify('item', event.x, event.y)
    if item not in tree.selection():
      tree.selection_set(item)
    # print(tree.selection())
    has_multi = True if len(tree.selection()) > 1 else False
    menu = tk.Menu(tree)
    menu.add_command(label=F"Copy Item{'s' if has_multi else ''}", command=lambda:[self.copy_tree_selection_to_clipboard(tree)])
    menu.add_separator()
    menu.add_command(label=F"Check Item{'s' if has_multi else ''}", command=lambda:[
      [tree.click_item(item, True) for item in tree.selection()] 
    ])
    menu.add_command(label=F"Uncheck Item{'s' if has_multi else ''}", command=lambda:[
      [tree.click_item(item, False) for item in tree.selection()] 
    ])
    if not has_multi and len(tree.selection()) > 0 and len(tree.item(tree.selection()[0])['values']) > 1:
      menu.add_separator()
      menu.add_command(label="Copy Link", command=lambda: [
        tree.clipboard_clear(), 
        tree.clipboard_append(tree.item(tree.selection()[0])['values'][2])
      ]), 
      menu.add_command(label="Open Link", command=lambda: [
        webbrowser.open_new_tab(tree.item(tree.selection()[0])['values'][2])
      ]), 
    menu.post(event.x_root, event.y_root)

  def copy_tree_selection_to_clipboard(self, tree):
    tree.clipboard_clear()
    tree.clipboard_append('\n'.join('\t'.join([item, tree.item(item)['text'].strip()] + [str(x) for x in tree.item(item)['values']]) for item in tree.selection()))
  
  def select_all_tree(self, tree, item=None):
    for child in tree.get_children(item):
      tree.selection_add(child)
      self.select_all_tree(tree, child)

  def refresh_source(self):
    self.refresh_button.config(state='disabled')
    self.dir_tree.delete(*self.dir_tree.get_children())
    try:
      ss = SmartsheetLib(self.root.vars.get('ss_token').get())
      ss.client.errors_as_exceptions()
      if self.source_folder_type.get() == 'Workspace':
        source_folders = ss.client.Workspaces.list_folders(self.source_folder_id.get()).data # if id_type == "workspace" else get_folder_hierarchy(source_id)
      elif self.source_folder_type.get() == 'Folder':
        source_folders = ss.client.Folders.list_folders(self.source_folder_id.get()).data
      elif self.source_folder_type.get() == 'Home':
        source_folders = ss.client.Home.list_folders().data
    except Exception as e:
      messagebox.showerror("Error", F"An error occurred while retrieving the list of folders. Check that the Source ID type (workspace, folder, home) is correct:\n\n{e}")
      self.refresh_button.config(state='normal')
      return
    source_folders = [folder for folder in source_folders if not ( folder.name.startswith('_') or any(x in folder.name.lower() for x in ['admin','zzz','dnu','test']) )]
    pid = self.dir_tree.insert(parent='', index=tk.END, text=F" ALL FOLDERS", open=True)
    for f in source_folders:
      # print(f)
      self.dir_tree.insert(parent=pid, index=tk.END, text=F" {f.name}", values=('', f.id, f.permalink))
    self.refresh_button.config(state='normal')

  def copy_folders(self):
    overwrite = self.overwrite_check_var.get()
    if not self.target_folder_id.get():
      messagebox.showerror("Error", F"Missing the Target Folder ID")
      return                           
    self.copy_button.config(state='disabled')
    checked_folders = self.dir_tree.get_tagged(tag_has="checked")
    for i in checked_folders:
      # print(i)
      self.dir_tree.set(i['iid'], column=1, value='Pending Copy')
    self.root.update_idletasks()
    try:
      ss = SmartsheetLib(self.root.vars.get('ss_token').get())
      existing_folders = ss.client.Folders.list_folders(self.target_folder_id.get()).data
    except Exception as e:
      messagebox.showerror("Error", F"An error occurred while getting existing folders:\n{e}")
      self.copy_button.config(state='normal')
      return
    for i in checked_folders:
      try:
        self.dir_tree.set(i['iid'], column=1, value='Copying')
        self.root.update_idletasks()
        folder_name = i['text'].strip()
        self.write(F"""-- Copying folder "{folder_name}" to target folder ...""")
        existing_folder = next((f for f in existing_folders if f.name == folder_name), None)
        if existing_folder:
          self.write(F"Skipping folder {folder_name} creation - already exists")
          # self.dir_tree.set(i['iid'], column=1, value='Skipped: Existing Folder')
          # continue
          new_folder = existing_folder
        else:
          new_folder = ss.client.Folders.create_folder_in_folder(self.target_folder_id.get(), ss.client.models.Folder({'name': folder_name}))
          if new_folder.message != "SUCCESS":
            raise Exception(new_folder.message)
          else:
            new_folder = new_folder.result
          self.write(f"Created folder {new_folder.name} in target location")
        sheets = None
        for j in range(5):
          try:
            if j > 0:
              self.write(F"Retrying getting sheets for folder {folder_name} ({i['values'][1]})")
            else:
              self.write(F"Getting sheets for folder {folder_name} ({i['values'][1]})")
            sheets = ss.client.Folders.get_folder(i['values'][1]).sheets
            if not sheets is None: break
          except Exception as e:
            self.dir_tree.set(i['iid'], column=1, value=F"Error: {e}")
            self.write(F"Error while getting sheets for folder {folder_name} ({i['values'][1]}): {e}", tag="stderr")
            if j == 4:
              raise Exception(F"Failed to get sheets for folder {folder_name} ({i['values'][1]})")
            else:
              self.write(F"Retrying in {j+1} seconds ...")
              time.sleep(j+1)
        if sheets is None: continue
        existing_sheets = None
        for j in range(5):
          try:
            if j > 0:
              self.write(F"Retrying getting existing sheets for folder {folder_name} ({new_folder.id})")
            else:
              self.write(F"Getting existing sheets for folder {folder_name} ({new_folder.id})")
            existing_sheets = ss.client.Folders.get_folder(new_folder.id).sheets
            if not existing_sheets is None: break
          except Exception as e:
            self.dir_tree.set(i['iid'], column=1, value=F"Error: {e}")
            self.write(F"Error while getting existing sheets for folder {folder_name} ({new_folder.id}): {e}", tag="stderr")
            if j == 4:
              raise Exception(F"Failed to get existing sheets for folder {folder_name} ({new_folder.id})")
            else:
              self.write(F"Retrying in {j+1} seconds ...")
              time.sleep(j+1)
        if existing_sheets is None: continue
        for sheet in sheets:
          if "checklist" in sheet.name.lower():  # Add this line to check for "Checklist" in the sheet name
            self.write(f"Skipping sheet {sheet.name} - contains 'Checklist' in the name")
            continue  # Skip copying this sheet
          matching_existing_sheets = [s for s in existing_sheets if s.name.lower() == sheet.name.lower()]
          if matching_existing_sheets and overwrite:
            for s in matching_existing_sheets:
              ss.client.Sheets.delete_sheet(s.id)
              self.write(f"Deleted existing sheet {s.name} in folder {new_folder.name}")
          elif matching_existing_sheets:
            self.write(f"Skipping sheet {sheet.name} - already exists")
            continue
          new_sheet = ss.client.Sheets.copy_sheet(
            sheet.id,
            ss.client.models.ContainerDestination({
              'destination_type': 'folder',
              'destination_id': new_folder.id,
              'new_name': sheet.name
            }), include='all'
          )
          self.write(F"Copied sheet {sheet.name} to folder {folder_name}: ", end="")
          self.write(F"{new_sheet.message}", tag="messages" if new_sheet.message == "SUCCESS" else "stderr")
          if new_sheet.message != "SUCCESS":
            raise Exception(new_sheet.message)
        self.dir_tree.set(i['iid'], column=1, value=F"Successfully Copied!")
        self.write(F"Successfully copied folder {folder_name} sheets to target location!", tag="messages")
      except Exception as e:
        self.dir_tree.set(i['iid'], column=1, value=F"Error: {e}")
        self.write(F"Error while copying folder {folder_name} sheets to target location: {e}", tag="stderr")
      finally:
        continue
    self.copy_button.config(state='normal')

  def pick_smartsheet_folder(self, widget):
    ssp = Smartsheet_Picker(self.root, x_y=(widget.winfo_rootx(), widget.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      widget.setvar(widget.cget('textvariable'), ssp.result['id'])
      # print(ssp.result)
      if hasattr(widget, 'id_type'):
        widget.id_type.set(ssp.result['type'])
      if hasattr(widget, 'type_var'):
        widget.type_var.set(value=ssp.result['type'].title()),
    self.after(1, lambda: widget.event_generate('<Escape>'))

  def get_folder_url_from_id(self, event):
    widget = event.widget
    # print(widget.get())
    if not widget.get():
      return
    try:
      ss = SmartsheetLib(self.root.vars.get('ss_token').get())
      ss.client.errors_as_exceptions()
      if hasattr(widget, 'id_type'):
        # print(widget.id_type.get())
        if widget.id_type.get() == 'workspace':
          folder = ss.client.Workspaces.get_workspace(widget.get())
        elif widget.id_type.get() == 'folder':
          folder = ss.client.Folders.get_folder(widget.get())
        elif widget.id_type.get() == 'home':
          folder = lambda: None
          folder.permalink = "https://app.smartsheet.com/folders/personal"
      else:
        folder = ss.client.Folders.get_folder(widget.get())
      if not hasattr(folder, 'permalink'):
        return
      menu = tk.Menu(widget)
      menu.add_command(label=F"Open Folder Link", command=lambda:[webbrowser.open_new_tab(folder.permalink)])
      menu.add_command(label=F"Copy Folder Link", command=lambda:[
        widget.clipboard_clear(), 
        widget.clipboard_append(folder.permalink)
      ])
      menu.post(event.x_root, event.y_root)
    except Exception as e:
      # messagebox.showerror("Error", F"An error occurred while retrieving the folder URL:\n{e}")
      return

if __name__ == "__main__":
  root = tk.Tk()
  root.title("Folders")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ss_token':tk.StringVar(value=dict_config.get('ss_token')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()