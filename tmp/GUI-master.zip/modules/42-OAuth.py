import tkinter as tk
from tkinter import ttk, messagebox, filedialog
# from tkinter.filedialog import askopenfilename
from pathlib import Path
import sys, json
import threading
import webbrowser
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import StyledHovertip, Proteus_Picker, Proteus, OAuth, SLNG, data_centers
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import StyledHovertip, Proteus_Picker, Proteus, OAuth, SLNG, data_centers

class App(ttk.Frame):

  def __init__(self, parent, left_file=None, right_file=None, minimum=False):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.grid_rowconfigure(1, weight=1)
    self.grid_columnconfigure(0, weight=1)

    # Label
    self.label = ttk.Label(self, text="Tenant OAuth Setup", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, columnspan=99, padx=10, pady=10, sticky=tk.EW)

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=1, column=0, columnspan=99, padx=5, pady=5, sticky=tk.NSEW)

    # Tenant and OAuth Details Label Frame
    self.details_frame = ttk.LabelFrame(self.config_frame, text="Tenant and OAuth Details")
    self.details_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NSEW)
    self.details_frame.grid_columnconfigure(0, weight=1)
    self.details_frame.grid_columnconfigure(1, weight=1)      

    details_row = 0
    
    if SLNG.base_slng_url() == "Unknown Location":
      # import from proteus
      self.pp_cc_button = ttk.Button(self.details_frame, text="Import from Proteus", command=self.get_proteus_suv)
      self.pp_cc_button.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
      StyledHovertip(self.pp_cc_button, text="Choose SUV from Proteus Picker")
      details_row += 1

    # Import from Saved Tenants Combobox
    self.saved_tenant = tk.StringVar()
    self.saved_tenants_label = ttk.Label(self.details_frame, text="Import Saved Tenant")
    self.saved_tenants_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.saved_tenants_entry = ttk.Combobox(self.details_frame, textvariable=self.saved_tenant, width=60, state='readonly')
    self.refresh_saved_tenant_list()
    self.saved_tenants_entry.bind("<<ComboboxSelected>>", lambda e: [
      self.tenant_dc.set(self.saved_tenants_entry.get().split('@')[1].split('(')[1].split(')')[0]),
      self.tenant_name.set(self.saved_tenants_entry.get().split('@')[1].split('(')[0]),
      self.tenant_username.set(self.saved_tenants_entry.get().split('@')[0]),
      self.tenant_password.set(next((self.root.vars.get(F't{i}_password').get() for i in range(1, max([int(x.split('_')[0][1:]) for x in self.root.vars.keys() if x.startswith('t') and x.endswith('_username')] or [1])+1) if self.root.vars.get(F't{i}_username').get() == self.saved_tenants_entry.get().split('@')[0] and self.root.vars.get(F't{i}_name').get() == self.saved_tenants_entry.get().split('@')[1].split('(')[0] and self.root.vars.get(F't{i}_datacenter').get() == self.saved_tenants_entry.get().split('@')[1].split('(')[1].split(')')[0]), None) if self.saved_tenants_entry.get() else None)
    ])
    self.saved_tenants_entry.grid(row=details_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    StyledHovertip(self.saved_tenants_entry, text="Select a saved tenant to import")
    # Refresh button
    self.refresh_tenants_button = ttk.Button(self.details_frame, text="↻", width=2, command=self.refresh_saved_tenant_list)
    self.refresh_tenants_button.grid(row=details_row, column=1, padx=5, pady=(0,5), sticky=tk.W)
    StyledHovertip(self.refresh_tenants_button, text="Refresh Tenants")
    details_row += 1

    self.tenant_dc = tk.StringVar()
    self.tenant_dc_label = ttk.Label(self.details_frame, text="Datacenter")
    self.tenant_dc_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.tenant_dc_entry = ttk.Combobox(self.details_frame, textvariable=self.tenant_dc, values=list(data_centers.keys()))
    self.tenant_dc_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1

    self.tenant_name = tk.StringVar()
    self.tenant_name_label = ttk.Label(self.details_frame, text="Tenant Name")
    self.tenant_name_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.tenant_name_entry = ttk.Entry(self.details_frame, textvariable=self.tenant_name)
    self.tenant_name_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1
    # on tenant name change, update the redirect values
    self.tenant_name.trace_add("write", lambda *args: [self.redirect.set(''), self.redirect_entry.configure(values=self.get_redirect_values())])

    self.tenant_username = tk.StringVar()
    self.tenant_username_label = ttk.Label(self.details_frame, text="Implementer Username")
    self.tenant_username_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.tenant_username_entry = ttk.Entry(self.details_frame, textvariable=self.tenant_username)
    self.tenant_username_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1

    self.tenant_password = tk.StringVar()
    self.tenant_password_label = ttk.Label(self.details_frame, text="Implementer Password")
    self.tenant_password_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.tenant_password_entry = ttk.Entry(self.details_frame, show='*', textvariable=self.tenant_password)
    self.tenant_password_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1

    self.tenant_level = tk.StringVar(value="Impl")
    self.tenant_level_label = ttk.Label(self.details_frame, text="Tenant Level (Checker Only)")
    self.tenant_level_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.tenant_level_entry = ttk.Combobox(self.details_frame, textvariable=self.tenant_level, values=["Impl", "Prod"], state='readonly')
    self.tenant_level_entry.bind("<<ComboboxSelected>>", lambda e: [self.redirect.set(''), self.redirect_entry.configure(values=self.get_redirect_values())])
    self.tenant_level_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1

    self.client_name = tk.StringVar(value="DC Client")
    self.client_name_label = ttk.Label(self.details_frame, text="API Client Name")
    self.client_name_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.client_name_entry = ttk.Combobox(self.details_frame, textvariable=self.client_name, values=["DC SLNG Client", "DC Checker Client"])
    self.client_name_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1

    self.redirect = tk.StringVar(value="https://localhost/")
    self.redirect_label = ttk.Label(self.details_frame, text="Redirect URL")
    self.redirect_label.grid(row=details_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    details_row += 1
    self.redirect_entry = ttk.Combobox(self.details_frame, textvariable=self.redirect, width=65, values=self.get_redirect_values())
    self.redirect_entry.grid(row=details_row, column=0, columnspan=2, padx=5, pady=(0,5), sticky=tk.EW)
    details_row += 1

    # Action Frame column 1
    self.action_frame = ttk.LabelFrame(self.config_frame, text="Actions")
    self.action_frame.grid(row=0, column=1, padx=5, pady=5, sticky=tk.NSEW)

    action_row = 0
    
    # Enable OAuth button
    self.enable_oauth_button = ttk.Button(self.action_frame, text="Enable OAuth", command=self.enable_oauth)
    self.enable_oauth_button.grid(row=action_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
    StyledHovertip(self.enable_oauth_button, text="Enable OAuth 2.0 for the selected tenant")
    # Result label
    self.enable_result_label = ttk.Label(self.action_frame, text="")
    self.enable_result_label.grid(row=action_row, column=1, padx=5, pady=(5,0), sticky=tk.EW)
    action_row += 1

    # Get Existing Client IDs button
    self.get_client_ids_button = ttk.Button(self.action_frame, text="Get Existing Client IDs", command=self.get_client_ids)
    self.get_client_ids_button.grid(row=action_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
    StyledHovertip(self.get_client_ids_button, text="Get existing client IDs for the selected tenant")
    # Result Text Area
    self.client_ids_text = tk.Text(self.action_frame, height=10, width=50, wrap=tk.WORD)
    self.client_ids_text.grid(row=action_row, column=1, padx=5, pady=(5,0), sticky=tk.EW)
    action_row += 1

    # Register Client button
    self.register_client_button = ttk.Button(self.action_frame, text="Register Client", command=self.register_client)
    self.register_client_button.grid(row=action_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
    StyledHovertip(self.register_client_button, text="Register a new client for the selected tenant")
    # Result entry readonly
    self.register_result_entry = ttk.Entry(self.action_frame, state='readonly')
    self.register_result_entry.grid(row=action_row, column=1, padx=5, pady=(5,0), sticky=tk.EW)
    action_row += 1

  def enable_oauth(self):
    oa = OAuth()
    if not all([
      self.tenant_dc.get(), 
      self.tenant_name.get(), 
      self.tenant_username.get(), 
      self.tenant_password.get(), 
    ]):
      messagebox.showerror("Error", "Please fill in all required fields")
      return
    if self.tenant_dc.get() == "Unknown Location":
      messagebox.showerror("Error", "Please select a valid datacenter")
      return
    try:
      if 'workdaysuv.com' in self.tenant_dc.get():
        base_url = self.tenant_dc.get()
      else:
        base_url = data_centers.get(self.tenant_dc.get(), (None, None))[1]
        if not base_url:
          messagebox.showerror("Error", "Please select a valid datacenter")
          return
      tenant = self.tenant_name.get()
      username = self.tenant_username.get()
      password = self.tenant_password.get()
      oa.enable_oauth_clients(base_url, tenant, username, password)
    except Exception as e:
      e.add_note('Error enabling OAuth 2.0 Clients')
      messagebox.showerror("Error", F"Error enabling OAuth 2.0 Clients: {e}")
      return
    messagebox.showinfo('OAuth', 'OAuth 2.0 Clients Enabled in Tenant')

  def get_client_ids(self):
    oa = OAuth()
    if not all([
      self.tenant_dc.get(),
      self.tenant_name.get(),
      self.tenant_username.get(),
      self.tenant_password.get(),
    ]):
      messagebox.showerror("Error", "Please fill in all required fields")
      return
    if self.tenant_dc.get() == "Unknown Location":
      messagebox.showerror("Error", "Please select a valid datacenter")
      return
    try:
      if 'workdaysuv.com' in self.tenant_dc.get():
        base_url = self.tenant_dc.get()
      else:
        base_url = data_centers.get(self.tenant_dc.get(), (None, None))[1]
        if not base_url:
          messagebox.showerror("Error", "Please select a valid datacenter")
          return
      tenant = self.tenant_name.get()
      username = self.tenant_username.get()
      password = self.tenant_password.get()
      api_client_ids = oa.get_api_client_ids(base_url, tenant, username, password)
    except Exception as e:
      e.add_note('Error getting API Client IDs')
      messagebox.showerror("Error", F"Error getting API Client IDs: {e}")
      return
    if api_client_ids:
      self.client_ids_text.delete(1.0, tk.END)
      self.client_ids_text.insert(tk.END, F"Client IDs for {tenant}:\n")
      for client_id in api_client_ids:
        self.client_ids_text.insert(tk.END, F"{client_id}\n")
    else:
      messagebox.showinfo("Info", "No API Client IDs found for the selected tenant")


  def register_client(self):
  # try:
  #   client_id = oa.register_api_client(base_url, tenant, username, password, tenant_client_name, tenant_redirect_uri)
  # except Exception as e:
  #   e.add_note('Error registering API Client')
  #   raise(e)
  # print(client_id)
    oa = OAuth()
    if not all([
      self.tenant_dc.get(),
      self.tenant_name.get(),
      self.tenant_username.get(),
      self.tenant_password.get(),
      self.client_name.get(),
      self.redirect.get(),
    ]):
      messagebox.showerror("Error", "Please fill in all required fields")
      return
    if self.tenant_dc.get() == "Unknown Location":
      messagebox.showerror("Error", "Please select a valid datacenter")
      return
    try:
      if 'workdaysuv.com' in self.tenant_dc.get():
        base_url = self.tenant_dc.get()
      else:
        base_url = data_centers.get(self.tenant_dc.get(), (None, None))[1]
        if not base_url:
          messagebox.showerror("Error", "Please select a valid datacenter")
          return
      tenant = self.tenant_name.get()
      username = self.tenant_username.get()
      password = self.tenant_password.get()
      tenant_client_name = self.client_name.get()
      tenant_redirect_uri = self.redirect.get()
      client_id = oa.register_api_client(base_url, tenant, username, password, tenant_client_name, tenant_redirect_uri)
    except Exception as e:
      e.add_note('Error registering API Client')
      messagebox.showerror("Error", F"Error registering API Client: {e}")
      return
    if client_id:
      self.register_result_entry.configure(state='normal')
      self.register_result_entry.delete(0, tk.END)
      self.register_result_entry.insert(0, client_id)
      self.register_result_entry.configure(state='readonly')
    else:
      messagebox.showinfo("Info", "No Client ID returned during the registration process")

  def get_redirect_values(self):
    slng_baseurl = SLNG.base_slng_url()
    checker_baseurl = SLNG.base_checker_url()
    if slng_baseurl == "Unknown Location":
      if 'workdaysuv.com' in self.tenant_dc.get():
        return [
          F"{self.tenant_dc.get()}:3443/tenant/get-tokens/{self.tenant_name.get() or '<tenant>'}", 
          F"{self.tenant_dc.get()}:4444/api/tenant/oauth-token/{self.tenant_name.get() or '<tenant>'}/{self.tenant_level.get()}",
          F"https://localhost/tenant/get-tokens/{self.tenant_name.get() or '<tenant>'}", 
          F"https://localhost:4444/api/tenant/oauth-token/{self.tenant_name.get() or '<tenant>'}/{self.tenant_level.get()}",
        ]
      else:
        return [
          F"{self.tenant_dc.get() or 'https://<slng-url>'}/tenant/get-tokens/{self.tenant_name.get() or '<tenant>'}", 
          F"https://<checker-url>/api/tenant/oauth-token/{self.tenant_name.get() or '<tenant>'}/{self.tenant_level.get()}",
          F"https://localhost/tenant/get-tokens/{self.tenant_name.get() or '<tenant>'}", 
          F"https://localhost:4444/api/tenant/oauth-token/{self.tenant_name.get() or '<tenant>'}/{self.tenant_level.get()}",
        ]
    else:
      return [
        F"https://{slng_baseurl}/tenant/get-tokens/{self.tenant_name.get() or '<tenant>'}", 
        F"https://{checker_baseurl}/api/tenant/oauth-token/{self.tenant_name.get() or '<tenant>'}/{self.tenant_level.get()}",
      ]

  def get_proteus_suv(self):
    pp = Proteus_Picker(self.root, self.root.winfo_pointerxy()) # Use the root object with the cred/config vars.
    if not pp.error: self.wait_window(pp.top)
    if pp.result:
      # It's an SUV, we already know mostly what we need here
      self.tenant_dc.set(pp.result['url'])
      self.tenant_name.set('vacant')
      self.tenant_username.set('ccu')
      self.tenant_password.set(pp.result['password'])

  def refresh_saved_tenant_list(self):
    self.saved_tenant.set('')
    tenant_list = [F"{(self.root.vars.get(F't{i}_username') or tk.StringVar()).get()}@{(self.root.vars.get(F't{i}_name') or tk.StringVar()).get()}({(self.root.vars.get(F't{i}_datacenter') or tk.StringVar()).get()})" for i in range(1, max([int(x.split('_')[0][1:]) for x in self.root.vars.keys() if x.startswith('t') and x.endswith('_username')] or [1])+1) if (self.root.vars.get(F't{i}_cc') or tk.StringVar()).get() == False]
    self.saved_tenants_entry.configure(values=tenant_list)

  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()


if __name__ == "__main__":
  root = tk.Tk()
  root.title("Tenant OAuth Setup")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()