import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont
# from idlelib import tooltip
import getpass
from pathlib import Path
import sys, re

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try: from lib import slng_urls, data_centers, SLNG, StyledHovertip, Proteus_Picker, MySQL_Workbench, MySQL
except: 
  sys.path.append(LibPath.absolute().as_posix())
  from lib import slng_urls, data_centers, SLNG, StyledHovertip, Proteus_Picker, MySQL_Workbench, MySQL

getuser = getpass.getuser()

var_defaults = {
  'ad_username': getuser or "user.name",
  'ad_password': "",
  'db_username': "slng_user",
  'db_password': "",
  'db_host': "us3p-kube-minixx",
  'db_port': "3307",
  'mywb_name': "Auto Initialized Connection",
  'tenant_username': F"{getuser[0] + getuser.split('.')[-1]}-impl" if getuser else "user-impl",
  'tenant_password': "",
  'tenant_datacenter': list(data_centers.keys())[0],
  'tenant_name': "customer1",
  'tenant_cc': False,
  'ss_token': "",
}

class App(ttk.Frame):
  def __init__(self, parent): # Save global vars to the parent.vars dict to share with other pages/tools/modules
    ttk.Frame.__init__(self, parent)

    self.root = self.master.master or self.master

    _ = [self.columnconfigure(x, weight=1) for x in range(3)]
    self.rowconfigure(1, weight=1)

    # s = ttk.Style()
    # s.configure("Bold.TLabelframe.Label", font=("TkDefaultFont", 10, "bold"))
    # _ = [s.configure(F'{x.title()}.TButton', foreground=x) for x in ['green','red','blue']]

    
    # ALL save, refresh, delete frame
    self.all_save_refesh_delete_frame = ttk.Frame(self)
    self.all_save_refesh_delete_frame.grid(row=0, column=0, columnspan=99, padx=5, pady=5, sticky=tk.NSEW)
    # _ = [self.all_save_refesh_delete_frame.columnconfigure(x, weight=1) for x in range(4)]
    self.all_save_refesh_delete_frame.columnconfigure(0, weight=1)
    # Page Label # "DCDD Hub/Central/Mall/Station/Center",
    self.label = ttk.Label(self.all_save_refesh_delete_frame, text="Credentials & Config", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, padx=(10, 5), pady=10, sticky=tk.NW)
    # Save ALL, refresh ALL, delete ALL (from keyring) buttons
    self.save_all_button = ttk.Button(self.all_save_refesh_delete_frame, text="💾 Save ALL", style="Blue.TButton", command=lambda:[self.root.set_keyring_config()])
    self.save_all_button.grid(row=0, column=1, padx=(5,2), pady=5, sticky=tk.NE)
    self.refresh_all_button = ttk.Button(self.all_save_refesh_delete_frame, text="↻ Refresh ALL", style="Green.TButton", command=lambda:[self.root.get_keyring_config(), self.refresh_tenant_widgets()])
    self.refresh_all_button.grid(row=0, column=2, padx=2, pady=5, sticky=tk.NE)
    self.delete_all_button = ttk.Button(self.all_save_refesh_delete_frame, text="❌ Reset ALL", style="Red.TButton", command=lambda:[self.delete_config()])
    self.delete_all_button.grid(row=0, column=3, padx=(2,5), pady=5, sticky=tk.NE)
    # self.tt_save_all_button = 
    StyledHovertip(self.save_all_button, ' -- Save ALL Credentials & Config to the Keyring/Manager -- ')
    StyledHovertip(self.refresh_all_button, ' -- Refresh ALL Credentials & Config from the Keyring/Manager -- ')
    StyledHovertip(self.delete_all_button, ' -- Reset ALL Credentials & Config to Defaults -- ')

    self.notebook = ttk.Notebook(self)
    self.notebook.grid(row=1, column=0, columnspan=99, sticky=tk.NSEW)
    self.tab1 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab1, text='AD & Smartsheet')
    self.tab2 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab2, text='Database')
    self.tab3 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab3, text='Tenants')
    self.tab3.columnconfigure(0, weight=1)
    self.tab3.rowconfigure(0, weight=1)

    # Have separate non-joined columns
    self.tab1_column_frame1 = ttk.Frame(self.tab1)
    self.tab1_column_frame1.grid(row=1, column=0, padx=10, pady=10, sticky=tk.NSEW)
    self.tab1_column_frame1.columnconfigure(0, weight=1)

    self.tab1_column_frame2 = ttk.Frame(self.tab1)
    self.tab1_column_frame2.grid(row=1, column=1, padx=(10, 5), pady=10, sticky=tk.NSEW)
    self.tab1_column_frame2.columnconfigure(0, weight=1)

    # self.column_frame3 = ttk.Frame(self)
    # self.column_frame3.grid(row=1, column=2, padx=(10, 5), pady=10, sticky=tk.NSEW)
    # self.column_frame3.columnconfigure(0, weight=1)

    self.tab2_column_frame1 = ttk.Frame(self.tab2)
    self.tab2_column_frame1.grid(row=1, column=0, padx=10, pady=10, sticky=tk.NSEW)
    self.tab2_column_frame1.columnconfigure(0, weight=1)

    self.tab2_column_frame2 = ttk.Frame(self.tab2)
    self.tab2_column_frame2.grid(row=1, column=1, padx=(10, 5), pady=10, sticky=tk.NSEW)
    self.tab2_column_frame2.columnconfigure(0, weight=1)

    self.tab3_column_frame1 = ttk.Frame(self.tab3)
    self.tab3_column_frame1.grid(row=0, column=0, padx=10, pady=10, sticky=tk.NSEW)
    self.tab3_column_frame1.columnconfigure(0, weight=1)
    self.tab3_column_frame1.columnconfigure(1, weight=1)
    self.tab3_column_frame1.rowconfigure(1, weight=1) # Tenant Text only

    # --------------------
    # | Active Directory |
    # --------------------

    ad_vars = ['ad_username', 'ad_password']

    # Create a Frame for the Active Directory (AD) Creds
    self.ad_frame = ttk.LabelFrame(self.tab1_column_frame1, text="Active Directory", padding=(10, 5), style="Bold.TLabelframe")
    self.ad_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.EW)
    self.ad_frame.columnconfigure(0, weight=1)
    self.ad_frame.columnconfigure(1, weight=1)
    self.ad_frame.columnconfigure(2, weight=1)

    # AD Username 
    self.ad_u_label = ttk.Label(self.ad_frame, text="Username", justify="left")
    self.ad_u_label.grid(row=0, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get("ad_username"): self.root.vars["ad_username"] = tk.StringVar(value=var_defaults['ad_username'])
    self.ad_u_entry = ttk.Entry(self.ad_frame, textvariable=self.root.vars["ad_username"])
    self.ad_u_entry.grid(row=1, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)

    # AD Password 
    self.ad_p_label = ttk.Label(self.ad_frame, text="Password", justify="left")
    self.ad_p_label.grid(row=2, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get("ad_password"): self.root.vars["ad_password"] = tk.StringVar(value=var_defaults['ad_password'])
    self.ad_p_entry = ttk.Entry(self.ad_frame, show='*', textvariable=self.root.vars["ad_password"])
    self.ad_p_entry.grid(row=3, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)

    # Save, refresh, delete (from keyring) buttons
    self.ad_save_button = ttk.Button(self.ad_frame, text="💾", width=3, style="Blue.TButton", command=lambda:[self.root.set_keyring_config(ad_vars)])
    self.ad_save_button.grid(row=4, column=0, padx=(5,2), pady=5, sticky=tk.NSEW)
    self.ad_refresh_button = ttk.Button(self.ad_frame, text="↻", width=3, style="Green.TButton", command=lambda:[self.root.get_keyring_config(ad_vars)])
    self.ad_refresh_button.grid(row=4, column=1, padx=2, pady=5, sticky=tk.NSEW)
    self.ad_delete_button = ttk.Button(self.ad_frame, text="❌", width=3, style="Red.TButton", command=lambda:[self.delete_config(ad_vars)])
    self.ad_delete_button.grid(row=4, column=2, padx=(2,5), pady=5, sticky=tk.NSEW)
    StyledHovertip(self.ad_save_button, ' -- Save Only Active Directory Credentials & Config to the Keyring/Manager -- ')
    StyledHovertip(self.ad_refresh_button, ' -- Refresh Only Active Directory Credentials & Config from the Keyring/Manager -- ')
    StyledHovertip(self.ad_delete_button, ' -- Reset Only Active Directory Credentials & Config to Defaults -- ')

    # ------------
    # | Database |
    # ------------

    db_vars = ['db_username', "db_password", "db_host", 'db_port']

    # Create a Frame for the Database Creds
    self.db_frame = ttk.LabelFrame(self.tab2_column_frame1, text="Database", padding=(10, 5), style="Bold.TLabelframe")
    self.db_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.EW)
    self.db_frame.columnconfigure(0, weight=1)
    self.db_frame.columnconfigure(1, weight=1)
    self.db_frame.columnconfigure(2, weight=1)

    db_frame_row = 0

    # DB Username 
    self.db_u_label = ttk.Label(self.db_frame, text="Username", justify="left")
    self.db_u_label.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    db_frame_row += 1
    if not self.root.vars.get("db_username"): self.root.vars["db_username"] = tk.StringVar(value=var_defaults['db_username'])
    self.db_u_entry = ttk.Entry(self.db_frame, textvariable=self.root.vars["db_username"])
    self.db_u_entry.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)
    db_frame_row += 1

    # DB Password 
    self.db_p_label = ttk.Label(self.db_frame, text="Password", justify="left")
    self.db_p_label.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    db_frame_row += 1
    if not self.root.vars.get("db_password"): self.root.vars["db_password"] = tk.StringVar(value=var_defaults['db_password'])
    self.db_p_entry = ttk.Entry(self.db_frame, show='*', textvariable=self.root.vars["db_password"])
    self.db_p_entry.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)
    db_frame_row += 1

    # DB Host 
    self.db_h_label = ttk.Label(self.db_frame, text="Host", justify="left")
    self.db_h_label.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    db_frame_row += 1
    if not self.root.vars.get("db_host"): self.root.vars["db_host"] = tk.StringVar(value=var_defaults['db_host'])
    self.db_h_entry = ttk.Entry(self.db_frame, textvariable=self.root.vars["db_host"])
    self.db_h_entry.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)
    db_frame_row += 1

    # DB Port 
    self.db_pt_label = ttk.Label(self.db_frame, text="Port", justify="left")
    self.db_pt_label.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    db_frame_row += 1
    if not self.root.vars.get("db_port"): self.root.vars["db_port"] = tk.StringVar(value=var_defaults['db_port'])
    self.db_pt_entry = ttk.Entry(self.db_frame, textvariable=self.root.vars["db_port"])
    self.db_pt_entry.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)
    db_frame_row += 1

    # Save, refresh, delete (from keyring) buttons
    self.db_save_button = ttk.Button(self.db_frame, text="💾", width=3, style="Blue.TButton", command=lambda:[self.root.set_keyring_config(db_vars)])
    self.db_save_button.grid(row=db_frame_row, column=0, padx=(5,2), pady=5, sticky=tk.NSEW)
    self.db_refresh_button = ttk.Button(self.db_frame, text="↻", width=3, style="Green.TButton", command=lambda:[self.root.get_keyring_config(db_vars)])
    self.db_refresh_button.grid(row=db_frame_row, column=1, padx=2, pady=5, sticky=tk.NSEW)
    self.db_delete_button = ttk.Button(self.db_frame, text="❌", width=3, style="Red.TButton", command=lambda:[self.delete_config(db_vars)])
    self.db_delete_button.grid(row=db_frame_row, column=2, padx=(2,5), pady=5, sticky=tk.NSEW)
    db_frame_row += 1
    StyledHovertip(self.db_save_button, ' -- Save Only Database Credentials & Config to the Keyring/Manager -- ')
    StyledHovertip(self.db_refresh_button, ' -- Refresh Only Database Credentials & Config from the Keyring/Manager -- ')
    StyledHovertip(self.db_delete_button, ' -- Reset Only Database Credentials & Config to Defaults -- ')

    # Test DB Connection
    self.db_test_button = ttk.Button(self.db_frame, text="Test Connection", command=self.test_db_connection)
    self.db_test_button.grid(row=db_frame_row, column=0, columnspan=3, padx=5, pady=5, sticky=tk.NSEW)
    db_frame_row += 1

    # --------
    # | SLNG |
    # --------

    # Create a Frame for the SLNG stuff
    self.slng_frame = ttk.LabelFrame(self.tab2_column_frame2, text="SLNG", padding=(10, 5), style="Bold.TLabelframe")
    self.slng_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.EW)
    self.slng_frame.columnconfigure(0, weight=1)
    self.slng_frame.columnconfigure(1, weight=1)
    # self.slng_frame.columnconfigure(2, weight=1)

    # SLNG URL
    self.slng_url_label = ttk.Label(self.slng_frame, text="URL", justify="left")
    self.slng_url_label.grid(row=2, column=0, columnspan=2, padx=5, pady=0, sticky=tk.EW)
    slng_url_var = tk.StringVar()
    self.slng_url_combo = ttk.Combobox(self.slng_frame, textvariable=slng_url_var, values=slng_urls)
    slng_url_var.set(SLNG.base_slng_url())    
    # self.slng_url_combo.current(0)
    self.slng_url_combo.bind('<Configure>', self.on_combo_configure)
    self.slng_url_combo.grid(row=3, column=0, columnspan=2, padx=5, pady=(0, 5), sticky=tk.EW)

    # Import SLNG DB Info
    self.slng_import_button = ttk.Button(self.slng_frame, text="⬅️", width=3, style="Blue.TButton", command=lambda:[get_slng_db_info()])
    self.slng_import_button.grid(row=5, column=0, padx=5, pady=5, sticky=tk.NSEW)
    StyledHovertip(self.slng_import_button, ' -- Copy SLNG Host and Port to the Database    \n    Configuration (uses AD credentials) -- ')

    def get_slng_db_info():
      if all([self.root.vars["ad_username"].get(), self.root.vars["ad_username"].get(), slng_url_var.get()]):
        db_info = SLNG(password=self.root.vars['ad_password'].get(), mysql_password=self.root.vars['db_password'].get() or 'myDbPassword', url=slng_url_var.get()).get_db_endpoint()
        # print(db_info)
        self.root.vars['db_host'].set(db_info['mysqlHost'])
        self.root.vars['db_port'].set(db_info['mysqlPort'])

    self.slng_db_password_button = ttk.Button(self.slng_frame, text="🗝️", width=3, style="Blue.TButton", command=lambda:[set_slng_db_password()])
    self.slng_db_password_button.grid(row=5, column=1, padx=5, pady=5, sticky=tk.NSEW)
    StyledHovertip(self.slng_db_password_button, ' -- Set the slng_user DB Password in SLNG    \n    (uses current DB password & AD credentials) -- ')

    def set_slng_db_password():
      if all([self.root.vars["ad_username"].get(), self.root.vars["ad_username"].get(), slng_url_var.get()]):
        try:
          result = SLNG(password=self.root.vars['ad_password'].get(), mysql_password=self.root.vars['db_password'].get() or 'myDbPassword', url=slng_url_var.get()).set_db_password()
        except Exception as e:
          result = e
        messagebox.showinfo(title='SLNG DB Password', message=F"Set SLNG DB Password: \n{result}")
        # print(result)

    if SLNG.base_slng_url() == "Unknown Location": # Hide on VCR
      self.slng_suv_frame = ttk.Frame(self.slng_frame)
      self.slng_suv_frame.grid(row=4, column=0, columnspan=2, sticky=tk.EW)

      self.slng_suv_button = ttk.Button(self.slng_suv_frame, text="Proteus Picker", command=lambda:[get_proteus_suv_url()])
      self.slng_suv_button.grid(row=0, column=0, padx=5, pady=5, sticky=tk.EW)
      self.slng_suv_port_var = tk.StringVar()
      self.slng_suv_port_combo = ttk.Combobox(self.slng_suv_frame, textvariable=self.slng_suv_port_var, values=('3443', '4001'), width=4)
      self.slng_suv_port_combo.current(0)
      self.slng_suv_port_combo.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)

    def get_proteus_suv_url():
      pp = Proteus_Picker(self.root, self.root.winfo_pointerxy()) # Use the root object with the cred/config vars.
      if not pp.error: self.wait_window(pp.top)
      if pp.result:
        slng_url_var.set(F'{pp.result['url']}:{self.slng_suv_port_var.get()}')

    # -------------------
    # | MySQL Workbench |
    # -------------------
        
    # Create a Frame for the MySQL Workbench stuff
    self.mywb_frame = ttk.LabelFrame(self.tab2_column_frame2, text="Mysql Workbench", padding=(10, 5), style="Bold.TLabelframe")
    self.mywb_frame.grid(row=1, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.EW)
    self.mywb_frame.columnconfigure(0, weight=1)
    self.mywb_frame.columnconfigure(1, weight=1)

    self.mywb_name_label = ttk.Label(self.mywb_frame, text="Connection Name", justify="left")
    self.mywb_name_label.grid(row=0, column=0, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get("mywb_name"): self.root.vars["mywb_name"] = tk.StringVar(value=var_defaults['mywb_name'])
    self.mywb_name_entry = ttk.Entry(self.mywb_frame, textvariable=self.root.vars["mywb_name"])
    self.mywb_name_entry.grid(row=1, column=0, padx=5, pady=(0, 5), sticky=tk.EW)

    self.mywb_update_button = ttk.Button(self.mywb_frame, text="Set Connection", command=lambda:[update_connection()])
    self.mywb_update_button.grid(row=2, column=0, padx=5, pady=5, sticky=tk.NSEW)
    StyledHovertip(self.mywb_update_button, ' -- Create an Auto Initialized Connection   \n    in MySQL Workbench with DB creds -- ')

    self.run_mywb_switch = ttk.Checkbutton(self.mywb_frame, text="Run", style="Switch.TCheckbutton")
    self.run_mywb_switch.grid(row=1, column=1, padx=5, pady=5)
    self.run_mywb_switch.state(['selected'])
    StyledHovertip(self.run_mywb_switch, ' -- Run MySQL Workbench   \n    after creating/updating the connection -- ')

    self.kill_mywb_switch = ttk.Checkbutton(self.mywb_frame, text="Close", style="Switch.TCheckbutton")
    self.kill_mywb_switch.grid(row=2, column=1, padx=5, pady=5)
    self.kill_mywb_switch.state(['!selected'])
    StyledHovertip(self.kill_mywb_switch, ' -- Close MySQL Workbench if running   \n    while creating/updating the connection -- ')

    def update_connection():
      self.mywb_update_button.configure(state=tk.DISABLED)
      self.update_idletasks()
      mywb = MySQL_Workbench(
        host=self.root.vars['db_host'].get(), 
        port=self.root.vars['db_port'].get(), 
        user=self.root.vars['db_username'].get(), 
        passwd=self.root.vars['db_password'].get()
      )
      name = self.root.vars["mywb_name"].get()
      run = self.run_mywb_switch.instate(['selected'])
      kill = self.kill_mywb_switch.instate(['selected'])
      if mywb.is_running() and not kill:
        messagebox.showerror(title='MySQL Workbench', message='MySQL Workbench is running, cannot update connection.')
        self.mywb_update_button.configure(state=tk.NORMAL)
        return
      else:
        result = mywb.update_connections(name=name, run=run, kill=kill)
        if result: messagebox.showinfo(title='MySQL Workbench', message=result)
        if not run and not result:
          messagebox.showinfo(title='MySQL Workbench', message='MySQL Workbench connection updated.')
      self.mywb_update_button.configure(state=tk.NORMAL)

    # -----------
    # | Tenants |
    # -----------

    # Tenant Button Frame
    self.tenants_button_frame = ttk.Frame(self.tab3_column_frame1)
    self.tenants_button_frame.grid(row=0, column=0, padx=0, pady=0, sticky=tk.W)
    # Save, Refresh and Reset All Tenant Buttons
    self.tenants_save_button = ttk.Button(self.tenants_button_frame, text="💾 Save All Tenants", style="Blue.TButton", command=lambda:[self.root.set_keyring_config(tenant_only=True)])
    self.tenants_save_button.grid(row=0, column=0, padx=(5,2), pady=5, sticky=tk.W)
    StyledHovertip(self.tenants_save_button, ' -- Save All (Current) Tenant Credentials & Config to the Keyring/Manager (Removing All Previous Saves) -- ')
    self.tenants_refresh_button = ttk.Button(self.tenants_button_frame, text="↻ Refresh All Tenants", style="Green.TButton", command=lambda:[self.refresh_tenant_widgets()])
    self.tenants_refresh_button.grid(row=0, column=1, padx=(5,2), pady=5, sticky=tk.W)
    StyledHovertip(self.tenants_refresh_button, ' -- Refresh All Tenant Credentials & Config from the Keyring/Manager (Removes All and Recreates) -- ')
    self.tenants_reset_button = ttk.Button(self.tenants_button_frame, text="❌ Reset All Tenants", style="Red.TButton", command=lambda:[self.reset_tenant_widgets()])
    self.tenants_reset_button.grid(row=0, column=2, padx=2, pady=5, sticky=tk.W)
    StyledHovertip(self.tenants_reset_button, ' -- Reset (Remove) All Tenant Credentials & Config to Single Default -- ')
    # import from proteus button
    self.tenants_import_button = ttk.Button(self.tenants_button_frame, text="Import from Proteus", command=lambda:[self.import_pp_tenant()])
    self.tenants_import_button.grid(row=0, column=3, padx=(5,2), pady=5, sticky=tk.W)
    StyledHovertip(self.tenants_import_button, ' -- Import Tenants from Proteus (Adds a new tenant) -- ')

    # Text Area for the tenant widgets
    self.tenants_text = tk.Text(self.tab3_column_frame1, wrap=tk.WORD, bd=0, highlightthickness=0, borderwidth=0, cursor='arrow') # height=1, width=1)
    self.tenants_text.configure(selectbackground=self.tenants_text.cget('bg'), inactiveselectbackground=self.tenants_text.cget('bg'))
    self.tenants_text.grid(row=1, column=0, padx=0, pady=0, sticky=tk.NSEW)

    self.tenant_widgets = []

    self.refresh_tenant_widgets()

    # # See how many saved tenants we have and get max (or default to 1)
    # max_tenant = max([int(x.split('_')[0][1:]) for x in self.root.vars.keys() if x.startswith('t') and x.endswith('_username')] or [1])

    # # Create a tenant widget for each tenant up to the max
    # for i in range(1, max_tenant+1):
    #   self.tenant_widgets.append(self.create_tenant_widget(i))

    # # Insert the tenant widgets into the text area
    # for t in self.tenant_widgets:
    #   self.tenants_text.window_create(tk.END, window=t, padx=5, pady=5)
    # # self.tenants_text.insert(tk.END, 'ID')

    # # Add a create new tenant button into the text widget
    # self.new_tenant_button = ttk.Button(self.tenants_text, text="➕", width=5, style="Blue.TButton", command=lambda:[self.tenant_widgets.append(self.create_tenant_widget(len(self.tenant_widgets)+1)), self.tenants_text.window_create(self.tenants_text.index('end-2c'), window=self.tenant_widgets[-1], padx=5, pady=5)])
    # self.tenants_text.window_create(tk.END, window=self.new_tenant_button, padx=5, pady=5)

    # self.tenants_text.config(state=tk.DISABLED) 

    # --------------
    # | Smartsheet |
    # --------------

    ss_vars = ['ss_token']

    # Create a Frame for the Smartsheet Creds
    self.ss_frame = ttk.LabelFrame(self.tab1_column_frame2, text="Smartsheet", padding=(10, 5), style="Bold.TLabelframe")
    self.ss_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.EW)
    self.ss_frame.columnconfigure(0, weight=1)
    self.ss_frame.columnconfigure(1, weight=1)
    self.ss_frame.columnconfigure(2, weight=1)

    # SS Token 
    self.ss_t_label = ttk.Label(self.ss_frame, text="Token", justify="left")
    self.ss_t_label.grid(row=2, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get("ss_token"): self.root.vars["ss_token"] = tk.StringVar(value=var_defaults['ss_token'])
    self.ss_t_entry = ttk.Entry(self.ss_frame, show='*', textvariable=self.root.vars["ss_token"])
    self.ss_t_entry.grid(row=3, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)

    # Save, refresh, delete (from keyring) buttons
    self.ss_save_button = ttk.Button(self.ss_frame, text="💾", width=3, style="Blue.TButton", command=lambda:[self.root.set_keyring_config(ss_vars)])
    self.ss_save_button.grid(row=4, column=0, padx=(5,2), pady=5, sticky=tk.NSEW)
    self.ss_refresh_button = ttk.Button(self.ss_frame, text="↻", width=3, style="Green.TButton", command=lambda:[self.root.get_keyring_config(ss_vars)])
    self.ss_refresh_button.grid(row=4, column=1, padx=2, pady=5, sticky=tk.NSEW)
    self.ss_delete_button = ttk.Button(self.ss_frame, text="❌", width=3, style="Red.TButton", command=lambda:[self.delete_config(ss_vars)])
    self.ss_delete_button.grid(row=4, column=2, padx=(2,5), pady=5, sticky=tk.NSEW)
    StyledHovertip(self.ss_save_button, ' -- Save Only Smartsheet Credentials & Config to the Keyring/Manager -- ')
    StyledHovertip(self.ss_refresh_button, ' -- Refresh Only Smartsheet Credentials & Config from the Keyring/Manager -- ')
    StyledHovertip(self.ss_delete_button, ' -- Reset Only Smartsheet Credentials & Config to Defaults -- ')

  def refresh_tenant_widgets(self):
    # Destroy tenant widgets
    for t in self.tenant_widgets:
      for v in t.vars:
        # remove var from root.vars
        self.root.vars.pop(v, None)
      t.destroy()
    # Clear the text widget
    self.tenants_text.config(state=tk.NORMAL)
    self.tenants_text.delete('1.0', tk.END)

    self.tenant_widgets = []

    # Restore just the tenant vars
    self.root.get_keyring_config(tenant_only=True)

    # See how many saved tenants we have and get max (or default to 1)
    max_tenant = max([int(x.split('_')[0][1:]) for x in self.root.vars.keys() if x.startswith('t') and x.endswith('_username')] or [1])

    # Create a tenant widget for each tenant up to the max
    for i in range(1, max_tenant+1):
      self.tenant_widgets.append(self.create_tenant_widget(i))

    # Insert the tenant widgets into the text area
    for t in self.tenant_widgets:
      self.tenants_text.window_create(tk.END, window=t, padx=5, pady=5)
    # self.tenants_text.insert(tk.END, 'ID')

    # Add a create new tenant button into the text widget
    self.new_tenant_button = ttk.Button(self.tenants_text, text="➕", width=5, style="Blue.TButton", command=lambda:[self.tenant_widgets.append(self.create_tenant_widget(len(self.tenant_widgets)+1)), self.tenants_text.window_create(self.tenants_text.index('end-2c'), window=self.tenant_widgets[-1], padx=5, pady=5)])
    self.tenants_text.window_create(tk.END, window=self.new_tenant_button, padx=5, pady=5)

    self.tenants_text.config(state=tk.DISABLED) 

  def import_pp_tenant(self):
    pp = Proteus_Picker(self.root, self.root.winfo_pointerxy())
    if not pp.error: self.wait_window(pp.top)
    if pp.result:
      tw = self.create_tenant_widget(
        index=len(self.tenant_widgets)+1,
        username='ccu',
        password=pp.result['password'],
        datacenter=pp.result['url'],
        name='super'
      )
      self.tenant_widgets.append(tw)
      self.tenants_text.window_create(self.tenants_text.index('end-2c'), window=tw, padx=5, pady=5)

  def reset_tenant_widgets(self):
    for t in self.tenant_widgets:
      for v in t.vars:
        # remove var from root.vars
        self.root.vars.pop(v, None)
      t.destroy()
    self.tenant_widgets = [self.create_tenant_widget(1)]
    self.tenants_text.window_create(self.tenants_text.index('end-2c'), window=self.tenant_widgets[-1], padx=5, pady=5)

  def create_tenant_widget(self, index, username=None, password=None, datacenter=None, name=None, cc=None):
    tenant_vars = [F't{index}_username', F't{index}_password', F't{index}_datacenter', F't{index}_name', F't{index}_cc']

    # Create a Frame for the Tenant Creds
    tenant_frame = ttk.LabelFrame(self.tenants_text, text=F"Tenant {index}", padding=(10, 5), style="Bold.TLabelframe")
    tenant_frame.vars = tenant_vars
    # Don't add to frame as it will be inserted later into the text widget
    # tenant_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.EW)
    tenant_frame.columnconfigure(0, weight=1)
    tenant_frame.columnconfigure(1, weight=1)
    tenant_frame.columnconfigure(2, weight=1)

    # Tenant Username 
    tenant_u_label = ttk.Label(tenant_frame, text="Username", justify="left")
    tenant_u_label.grid(row=0, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get(F"t{index}_username"): self.root.vars[F"t{index}_username"] = tk.StringVar(value=var_defaults[F'tenant_username'] if not username else username)
    tenant_u_entry = ttk.Entry(tenant_frame, textvariable=self.root.vars[F"t{index}_username"])
    tenant_u_entry.grid(row=1, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)

    # Tenant Password 
    tenant_p_label = ttk.Label(tenant_frame, text="Password", justify="left")
    tenant_p_label.grid(row=2, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get(F"t{index}_password"): self.root.vars[F"t{index}_password"] = tk.StringVar(value=var_defaults[F'tenant_password'] if not password else password)
    tenant_p_entry = ttk.Entry(tenant_frame, show='*', textvariable=self.root.vars[F"t{index}_password"])
    tenant_p_entry.grid(row=3, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)

    # Tenant Datacenter 
    tenant_dc_label = ttk.Label(tenant_frame, text="Datacenter", justify="left")
    tenant_dc_label.grid(row=4, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get(F"t{index}_datacenter"): self.root.vars[F"t{index}_datacenter"] = tk.StringVar(value=var_defaults[F'tenant_datacenter'] if not datacenter else datacenter)
    tenant_dc_combo = ttk.Combobox(tenant_frame, textvariable=self.root.vars[F"t{index}_datacenter"], values=list(data_centers.keys()))
    # tenant_dc_combo.current(0)
    tenant_dc_combo.bind('<Configure>', self.on_combo_configure)
    tenant_dc_combo.grid(row=5, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)
    
    # Tenant Name 
    tenant_n_label = ttk.Label(tenant_frame, text="Tenant Name", justify="left")
    tenant_n_label.grid(row=6, column=0, columnspan=3, padx=5, pady=0, sticky=tk.EW)
    if not self.root.vars.get(F"t{index}_name"): self.root.vars[F"t{index}_name"] = tk.StringVar(value=var_defaults[F'tenant_name'] if not name else name)
    tenant_n_entry = ttk.Entry(tenant_frame, textvariable=self.root.vars[F"t{index}_name"])
    tenant_n_entry.grid(row=7, column=0, columnspan=3, padx=5, pady=(0, 5), sticky=tk.EW)

    # Tenant Customer Central
    if not self.root.vars.get(F"t{index}_cc"): self.root.vars[F"t{index}_cc"] = tk.BooleanVar(value=var_defaults[F'tenant_cc'] if cc is None else cc)
    tenant_cc_switch = ttk.Checkbutton(tenant_frame, text="Is Customer Central", variable=self.root.vars[F"t{index}_cc"], style="Switch.TCheckbutton",
      command=lambda:[self.root.vars[F"t{index}_name"].set('customercentral') if self.root.vars[F"t{index}_cc"].get() and not self.root.vars[F"t{index}_name"].get() and 'workdaysuv' in self.root.vars[F"t{index}_datacenter"].get() else None])
    tenant_cc_switch.grid(row=8, columnspan=3, column=0, padx=5, pady=5, sticky=tk.EW)
    if self.root.vars[F"t{index}_cc"].get():
      tenant_cc_switch.state(['selected'])
    else:
      tenant_cc_switch.state(['!selected'])

    # Save, refresh, delete (from keyring) buttons
    tenant_save_button = ttk.Button(tenant_frame, text="💾", width=3, style="Blue.TButton", command=lambda:[self.root.set_keyring_config(tenant_frame.vars)])
    tenant_save_button.grid(row=9, column=0, padx=(5,2), pady=5, sticky=tk.NSEW)
    tenant_refresh_button = ttk.Button(tenant_frame, text="↻", width=3, style="Green.TButton", command=lambda:[self.root.get_keyring_config(tenant_frame.vars)])
    tenant_refresh_button.grid(row=9, column=1, padx=2, pady=5, sticky=tk.NSEW)
    tenant_delete_button = ttk.Button(tenant_frame, text="❌", width=3, style="Red.TButton", command=lambda:[self.delete_config(tenant_frame.vars)])
    tenant_delete_button.grid(row=9, column=2, padx=(2,5), pady=5, sticky=tk.NSEW)
    StyledHovertip(tenant_save_button, F' -- Save Only Tenant {index} Credentials & Config to the Keyring/Manager -- ')
    StyledHovertip(tenant_refresh_button, F' -- Refresh Only Tenant {index} Credentials & Config from the Keyring/Manager -- ')
    StyledHovertip(tenant_delete_button, F' -- Remove Only Tenant {index} Credentials & Config -- ')

    return tenant_frame

  def test_db_connection(self):
    db_vars = ['db_username', "db_password", "db_host", 'db_port']
    if not all(self.root.vars[x].get() for x in db_vars):
      messagebox.showerror(title='Database Connection', message='Please fill out all Database fields.')
      return
    m = MySQL(user=self.root.vars['db_username'].get(), passwd=self.root.vars['db_password'].get(), host=self.root.vars['db_host'].get(), port=self.root.vars['db_port'].get())
    try:
      m.connect()
    except Exception as e:
      messagebox.showerror(title='Database Connection', message='Failed to connect to the Database with provided credentials.\n\n' + str(e))
    else:
      messagebox.showinfo(title='Database Connection', message='Successfully connected to the Database!')

  def delete_config(self, items=[]): # restore defaults
    # print(items or var_defaults.keys())
    for i in (items if items else var_defaults):
      # print(i, end=': ')
      if not i.startswith('tenant_'):
        # self.root.vars[i].set(var_defaults[i])
        # print(var_defaults[re.sub(r'^t\d+', 'tenant', i)])
        self.root.vars[i].set(var_defaults[re.sub(R'^t\d+', 'tenant', i)])
    if all([re.match(R'^t\d+_', x) for x in items]): # Reset Tenant pressed so remove tenant vars and tenant widget
      for t in self.tenant_widgets:
        if items == t.vars:
          for v in t.vars:
            # remove var from root.vars
            self.root.vars.pop(v, None)
          t.destroy()
          self.tenant_widgets.remove(t)
          break
      # Reorder the remaining tenant widgets
      for i, t in enumerate(self.tenant_widgets, 1):
        orig_tvars = t.vars
        t.config(text=F"Tenant {i}")
        t.vars = [re.sub(R'^t\d+', F't{i}', x) for x in t.vars]
        # Swap root.var names and values
        for v in orig_tvars:
          self.root.vars[F't{i}_{v.split("_", 1)[1]}'] = self.root.vars.pop(v, None)
    if not items: # Reset ALL pressed so remove tenant vars and tenant widgets
      self.reset_tenant_widgets()

  def on_combo_configure(self, event):
    style = ttk.Style()
    # check if the combobox already has the "postoffest" property
    current_combo_style = event.widget.cget('style') or "TCombobox"
    # if len(style.lookup(current_combo_style, 'postoffset'))>0:
    #     return
    combo_values = event.widget.cget('values')
    if len(combo_values) == 0:
        return
    longest_value = max(combo_values, key=len)
    # try:
    #   font = tkfont.nametofont(str(event.widget.cget('font')))
    # except:
    #   font = tkfont.nametofont("TkDefaultFont")
    font = tkfont.Font(font=event.widget.cget('font'))
    offset_width = font.measure(longest_value + "000") - (event.width)
    # print(longest_value, font.measure(longest_value + "000"), event.width, offset_width, event.widget.winfo_width())
    if (offset_width<0):
        # no need to make the popdown smaller
        return
    # create an unique style name using widget's id
    unique_name=F'Combobox{event.widget.winfo_id()}'
    # the new style must inherit from curret widget style (unless it's our custom style!) 
    if unique_name in current_combo_style:
        style_name = current_combo_style 
    else:
        style_name = F"{unique_name}.{current_combo_style}"
    style.configure(style_name, postoffset=(-offset_width//2,0,offset_width,0))
    event.widget.configure(style=style_name)


if __name__ == "__main__":
  root = tk.Tk()
  root.title("")

  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 'ad_password':tk.StringVar(value=dict_config.get('ad_password'))}

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()