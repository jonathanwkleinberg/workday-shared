import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import sys, json
import threading
import webbrowser
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import Proteus_Picker, Proteus, Jenkins, StyledHovertip, SLNG
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import Proteus_Picker, Proteus, Jenkins, StyledHovertip, SLNG

class App(ttk.Frame):

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(0, weight=1)
    self.rowconfigure(99, weight=1) # Expand Log Window

    # Label
    self.label = ttk.Label(self, text="Proteus Helper", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)

    # Picker Button
    self.slng_suv_button = ttk.Button(self, text="Proteus Picker", command=lambda: self.get_proteus_suv_url())
    self.slng_suv_button.grid(row=1, column=0, columnspan=98, padx=5, pady=5, sticky=tk.W)

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=2, column=0, columnspan=99, padx=(0,5), pady=5, sticky=tk.NW)

    # SUV Items (label_text: has_url)
    self.suv_items = {
      "Instance ID": False,
      "Tenants": True,
      "Proteus URL": True,
      "SUV Password": False,
      "Install SLNG Version": False,
      "Setup Data Centers": False,
      "SLNG POD": True,
      "Description": False,
      "Stage": False,
    }
    self.suv_items_vars = {x:tk.StringVar() if x != 'Tenants' else [] for x in self.suv_items}
    # Place SUV Items
    for i, suv_item in enumerate(self.suv_items):
      label_text = suv_item
      has_url = self.suv_items[suv_item]
      label = ttk.Label(self.config_frame, text=F"{label_text}:")
      label.grid(row=i, column=0, padx=5, pady=5, sticky=tk.W)
      if label_text == "Tenants":
        self.tenant_text = tk.Text(self.config_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
        self.tenant_text.configure(selectbackground=self.tenant_text.cget('bg'), inactiveselectbackground=self.tenant_text.cget('bg'))
        self.tenant_text.grid(row=i, column=1, padx=5, pady=5, sticky=tk.EW)
      elif label_text == "Install SLNG Version":
        subframe = ttk.Frame(self.config_frame)
        subframe.grid(row=i, column=1, padx=5, pady=5, sticky=tk.W)
        self.suv_items_vars[label_text].set('rc-2024.09')
        version = ttk.Entry(subframe, textvariable=self.suv_items_vars[label_text])
        version.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        install = ttk.Button(subframe, text='Install (Jenkins)', command=self.install_slng)
        install.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        StyledHovertip(install, "-- Install SLNG Pod on SUV (will overwrite existing Pod if already installed) --")
      elif label_text == "Setup Data Centers":
        subframe = ttk.Frame(self.config_frame)
        subframe.grid(row=i, column=1, padx=5, pady=5, sticky=tk.W)
        sales = ttk.Button(subframe, text='Sales', command=self.set_sales_data_centers)
        sales.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        StyledHovertip(sales, "-- Setup Sales Data Centers on SUV --")
        suv = ttk.Button(subframe, text='SUV', command=self.set_suv_data_center)
        suv.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        StyledHovertip(suv, "-- Setup SUV Data Center on SUV --")
      elif label_text in ("Description", "Stage"): # Description/Stage
        subframe = ttk.Frame(self.config_frame)
        subframe.grid(row=i, column=1, padx=5, pady=5, sticky=tk.W)
        desc = ttk.Entry(subframe, textvariable=self.suv_items_vars[label_text])
        desc.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        update = ttk.Button(subframe, text='Update', command=self.update_description)
        update.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
      else:
        link_label = ttk.Label(self.config_frame, cursor='hand1' if has_url else None, textvariable=self.suv_items_vars[label_text], style='Link.TLabel' if has_url else None, name=label_text.lower())
        link_label.grid(row=i, column=1, padx=5, pady=5, sticky=tk.W)
        if has_url:
          link_label.bind("<ButtonRelease-1>", lambda e: [webbrowser.open_new_tab(e.widget['text'])] if e.widget['text'] else [])
        else:
          link_label.bind("<ButtonRelease-1>", lambda e: [self.clipboard_clear(), self.clipboard_append(e.widget['text']), self.write(F" -- Copied {str(e.widget).split(".")[-1]} to clipboard -- ")] if e.widget['text'] else [])
        link_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [self.clipboard_clear(), self.clipboard_append(e.widget['text']), self.write(F" -- Copied {str(e.widget).split(".")[-1]} to clipboard -- ")] if e.widget['text'] else [])

    self.text_log = ttk.LabelFrame(self, text="Log", style="Bold.TLabelframe")
    self.text_log.grid(row=99, column=0, columnspan=98, padx=5, pady=(5,0), sticky=tk.NSEW)
    self.text_log.columnconfigure(0, weight=1)
    self.text_log.rowconfigure(0, weight=1)
    self.textbox = tk.Text(self.text_log, height=10, wrap="word", state="disabled", relief='flat') # width=50, 
    self.textbox.grid(column=0, row=0, sticky=tk.NSEW, padx=5, pady=5)
    self.text_scroll = tk.ttk.Scrollbar(self, command=self.textbox.yview)
    self.text_scroll.grid(row=99, column=99, pady=(12,5), sticky=tk.NSEW)
    self.textbox['yscrollcommand'] = self.text_scroll.set
    self.textbox.tag_configure("stderr", foreground="#b22222")
    self.textbox.tag_configure("messages", foreground="#22b222")
    self.textbox.bind("<1>", lambda event: self.textbox.focus_set())

    # self.write('this', 'is', 'a', 'test')
    # print('this', 'is', 'a', 'test')


  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()

  def write(self, *args, tag=None, end='\n'):
    string = ' '.join([str(x) for x in args]) + end
    widget = self.textbox
    widget.configure(state=tk.NORMAL)
    move = widget.yview()[1] >= 1
    widget.insert(tk.END, string, "stdout" if not tag else tag)
    if move: widget.see(tk.END)
    # if int(float(widget.index(tk.END))) > 1000:
    #   widget.delete( 1.0, float(int(float(widget.index(tk.END))) - 1000)  )
    widget.configure(state=tk.DISABLED)

  def get_proteus_suv_url(self):
    pp = Proteus_Picker(self.root, x_y=self.root.winfo_pointerxy()) # Use the root object with the cred/config vars.
    self.wait_window(pp.top)
    if pp.result:
      prot_url = f"https://wd5-suv.megaleo.com/proteus/projects/{pp.result.get('wdAdditionalTags', {}).get('projectName')}/pools/{pp.result.get('wdAdditionalTags', {}).get('poolName')}/suvs/{pp.result.get('instanceId')}"
      populate = {
        "Instance ID": pp.result.get('instanceId'),
        "Tenants": pp.result.get('wdTenants'),
        "Proteus URL": prot_url,
        "SUV Password": pp.result.get('password'),
        "SLNG POD": F"{pp.result.get('url')}:3443",
        "Description": pp.result.get('description'),
        "Stage": pp.result.get('poolStage'),
      }
      for x in populate:
        if x == "Tenants":
          self.tenant_text.delete('1.0', tk.END)
          for t in populate[x]:
            label = ttk.Label(self.tenant_text, cursor='hand1', text=t, style='Link.TLabel')
            label.bind("<ButtonRelease-1>", lambda e: [webbrowser.open_new_tab(F"{pp.result.get('url')}/{e.widget['text']}/")] if e.widget['text'] else [])
            label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [self.clipboard_clear(), self.clipboard_append(F"{pp.result.get('url')}/{e.widget['text']}/"), self.write(F" -- Copied Tenant URL ({e.widget['text']}) to clipboard -- ")] if e.widget['text'] else [])
            self.tenant_text.window_create(tk.END, window=label, padx=2)
        else:
          self.suv_items_vars[x].set(populate[x])
      self.write(json.dumps(pp.result, indent=2))

  def update_description(self):
    iid = self.suv_items_vars["Instance ID"].get()
    desc = self.suv_items_vars["Description"].get()
    stag = self.suv_items_vars["Stage"].get()
    if all([iid, desc]):
      p = Proteus(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
      r = p.set_description_stage_by_id(iid, desc, stag)
      self.write(r)
    else:
      self.write(" -- Missing Instance ID or Description -- ")

  def install_slng(self):
    iid = self.suv_items_vars["Instance ID"].get()
    version = self.suv_items_vars["Install SLNG Version"].get()
    if not all([iid, version]):
      self.write(" -- Missing Instance ID or Version -- ")
      return
    j = Jenkins(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
    try:
      r = j.build_job_with_params('SLNG_SUV', {'SUV_HOST':iid, 'BUILD_VERSION':version})
      self.write(F"{r.status_code}: {r.reason} ({r.headers.get('Location', '')})")
    except Exception as e:
      self.write(e)

  def set_sales_data_centers(self):
    slng_url = self.suv_items_vars["SLNG POD"].get()
    if not slng_url:
      self.write(" -- Missing SLNG POD -- ")
      return
    self.write(" -- Setting Sales Data Centers -- ")
    s = SLNG(url=slng_url)
    r = s.set_sales_data_centers()
    self.write(r)

  def set_suv_data_center(self):
    slng_url = self.suv_items_vars["SLNG POD"].get()
    if not slng_url:
      self.write(" -- Missing SLNG POD -- ")
      return
    self.write(" -- Setting SUV Data Center -- ")
    s = SLNG(url=slng_url)
    r = s.set_suv_data_center()
    self.write(r)

if __name__ == "__main__":
  root = tk.Tk()
  root.title("Proteus Helper")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()