import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import tkinter.font as tkfont
from pathlib import Path
import sys, os, json, re, csv, io
import threading
import concurrent.futures
import webbrowser
import platform
from datetime import datetime
import traceback

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import WSDL, GitHub, SmartsheetLib, Smartsheet_Picker, data_centers, StyledHovertip, DifflibParser, DiffCode, TextRedirector
  from FileDiff import App as DiffApp
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import WSDL, GitHub, SmartsheetLib, Smartsheet_Picker, data_centers, StyledHovertip, DifflibParser, DiffCode, TextRedirector
  sys.path.append(CurrentPath.absolute().as_posix())
  from FileDiff import App as DiffApp

checklist_template_sheet_id = 2246540011038596  # DO NOT CHANGE THIS - SOURCE CHECKLIST TEMPLATE in DTOE Workspace
dcdd_template_sheet_id = 8678320964429700  # DO NOT CHANGE THIS - DCDD TEMPLATE in DTOE Workspace
tracking_sheet_id = 6535507065759620  # DO NOT CHANGE THIS - DCDD TRACKING SHEET
dcdd_folder_id = 8393978237216644  # DO NOT CHANGE THIS - DCDD Folder ID
tracking_column_name = 'DCDD'         # DO NOT CHANGE THIS - Column name of the DCDD Name List
category_column_names = ['category', 'workstream']

service_urls = { # 'https://wd2-impl-services1.workday.com/ccx/service/TENANT/WEB_SERVICE/vXX?wsdl'
  'wd1': 'https://services1.myworkday.com',
  'wd2': 'https://wd2-impl-services1.workday.com'
}

class App(ttk.Frame):
  wsdl = None
  github = None
  all_dcdds = None
  all_web_services = None
  all_operations = None

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(0, weight=1)
    self.rowconfigure(1, weight=1)

    # Label
    self.label = ttk.Label(self, text="DCDD Generator", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, padx=10, pady=10, sticky=tk.NW)

    self.notebook = ttk.Notebook(self)
    self.notebook.grid(row=1, column=0, sticky=tk.NSEW)
    self.tab1 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab1, text='Single DCDD')
    self.tab2 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab2, text='DCDDs en masse')
    self.tab3 = ttk.Frame(self.notebook)
    self.notebook.add(self.tab3, text='Resources')

    # ---------
    # | Tab 1 |
    # ---------

    # for i in range(3): self.tab1.columnconfigure(i, weight=1)
    self.tab1.columnconfigure(3, weight=1) # just the log text area

    # WSDL ---------------------------------------------

    self.wsdl_frame = ttk.LabelFrame(self.tab1, text="WSDL", padding=5, style="Bold.TLabelframe")
    self.wsdl_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.wsdl_frame.columnconfigure(i, weight=1)

    wsdl_frame_row = 0

    self.web_service = tk.StringVar()
    self.web_service_label = ttk.Label(self.wsdl_frame, text="Web Service", justify="left")
    self.web_service_label.grid(row=wsdl_frame_row, column=0,  padx=5, pady=0, sticky=tk.EW)
    wsdl_frame_row += 1
    self.web_service_entry = ttk.Combobox(self.wsdl_frame, values=sorted(WSDL.WEB_SERVICES), textvariable=self.web_service)
    self.web_service_entry.current(0)
    self.web_service_entry.bind('<Configure>', self.on_combo_configure)
    self.web_service_entry.grid(row=wsdl_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    wsdl_frame_row += 1

    self.version = tk.StringVar()
    self.version_label = ttk.Label(self.wsdl_frame, text="Version", justify="left")
    self.version_label.grid(row=wsdl_frame_row, column=0,  padx=5, pady=0, sticky=tk.EW)
    wsdl_frame_row += 1
    self.version_entry = ttk.Combobox(self.wsdl_frame, values=WSDL.VERSIONS, textvariable=self.version)
    self.version_entry.current(0)
    self.version_entry.bind('<Configure>', self.on_combo_configure)
    self.version_entry.grid(row=wsdl_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    wsdl_frame_row += 1

    self.dc = tk.StringVar()
    self.dc_label = ttk.Label(self.wsdl_frame, text="Data Center / SUV", justify="left")
    self.dc_label.grid(row=wsdl_frame_row, column=0,  padx=5, pady=0, sticky=tk.EW)
    wsdl_frame_row += 1
    self.dc_combo = ttk.Combobox(self.wsdl_frame, values=list(data_centers.keys()), textvariable=self.dc)
    self.dc_combo.current(0)
    self.dc_combo.bind('<Configure>', self.on_combo_configure)
    self.dc_combo.grid(row=wsdl_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    wsdl_frame_row += 1

    self.tenant = tk.StringVar(value='wdprofservices_ldp1')
    self.tenant_label = ttk.Label(self.wsdl_frame, text="Tenant", justify="left")
    self.tenant_label.grid(row=wsdl_frame_row, column=0,  padx=5, pady=0, sticky=tk.EW)
    wsdl_frame_row += 1
    self.tenant_entry = ttk.Entry(self.wsdl_frame, textvariable=self.tenant)
    self.tenant_entry.grid(row=wsdl_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    wsdl_frame_row += 1

    self.wsdl_url = tk.StringVar(value='https://wsdl.url')
    self.wsdl_url_label = ttk.Label(self.wsdl_frame, justify="center", text="Link to WSDL", cursor='hand1', style='Link.TLabel') # textvariable=self.wsdl_url,
    self.wsdl_url_label.grid(row=wsdl_frame_row, column=0, padx=5, pady=(5,10), sticky=tk.NW)
    wsdl_frame_row += 1
    self.wsdl_url_tip = StyledHovertip(self.wsdl_url_label, text=self.wsdl_url.get())
    self.wsdl_url_label.bind('<ButtonRelease-1>', lambda e: webbrowser.open_new_tab(self.wsdl_url.get()))
    self.wsdl_url_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.wsdl_url_label, tearoff=0)), 
      copy_menu.add_command(label='Copy Link', command=lambda: [
        self.wsdl_url_label.clipboard_clear(), 
        self.wsdl_url_label.clipboard_append(self.wsdl_url.get())
      ]), 
      copy_menu.add_command(label='Open Link', command=lambda: [
        webbrowser.open_new_tab(self.wsdl_url.get())
      ]), 
      copy_menu.post(e.x_root, e.y_root)
    ])

    self.get_operation_button = ttk.Button(self.wsdl_frame, text='Get Operations', command=lambda:[self.background(self.get_operations)])
    self.get_operation_button.grid(row=wsdl_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    wsdl_frame_row += 1

    self.operation = tk.StringVar()
    self.operation_label = ttk.Label(self.wsdl_frame, text="Operation", justify="left")
    self.operation_label.grid(row=wsdl_frame_row, column=0,  padx=5, pady=0, sticky=tk.EW)
    wsdl_frame_row += 1
    self.operation_entry = ttk.Combobox(self.wsdl_frame, textvariable=self.operation)
    # self.operation_entry.current(0)
    self.operation_entry.bind('<Configure>', self.on_combo_configure)
    self.operation_entry.grid(row=wsdl_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    wsdl_frame_row += 1

    
    self.dc.trace_add('write', self.update_wsdl_service_url)
    self.tenant.trace_add('write', self.update_wsdl_service_url)
    self.web_service.trace_add('write', self.update_wsdl_service_url)
    self.version.trace_add('write', self.update_wsdl_service_url)
    self.update_wsdl_service_url()

    # Exports ---------------------------------------

    self.export_frame = ttk.LabelFrame(self.tab1, text="Export", padding=5, style="Bold.TLabelframe")
    self.export_frame.grid(row=0, column=1, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.export_frame.columnconfigure(i, weight=1)

    export_frame_row = 0
    
    self.full_name_label = ttk.Label(self.export_frame, text="Full Name Override", justify="left")
    self.full_name_label.grid(row=export_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    export_frame_row += 1
    self.full_name = tk.StringVar()
    self.full_name_entry = ttk.Entry(self.export_frame, textvariable=self.full_name)
    self.full_name_entry.grid(row=export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    export_frame_row += 1

    self.short_name_label = ttk.Label(self.export_frame, text="Short Name Override (50 Max)", justify="left")
    self.short_name_label.grid(row=export_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    export_frame_row += 1
    self.short_name = tk.StringVar()
    self.short_name_entry = ttk.Entry(self.export_frame, textvariable=self.short_name)
    self.short_name_entry.grid(row=export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    export_frame_row += 1

    self.full_name.trace_add('write', lambda *e:self.dcdd_name_validation(self.full_name))
    self.short_name.trace_add('write', lambda *e:self.dcdd_name_validation(self.short_name, 50))
    self.operation.trace_add('write', lambda *e:[self.full_name.set(F"{self.operation.get()}_DCDD"), self.short_name.set(F"{self.operation.get()}_DCDD")])
    

    self.save_as_proposed_json_button = ttk.Button(self.export_frame, text='Create DCDD', command=lambda:[self.background(self.save_dcdd, ('json',self.save_as_upgraded_json.get()))])
    self.save_as_proposed_json_button.grid(row=export_frame_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
    export_frame_row += 1

    self.save_as_upgraded_json = tk.BooleanVar(value=True)
    self.save_as_upgraded_json_switch = ttk.Checkbutton(self.export_frame, text="from current DCDD", variable=self.save_as_upgraded_json, style="Switch.TCheckbutton")
    self.save_as_upgraded_json_switch.grid(row=export_frame_row, column=0, padx=5, pady=(0,10), sticky=tk.EW)
    StyledHovertip(self.save_as_upgraded_json_switch, text="  -- If not selected, will create brand new json DCDD with proposed fields,\n    current DCDD comes from extracted JSON on 'Resources' tab -- ")
    export_frame_row += 1

    # self.save_as_upgraded_json_button = ttk.Button(self.export_frame, text='Upgrade DCDD', command=lambda:[self.background(self.save_dcdd, ('json',True))])
    # self.save_as_upgraded_json_button.grid(row=export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    # export_frame_row += 1

    self.path_label = ttk.Label(self.export_frame, text="File Location", justify="left")
    self.path_label.grid(row=export_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    export_frame_row += 1
    self.save_path = tk.StringVar(value='/path/to/csv_or_json')
    # self.save_path_label = ttk.Label(self.tab1, justify="center", textvariable=self.save_path, cursor='hand1', style='Link.TLabel')
    self.save_path_label = ttk.Combobox(self.export_frame, justify="center", textvariable=self.save_path, postcommand=lambda:[
      self.save_path.set(filedialog.askopenfilename(title=F"Select JSON or CSV File", filetypes=(("JSON Files", "*.json"), ("CSV Files", "*.csv"), ("All Files", "*.*"))) or self.save_path.get()),
      self.after(1, lambda: self.save_path_label.event_generate('<Escape>'))
    ])
    self.save_path_label.grid(row=export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    export_frame_row += 1
    # self.save_path_label.bind('<ButtonRelease-1>', lambda e: webbrowser.open('file://'+self.save_path.get()))
    self.save_path_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.save_path_label, tearoff=0)), 
      copy_menu.add_command(label='Copy Path', command=lambda: [
        self.save_path_label.clipboard_clear(), 
        self.save_path_label.clipboard_append(self.save_path.get())
      ]), 
      copy_menu.add_command(label='Open Folder', command=lambda: [
        webbrowser.open('file://'+str(Path(self.save_path.get()).parent))
      ]), 
      copy_menu.add_command(label='Open File', command=lambda: [
        webbrowser.open('file://'+self.save_path.get())
      ]), 
      copy_menu.add_separator(),
      copy_menu.add_command(label='Select File', command=lambda: [
        self.save_path.set(filedialog.askopenfilename(title=F"Select JSON or CSV File", filetypes=(("JSON Files", "*.json"), ("CSV Files", "*.csv"), ("All Files", "*.*"))) or self.save_path.get())
      ]),
      copy_menu.post(e.x_root, e.y_root)
    ])

    helper_label = ttk.Label(self.export_frame, text="Helper Buttons", justify="center")
    helper_label.grid(row=export_frame_row, column=0, padx=5, pady=(20,5), sticky=tk.EW)
    export_frame_row += 1

    self.save_as_csv_button = ttk.Button(self.export_frame, text='WSO Extract (CSV)', command=lambda:[self.background(self.save_dcdd, ('csv',))])
    self.save_as_csv_button.grid(row=export_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    StyledHovertip(self.save_as_csv_button, text="  -- Web Service Operations - Raw CSV View (pre-json)\n    used to help troubleshoot WSDL extract -- ")
    export_frame_row += 1

    self.save_as_csv_button = ttk.Button(self.export_frame, text='Convert JSON to CSV', command=self.json_to_csv)# lambda:[messagebox.showwarning(title='Work In Progress', message='Not yet implemented!')])
    self.save_as_csv_button.grid(row=export_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    StyledHovertip(self.save_as_csv_button, text="  -- Convert JSON to CSV to view locally easier -- ")
    export_frame_row += 1

    # Diff button
    self.diff_button = ttk.Button(self.export_frame, text='Diff with Current', command=self.diff_jsons)
    self.diff_button.grid(row=export_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    StyledHovertip(self.diff_button, text="  -- Compare current DCDD with proposed DCDD\n    to see differences -- ")
    export_frame_row += 1

    # Smartsheet ----------------------------

    self.ss_frame = ttk.LabelFrame(self.tab1, text="Smartsheet", padding=5, style="Bold.TLabelframe")
    self.ss_frame.grid(row=0, column=2, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.ss_frame.columnconfigure(i, weight=1)

    ss_frame_row = 0

    self.use_exisiting_sheet = tk.IntVar()
    self.existing_switch = ttk.Checkbutton(self.ss_frame, text="Use Existing Sheet", variable=self.use_exisiting_sheet, style="Switch.TCheckbutton", command=lambda:[
      self.ss_existing_sheet_id_label.config(state=tk.DISABLED if not self.use_exisiting_sheet.get() else tk.NORMAL),
      self.ss_existing_sheet_id_entry.config(state=tk.DISABLED if not self.use_exisiting_sheet.get() else tk.NORMAL),
      self.ss_merge_existing_rows_switch.config(state=tk.DISABLED if not self.use_exisiting_sheet.get() else tk.NORMAL),
      self.ss_delete_existing_rows_switch.config(state=tk.DISABLED if not self.use_exisiting_sheet.get() else tk.NORMAL),
      self.ss_order_existing_switch.config(state=tk.DISABLED if not self.use_exisiting_sheet.get() else tk.NORMAL),
      
      self.ss_save_folder_type_label.config(state=tk.DISABLED if self.use_exisiting_sheet.get() else tk.NORMAL),
      # self.ss_save_folder_text_label # Text Area Disable?
      self.ss_save_folder_text_label.configure(foreground=ttk.Style().lookup("TLabel", "foreground", (tk.DISABLED,)) if self.use_exisiting_sheet.get() else ttk.Style().lookup("TLabel", "foreground")),
      self.ss_save_folder_id_entry.config(state=tk.DISABLED if self.use_exisiting_sheet.get() else tk.NORMAL),
      self.ss_template_id_label.config(state=tk.DISABLED if self.use_exisiting_sheet.get() else tk.NORMAL),
      self.ss_template_id_entry.config(state=tk.DISABLED if self.use_exisiting_sheet.get() else tk.NORMAL)
    ])
    self.existing_switch.grid(row=ss_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    ss_frame_row += 1
    self.existing_switch.state(['!selected'])

    def show_menu_if_existing(e):
     if self.use_exisiting_sheet.get(): self.smart_sheet_menu(e)

    def show_menu_if_not_existing(e):
     if not self.use_exisiting_sheet.get(): self.smart_sheet_menu(e)

    # SS Existing Sheet
    self.ss_existing_sheet_id = tk.IntVar()
    self.ss_existing_sheet_id_label = ttk.Label(self.ss_frame, text="Existing Sheet ID")
    self.ss_existing_sheet_id_label.grid(row=ss_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    ss_frame_row += 1
    self.ss_existing_sheet_id_entry = ttk.Combobox(self.ss_frame, textvariable=self.ss_existing_sheet_id, postcommand=lambda:self.pick_smartsheet_sheet(self.ss_existing_sheet_id_entry))
    self.ss_existing_sheet_id_entry.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.ss_existing_sheet_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', show_menu_if_existing)
    ss_frame_row += 1
    self.ss_merge_existing_rows = tk.BooleanVar(value=True)
    self.ss_merge_existing_rows_switch = ttk.Checkbutton(self.ss_frame, text="Merge Existing Rows", variable=self.ss_merge_existing_rows, style="Switch.TCheckbutton")
    StyledHovertip(self.ss_merge_existing_rows_switch, text="  -- Merge existing rows with new DCDD data for highlighting changes \n    otherwise add only to existing rows (no updates) -- ")
    self.ss_merge_existing_rows_switch.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.ss_merge_existing_rows_switch.state(['selected'])
    ss_frame_row += 1
    self.ss_delete_existing_rows = tk.BooleanVar(value=False)
    self.ss_delete_existing_rows_switch = ttk.Checkbutton(self.ss_frame, text="Delete Non-Matching Rows", variable=self.ss_delete_existing_rows, style="Switch.TCheckbutton")
    StyledHovertip(self.ss_delete_existing_rows_switch, text="  -- Delete non-matching existing rows \n    otherwise format these rows -- ")
    self.ss_delete_existing_rows_switch.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.ss_delete_existing_rows_switch.state(['!selected'])
    ss_frame_row += 1

    self.ss_order_existing = tk.BooleanVar(value=False)
    self.ss_order_existing_switch = ttk.Checkbutton(self.ss_frame, text="Order Rows", variable=self.ss_order_existing, style="Switch.TCheckbutton")
    StyledHovertip(self.ss_order_existing_switch, text="  -- Order existing rows to new WSDL output (based on XPATH)\n    otherwise keep existing order (new rows at the bottom -- ")
    self.ss_order_existing_switch.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.ss_order_existing_switch.state(['!selected'])
    ss_frame_row += 1

    # Start existing widgets as Disabled
    self.ss_existing_sheet_id_label.config(state=tk.DISABLED)
    self.ss_existing_sheet_id_entry.config(state=tk.DISABLED)
    self.ss_merge_existing_rows_switch.config(state=tk.DISABLED)
    self.ss_delete_existing_rows_switch.config(state=tk.DISABLED)
    self.ss_order_existing_switch.config(state=tk.DISABLED)

    # horizontal line
    ttk.Separator(self.ss_frame, orient='horizontal').grid(row=ss_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    ss_frame_row += 1
    

    # SS Save Folder
    self.ss_save_folder_id = tk.IntVar(value=227890882209668)
    self.ss_save_folder_type = tk.StringVar(value='Folder')
    self.ss_save_folder_text_label = tk.Text(self.ss_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.ss_save_folder_text_label.configure(selectbackground=self.ss_save_folder_text_label.cget('bg'), inactiveselectbackground=self.ss_save_folder_text_label.cget('bg'))
    self.ss_save_folder_text_label.grid(row=ss_frame_row, column=0, padx=5, pady=2, sticky=tk.EW)
    ss_frame_row += 1

    # self.ss_save_folder_text_label.insert(tk.END, 'Smartsheet')
    self.ss_save_folder_type_label = ttk.Label(self.ss_frame, textvariable=self.ss_save_folder_type, cursor='hand1', style='Link.TLabel')
    self.ss_save_folder_text_label.window_create(tk.END, window=self.ss_save_folder_type_label, padx=2)
    self.ss_save_folder_text_label.insert(tk.END, 'ID')
    self.ss_save_folder_text_label.config(state=tk.DISABLED)

    self.ss_save_folder_id_entry = ttk.Combobox(self.ss_frame, textvariable=self.ss_save_folder_id, postcommand=lambda:self.pick_smartsheet_folder(self.ss_save_folder_id_entry))
    self.ss_save_folder_id_entry.id_type = tk.StringVar(value='folder')
    self.ss_save_folder_id_entry.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.ss_save_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', show_menu_if_not_existing)
    ss_frame_row += 1

    def save_folder_type_menu(e):
      type_menu = tk.Menu(self.ss_save_folder_type_label, tearoff=0)
      type_menu.add_command(label='Workspace', command=lambda:[
        self.ss_save_folder_type.set(value='Workspace'),
        self.ss_save_folder_id_entry.id_type.set('workspace'),
      ])
      type_menu.add_command(label='Folder', command=lambda:[
        self.ss_save_folder_type.set(value='Folder'),
        self.ss_save_folder_id_entry.id_type.set('folder'),
      ])
      type_menu.add_command(label='Home', command=lambda:[
        self.ss_save_folder_type.set(value='Home'),
        self.ss_save_folder_id_entry.id_type.set('home'),
      ])
      type_menu.post(e.x_root, e.y_root)

    self.ss_save_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', save_folder_type_menu)
    self.ss_save_folder_type_label.bind('<ButtonRelease-1>', save_folder_type_menu)

    # SS Template Sheet
    self.ss_template_id = tk.IntVar(value=dcdd_template_sheet_id)
    self.ss_template_id_label = ttk.Label(self.ss_frame, text="Template ID")
    self.ss_template_id_label.grid(row=ss_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    ss_frame_row += 1
    self.ss_template_id_entry = ttk.Combobox(self.ss_frame, textvariable=self.ss_template_id, postcommand=lambda:self.pick_smartsheet_sheet(self.ss_template_id_entry))
    self.ss_template_id_entry.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.ss_template_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', show_menu_if_not_existing)
    ss_frame_row += 1

    self.json_to_dcdd_button = ttk.Button(self.ss_frame, text='JSON to Smartsheet DCDD', command=lambda:[self.background(self.json_to_dcdd)])
    self.json_to_dcdd_button.grid(row=ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    ss_frame_row += 1

    # SS New DCDD Location
    self.ss_dcdd_location = tk.StringVar(value='')
    self.ss_dcdd_location_label = ttk.Label(self.ss_frame, textvariable=self.ss_dcdd_location, cursor='hand1', style='Link.TLabel')
    self.ss_dcdd_location_label.grid(row=ss_frame_row, column=0, columnspan=99, padx=5, pady=(0,5), sticky=tk.W)
    ss_frame_row += 1
    self.ss_dcdd_location_label.bind('<ButtonRelease-1>', lambda e: webbrowser.open(self.ss_dcdd_location.get()) if self.ss_dcdd_location.get() else None)
    self.ss_dcdd_location_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.save_path_label, tearoff=0)), 
      copy_menu.add_command(label='Copy URL', command=lambda: [
        self.ss_dcdd_location_label.clipboard_clear() if self.ss_dcdd_location.get() else None, 
        self.ss_dcdd_location_label.clipboard_append(self.ss_dcdd_location.get()) if self.ss_dcdd_location.get() else None
      ]), 
      copy_menu.add_command(label='Open URL', command=lambda: [
        webbrowser.open(self.ss_dcdd_location.get()) if self.ss_dcdd_location.get() else None
      ]), 
      copy_menu.post(e.x_root, e.y_root)
    ])

    # Log Text Frame ---------------------------------
    self.log_frame = ttk.LabelFrame(self.tab1, text="Log", padding=5, style="Bold.TLabelframe")
    self.log_frame.grid(row=0, column=3, columnspan=99, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.log_frame.columnconfigure(i, weight=1)
    self.log_frame.columnconfigure(0, weight=1)
    self.log_frame.rowconfigure(1, weight=1)

    self.log_text = tk.Text(self.log_frame, wrap='word', height=10)
    self.log_text.grid(row=1, column=0, padx=5, pady=5, sticky=tk.NSEW)
    self.log_text.tag_configure("stderr", foreground="red")
    # self.log_text.tag_configure("stdout", foreground="black")

    # Log Scrollbar
    self.log_scrollbar = ttk.Scrollbar(self.log_frame, orient="vertical", command=self.log_text.yview)
    self.log_scrollbar.grid(row=1, column=1, sticky='ns')
    self.log_text['yscrollcommand'] = self.log_scrollbar.set

    # Clear Log Label
    self.clear_log_label = ttk.Label(self.log_frame, text="X", cursor='hand1', style='Link.TLabel')
    self.clear_log_label.grid(row=0, column=1, padx=(0,5), pady=(0,5), sticky=tk.EW)
    self.clear_log_label.bind('<Button-1>', lambda e: self.log_text.delete('1.0', tk.END))
    StyledHovertip(self.clear_log_label, text=" -- Clear Log -- ")

    # ---------
    # | Tab 2 |
    # ---------

    self.tab2.columnconfigure(0, weight=1)
    # self.tab2.columnconfigure(1, weight=1)

    self.en_masse_warning_label = ttk.Label(self.tab2, text="Web Services and Operations from Existing DCDDs (only)", justify="left", font=("-size", 12, "-weight", "bold"))
    self.en_masse_warning_label.grid(row=0, column=0, columnspan=99, padx=20, pady=0, sticky=tk.EW)

    self.wso_frame = ttk.Frame(self.tab2)
    self.wso_frame.grid(row=1, column=0, columnspan=99, padx=5, pady=0, sticky=tk.EW)

    self.wso_frame.columnconfigure(0, weight=1) # Web Services
    self.wso_frame.columnconfigure(1, weight=1) # Operations
    # self.wso_frame.columnconfigure(2, weight=1) # Log Text Area

    self.en_masse_web_service_label = ttk.Label(self.wso_frame, text="Web Services", justify="left")
    self.en_masse_web_service_label.grid(row=1, column=0,  padx=5, pady=0, sticky=tk.EW)
    self.en_masse_web_service_frame = ttk.Frame(self.wso_frame)
    self.en_masse_web_service_frame.grid(row=2, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.en_masse_web_service_scrollbar = ttk.Scrollbar(self.en_masse_web_service_frame)
    self.en_masse_web_service_tree_view = ttk.Treeview(self.en_masse_web_service_frame, yscrollcommand=self.en_masse_web_service_scrollbar.set, show="tree", height=7)
    self.en_masse_web_service_tree_view.bind('<Command-a>' if MAC_OS else '<Control-a>', lambda e: self.en_masse_web_service_tree_view.selection_add(self.en_masse_web_service_tree_view.get_children()))
    self.en_masse_web_service_scrollbar.configure(command=self.en_masse_web_service_tree_view.yview)
    self.en_masse_web_service_scrollbar.pack(side="right", fill="y")
    self.en_masse_web_service_tree_view.pack(side="left", fill="both", expand=True)

    self.en_masse_operation_label = ttk.Label(self.wso_frame, text="Operations", justify="left")
    self.en_masse_operation_label.grid(row=1, column=1,  padx=5, pady=0, sticky=tk.EW)
    self.en_masse_operation_frame = ttk.Frame(self.wso_frame)
    self.en_masse_operation_frame.grid(row=2, column=1, padx=5, pady=(0,5), sticky=tk.EW)
    self.en_masse_operation_scrollbar = ttk.Scrollbar(self.en_masse_operation_frame)
    self.en_masse_operation_tree_view = ttk.Treeview(self.en_masse_operation_frame, yscrollcommand=self.en_masse_operation_scrollbar.set, show="tree", height=7)
    self.en_masse_operation_tree_view.bind('<Command-a>' if MAC_OS else '<Control-a>', lambda e: self.en_masse_operation_tree_view.selection_add(self.en_masse_operation_tree_view.get_children()))
    self.en_masse_operation_scrollbar.configure(command=self.en_masse_operation_tree_view.yview)
    self.en_masse_operation_scrollbar.pack(side="right", fill="y")
    self.en_masse_operation_tree_view.pack(side="left", fill="both", expand=True)

    # Frame for Export and Other Options
    self.em_other_frame = ttk.Frame(self.tab2)
    self.em_other_frame.grid(row=2, column=0, columnspan=99, padx=5, pady=0, sticky=tk.EW)
    self.em_other_frame.columnconfigure(4, weight=1)

    # EN Masse Export --------

    self.em_export_frame = ttk.LabelFrame(self.em_other_frame, text="Export", padding=5, style="Bold.TLabelframe")
    self.em_export_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.em_export_frame.columnconfigure(i, weight=1)

    em_export_frame_row = 0

    self.em_select_all_button = ttk.Button(self.em_export_frame, text='Select All')
    self.em_select_all_button.config(command=lambda: [
      self.en_masse_web_service_tree_view.selection_set(self.en_masse_web_service_tree_view.get_children()) if self.em_select_all_button.cget('text') == "Select All" else self.en_masse_web_service_tree_view.selection_remove(self.en_masse_web_service_tree_view.get_children()), 
      self.en_masse_operation_tree_view.selection_set(self.en_masse_operation_tree_view.get_children()) if self.em_select_all_button.cget('text') == "Select All" else self.en_masse_operation_tree_view.selection_remove(self.en_masse_operation_tree_view.get_children()), 
      self.em_select_all_button.config(text="Unselect All" if self.em_select_all_button.cget('text') == "Select All" else "Select All")
    ])
    self.em_select_all_button.grid(row=em_export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_export_frame_row += 1

    # Horizontal Line
    ttk.Separator(self.em_export_frame, orient='horizontal').grid(row=em_export_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    em_export_frame_row += 1

    self.em_version = tk.StringVar()
    self.em_version_label = ttk.Label(self.em_export_frame, text="Version", justify="left")
    self.em_version_label.grid(row=em_export_frame_row, column=0,  padx=5, pady=0, sticky=tk.EW)
    em_export_frame_row += 1
    self.em_version_entry = ttk.Combobox(self.em_export_frame, values=WSDL.VERSIONS, textvariable=self.em_version)
    self.em_version_entry.current(0)
    self.em_version_entry.bind('<Configure>', self.on_combo_configure)
    self.em_version_entry.grid(row=em_export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_export_frame_row += 1

    self.em_path_label = ttk.Label(self.em_export_frame, text="Save Folder Location", justify="left")
    self.em_path_label.grid(row=em_export_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    em_export_frame_row += 1
    self.em_save_path = tk.StringVar(value='/path/to/folder')
    # self.save_path_label = ttk.Label(self.tab1, justify="center", textvariable=self.save_path, cursor='hand1', style='Link.TLabel')
    self.em_save_path_label = ttk.Combobox(self.em_export_frame, justify="center", textvariable=self.em_save_path, postcommand=lambda:[
      self.em_save_path.set(filedialog.askdirectory(title=F"Select an Output Folder") or self.em_save_path.get()),
      self.after(1, lambda: self.em_save_path_label.event_generate('<Escape>'))
    ])
    self.em_save_path_label.grid(row=em_export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_export_frame_row += 1
    # self.save_path_label.bind('<ButtonRelease-1>', lambda e: webbrowser.open('file://'+self.save_path.get()))
    self.em_save_path_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.em_save_path_label, tearoff=0)), 
      copy_menu.add_command(label='Copy Path', command=lambda: [
        self.em_save_path_label.clipboard_clear(), 
        self.em_save_path_label.clipboard_append(self.em_save_path.get())
      ]), 
      copy_menu.add_command(label='Open Folder', command=lambda: [
        webbrowser.open(F'file://{self.em_save_path.get()}')
      ]), 
      copy_menu.add_separator(),
      copy_menu.add_command(label='Select Folder', command=lambda: [
        self.em_save_path.set(filedialog.askdirectory(title=F"Select an Output Folder") or self.em_save_path.get()),
      ]),
      copy_menu.post(e.x_root, e.y_root)
    ])

    self.em_save_as_upgraded_json_button = ttk.Button(self.em_export_frame, text='Upgrade DCDDs', command=lambda:[self.background(self.en_mass_upgrade)])
    self.em_save_as_upgraded_json_button.grid(row=em_export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_export_frame_row += 1

    # horizontal line with text
    ttk.Separator(self.em_export_frame, orient='horizontal').grid(row=em_export_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    ttk.Label(self.em_export_frame, text="Comparisons", justify="left").grid(row=em_export_frame_row, column=0, padx=(15,5), pady=5, sticky=tk.W)
    em_export_frame_row += 1

    # EN Masse Comparison Button
    self.em_comparison_button = ttk.Button(self.em_export_frame, text='Compare DCDDs', command=lambda:[self.background(self.en_mass_compare)])
    self.em_comparison_button.grid(row=em_export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_export_frame_row += 1
    StyledHovertip(self.em_comparison_button, text="  -- Compare new DCDD JSONs to the current DCDD JSONs -- ")


    # horizontal line with text
    ttk.Separator(self.em_export_frame, orient='horizontal').grid(row=em_export_frame_row, column=0, padx=5, pady=5, sticky=tk.EW)
    ttk.Label(self.em_export_frame, text="Optional", justify="left").grid(row=em_export_frame_row, column=0, padx=(15,5), pady=5, sticky=tk.W)
    em_export_frame_row += 1

    # EN Masse WSO Exports (CSVs) Button
    self.em_save_as_csv_button = ttk.Button(self.em_export_frame, text='WSO Extracts (CSVs)', command=lambda:[self.background(self.en_mass_upgrade(csv=True))])
    self.em_save_as_csv_button.grid(row=em_export_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_export_frame_row += 1

    # # EN Masse Comparisons Frame ------
    # self.em_comparison_frame = ttk.LabelFrame(self.em_other_frame, text="Comparisons", padding=5, style="Bold.TLabelframe")
    # self.em_comparison_frame.grid(row=0, column=1, padx=5, pady=5, sticky=tk.NSEW)
    # for i in range(1): self.em_comparison_frame.columnconfigure(i, weight=1)

    # em_comparison_frame_row = 0

    # # EN Masse Comparison Button
    # self.em_comparison_button = ttk.Button(self.em_comparison_frame, text='Compare DCDDs', command=lambda:[self.background(self.en_mass_compare)])
    # self.em_comparison_button.grid(row=em_comparison_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    # em_comparison_frame_row += 1
    # StyledHovertip(self.em_comparison_button, text="  -- Compare new DCDD JSONs to the current DCDD JSONs -- ")

    # EN Masse Smartsheet --------
    self.em_ss_frame = ttk.LabelFrame(self.em_other_frame, text="Smartsheet", padding=5, style="Bold.TLabelframe")
    self.em_ss_frame.grid(row=0, column=2, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.em_ss_frame.columnconfigure(i, weight=1)

    em_ss_frame_row = 0
 
    # smartsheet folder id
    self.em_ss_save_folder_id = tk.IntVar(value=227890882209668)
    self.em_ss_save_folder_type = tk.StringVar(value='Folder')
    self.em_ss_save_folder_text_label = tk.Text(self.em_ss_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.em_ss_save_folder_text_label.configure(selectbackground=self.em_ss_save_folder_text_label.cget('bg'), inactiveselectbackground=self.em_ss_save_folder_text_label.cget('bg'))
    self.em_ss_save_folder_text_label.grid(row=em_ss_frame_row, column=0, padx=5, pady=2, sticky=tk.EW)
    em_ss_frame_row += 1

    # self.ss_save_folder_text_label.insert(tk.END, 'Smartsheet')
    self.em_ss_save_folder_type_label = ttk.Label(self.em_ss_frame, textvariable=self.em_ss_save_folder_type, cursor='hand1', style='Link.TLabel')
    self.em_ss_save_folder_text_label.window_create(tk.END, window=self.em_ss_save_folder_type_label, padx=2)
    self.em_ss_save_folder_text_label.insert(tk.END, 'ID')
    self.em_ss_save_folder_text_label.config(state=tk.DISABLED)

    self.em_ss_save_folder_id_entry = ttk.Combobox(self.em_ss_frame, textvariable=self.em_ss_save_folder_id, postcommand=lambda:self.em_pick_smartsheet_folder(self.em_ss_save_folder_id_entry))
    self.em_ss_save_folder_id_entry.id_type = tk.StringVar(value='folder')
    self.em_ss_save_folder_id_entry.grid(row=em_ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_save_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_frame_row += 1

    def em_save_folder_type_menu(e):
      type_menu = tk.Menu(self.em_ss_save_folder_type_label, tearoff=0)
      type_menu.add_command(label='Workspace', command=lambda:[
        self.em_ss_save_folder_type.set(value='Workspace'),
        self.em_ss_save_folder_id_entry.id_type.set('workspace'),
      ])
      type_menu.add_command(label='Folder', command=lambda:[
        self.em_ss_save_folder_type.set(value='Folder'),
        self.em_ss_save_folder_id_entry.id_type.set('folder'),
      ])
      type_menu.add_command(label='Home', command=lambda:[
        self.em_ss_save_folder_type.set(value='Home'),
        self.em_ss_save_folder_id_entry.id_type.set('home'),
      ])
      type_menu.post(e.x_root, e.y_root)

    self.em_ss_save_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', em_save_folder_type_menu)
    self.em_ss_save_folder_type_label.bind('<ButtonRelease-1>', em_save_folder_type_menu)

    # EN Masse SS Template Sheet
    self.em_ss_template_id = tk.IntVar(value=dcdd_template_sheet_id)
    self.em_ss_template_id_label = ttk.Label(self.em_ss_frame, text="Template ID")
    self.em_ss_template_id_label.grid(row=em_ss_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    em_ss_frame_row += 1

    self.em_ss_template_id_entry = ttk.Combobox(self.em_ss_frame, textvariable=self.em_ss_template_id, postcommand=lambda:self.pick_smartsheet_sheet(self.em_ss_template_id_entry))
    self.em_ss_template_id_entry.grid(row=em_ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_template_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_frame_row += 1

    # EN Masse SS Toggle Create Sub Directory
    self.em_ss_create_sub_dir = tk.BooleanVar(value=True)
    self.em_ss_create_sub_dir_switch = ttk.Checkbutton(self.em_ss_frame, text="Create Sub Directory", variable=self.em_ss_create_sub_dir, style="Switch.TCheckbutton")
    self.em_ss_create_sub_dir_switch.grid(row=em_ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_ss_frame_row += 1

    # EN Masse SS Sub Directory Name
    self.em_ss_sub_dir_name = tk.StringVar(value=F'{self.em_version.get()}_{datetime.now().strftime("%Y%m%d%H%M%S")}')
    self.em_ss_sub_dir_name_label = ttk.Label(self.em_ss_frame, text="Sub Directory Name", justify="left")
    self.em_ss_sub_dir_name_label.grid(row=em_ss_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    em_ss_frame_row += 1

    self.em_ss_sub_dir_name_entry = ttk.Entry(self.em_ss_frame, textvariable=self.em_ss_sub_dir_name)
    self.em_ss_sub_dir_name_entry.grid(row=em_ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_ss_frame_row += 1

    #Listner for version change
    self.em_version.trace_add('write', lambda *e: self.em_ss_sub_dir_name.set(F'{self.em_version.get()}_{datetime.now().strftime("%Y%m%d%H%M%S")}'))

    self.em_json_to_dcdd_button = ttk.Button(self.em_ss_frame, text='JSONs to Smartsheet DCDDs', command=lambda:[self.background(self.em_json_to_dcdd)])
    self.em_json_to_dcdd_button.grid(row=em_ss_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)

    # EN Masse Smartsheet Admin --------
    self.em_ss_admin_frame = ttk.LabelFrame(self.em_other_frame, text="Smartsheet Admin", padding=5, style="Bold.TLabelframe")
    self.em_ss_admin_frame.grid(row=0, column=3, padx=5, pady=5, sticky=tk.NSEW)
    for i in range(1): self.em_ss_admin_frame.columnconfigure(i, weight=1)

    em_ss_admin_frame_row = 0

    # SS Admin Backup DCDD Folder (and Tracking Sheet) --
    # DCDD Folder ID
    self.em_ss_dcdd_folder_id = tk.IntVar(value=dcdd_folder_id)
    self.em_ss_dcdd_folder_type = tk.StringVar(value='Folder')
    self.em_ss_dcdd_folder_text_label = tk.Text(self.em_ss_admin_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.em_ss_dcdd_folder_text_label.configure(selectbackground=self.em_ss_dcdd_folder_text_label.cget('bg'), inactiveselectbackground=self.em_ss_dcdd_folder_text_label.cget('bg'))
    self.em_ss_dcdd_folder_text_label.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=2, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_dcdd_folder_text_label.insert(tk.END, 'DCDD')
    self.em_ss_dcdd_folder_type_label = ttk.Label(self.em_ss_admin_frame, textvariable=self.em_ss_dcdd_folder_type, cursor='hand1', style='Link.TLabel')
    self.em_ss_dcdd_folder_text_label.window_create(tk.END, window=self.em_ss_dcdd_folder_type_label, padx=2)
    self.em_ss_dcdd_folder_text_label.insert(tk.END, 'ID')
    self.em_ss_dcdd_folder_text_label.config(state=tk.DISABLED)

    self.em_ss_dcdd_folder_id_entry = ttk.Combobox(self.em_ss_admin_frame, textvariable=self.em_ss_dcdd_folder_id, postcommand=lambda:self.pick_smartsheet_folder_generic(self.em_ss_dcdd_folder_id_entry, self.em_ss_dcdd_folder_type))
    self.em_ss_dcdd_folder_id_entry.id_type = tk.StringVar(value='folder')
    self.em_ss_dcdd_folder_id_entry.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_dcdd_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_admin_frame_row += 1

    self.em_ss_dcdd_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: self.folder_type_menu(e, self.em_ss_dcdd_folder_id_entry))
    self.em_ss_dcdd_folder_type_label.bind('<ButtonRelease-1>', lambda e: self.folder_type_menu(e, self.em_ss_dcdd_folder_id_entry))
    

    # SS Admin Backup Target Folder ID
    self.em_ss_target_folder_id = tk.IntVar()
    self.em_ss_target_folder_type = tk.StringVar(value='Folder')
    self.em_ss_target_folder_text_label = tk.Text(self.em_ss_admin_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.em_ss_target_folder_text_label.configure(selectbackground=self.em_ss_target_folder_text_label.cget('bg'), inactiveselectbackground=self.em_ss_target_folder_text_label.cget('bg'))
    self.em_ss_target_folder_text_label.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=2, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_target_folder_text_label.insert(tk.END, 'Target')
    self.em_ss_target_folder_type_label = ttk.Label(self.em_ss_admin_frame, textvariable=self.em_ss_target_folder_type, cursor='hand1', style='Link.TLabel')
    self.em_ss_target_folder_text_label.window_create(tk.END, window=self.em_ss_target_folder_type_label, padx=2)
    self.em_ss_target_folder_text_label.insert(tk.END, 'ID')
    self.em_ss_target_folder_text_label.config(state=tk.DISABLED)
   

    self.em_ss_target_folder_id_entry = ttk.Combobox(self.em_ss_admin_frame, textvariable=self.em_ss_target_folder_id, postcommand=lambda:self.pick_smartsheet_folder_generic(self.em_ss_target_folder_id_entry, self.em_ss_target_folder_type))
    self.em_ss_target_folder_id_entry.id_type = tk.StringVar(value='folder')
    self.em_ss_target_folder_id_entry.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_target_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_admin_frame_row += 1

    self.em_ss_target_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: self.folder_type_menu(e, self.em_ss_target_folder_id_entry))
    self.em_ss_target_folder_type_label.bind('<ButtonRelease-1>', lambda e: self.folder_type_menu(e, self.em_ss_target_folder_id_entry))
    
    # SS Admin Backup Crate New Folder Toggle
    self.em_ss_create_new_folder = tk.BooleanVar(value=True)
    self.em_ss_create_new_folder_switch = ttk.Checkbutton(self.em_ss_admin_frame, text="Use New Folder", variable=self.em_ss_create_new_folder, style="Switch.TCheckbutton")
    self.em_ss_create_new_folder_switch.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    StyledHovertip(self.em_ss_create_new_folder_switch, text=" -- For Backups, rename copied folder to new name (else original name). \n    For Moves, create a new folder with name (else move sheets directly into target folder) -- ")
    em_ss_admin_frame_row += 1
    
    # SS Admin Backup DCDD Folder Name
    self.em_ss_backup_folder_name = tk.StringVar(value=F'vXX.X_{datetime.now().strftime("%Y%m%d")}')
    self.em_ss_backup_folder_name_label = ttk.Label(self.em_ss_admin_frame, text="New Folder Name", justify="left")
    self.em_ss_backup_folder_name_label.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=0, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_backup_folder_name_entry = ttk.Entry(self.em_ss_admin_frame, textvariable=self.em_ss_backup_folder_name)
    self.em_ss_backup_folder_name_entry.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_ss_admin_frame_row += 1

    # SS Admin Backup DCDD Folder Button
    self.em_ss_backup_dcdd_button = ttk.Button(self.em_ss_admin_frame, text='Backup DCDD Sheets', command=lambda:[self.background(self.backup_dcdd_folder)])
    self.em_ss_backup_dcdd_button.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    StyledHovertip(self.em_ss_backup_dcdd_button, text="  -- Backup DCDD Folder Sheets to above DCDD Folder ID (will create a new sub directory with new or original name) -- ")
    em_ss_admin_frame_row += 1

    # Label "OR"
    ttk.Label(self.em_ss_admin_frame, text="OR", font=("-size", 10, "-weight", "bold"), anchor=tk.CENTER).grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    em_ss_admin_frame_row += 1

    # SS Admin Move DCDD Folder Button
    self.em_ss_move_dcdd_button = ttk.Button(self.em_ss_admin_frame, text='Move DCDD Sheets', command=lambda:[self.background(self.move_dcdd_folder)])
    self.em_ss_move_dcdd_button.grid(row=em_ss_admin_frame_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    StyledHovertip(self.em_ss_move_dcdd_button, text="  -- Move DCDD Folder Sheets to above Target Folder ID (if using new folder, will create a new sub directory) -- ")
    em_ss_admin_frame_row += 1

    # Vertical Spacer
    ttk.Separator(self.em_ss_admin_frame, orient='vertical').grid(row=0, rowspan=99, column=1,  padx=5, pady=5, sticky=tk.NS)

    # New Admin Column, reset row
    em_ss_admin_frame_row = 0

    # SS Admin Tracking Sheet
    self.em_ss_tracking_id = tk.IntVar(value=tracking_sheet_id)
    self.em_ss_tracking_id_label = ttk.Label(self.em_ss_admin_frame, text="Tracking Sheet ID")
    self.em_ss_tracking_id_label.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=0, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_tracking_id_entry = ttk.Combobox(self.em_ss_admin_frame, textvariable=self.em_ss_tracking_id, postcommand=lambda:self.pick_smartsheet_sheet(self.em_ss_tracking_id_entry))
    self.em_ss_tracking_id_entry.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_tracking_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_admin_frame_row += 1

    # SS Admin Tracking Destination Folder
    self.em_ss_tracking_folder_id = tk.IntVar(value=0)
    self.em_ss_tracking_folder_type = tk.StringVar(value='Folder')
    self.em_ss_tracking_folder_text_label = tk.Text(self.em_ss_admin_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.em_ss_tracking_folder_text_label.configure(selectbackground=self.em_ss_tracking_folder_text_label.cget('bg'), inactiveselectbackground=self.em_ss_tracking_folder_text_label.cget('bg'))
    self.em_ss_tracking_folder_text_label.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=2, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_tracking_folder_text_label.insert(tk.END, 'Target Tracking')
    self.em_ss_tracking_folder_type_label = ttk.Label(self.em_ss_admin_frame, textvariable=self.em_ss_tracking_folder_type, cursor='hand1', style='Link.TLabel')
    self.em_ss_tracking_folder_text_label.window_create(tk.END, window=self.em_ss_tracking_folder_type_label, padx=2)
    self.em_ss_tracking_folder_text_label.insert(tk.END, 'ID')
    self.em_ss_tracking_folder_text_label.config(state=tk.DISABLED)

    self.em_ss_tracking_folder_id_entry = ttk.Combobox(self.em_ss_admin_frame, textvariable=self.em_ss_tracking_folder_id, postcommand=lambda:self.pick_smartsheet_folder_generic(self.em_ss_tracking_folder_id_entry, self.em_ss_tracking_folder_type))
    self.em_ss_tracking_folder_id_entry.id_type = tk.StringVar(value='folder')
    self.em_ss_tracking_folder_id_entry.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_tracking_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_admin_frame_row += 1

    self.em_ss_tracking_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: self.folder_type_menu(e, self.em_ss_tracking_folder_id_entry))
    self.em_ss_tracking_folder_type_label.bind('<ButtonRelease-1>', lambda e: self.folder_type_menu(e, self.em_ss_tracking_folder_id_entry))

    
    # SS Admin Copy Tracking Sheet Button
    self.em_ss_copy_tracking_button = ttk.Button(self.em_ss_admin_frame, text='Copy Tracking Sheet', command=lambda:[self.background(self.copy_tracking_sheet)])
    self.em_ss_copy_tracking_button.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=(0,2), sticky=tk.EW)
    StyledHovertip(self.em_ss_copy_tracking_button, text="  -- Copy Tracking Sheet to Folder ID (defined to the left) -- ")
    em_ss_admin_frame_row += 1

    # Horizontal Spacer
    ttk.Separator(self.em_ss_admin_frame, orient='horizontal').grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=0, sticky=tk.EW)
    em_ss_admin_frame_row += 1

    # SS Admin Tracking Sheet Update Sheet ID
    self.em_ss_tracking_update_id = tk.IntVar(value=tracking_sheet_id)
    self.em_ss_tracking_update_id_label = ttk.Label(self.em_ss_admin_frame, text="Update Tracking Sheet ID")
    self.em_ss_tracking_update_id_label.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=0, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_tracking_update_id_entry = ttk.Combobox(self.em_ss_admin_frame, textvariable=self.em_ss_tracking_update_id, postcommand=lambda:self.pick_smartsheet_sheet(self.em_ss_tracking_update_id_entry))
    self.em_ss_tracking_update_id_entry.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_tracking_update_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_admin_frame_row += 1

    # SS Admin Tracking Sheet Update Source Folder
    self.em_ss_tracking_update_folder_id = tk.IntVar(value=0)
    self.em_ss_tracking_update_folder_type = tk.StringVar(value='Folder')
    self.em_ss_tracking_update_folder_text_label = tk.Text(self.em_ss_admin_frame, bd=0, highlightthickness=0, borderwidth=0, height=1, width=1, cursor='arrow')
    self.em_ss_tracking_update_folder_text_label.configure(selectbackground=self.em_ss_tracking_update_folder_text_label.cget('bg'), inactiveselectbackground=self.em_ss_tracking_update_folder_text_label.cget('bg'))
    self.em_ss_tracking_update_folder_text_label.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=2, sticky=tk.EW)
    em_ss_admin_frame_row += 1
    self.em_ss_tracking_update_folder_text_label.insert(tk.END, 'Source Tracking')
    self.em_ss_tracking_update_folder_type_label = ttk.Label(self.em_ss_admin_frame, textvariable=self.em_ss_tracking_update_folder_type, cursor='hand1', style='Link.TLabel')
    self.em_ss_tracking_update_folder_text_label.window_create(tk.END, window=self.em_ss_tracking_update_folder_type_label, padx=2)
    self.em_ss_tracking_update_folder_text_label.insert(tk.END, 'ID')
    self.em_ss_tracking_update_folder_text_label.config(state=tk.DISABLED)

    self.em_ss_tracking_update_folder_id_entry = ttk.Combobox(self.em_ss_admin_frame, textvariable=self.em_ss_tracking_update_folder_id, postcommand=lambda:self.pick_smartsheet_folder_generic(self.em_ss_tracking_update_folder_id_entry, self.em_ss_tracking_update_folder_type))
    self.em_ss_tracking_update_folder_id_entry.id_type = tk.StringVar(value='folder')
    self.em_ss_tracking_update_folder_id_entry.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=(0,5), sticky=tk.EW)
    self.em_ss_tracking_update_folder_id_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', self.smart_sheet_menu)
    em_ss_admin_frame_row += 1

    self.em_ss_tracking_update_folder_type_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: self.folder_type_menu(e, self.em_ss_tracking_update_folder_id_entry))
    self.em_ss_tracking_update_folder_type_label.bind('<ButtonRelease-1>', lambda e: self.folder_type_menu(e, self.em_ss_tracking_update_folder_id_entry))

    # SS Admin Tracking Sheet Update Button
    self.em_ss_tracking_update_button = ttk.Button(self.em_ss_admin_frame, text='Update Tracking Sheet', command=lambda:[self.background(self.update_tracking_sheet)])
    self.em_ss_tracking_update_button.grid(row=em_ss_admin_frame_row, column=2, padx=5, pady=(0,5), sticky=tk.EW)
    StyledHovertip(self.em_ss_tracking_update_button, text="  -- Update Tracking Sheet with data from Source Folder -- ")
    em_ss_admin_frame_row += 1

    # Log Frame --
    self.em_log_frame = ttk.LabelFrame(self.em_other_frame, text="Log", padding=5, style="Bold.TLabelframe")
    self.em_log_frame.grid(row=0, column=4, padx=5, pady=5, sticky=tk.NSEW)
    self.em_log_frame.columnconfigure(2, weight=1)
    self.em_log_frame.rowconfigure(2, weight=1)

    # Log Text Area
    # self.en_masse_log_label = ttk.Label(self.em_log_frame, text="Log", justify="left")
    # self.en_masse_log_label.grid(row=1, column=2,  padx=5, pady=0, sticky=tk.EW)
    self.en_masse_log_text = tk.Text(self.em_log_frame, wrap='word', height=7, width=10)
    self.en_masse_log_text.grid(row=2, column=2, padx=5, pady=(0,5), sticky=tk.NSEW)
    self.en_masse_log_text.tag_configure("stderr", foreground="red")
    # self.en_masse_log_text.tag_configure("stdout", foreground="black")
    # self.en_masse_log_text.tag_configure("bold", font=("-weight", "bold"))
    # self.en_masse_log_text.tag_configure("italic", font=("-slant", "italic"))
    # self.en_masse_log_text.tag_configure("underline", font=("-underline", "true"))
    # self.en_masse_log_text.tag_configure("strike", font=("-overstrike", "true"))
    # self.en_masse_log_text.tag_configure("highlight", background="yellow")
    # self.en_masse_log_text.tag_configure("link", foreground="blue", underline=True)
    # self.en_masse_log_text.tag_configure("code", font=("Courier New", 10))
    # self.en_masse_log_text.tag_configure("superscript", offset=10)
    # self.en_masse_log_text.tag_configure("subscript", offset=-10)
    # self.en_masse_log_text.tag_configure("bg", background="lightgrey")
    # self.en_masse_log_text.tag_configure("fg", foreground="blue")
    # self.en_masse_log_text.tag_configure("big", font=("Helvetica", 24, "bold"))
    # self.en_masse_log_text.tag_configure("small", font=("Helvetica", 8))
    # self.en_masse_log_text.tag_configure("center", justify="center")
    # self.en_masse_log_text.tag_configure("right", justify="right")
    # self.en_masse_log_text.tag_configure("left", justify="left")
    # self.en_masse_log_text.tag_configure("indent", lmargin1=36, lmargin2=72)
    # self.en_masse_log_text.tag_configure("space", spacing1=12, spacing2=6)
    # self.en_masse_log_text.tag_configure("tab", lmargin1=36, lmargin2=72, tabs=(72, 144, 216, 288, 360))
    # self.en_masse_log_text.tag_configure("firstline", lmargin1=36)
    # self.en_masse_log_text.tag_configure("hanging", lmargin2=36)
    # self.en_masse_log_text.tag_configure("array", lmargin1=36, lmargin2=36, tabs=(36, 72, 108, 144, 180, 216, 252, 288))
    # self.en_masse_log_text.tag_configure("list", lmargin1=36, lmargin2=72, tabs=(72, 108, 144, 180, 216))
    # self.en_masse_log_text.tag_configure("quote", lmargin1=36, lmargin2=72, wrap="word")
    # self.en_masse_log_text.tag_configure("bullet", lmargin1=36, lmargin2=72, tabs=(36, 72, 108, 144, 180))
    # self.en_masse_log_text.tag_configure("definition", lmargin1=36, lmargin2=72, tabs=(36, 72, 108, 144, 180))
    # self.en_masse_log_text.tag_configure("example", lmargin1=36, lmargin2=72, tabs=(36, 72, 108, 144, 180))
    # self.en_masse_log_text.tag_configure("note", lmargin1=36, lmargin2=72, tabs=(36, 72, 108, 144, 180))
    # self.en_masse_log_text.tag_configure("warning", lmargin1=36, lmargin2=72, tabs=(36, 72, 108, 144, 180))
    # self.en_masse_log_text.tag_configure("error", lmargin1=36, lmargin2=72, tabs=(36, 72, 108, 144, 180))

    # Log scrollbar
    self.en_masse_log_scrollbar = ttk.Scrollbar(self.em_log_frame, orient='vertical', command=self.en_masse_log_text.yview)
    self.en_masse_log_scrollbar.grid(row=2, column=3, padx=(0,5), pady=(0,5), sticky=tk.NS)
    self.en_masse_log_text.configure(yscrollcommand=self.en_masse_log_scrollbar.set)

    # Clear Log Label
    self.en_masse_clear_log_label = ttk.Label(self.em_log_frame, text="X", cursor='hand1', style='Link.TLabel')
    self.en_masse_clear_log_label.grid(row=1, column=3, padx=(0,5), pady=(0,5), sticky=tk.EW)
    self.en_masse_clear_log_label.bind('<Button-1>', lambda e: self.en_masse_log_text.delete('1.0', tk.END))
    StyledHovertip(self.en_masse_clear_log_label, text=" -- Clear Log -- ")
    # self.en_masse_clear_log_button = ttk.Button(self.em_log_frame, text='Clear Log', command=lambda:[self.en_masse_log_text.delete('1.0', tk.END)])
    # self.en_masse_clear_log_button.grid(row=1, column=3, padx=(0,5), pady=(0,5), sticky=tk.EW)



    # ---------
    # | Tab 3 |
    # ---------
    self.tab3.columnconfigure(0, weight=1)
    self.tab3.columnconfigure(1, weight=1)

    self.current_dcdd_location = tk.StringVar()
    cur_dcdd_urls = [
      'https://ghe.megaleo.com/DTOE/DCDD_JSON/tree/master/JSONs',
      'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/JSONs',
    ]
    self.current_dcdd_location_entry = ttk.Combobox(self.tab3, textvariable=self.current_dcdd_location, values=cur_dcdd_urls)
    self.current_dcdd_location_entry.current(0)
    self.current_dcdd_location_entry.grid(row=0, column=0, columnspan=99, padx=5, pady=5, sticky=tk.EW)

    self.get_current_dcdds_var = tk.StringVar(value="Not yet retrieved")
    self.get_current_dcdds_button = ttk.Button(self.tab3, text='Get Current DCDDs', command=lambda:[self.background(self.get_current_dcdds, (True,))])
    self.get_current_dcdds_button.grid(row=1, column=0, padx=5, pady=5, sticky=tk.EW)
    self.get_current_dcdds_label = ttk.Label(self.tab3, justify="center", textvariable=self.get_current_dcdds_var)
    self.get_current_dcdds_label.grid(row=1, column=1, padx=5, pady=5, sticky=tk.NW)

    self.current_dcdds_label = ttk.Label(self.tab3, text="Current DCDDs", justify="left")
    self.current_dcdds_label.grid(row=2, column=0, columnspan=99, padx=5, pady=0, sticky=tk.EW)
    self.current_dcdds_frame = ttk.Frame(self.tab3)
    self.current_dcdds_frame.grid(row=3, column=0, columnspan=99, padx=5, pady=(0,5), sticky=tk.EW)
    self.current_dcdds_scrollbar = ttk.Scrollbar(self.current_dcdds_frame)
    self.current_dcdds_hscrollbar = ttk.Scrollbar(self.current_dcdds_frame, orient='horizontal')
    self.current_dcdds_tree_view = ttk.Treeview(self.current_dcdds_frame, yscrollcommand=self.current_dcdds_scrollbar.set, xscrollcommand=self.current_dcdds_hscrollbar.set, show="tree")
    self.current_dcdds_tree_view.column("#0", minwidth=1200, stretch=True) # Guessing on minwidth to handle max length - not that important 1080? 1200?
    self.current_dcdds_tree_view.bind('<Command-a>' if MAC_OS else '<Control-a>', lambda e: self.current_dcdds_tree_view.selection_add(self.current_dcdds_tree_view.get_children()))
    self.current_dcdds_scrollbar.configure(command=self.current_dcdds_tree_view.yview)
    self.current_dcdds_hscrollbar.configure(command=self.current_dcdds_tree_view.xview)
    self.current_dcdds_scrollbar.pack(side="right", fill="y")
    self.current_dcdds_hscrollbar.pack(side="bottom", fill="x")
    self.current_dcdds_tree_view.pack(side="left", fill="both", expand=True)

    # --------------
    # | After Tabs |
    # --------------
    self.background(self.get_current_dcdds, (False,)) # Get Current DCDDs in the background
    
  def background(self, func, args=(), kwargs={}):
    th = threading.Thread(target=func, args=args, kwargs=kwargs)
    th.start()

  def dcdd_name_validation(self, strvar, limit=None):
    text = strvar.get()
    if not text:
      return
    text = re.sub('[^A-Za-z0-9_]', '_', text)
    text = re.sub('__+', '_', text)
    text = re.sub('dcdd', 'DCDD', text, re.I)
    if limit:
      text = text[:limit]
    strvar.set(text)

  def get_current_dcdds(self, show_msg=False):
    self.get_current_dcdds_button.config(state=tk.DISABLED)
    self.get_current_dcdds_var.set(value=" -- Retrieving DCDDs -- ")
    try:
      if self.github is None:self.github = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
      self.all_dcdds = self.github.get_jsons_from_zip(url=self.current_dcdd_location.get())
      self.current_dcdds_tree_view.delete(*self.current_dcdds_tree_view.get_children())
      for dcdd in sorted(x for x in self.all_dcdds): self.current_dcdds_tree_view.insert('', tk.END, text=F'{dcdd} ({self.all_dcdds[dcdd]['metadata']['WEB SERVICE']}: {self.all_dcdds[dcdd]['metadata']['WEB SERVICE OPERATION']})')
      self.all_web_services = sorted({ws for d in self.all_dcdds for ws in (self.all_dcdds[d]['metadata']['WEB SERVICE'] or '').split(', ') if ws})
      self.en_masse_web_service_tree_view.delete(*self.en_masse_web_service_tree_view.get_children())
      for ws in self.all_web_services: self.en_masse_web_service_tree_view.insert('', tk.END, text=ws)
      self.all_operations = sorted({self.all_dcdds[d]['metadata']['WEB SERVICE OPERATION'] for d in self.all_dcdds if self.all_dcdds[d]['metadata'].get('WEB SERVICE OPERATION')})
      self.en_masse_operation_tree_view.delete(*self.en_masse_operation_tree_view.get_children())
      for op in self.all_operations: self.en_masse_operation_tree_view.insert('', tk.END, text=op)
      self.get_current_dcdds_var.set(value=F"Last retrieved at {datetime.now()}")
      if show_msg: messagebox.showinfo("DCDD Generator",message=F"{len(self.all_dcdds)} DCDDs {len(self.all_web_services)} Web Services {len(self.all_operations)} Operations")
    except Exception as e:
      # get stack trace
      exc_type, exc_obj, exc_tb = sys.exc_info()
      fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
      print(exc_type, fname, exc_tb.tb_lineno)
      if show_msg: messagebox.showerror("DCDD Generator Error", message=F'Error Retrieving Current DCDDs from GitHub!\n{e}')
    # Check if the root window is still running before configuring the button
    if self.root.winfo_exists():
      self.get_current_dcdds_button.config(state=tk.NORMAL)

  def pick_smartsheet_folder(self, widget):
    ssp = Smartsheet_Picker(self.root, x_y=(widget.winfo_rootx(), widget.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      widget.setvar(widget.cget('textvariable'), ssp.result['id'])
      # print(ssp.result)
      widget.id_type.set(ssp.result['type'])
      self.ss_save_folder_type.set(value=ssp.result['type'].title()),
    self.after(1, lambda: widget.event_generate('<Escape>'))

  def pick_smartsheet_folder_generic(self, entry, label_var):
    ssp = Smartsheet_Picker(self.root, x_y=(entry.winfo_rootx(), entry.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      entry.setvar(entry.cget('textvariable'), ssp.result['id'])
      entry.id_type.set(ssp.result['type'])
      label_var.set(value=ssp.result['type'].title()),
    self.after(1, lambda: entry.event_generate('<Escape>'))

  def em_pick_smartsheet_folder(self, widget):
    ssp = Smartsheet_Picker(self.root, x_y=(widget.winfo_rootx(), widget.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      widget.setvar(widget.cget('textvariable'), ssp.result['id'])
      # print(ssp.result)
      widget.id_type.set(ssp.result['type'])
      self.em_ss_save_folder_type.set(value=ssp.result['type'].title()),
    self.after(1, lambda: widget.event_generate('<Escape>'))

  def pick_smartsheet_sheet(self, widget):
    ssp = Smartsheet_Picker(self.root, 'sheet', x_y=(widget.winfo_rootx(), widget.winfo_rooty()))
    self.wait_window(ssp.top)
    if ssp.result:
      widget.setvar(widget.cget('textvariable'), ssp.result['id'])
      # print(ssp.result)
    self.after(1, lambda: widget.event_generate('<Escape>'))

  def smart_sheet_menu(self, e):
    widget = e.widget
    ssl = SmartsheetLib(self.root.vars['ss_token'].get())
    id = widget.get()
    try: id_type = widget.id_type.get()
    except: id_type = 'sheet'
    ss_menu = tk.Menu(widget, tearoff=0)
    ss_menu.add_command(label='Copy ID', command=lambda: [
      widget.clipboard_clear(), 
      widget.clipboard_append(id)
    ])
    ss_menu.add_separator()
    ss_menu.add_command(label='Copy URL', command=lambda: [
      widget.clipboard_clear(), 
      widget.clipboard_append(ssl.get_url_from_sheet_id(id) if id_type == 'sheet' else ssl.get_url_from_folder_id(id, id_type))
    ])
    ss_menu.add_command(label='Open URL', command=lambda: [
      webbrowser.open(ssl.get_url_from_sheet_id(id) if id_type == 'sheet' else ssl.get_url_from_folder_id(id, id_type))
    ])
    ss_menu.add_separator()
    ss_menu.add_command(label='Select/Find ID', command=lambda: [
      self.pick_smartsheet_sheet(widget) if id_type == 'sheet' else self.em_pick_smartsheet_folder(widget)
    ])
    ss_menu.post(e.x_root, e.y_root)

  def folder_type_menu(self, e, entry=None):
    widget = e.widget
    type_menu = tk.Menu(widget, tearoff=0)
    type_menu.add_command(label='Workspace', command=lambda:[
      widget.setvar(widget.cget('textvariable'), 'Workspace'),
      entry.id_type.set('workspace'),
    ])
    type_menu.add_command(label='Folder', command=lambda:[
      widget.setvar(widget.cget('textvariable'), 'Folder'),
      entry.id_type.set('folder'),
    ])
    type_menu.add_command(label='Home', command=lambda:[
      widget.setvar(widget.cget('textvariable'), 'Home'),
      entry.id_type.set('home'),
    ])
    type_menu.post(e.x_root, e.y_root)

  def em_json_to_dcdd(self):
    # Get JSONs from Save Folder Location
    save_path = self.em_save_path.get()
    if not save_path or not Path(save_path).is_dir():
      messagebox.showerror("JSONs to DCDDs", message='Bad path to JSONs Folder!')
      return
    json_files = [str(f) for f in Path(save_path).iterdir() if f.is_file() and f.suffix == '.json']
    if not json_files:
      messagebox.showerror("JSONs to DCDDs", message='No JSON files found in JSONs Folder!')
      return
    ss_token = self.root.vars['ss_token'].get()
    if not ss_token:
       messagebox.showerror("JSON to DCDD", message='Missing Smartsheet Token!')
       return
    dcdd_template_id = int(self.em_ss_template_id.get())
    dest_folder_id = int(self.em_ss_save_folder_id.get()) if self.em_ss_save_folder_id_entry.id_type.get() != 'home' else '1'
    if not all([dcdd_template_id, dest_folder_id]):
      messagebox.showerror("JSON to DCDD", message=F'Missing Smartsheet Folder or Template ID!')
      return
    sub_dir_name = self.em_ss_sub_dir_name.get()
    if not sub_dir_name and self.em_ss_create_sub_dir.get():
      self.em_ss_sub_dir_name.set(F'{self.em_version.get()}_{datetime.now().strftime("%Y%m%d%H%M%S")}')
      messagebox.showwarning("JSON to DCDD", message='Sub Directory Name is required! Defaulting to version and current date and time.')
      sub_dir_name = self.em_ss_sub_dir_name.get()
    # Redirect stdout and stderr
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")

    self.em_json_to_dcdd_button.config(state=tk.DISABLED)

    # Create smarthsheet sub directory in folder
    if self.em_ss_create_sub_dir.get():
      ssl = SmartsheetLib(ss_token)
      ss = ssl.client
      ss.errors_as_exceptions(True)
      try:
        if self.em_ss_save_folder_id_entry.id_type.get() == 'folder':
          new_folder = ss.Folders.create_folder_in_folder(dest_folder_id, sub_dir_name)
        elif self.em_ss_save_folder_id_entry.id_type.get() == 'workspace':
          new_folder = ss.Workspaces.create_folder_in_workspace(dest_folder_id, sub_dir_name)
        else: # home
          new_folder = ss.Home.create_folder(sub_dir_name)
      except Exception as e:
        messagebox.showerror("JSON to DCDD", message=F'Error Creating Smartsheet Sub Directory: {e}')
        self.em_json_to_dcdd_button.config(state=tk.NORMAL)
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        return
      self.em_ss_save_folder_id.set(new_folder.result.id)
      self.em_ss_save_folder_type.set('Folder')
      self.em_ss_save_folder_id_entry.id_type.set('folder')
      self.em_ss_create_sub_dir.set(False)
      self.em_ss_tracking_update_folder_id.set(new_folder.result.id)
      self.em_ss_tracking_update_folder_type.set('Folder')
      self.em_ss_tracking_update_folder_id_entry.id_type.set('folder')


    # Limit the number of threads
    max_threads = 5  # Set the maximum number of threads
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
      futures = []
      for json_file in json_files:
        futures.append(executor.submit(self.json_to_dcdd, em=True, json_path=json_file))
      # Wait for all futures to complete
      concurrent.futures.wait(futures)
    messagebox.showinfo("JSONs to DCDDs", message=F'All JSONs have been processed! Folder {new_folder.result.permalink}\n ID ({new_folder.result.id}) set as Main Folder ID & Source Tracking Folder ID')
    print(F'All JSONs have been processed! Folder {new_folder.result.permalink}\n ID ({new_folder.result.id}) set as Main Folder ID & Source Tracking Folder ID')
    self.em_json_to_dcdd_button.config(state=tk.NORMAL)
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
            
  def json_to_dcdd(self, em=False, json_path=None):
    if em: 
      thread_name = threading.current_thread().name
      print(F"Thread ({thread_name}) Processing {json_path}")
    ss_token = self.root.vars['ss_token'].get()
    if not ss_token:
       messagebox.showerror("JSON to DCDD", message='Missing Smartsheet Token!')
       return
    json_path = self.save_path.get() if not em else json_path
    if not json_path or not json_path.endswith('.json') or not Path(json_path).is_file():
       messagebox.showerror("JSON to DCDD", message=F'Bad path to JSON file: {json_path}')
       return
    if not em:
      if not self.use_exisiting_sheet.get():
        dcdd_template_id = int(self.ss_template_id.get())
        dest_folder_id = int(self.ss_save_folder_id.get()) if self.ss_save_folder_id_entry.id_type.get() != 'home' else '1'
        if not all([dcdd_template_id, dest_folder_id]):
          messagebox.showerror("JSON to DCDD", message=F'Missing Smartsheet Folder or Template ID!')
          return
      else: # Using existing sheet
        new_sheet_id = int(self.ss_existing_sheet_id.get())
        if not new_sheet_id:
          messagebox.showerror("JSON to DCDD", message=F'Missing Smartsheet Existing Sheet ID!')
          return
    else: # En Masse 
      dcdd_template_id = int(self.em_ss_template_id.get())
      dest_folder_id = int(self.em_ss_save_folder_id.get()) if self.em_ss_save_folder_id_entry.id_type.get() != 'home' else '1'
      if not all([dcdd_template_id, dest_folder_id]):
        print('Missing Smartsheet Folder or Template ID!')
        return
      
    if not em:
      # Redirect stdout and stderr
      sys.stdout = TextRedirector(self.log_text, "stdout")
      sys.stderr = TextRedirector(self.log_text, "stderr")
    
    try:
      with open(json_path) as f:
        json_dcdd = json.load(f)
      ssl = SmartsheetLib(ss_token)
      ss = ssl.client
    except Exception as e:
      print(F"{thread_name} - Error loading JSON file: {e}", file=sys.stderr)
      if not em:
        messagebox.showerror("JSON to DCDD", message=e)
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
      return      
    
    if not em: self.json_to_dcdd_button.config(state=tk.DISABLED)
    if not self.use_exisiting_sheet.get() or em:
      new_name = json_dcdd.get('short_name')[:50] or json_path.stem[:50] or json_dcdd.get('metadata', {}).get('FULL NAME', '')[:50] # 50 char limit
      if em:
        destination_type = self.em_ss_save_folder_id_entry.id_type.get() # folder, workspace, or home
        destination_id = dest_folder_id if self.em_ss_save_folder_id_entry.id_type.get() != 'home' else None # folder_id (null for home folder)
      else:
        destination_type = self.ss_save_folder_id_entry.id_type.get() # folder, workspace, or home
        destination_id = dest_folder_id if self.ss_save_folder_id_entry.id_type.get() != 'home' else None # folder_id (null for home folder)
      copy_response = ss.Sheets.copy_sheet(dcdd_template_id, 
              ss.models.ContainerDestination({
                'destination_type': destination_type,
                'destination_id': destination_id,
                'new_name': new_name,             # 50 char limit
              }),
              include=['filters']
            )
      print(F"  Creating new DCDD ({new_name} : {copy_response.result.permalink if copy_response.result.permalink else ''}) from Blank Template to Dev Folder: {copy_response.message}") # Looking for SUCCESS
      if copy_response.message != "SUCCESS":
        if not em:
          messagebox.showerror("JSON to DCDD", message="Template Copy Failed!")
          self.json_to_dcdd_button.config(state=tk.NORMAL)
        print(F"{thread_name} - Template Copy Failed for {json_dcdd.get('name')}: {copy_response.message}", file=sys.stderr)
        return
      else:
        if not em: self.ss_dcdd_location.set(copy_response.result.permalink if copy_response.result.permalink else '')
      new_sheet_id = copy_response.data.id
    else: # Using Existing Sheet
      new_sheet_id = new_sheet_id
    new_sheet_data = ss.Sheets.get_sheet(new_sheet_id)
    self.ss_dcdd_location.set(new_sheet_data.permalink if new_sheet_data.permalink else '')
    new_summary_data = ss.Sheets.get_sheet_summary_fields(new_sheet_id, include_all=True)

    # map metadata to new sheet summary fields
    fields = {s.title: s.to_dict() for s in new_summary_data.data}
    mapped_fields = {m:fields[m] for m in json_dcdd['metadata'] if m in fields}

    # add metadata to summary
    new_fields = []
    for field in mapped_fields:
      json_data =  json_dcdd['metadata'][field]
      if not json_data: # skip empty fields or use empty string if None?
        # continue
        json_data = ''
      if type(json_data) == list:
        json_data = ', '.join(json_data)
      
      new_fields.append(
        ss.models.SummaryField({
          'id': mapped_fields[field]['id'],
          'type': mapped_fields[field]['type'],
          'object_value': json_data,
          'title': field,
        })
      )
    if new_fields:
      field_result = ss.Sheets.update_sheet_summary_fields(new_sheet_id, new_fields, False) # rename_if_conflict
      print(F"  Adding Summary Data from Source JSON to New Sheet: {field_result.message}") # Looking for SUCCESS
    if field_result.message != "SUCCESS":
      if not em: 
        messagebox.showerror("JSON to DCDD", message="Adding Summary Data Failed!")
      print(F"{thread_name} - Adding Summary Data Failed ({json_dcdd.get('name')}): {field_result.message}", file=sys.stderr)
      # return

    # map row columns to new sheet columns
    column_ids = {c.title:{'id':c.id, 'version':c.version} for c in new_sheet_data.columns}
    mapped_columns = {c:{'id':column_ids[c]['id'], 'index':i, 'version':column_ids[c]['version']} for i,c in enumerate(json_dcdd['columns']) if c in column_ids}  

    # add data to sheet
    new_rows = []
    update_rows = []
    delete_rows = []
    strike_rows = []

    if not em and self.use_exisiting_sheet.get() and self.ss_merge_existing_rows.get():
      NEW_XPATH_IDX = mapped_columns['XPATH']['index'] if mapped_columns.get('XPATH', None) else None
      NEW_NAME_IDX = mapped_columns['WD Field Name']['index'] if mapped_columns.get('WD Field Name', None) else None
      NEW_HEADER_IDX = mapped_columns['csv Header']['index'] if mapped_columns.get('csv Header', None) else None
      OLD_XPATH_IDX = next((i for i, c in enumerate(new_sheet_data.columns) if c.title == 'XPATH' ), None)
      OLD_NAME_IDX = next((i for i, c in enumerate(new_sheet_data.columns) if c.title == 'WD Field Name'), None)
      OLD_HEADER_IDX = next((i for i, c in enumerate(new_sheet_data.columns) if c.title == 'csv Header'), None)

      # START COMPARING
      old_xpaths = [r.cells[OLD_XPATH_IDX].display_value for r in new_sheet_data.rows]
      new_xpaths = [r[NEW_XPATH_IDX] for r in json_dcdd['rows']]

      old_non_matching_xpaths = set(old_xpaths) - set(new_xpaths)
      old_non_match_rows = [r for r in new_sheet_data.rows if r.cells[OLD_XPATH_IDX].display_value in old_non_matching_xpaths]
      old_dcdd_non_match_names = [r.cells[OLD_NAME_IDX].display_value for r in old_non_match_rows]

      for i, json_row in enumerate(json_dcdd['rows'], 1):
        found_match = False
        current_row = ss.models.Row()
        # current_row.row_number = i
        if json_row[NEW_XPATH_IDX] in old_xpaths:
          if old_xpaths.count(json_row[NEW_XPATH_IDX]) > 1:
            old_row = next((r for r in new_sheet_data.rows if r.cells[OLD_XPATH_IDX].display_value == json_row[NEW_XPATH_IDX] and r.cells[OLD_HEADER_IDX].display_value == json_row[NEW_HEADER_IDX]), None)
            if old_row: found_match = True
          else:
            old_row = next(r for r in new_sheet_data.rows if r.cells[OLD_XPATH_IDX].display_value == json_row[NEW_XPATH_IDX])
            found_match = True
          if found_match: current_row.id = old_row.id
        for c in mapped_columns:
          cell_data = json_row[mapped_columns[c]['index']]
          if not cell_data: # Use empty string if None
            cell_data = ''
          if mapped_columns[c]['version'] == 2: # multi
            current_row.cells.append({
              'column_id': mapped_columns[c]['id'],
              'object_value': ss.models.MultiPicklistObjectValue({'values': cell_data.split(', ')}),
              'strict': False,
            })
          else:
            current_row.cells.append({
              'column_id': mapped_columns[c]['id'],
              'value': cell_data,
              'strict': False,
            })
        if found_match:
          update_rows.append(current_row)
        else:
          new_rows.append(current_row)

      # Delete non-matching rows or format
      if self.ss_delete_existing_rows.get() and old_non_match_rows:
        delete_rows = [x.id for x in old_non_match_rows]
      elif not self.ss_delete_existing_rows.get() and old_non_match_rows:
        for old_row in old_non_match_rows:
          current_row = ss.models.Row()
          current_row.id = old_row.id
          for c in mapped_columns:
            cell_data = old_row.cells[mapped_columns[c]['index']].display_value
            if not cell_data: # Use empty string if None
              cell_data = ''
            if mapped_columns[c]['version'] == 2: # multi
              current_row.cells.append({
                'column_id': mapped_columns[c]['id'],
                'object_value': ss.models.MultiPicklistObjectValue({'values': cell_data.split(', ')}),
                'strict': False,
              })
            else:
              current_row.cells.append({
                'column_id': mapped_columns[c]['id'],
                # 'value': F"DELETED_ROW {cell_data}",
                'value': cell_data,
                'format': ",,,,,1,,,,,,,,,,,",
                'strict': False,
              })
          strike_rows.append(current_row)

    else:
      # Add new rows as is
      for json_row in json_dcdd['rows']:
        new_row = ss.models.Row()
        new_row.to_top = True
        for c in mapped_columns:
          if not json_row[mapped_columns[c]['index']]: # Skip empty values
            continue
          if mapped_columns[c]['version'] == 2: # multi
            new_row.cells.append({
              'column_id': mapped_columns[c]['id'],
              'object_value': ss.models.MultiPicklistObjectValue({'values': json_row[mapped_columns[c]['index']].split(', ')}),
              'strict': False,
            })
          else:
            new_row.cells.append({
              'column_id': mapped_columns[c]['id'],
              'value': json_row[mapped_columns[c]['index']],
              'strict': False,
            })
        new_rows.append(new_row)

    if new_rows:
      row_result = ss.Sheets.add_rows(new_sheet_id, new_rows)
      print(F"  Adding Row Data ({len(new_rows)}) from Source JSON to New or Existing Sheet: {row_result.message}") # Looking for SUCCESS
      if row_result.message != "SUCCESS":
        if not em: messagebox.showerror("JSON to DCDD", message="Adding Row Data Failed!")
        else: print(F"{thread_name} - Adding Row Data Failed ({json_dcdd.get('name')}): {row_result.message}")
        # return

    if update_rows:
      row_result = ss.Sheets.update_rows(new_sheet_id, update_rows)
      print(F"  Updating Row Data ({len(update_rows)}) from Source JSON to Existing Sheet: {row_result.message}") # Looking for SUCCESS
      if row_result.message != "SUCCESS":
        messagebox.showerror("JSON to DCDD", message="Updating Row Data Failed!")
        # return  

    if delete_rows:
      row_result = ss.Sheets.delete_rows(new_sheet_id, delete_rows)
      print(F"  Deleting Row Data ({len(delete_rows)}) from Existing Sheet: {row_result.message}") # Looking for SUCCESS
      if row_result.message != "SUCCESS":
        messagebox.showerror("JSON to DCDD", message="Deleting Row Data Failed!")
        # return

    if strike_rows:
      row_result = ss.Sheets.update_rows(new_sheet_id, strike_rows)
      print(F"  Striking Row Data ({len(strike_rows)}) from Existing Sheet: {row_result.message}") # Looking for SUCCESS
      if row_result.message != "SUCCESS":
        messagebox.showerror("JSON to DCDD", message="Striking Row Data Failed!")
        # return

    # Order rows in sheet by new DCDD order
    if not em and self.use_exisiting_sheet.get() and self.ss_order_existing.get():
      # Add sorting column
      temp_col_title = F'TEMP_SORTING_COLUMN_{datetime.now().strftime("%Y%m%d%H%M%S")}'
      sort_column = ss.models.Column({
        'title': temp_col_title,
        'type': 'TEXT_NUMBER',
        'index': 999,
      })
      column_result = ss.Sheets.add_columns(new_sheet_id, [sort_column])
      print(F"  Adding Temporary Sorting Column: {column_result.message}") # Looking for SUCCESS
      if column_result.message == "SUCCESS":
        new_sheet_data = ss.Sheets.get_sheet(new_sheet_id)
        # Get sorting column id
        sort_column_id = next((c.id for c in new_sheet_data.columns if c.title == temp_col_title), None)
        # Get row ids and xpath
        new_updated_rows = {r.id:(r.cells[OLD_XPATH_IDX].display_value, r.cells[OLD_HEADER_IDX].display_value) for r in new_sheet_data.rows}
        # print(new_updated_rows)
        ordered_xpaths = [(r[NEW_XPATH_IDX], r[NEW_HEADER_IDX]) for r in json_dcdd['rows']]
        # print(ordered_xpaths)
        ordered_xpaths_length = len(ordered_xpaths)
        print(F"  Sorting {ordered_xpaths_length} Rows: ")
        # Add sort values to rows
        rows_to_update = []
        for rid in new_updated_rows:
          # Get index of row in ordered_xpaths (if exists)
          row_index = ordered_xpaths.index(new_updated_rows[rid]) if new_updated_rows[rid] in ordered_xpaths else 999999999
          new_cell = ss.models.Cell()
          new_cell.column_id = sort_column_id
          new_cell.value = row_index
          new_cell.strict = False
          new_row = ss.models.Row()
          new_row.id = rid
          new_row.cells.append(new_cell)
          rows_to_update.append(new_row)
        print(F"  Updating Temporary Sorting Column: ", end='')
        row_result = ss.Sheets.update_rows(new_sheet_id, rows_to_update)
        print(row_result.message) # Looking for SUCCESS
        if row_result.message == "SUCCESS":
          # Sort by sort column
          sort_specifier = ss.models.SortSpecifier({
              'sort_criteria': [ss.models.SortCriterion({
                  'column_id': sort_column_id,
                  'direction': 'ASCENDING'
              })]
          })
          print(F"  Sorting Rows ...")
          sorted_sheet = ss.Sheets.sort_sheet(new_sheet_id, sort_specifier)
          
          if sorted_sheet:
            # Delete sorting column
            column_result = ss.Sheets.delete_column(new_sheet_id, sort_column_id)
            print(F"  Deleting Temporary Sorting Column: {column_result.message}")
          else:
            print(F"  Sorting Rows Failed! Rows not sorted.", file=sys.stderr)
            messagebox.showerror("JSON to DCDD", message="Sorting Rows Failed! Rows not sorted.")
        else:
          print(F"  Updating Temporary Sorting Column Failed! Rows not sorted.", file=sys.stderr)
          messagebox.showerror("JSON to DCDD", message="Updating Temporary Sorting Column Failed! Rows not sorted.")

        # previous_row_id = None
        # for i, (xpath, header) in enumerate(ordered_xpaths):
        #   row_id = next((k for k, (v1, v2) in new_updated_rows.items() if v1 == xpath and v2 == header), None)
        #   # print(xpath, header, row_id)
        #   if row_id:
        #     previous_row_id = row_id
        #     current_row = ss.models.Row()
        #     current_row.id = row_id
        #     if i == 0:
        #       current_row.to_top = True
        #     else:
        #       current_row.sibling_id = previous_row_id # [x for x in new_updated_rows][i-1]
        #     row_result = ss.Sheets.update_rows(new_sheet_id, [current_row])
        #     print(F"  Reordering Row {i+1}/{ordered_xpaths_length} ({row_id}): {row_result.message}") # Looking for SUCCESS
      else: 
        print(F"  Adding Temporary Sorting Column Failed! Rows not sorted.", file=sys.stderr)
        messagebox.showerror("JSON to DCDD", message="Adding Temporary Sorting Column Failed! Rows not sorted.")
        

    if not em: 
      self.json_to_dcdd_button.config(state=tk.NORMAL)
      show_message = F"""DCDD {json_dcdd.get('short_name')} has been processed! ({('New ' + str(len(new_rows)) + ';') if new_rows else ''}{('Updated ' + str(len(update_rows)) + ';') if update_rows else ''}{('Deleted ' + str(len(delete_rows)) + ';') if delete_rows else ''}{('Struck ' + str(len(strike_rows)) + ';') if strike_rows else ''})"""
      messagebox.showinfo("JSON to DCDD", message=show_message)
      print(show_message)

      # restore stdout and stderr
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__


  def save_dcdd(self, file_type='csv', upgrade=False):
    csv = file_type.lower() != 'json' # default everything else to csv
    # print(file_type, csv)
    if not self.operation.get():
      messagebox.showerror(title='Save Error', message='Missing Operation')
      return
    if upgrade:
      if self.all_dcdds is None or self.all_operations is None or self.operation.get() not in self.all_operations:
        # print('all_dcdds', self.all_dcdds is not None, self.operation.get(), self.operation.get() not in self.all_operations)
        messagebox.showerror(title='Save Error', message=F"Couldn't find the operation {self.operation.get()} in the current DCDDs")
        return
      upgradable_dcdds = [x for x in self.all_dcdds if self.operation.get() == self.all_dcdds[x]['metadata']['WEB SERVICE OPERATION']]
      if len(upgradable_dcdds) > 1:
        messagebox.showinfo(title='Upgrade Info', message='Note that more than one current DCDD matches this Operation. The Full/Short Name Overrides will be ignored!' )
    else:
      init_file_name = (self.full_name.get() + ("_WSO_Extract.csv" if csv else ".json")) if self.full_name.get() else F"{self.operation.get()}_DCDD{"_WSO_Extract.csv" if csv else ".json"}"
      fname = filedialog.asksaveasfilename(title=F"Save as {'CSV' if csv else 'JSON'}", defaultextension=".csv" if csv else ".json", filetypes=(("CSV Files", "*.csv") if csv else ("JSON Files", "*.json"), ("All Files", "*.*")), initialfile=init_file_name)
      if not fname:
        return
    self.save_as_csv_button.config(state=tk.DISABLED)
    self.save_as_proposed_json_button.config(state=tk.DISABLED)
    # self.save_as_upgraded_json_button.config(state=tk.DISABLED)
    try:
      if not self.wsdl or self.wsdl.get_name() != self.web_service.get():
        self.wsdl = WSDL(url=self.wsdl_url.get())
      self.wsdl.get_proposed_dcdd(self.operation.get())
      if csv:
        self.wsdl.save_to_csv(fname)
      else:
        if upgrade:
          for up_dcdd in upgradable_dcdds:
            if len(upgradable_dcdds) == 1:
              init_file_name = self.full_name.get() or up_dcdd
              full_name = self.full_name.get()
              short_name = self.short_name.get()
            else:
              init_file_name = up_dcdd
              full_name = None
              short_name = None
            fname = filedialog.asksaveasfilename(title=F"Save as JSON", defaultextension=".json", filetypes=(("JSON Files", "*.json"), ("All Files", "*.*")), initialfile=F"{init_file_name}.json")
            if not fname:
              continue
            self.wsdl.save_to_upgraded_json(fname, self.all_dcdds.get(up_dcdd), full_name=full_name, short_name=short_name)
        else:
          self.wsdl.save_to_json(fname, full_name=self.full_name.get(), short_name=self.short_name.get())
      self.save_path.set(fname)
    except Exception as e:
        messagebox.showerror(title='WSDL Error', message=e)
    self.save_as_csv_button.config(state=tk.NORMAL)
    self.save_as_proposed_json_button.config(state=tk.NORMAL)
    # self.save_as_upgraded_json_button.config(state=tk.NORMAL)

  def en_mass_upgrade(self, csv=False):
    
    if not Path(self.em_save_path.get()).is_dir():
      self.em_save_path.set(filedialog.askdirectory(title=F"Select an Output Folder") or self.em_save_path.get())
      if not Path(self.em_save_path.get()).is_dir():
        messagebox.showerror(title='En Masse DCDD Error', message='Bad Folder Location')
        return

    self.em_save_as_upgraded_json_button.config(state=tk.DISABLED)
    self.em_save_as_csv_button.config(state=tk.DISABLED)

    # Redirect stdout and stderr to log text area
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")

    # Get Selections
    selected_web_services = [self.en_masse_web_service_tree_view.item(x)['text'] for x in self.en_masse_web_service_tree_view.selection()]
    # print(selected_web_services)
    selected_operations = [self.en_masse_operation_tree_view.item(x)['text'] for x in self.en_masse_operation_tree_view.selection()]
    # print(selected_operations)
    matching_dcdds = [d for d in self.all_dcdds if self.all_dcdds[d]['metadata']['WEB SERVICE'] and any(ws.strip() in selected_web_services for ws in self.all_dcdds[d]['metadata']['WEB SERVICE'].split(',')) and self.all_dcdds[d]['metadata']['WEB SERVICE OPERATION'] in selected_operations]
    # print(matching_dcdds)
    
    parsing_dict = {}
    for dcdd in matching_dcdds:
      # Get first web service of each DCDD
      ws = self.all_dcdds[dcdd]['metadata']['WEB SERVICE'].split(',')[0]
      if ws not in parsing_dict:
        parsing_dict[ws] = []
      op = self.all_dcdds[dcdd]['metadata']['WEB SERVICE OPERATION']
      parsing_dict[ws].append((dcdd, op))
    # print(parsing_dict)

    # Loop through WS and Ops
    dc = ''.join(data_centers.get(self.dc.get(), [])[0:1]) or next((x for x in self.dc.get().split('/') if x not in ['https:', '']), '')
    for ws in parsing_dict:
      wsdl_url = F'https://{dc}/ccx/service/{self.tenant.get()}/{ws}/{self.em_version.get()}?wsdl'
      wsdl = WSDL(url=wsdl_url, debug=True)
      for dcdd, op in parsing_dict[ws]:
        print(F"DCDD: {dcdd}, OP: {op}")
        fname = Path(self.em_save_path.get()) / F'{dcdd}.json'
        try:
          wsdl.get_proposed_dcdd(op)
        except Exception as e:
          print(F'Error parsing WSDL for {op} in {ws}\n{e}\n{traceback.format_exc()}\n\nSkipping to next', file=sys.stderr)
          # messagebox.showerror(title='En Masse DCDD Error', message=F'Error parsing WSDL for {op} in {ws}\n{e}\n{traceback.format_exc()}\n\nSkipping to next')
          continue
        try:
          if csv:
            wsdl.save_to_csv(fname.with_suffix('.csv'))
          else:
            wsdl.save_to_upgraded_json(fname, self.all_dcdds.get(dcdd))
        except Exception as e:
          print(F'Error upgrading DCDD for {op} in {ws}\n{e}\nSkipping to next', file=sys.stderr)
          # messagebox.showerror(title='En Masse DCDD Error', message=F'Error upgrading DCDD for {op} in {ws}\n{e}\nSkipping to next')
          continue

    self.em_save_as_upgraded_json_button.config(state=tk.NORMAL)
    self.em_save_as_csv_button.config(state=tk.NORMAL)
    # reset stdout and stderr
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

  def update_wsdl_service_url(self, *kwargs):
    dc = ''.join(data_centers.get(self.dc.get(), [])[0:1]) or next((x for x in self.dc.get().split('/') if x not in ['https:', '']), '')
    url = F'https://{dc}/ccx/service/{self.tenant.get()}/{self.web_service.get()}/{self.version.get()}?wsdl'
    # print(url)
    self.wsdl_url.set(url)
    self.wsdl_url_tip.text = url
    self.operation.set('')
    self.operation_entry.configure(values=[])

  def get_operations(self):
    self.operation.set('... Refreshing Operations ...')
    self.get_operation_button.config(state=tk.DISABLED)
    try:
      if not self.wsdl or self.wsdl.get_name != self.web_service.get():
        self.wsdl = WSDL(url=self.wsdl_url.get())
      self.operation_entry.configure(values=sorted(self.wsdl.list_all_operations()))
      self.operation_entry.current(0)
      self.operation_entry.event_generate('<Configure>')
    except Exception as e:
        self.operation.set('')
        messagebox.showerror(title='WSDL Error', message=e)
    self.get_operation_button.config(state=tk.NORMAL)

  def on_combo_configure(self, event):
    style = ttk.Style()
    # check if the combobox already has the "postoffest" property
    current_combo_style = event.widget.cget('style') or "TCombobox"
    combo_values = event.widget.cget('values')
    if len(combo_values) == 0:
        return
    longest_value = max(combo_values, key=len)
    font = tkfont.Font(font=event.widget.cget('font'))
    offset_width = font.measure(longest_value + "000") - (event.width)
    if (offset_width<0):
        # no need to make the popdown smaller
        return
    # create an unique style name using widget's id
    unique_name=F'Combobox{event.widget.winfo_id()}'
    # the new style must inherit from curret widget style (unless it's our custom style!) 
    if unique_name in current_combo_style:
        style_name = current_combo_style 
    else:
        style_name = F"{unique_name}.{current_combo_style}"
    style.configure(style_name, postoffset=(-offset_width//2,0,offset_width,0))
    event.widget.configure(style=style_name)

  def json_to_csv(self):
    json_path = self.save_path.get()
    if not json_path or not json_path.endswith('.json') or not Path(json_path).is_file():
       messagebox.showerror("JSON to CSV", message=F'Bad path to JSON file: {json_path}')
       return
    json_path = Path(json_path)
    try:
      with open(json_path) as f:
        json_dcdd = json.load(f)
    except Exception as e:
      messagebox.showerror("JSON to CSV", message=e)
    if json_dcdd: 
      with open(json_path.with_suffix('.csv'), 'w', newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(json_dcdd['columns'])
        csv_writer.writerows(json_dcdd['rows'])
      with open(json_path.with_stem(json_path.stem + '_META').with_suffix('.csv'), 'w', newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(json_dcdd['metadata'].keys())
        csv_writer.writerow(json_dcdd['metadata'].values())

  def csv_to_json(self, path, meta_path):
    pass

  def copy_tracking_sheet(self):
    ss = SmartsheetLib(self.root.vars['ss_token'].get())
    tracking_sheet_id = self.em_ss_tracking_id.get()
    if not tracking_sheet_id:
      messagebox.showerror("Copy Tracking Sheet", message='Missing Tracking Sheet ID')
      return
    dest_folder_id = int(self.em_ss_tracking_folder_id.get()) if self.em_ss_tracking_folder_id_entry.id_type.get() != 'home' else '1'
    if not dest_folder_id:
      messagebox.showerror("Copy Tracking Sheet", message='Missing Destination Folder ID')
      return
    self.em_ss_copy_tracking_button.config(state=tk.DISABLED)
    # redirect stdout and stderr
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")
    try:
      new_sheet = ss.copy_sheet(tracking_sheet_id, dest_folder_id, self.em_ss_tracking_folder_id_entry.id_type.get())
      if new_sheet:
        messagebox.showinfo("Copy Tracking Sheet", message=F"Tracking Sheet Copied to {new_sheet.result.permalink}")
        print(F"Tracking Sheet Copied to {new_sheet.result.permalink}")
      else: 
        messagebox.showerror("Copy Tracking Sheet", message="Error Copying Tracking Sheet")
        print("Error Copying Tracking Sheet", file=sys.stderr)
    except Exception as e:
      messagebox.showerror("Copy Tracking Sheet", message=F"Error Copying Tracking Sheet\n{e}")
      print(F"Error Copying Tracking Sheet\n{e}", file=sys.stderr)
    finally:
      self.em_ss_copy_tracking_button.config(state=tk.NORMAL)
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__

  def backup_dcdd_folder(self):
    ss = SmartsheetLib(self.root.vars['ss_token'].get())
    source_dcdd_folder_id = int(self.em_ss_dcdd_folder_id.get()) if self.em_ss_dcdd_folder_id_entry.id_type.get() != 'home' else '1'
    if not source_dcdd_folder_id:
      messagebox.showerror("Backup DCDD Sheets", message='Missing DCDD Folder ID')
      return
    destination_folder_id = int(self.em_ss_target_folder_id.get()) if self.em_ss_target_folder_id_entry.id_type.get() != 'home' else '1'
    if not destination_folder_id:
      messagebox.showerror("Backup DCDD Sheets", message='Missing Destination Folder ID')
      return
    # Check if create new folder and if we have a name
    if self.em_ss_create_new_folder.get() and not self.em_ss_backup_folder_name.get():
      messagebox.showerror("Backup DCDD Sheets", message='Missing New Folder Name')
      return
    self.em_ss_backup_dcdd_button.config(state=tk.DISABLED)
    # redirect stdout and stderr
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")
    try:
      # Get current folder name
      new_folder = ss.copy_folder(source_dcdd_folder_id, destination_folder_id, self.em_ss_target_folder_id_entry.id_type.get(), new_name=self.em_ss_backup_folder_name.get() if self.em_ss_create_new_folder.get() else None, log=True)
      if new_folder:
        messagebox.showinfo("Backup DCDD Sheets", message=F"DCDD Folder Backed Up to {new_folder.permalink}\n ID ({new_folder.id}) set as Target Tracking Folder ID")
        print(F"DCDD Folder Backed Up to {new_folder.permalink}\n ID ({new_folder.id}) set as Target Tracking Folder ID")
        self.em_ss_tracking_folder_id.set(new_folder.id) # Default new folder as tracking sheet copy folder destination
      else: 
        messagebox.showerror("Backup DCDD Sheets", message="Error Backing Up DCDD Folder")
        print("Error Backing Up DCDD Folder", file=sys.stderr)
    except Exception as e:
      messagebox.showerror("Backup DCDD Sheets", message=F"Error Backing Up DCDD Folder\n{e}")
      print(F"Error Backing Up DCDD Folder\n{e}", file=sys.stderr)
    finally:
      self.em_ss_backup_dcdd_button.config(state=tk.NORMAL)
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__

  def move_dcdd_folder(self):
    ss = SmartsheetLib(self.root.vars['ss_token'].get())
    source_dcdd_folder_id = int(self.em_ss_dcdd_folder_id.get()) if self.em_ss_dcdd_folder_id_entry.id_type.get() != 'home' else '1'
    if not source_dcdd_folder_id:
      messagebox.showerror("Move DCDD Sheets", message='Missing DCDD Folder ID')
      return
    destination_folder_id = int(self.em_ss_target_folder_id.get()) if self.em_ss_target_folder_id_entry.id_type.get() != 'home' else '1'
    if not destination_folder_id:
      messagebox.showerror("Move DCDD Sheets", message='Missing Destination Folder ID')
      return
    # Check if create new folder and if we have a name
    if self.em_ss_create_new_folder.get() and not self.em_ss_backup_folder_name.get():
      messagebox.showerror("Move DCDD Sheets", message='Missing New Folder Name')
      return
    self.em_ss_move_dcdd_button.config(state=tk.DISABLED)
    # redirect stdout and stderr
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")
    try:
      new_folder = ss.move_folder_sheets(source_dcdd_folder_id, destination_folder_id, self.em_ss_target_folder_id_entry.id_type.get(), new_name=self.em_ss_backup_folder_name.get() if self.em_ss_create_new_folder.get() else None, log=True)
      if new_folder:
        messagebox.showinfo("Move DCDD Sheets", message=F"DCDD Folder Sheets Moved to {new_folder.permalink}\n ID ({new_folder.id}) set as Target Tracking Folder ID")
        print(F"DCDD Folder Sheets Moved to {new_folder.permalink}\n ID ({new_folder.id}) set as Target Tracking Folder ID")
        self.em_ss_tracking_folder_id.set(new_folder.id) # Default new folder as tracking sheet copy folder destination
      else: 
        messagebox.showerror("Move DCDD Sheets", message="Error Moving DCDD Folder")
        print("Error Moving DCDD Folder", file=sys.stderr)
    except Exception as e:
      messagebox.showerror("Move DCDD Sheets", message=F"Error Moving DCDD Folder\n{e}")
      print(F"Error Moving DCDD Folder\n{e}", file=sys.stderr)
    finally:
      self.em_ss_move_dcdd_button.config(state=tk.NORMAL)
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__

  def update_tracking_sheet(self):
    update_tracking_sheet_id = self.em_ss_tracking_update_id.get()
    if not update_tracking_sheet_id:
      messagebox.showerror("Update Tracking Sheet", message='Missing Update Tracking Sheet ID')
      return
    if not self.em_ss_tracking_update_folder_id.get():
      messagebox.showerror("Update Tracking Sheet", message='Missing Source Tracking Folder ID')
      return
    if update_tracking_sheet_id == tracking_sheet_id:
      # This is the live actual tracking sheet, warn three times
      if not messagebox.askyesno("Update Tracking Sheet", message="Are you sure you want to update the live tracking sheet?"):
        return
      if not messagebox.askyesno("Update Tracking Sheet", message="Are you really sure you want to update the live tracking sheet?"):
        return
      if not messagebox.askyesno("Update Tracking Sheet", message="Are you really really sure you want to update the live tracking sheet? (Last Chance)"):
        return
    # Get Long Short Names from DCDD Resources
    if not self.all_dcdds:
      messagebox.showerror("Update Tracking Sheet", message='No DCDD Resourcs have been loaded! Check Resources Tab!')
      return
    long_short_names = {self.all_dcdds[dcdd]['name']:self.all_dcdds[dcdd]['short_name'] for dcdd in self.all_dcdds}
    # short_long_names = {self.all_dcdds[dcdd]['short_name']:self.all_dcdds[dcdd]['name'] for dcdd in self.all_dcdds}
    
    ss = SmartsheetLib(self.root.vars['ss_token'].get())
    self.em_ss_tracking_update_button.config(state=tk.DISABLED)
    # redirect stdout and stderr
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")
    try:
      ss.update_tracking_sheet(update_tracking_sheet_id, self.em_ss_tracking_update_folder_id.get(), self.em_ss_tracking_update_folder_id_entry.id_type.get(), long_short_names)
      messagebox.showinfo("Update Tracking Sheet", message=F"Tracking Sheet Updated!")
      print(F"Tracking Sheet Updated!")
    except Exception as e:
      messagebox.showerror("Update Tracking Sheet", message=F"Error Updating Tracking Sheet\n{e}")
      print(F"Error Updating Tracking Sheet\n{e}", file=sys.stderr)
    finally:
      self.em_ss_tracking_update_button.config(state=tk.NORMAL)
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__

  def en_mass_compare(self):
    # Get JSONs from Save Folder Location
    save_path = Path(self.em_save_path.get())
    if not save_path or not save_path.is_dir():
      messagebox.showerror("En Masse Compare", message='Bad path to JSONs Folder!')
      return
    json_files = [f for f in save_path.iterdir() if f.is_file() and f.suffix == '.json']
    if not json_files:
      messagebox.showerror("En Masse Compare", message='No JSON files found in JSONs Folder!')
      return
    # Get JSONs from resources
    if not self.all_dcdds:
      messagebox.showerror("En Masse Compare", message='No DCDD Resourcs have been loaded! Check Resources Tab!')
      return
    
    # Start comparisons --

    # Create two CSV files in the save folder
    overall_csv = save_path / '_overall_comparison.csv'
    detailed_csv = save_path / '_detailed_comparison.csv'
    
    # Write column headers
    with open(overall_csv, 'w', newline='') as f:
      csv_writer = csv.writer(f)
      csv_writer.writerow(['DCDD Name', 'Columns Match', 'Rows Match', 'Existing Rows', 'New Rows', 'XPATHs Match', 'New XPATHs Not in Existing', 'Existing XPATHs Not in New', 'Similar Rows', 'New Rows', 'Existing Rows', 'Changed Rows'])

    with open(detailed_csv, 'w', newline='') as f:
      csv_writer = csv.writer(f)
      csv_writer.writerow(['DCDD Name', 'XPATH', 'Update'])

    # Redirect stdout and stderr to log text area
    sys.stdout = TextRedirector(self.en_masse_log_text, "stdout")
    sys.stderr = TextRedirector(self.en_masse_log_text, "stderr")

    self.em_comparison_button.config(state=tk.DISABLED)

    try:

      print(F"New JSON Files: {len(json_files)}") # > {json_files}")
      print(F"Existing DCDD Resources: {len(self.all_dcdds)}") # > {self.all_dcdds.keys()}")

      for json_file in json_files:
        print(F"{json_file.stem}:")
        try:
          with open(json_file) as f:
            new_dcdd = json.load(f)
        except Exception as e:
          print(F"Error loading JSON file ({json_file.name}): {e}")
          continue

        # Find matching DCDD
        new_dcdd_name = new_dcdd.get('name') or json_file.stem
        # existing_dcdd = next((self.all_dcdds[d] for d in self.all_dcdds if d == new_dcdd_name), None)
        existing_dcdd =self.all_dcdds.get(new_dcdd_name)
        if not existing_dcdd:
          print(F"DCDD ({new_dcdd_name}) not found in resources")
          continue

        # Compare columns
        new_columns = new_dcdd.get('columns')
        existing_columns = existing_dcdd.get('columns')
        if new_columns != existing_columns:
          print(F"Columns do not exactly match for DCDD ({new_dcdd_name})")
          print(F"  New ({len(new_columns)}): {new_columns}")
          print(F"  Existing ({len(existing_columns)}): {existing_columns}")

        new_xpath_idx = next((i for i, c in enumerate(new_columns) if c == 'XPATH'), None)
        existing_xpath_idx = next((i for i, c in enumerate(existing_columns) if c == 'XPATH'), None)

        # Compare rows
        new_rows = new_dcdd.get('rows')
        existing_rows = existing_dcdd.get('rows')
        if len(new_rows) != len(existing_rows):
          print(F"  Row counts do not match for DCDD ({new_dcdd_name})")
          print(F"    New ({len(new_rows)}) vs Existing ({len(existing_rows)})")

        # Compare XPATHs
        new_xpaths = [r[new_xpath_idx] for r in new_rows if r[new_xpath_idx]]
        existing_xpaths = [r[existing_xpath_idx] for r in existing_rows if r[existing_xpath_idx]]

        new_non_matching_xpaths = set(new_xpaths) - set(existing_xpaths)
        existing_non_matching_xpaths = set(existing_xpaths) - set(new_xpaths)

        if new_non_matching_xpaths:
          print(F"  New XPATHs not in Existing DCDD ({len(new_non_matching_xpaths)})")
        if existing_non_matching_xpaths:
          print(F"  Existing XPATHs not in New DCDD ({len(existing_non_matching_xpaths)})")

        # Diff rows
        diff = DifflibParser([str(x) for x in existing_rows], [str(x) for x in new_rows])
        diff_codes = [x['code'] for x in diff]
        # Count the diffcodes
        similar_lines = diff_codes.count(DiffCode.SIMILAR)
        new_lines = diff_codes.count(DiffCode.RIGHTONLY)
        existing_lines = diff_codes.count(DiffCode.LEFTONLY)
        changed_lines = diff_codes.count(DiffCode.CHANGED)
        print(F"  Total New Rows: {len(new_rows)}| Similar Diff: {similar_lines} | New Rows Only Diff: {new_lines} | Existing Rows Only Diff: {existing_lines} | Changed Rows Diff: {changed_lines}")

        # Write to CSVs
        with open(overall_csv, 'a', newline='') as f:
          csv_writer = csv.writer(f)
          csv_writer.writerow([new_dcdd_name, new_columns == existing_columns, len(new_rows) == len(existing_rows), len(existing_rows), len(new_rows), new_xpaths == existing_xpaths, len(new_non_matching_xpaths), len(existing_non_matching_xpaths), similar_lines, new_lines, existing_lines, changed_lines])

        with open(detailed_csv, 'a', newline='') as f: 
          csv_writer = csv.writer(f)
          for xpath in sorted(new_non_matching_xpaths):
            csv_writer.writerow([new_dcdd_name, xpath, 'Added'])
          for xpath in sorted(existing_non_matching_xpaths):
            csv_writer.writerow([new_dcdd_name, xpath, 'Removed'])
      
      messagebox.showinfo("En Masse Compare", message=F'WIP!')
    except Exception as e:
      print(F"Error: {e}")
    finally:
      self.em_comparison_button.config(state=tk.NORMAL)
      # restore stdout and stderr
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__

  def diff_jsons(self):
    json_path = self.save_path.get()
    if not json_path or not json_path.endswith('.json') or not Path(json_path).is_file():
       messagebox.showerror("Diff JSONs", message=F'Bad path to JSON file: {json_path}')
       return
    json_path = Path(json_path)
    try:
      with open(json_path) as f:
        json_dcdd = json.load(f)
    except Exception as e:
      messagebox.showerror("Diff JSONs", message=e)
    # Get current DCDD from resources
    if not self.all_dcdds:
      messagebox.showerror("Diff JSONs", message='No DCDD Resourcs have been loaded! Check Resources Tab!')
      return
    existing_dcdd = self.all_dcdds.get(json_dcdd.get('name'))
    if not existing_dcdd:
      messagebox.showerror("Diff JSONs", message=F"DCDD ({json_dcdd.get('name')}) not found in resources")
      return
    # Open Diff Window
    self.tab4 = DiffApp(self.notebook, None, None, minimum=True)
    self.tab4.diff_files_into_text_areas(leftFileContents=json.dumps(existing_dcdd, indent=2), rightFileContents=json.dumps(json_dcdd, indent=2))
    self.notebook.add(self.tab4, text=F'Diff ({json_dcdd.get('name')})')
    

if __name__ == "__main__":
  root = tk.Tk()
  root.title("Generator")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ss_token':tk.StringVar(value=dict_config.get('ss_token')), 
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()