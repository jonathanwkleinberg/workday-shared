import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import tkinter.font as tkfont
from pathlib import Path
from urllib.parse import unquote
import sys, json, re
import threading
import webbrowser
import time
import platform
from xml.dom import minidom
# import difflib

MAC_OS = platform.system() == 'Darwin'
TITLE = "SLNG DCDD / SP Tester"

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent
try:
  from lib import GitHub, StyledHovertip, TextRedirector, ScrollableNotebook
  from lib import DCDD, SLNG, Smartsheet_Picker, Proteus_Picker, slng_urls
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import GitHub, StyledHovertip, TextRedirector, ScrollableNotebook
  from lib import DCDD, SLNG, Smartsheet_Picker, Proteus_Picker, slng_urls

class App(ttk.Frame):
  dcdd_refresh_loading = False
  sp_refresh_loading = False
  loading = False
  dcdds = {}
  sps = {}

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(0, weight=1)
    self.columnconfigure(1, weight=1)
    self.rowconfigure(2, weight=1)

    # Label
    self.label = ttk.Label(self, text=TITLE, justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, columnspan=98, padx=10, pady=10, sticky="nw")

    # Current DCDDs (JSON)
    self.dcdd_frame = ttk.LabelFrame(self, text="Current DCDDs (JSON)")
    self.dcdd_frame.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
    self.dcdd_frame.columnconfigure(1, weight=1)
    # self.dcdd_frame.rowconfigure(0, weight=1)

    grid_row = 0

    # Dropdown for DCDD JSON url on GHE
    self.dcdd_url_label = ttk.Label(self.dcdd_frame, text="GHE Folder:")
    self.dcdd_url_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky="w")
    self.dcdd_url_entry = ttk.Combobox(self.dcdd_frame, width=50, values=[
      "https://ghe.megaleo.com/DTOE/DCDD_JSON/tree/master/JSONs", 
      "https://ghe.megaleo.com/DTOE/Stored_Procedures/tree/master/SPs/v43 - Assets/JSONs"
    ])
    self.dcdd_url_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky="ew")
    self.dcdd_url_entry.set("https://ghe.megaleo.com/DTOE/DCDD_JSON/tree/master/JSONs")
    
    # Refresh button
    self.refresh_button = ttk.Button(self.dcdd_frame, text="Refresh", command=self.refresh_dcdd)
    self.refresh_button.grid(row=grid_row, column=2, padx=10, pady=5, sticky="ew")
    grid_row += 1

    # Entry for local copy of JSONs
    self.local_json_label = ttk.Label(self.dcdd_frame, text="Local Folder:")
    self.local_json_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky="w")
    self.local_json_entry = ttk.Entry(self.dcdd_frame, width=50)
    self.local_json_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky="ew")
    self.local_json_entry.insert(0, "")

    # Folder Refresh Button
    self.folder_refresh_button = ttk.Button(self.dcdd_frame, text="Refresh", command=self.refresh_local_dcdd)
    self.folder_refresh_button.grid(row=grid_row, column=2, padx=10, pady=5, sticky="ew")
    grid_row += 1

    # Single DCDD Frame
    self.single_dcdd_frame = ttk.Frame(self.dcdd_frame)
    self.single_dcdd_frame.grid(row=grid_row, column=0, columnspan=3, padx=0, pady=0, sticky="nsew")
    self.single_dcdd_frame.columnconfigure(2, weight=1)
    self.single_dcdd_frame.rowconfigure(0, weight=1)
    grid_row += 1

    self.single_dcdd_label = ttk.Label(self.single_dcdd_frame, text="Single DCDD:")
    self.single_dcdd_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
    self.single_dcdd_type = ttk.Combobox(self.single_dcdd_frame, state="readonly", width=10, values=['GHE', 'SS ID', 'Local'])
    self.single_dcdd_type.grid(row=0, column=1, padx=10, pady=5, sticky="w")
    self.single_dcdd_entry = ttk.Entry(self.single_dcdd_frame) #, width=33)
    self.single_dcdd_entry.grid(row=0, column=2, padx=10, pady=5, sticky="ew")
    self.single_dcdd_button = ttk.Button(self.single_dcdd_frame, text="Load", command=self.get_single_dcdd)
    self.single_dcdd_button.grid(row=0, column=3, padx=10, pady=5, sticky="ew")

    # Tree Frame
    self.tree_frame = ttk.Frame(self.dcdd_frame)
    self.tree_frame.grid(row=grid_row, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")
    self.tree_frame.columnconfigure(0, weight=1)
    self.tree_frame.rowconfigure(0, weight=1)
    
    # DCDD Tree
    self.dcdd_tree = ttk.Treeview(self.tree_frame, columns=(1, 2), height=5) # or CheckboxTreeview
    self.dcdd_tree.grid(row=0, column=0, columnspan=3, padx=10, pady=0, sticky="nsew")
    self.dcdd_tree.column("#0", width=100)
    self.dcdd_tree.column(1, width=100)
    self.dcdd_tree.column(2, width=100)
    self.dcdd_tree.heading("#0", text="Functional Area")
    self.dcdd_tree.heading(1, text="DCDD Name")
    self.dcdd_tree.heading(2, text="Additional Info")

    self.dcdd_tree.bind("<<TreeviewSelect>>", self.dcdd_select)
    self.dcdd_tree.bind('<ButtonRelease-1>', self.tree_left_click, add="+")

    self.dcdd_tree.all_children = []

    # Custom Filter String
    self.dcdd_tree.filterable = []
    self.dcdd_tree.filter = tk.StringVar(name='#1') # name is column to filter on
    self.dcdd_tree.filter_time = tk.IntVar(value=time.perf_counter_ns() // 1_000_000)
    self.dcdd_tree.filter.trace_add('write', lambda var, index, mode: [
      self.dcdd_tree.filter_time.set(time.perf_counter_ns() // 1_000_000),
      self.dcdd_tree.after(500, self.filter_tree, self.dcdd_tree),
    ])

    # Scroll bar
    self.scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.dcdd_tree.yview)
    self.scrollbar.grid(row=0, column=1, pady=10, sticky="ns")
    self.dcdd_tree.configure(yscrollcommand=self.scrollbar.set)
    # Horizontal Scrollbar
    # self.scrollbar_x = ttk.Scrollbar(self.tree_frame, orient="horizontal", command=self.dcdd_tree.xview)
    # self.scrollbar_x.grid(row=1, column=0, columnspan=2, padx=10, sticky="ew")
    # self.dcdd_tree.configure(xscrollcommand=self.scrollbar_x.set)
    

    # Current SPs 
    self.sp_frame = ttk.LabelFrame(self, text="Current Standard Procedures (SQL)")
    self.sp_frame.grid(row=1, column=1, padx=10, pady=10, sticky="nsew")
    self.sp_frame.columnconfigure(1, weight=1)
    # self.dcdd_frame.rowconfigure(0, weight=1)

    grid_row = 0

    # Dropdown for DCDD JSON url on GHE
    self.sp_url_label = ttk.Label(self.sp_frame, text="GHE Folder:")
    self.sp_url_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky="w")
    self.sp_url_entry = ttk.Combobox(self.sp_frame, width=50, values=[
      "https://ghe.megaleo.com/Workday-Data-Conversion/SLNG2.0-Direct/tree/master/DC_Standard/Stored_Procedures",
      "https://ghe.megaleo.com/DTOE/Stored_Procedures/tree/master/SPs/v43 - Skeleton Key WIP", 
      "https://ghe.megaleo.com/DTOE/Stored_Procedures/tree/master/SPs/v43 - Pieta Update",
    ])
    self.sp_url_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky="ew")
    self.sp_url_entry.set("https://ghe.megaleo.com/Workday-Data-Conversion/SLNG2.0-Direct/tree/master/DC_Standard/Stored_Procedures")

    # Refresh button
    self.sp_refresh_button = ttk.Button(self.sp_frame, text="Refresh", command=self.refresh_sp)
    self.sp_refresh_button.grid(row=grid_row, column=2, padx=10, pady=5, sticky="ew")
    grid_row += 1

    # Entry for local copy of SPs
    self.local_sp_label = ttk.Label(self.sp_frame, text="Local Folder:")
    self.local_sp_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky="w")
    self.local_sp_entry = ttk.Entry(self.sp_frame, width=50)
    self.local_sp_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky="ew")
    self.local_sp_entry.insert(0, "")

    # Folder Refresh Button
    self.folder_sp_refresh_button = ttk.Button(self.sp_frame, text="Refresh", command=self.refresh_local_sp)
    self.folder_sp_refresh_button.grid(row=grid_row, column=2, padx=10, pady=5, sticky="ew")
    grid_row += 1

    # Single SP Frame
    self.single_sp_frame = ttk.Frame(self.sp_frame)
    self.single_sp_frame.grid(row=grid_row, column=0, columnspan=3, padx=0, pady=0, sticky="nsew")
    self.single_sp_frame.columnconfigure(2, weight=1)
    self.single_sp_frame.rowconfigure(0, weight=1)
    grid_row += 1

    self.single_sp_label = ttk.Label(self.single_sp_frame, text="Single SP:")
    self.single_sp_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
    self.single_sp_type = ttk.Combobox(self.single_sp_frame, state="readonly", width=10, values=['GHE', 'Local'])
    self.single_sp_type.grid(row=0, column=1, padx=10, pady=5, sticky="w")
    self.single_sp_entry = ttk.Entry(self.single_sp_frame) #, width=33)
    self.single_sp_entry.grid(row=0, column=2, padx=10, pady=5, sticky="ew")
    self.single_sp_button = ttk.Button(self.single_sp_frame, text="Load", command=self.get_single_sp)
    self.single_sp_button.grid(row=0, column=3, padx=10, pady=5, sticky="ew")

    # SP Tree Frame
    self.sp_tree_frame = ttk.Frame(self.sp_frame)
    self.sp_tree_frame.grid(row=grid_row, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")
    self.sp_tree_frame.columnconfigure(0, weight=1)
    self.sp_tree_frame.rowconfigure(0, weight=1)

    # SP Tree
    self.sp_tree = ttk.Treeview(self.sp_tree_frame, columns=(1), height=5)
    self.sp_tree.grid(row=0, column=0, columnspan=3, padx=10, pady=0, sticky="nsew")
    self.sp_tree.column("#0", width=150)
    self.sp_tree.column("1", width=20)
    self.sp_tree.heading("#0", text="SP Name")
    self.sp_tree.heading("1", text="Additional Info")

    self.sp_tree.bind("<<TreeviewSelect>>", self.sp_select)
    self.sp_tree.bind('<ButtonRelease-1>', self.tree_left_click, add="+")

    self.sp_tree.all_children = []

    # Custom Filter String
    self.sp_tree.filterable = []
    self.sp_tree.filter = tk.StringVar(name='#0') # name is column to filter on
    self.sp_tree.filter_time = tk.IntVar(value=time.perf_counter_ns() // 1_000_000)
    self.sp_tree.filter.trace_add('write', lambda var, index, mode: [
      self.sp_tree.filter_time.set(time.perf_counter_ns() // 1_000_000),
      self.sp_tree.after(500, self.filter_tree, self.sp_tree),
    ])

    # Scroll bar
    self.sp_scrollbar = ttk.Scrollbar(self.sp_tree_frame, orient="vertical", command=self.sp_tree.yview)
    self.sp_scrollbar.grid(row=0, column=1, pady=10, sticky="ns")
    self.sp_tree.configure(yscrollcommand=self.sp_scrollbar.set)
    # Horizontal Scrollbar
    # self.sp_scrollbar_x = ttk.Scrollbar(self.sp_tree_frame, orient="horizontal", command=self.sp_tree.xview)
    # self.sp_scrollbar_x.grid(row=1, column=0, columnspan=2, padx=10, sticky="ew")
    # self.sp_tree.configure(xscrollcommand=self.sp_scrollbar_x.set)

    # New Row Frame
    self.second_row_frame = ttk.Frame(self)
    self.second_row_frame.grid(row=2, column=0, columnspan=98, padx=0, pady=0, sticky="nsew")
    self.second_row_frame.columnconfigure(0, weight=1)
    self.second_row_frame.columnconfigure(1, weight=1)
    self.second_row_frame.rowconfigure(1, weight=1)

    # SLNG Pod Frame
    self.slng_frame = ttk.LabelFrame(self.second_row_frame, text="SLNG Pod")
    self.slng_frame.grid(row=0, column=0, padx=10, pady=(0,10), sticky=tk.NSEW)
    self.slng_frame.columnconfigure(0, weight=1)
    self.dcdd_frame.rowconfigure(1, weight=1)

    grid_row = 0

    # SLNG Pod URL
    # self.slng_url_label = ttk.Label(self.slng_frame, text="URL")
    # self.slng_url_label.grid(row=grid_row, column=0, padx=10, pady=0, sticky=tk.W)
    # grid_row += 1
    self.slng_url_var = tk.StringVar()
    self.slng_url_combo = ttk.Combobox(self.slng_frame, textvariable=self.slng_url_var, values=slng_urls) #, width=30)
    self.slng_url_var.set(SLNG.base_slng_url())    
    # self.slng_url_combo.current(0)
    self.slng_url_combo.bind('<Configure>', self.on_combo_configure)
    self.slng_url_combo.grid(row=grid_row, column=0, padx=5, pady=(0, 5), sticky=tk.EW)

    if SLNG.base_slng_url() == "Unknown Location": # Hide on VCR
      self.slng_suv_frame = ttk.Frame(self.slng_frame)
      self.slng_suv_frame.grid(row=grid_row, column=1, columnspan=2, sticky=tk.EW)

      self.slng_suv_button = ttk.Button(self.slng_suv_frame, text="Proteus Picker", command=lambda:[self.get_proteus_suv_url()])
      self.slng_suv_button.grid(row=0, column=0, padx=5, pady=(0, 5), sticky=tk.EW)
      self.slng_suv_port_var = tk.StringVar()
      self.slng_suv_port_combo = ttk.Combobox(self.slng_suv_frame, textvariable=self.slng_suv_port_var, values=('3443', '4001'), width=4)
      self.slng_suv_port_combo.current(0)
      self.slng_suv_port_combo.grid(row=0, column=1, padx=5, pady=(0, 5), sticky=tk.EW)

    # Log, DDL, CSV, XML Notebook
    self.output_notebook = ttk.Notebook(self.second_row_frame)
    self.output_notebook.grid(row=1, column=0, padx=10, pady=(0,10), sticky=tk.NSEW)
    self.output_tabs = {}

    # Log Frame
    # self.log_frame = ttk.LabelFrame(self.second_row_frame, text="Log")
    # self.log_frame.grid(row=1, column=0, padx=10, pady=(0,10), sticky=tk.NSEW)
    self.log_frame = ttk.Frame(self.output_notebook)
    self.output_notebook.add(self.log_frame, text="Log")
    self.log_frame.columnconfigure(0, weight=1)
    self.log_frame.rowconfigure(1, weight=1)

    self.log_text = tk.Text(self.log_frame, wrap="word", height=10)
    self.log_text.grid(row=1, column=0, padx=0, pady=0, sticky=tk.NSEW)
    self.log_text.tag_configure("stderr", foreground="red")
    self.log_text.config(state="disabled")

    self.log_scrollbar = ttk.Scrollbar(self.log_frame, orient="vertical", command=self.log_text.yview)
    self.log_scrollbar.grid(row=1, column=1, sticky="ns", pady=0, padx=0)
    self.log_text.configure(yscrollcommand=self.log_scrollbar.set)

    # Clear Log Label
    self.clear_log_label = ttk.Label(self.log_frame, text="X", cursor='hand1', style='Link.TLabel')
    self.clear_log_label.grid(row=0, column=1, padx=0, pady=0, sticky=tk.EW)
    self.clear_log_label.bind('<Button-1>', lambda e:[self.log_text.config(state="normal"), self.log_text.delete('1.0', tk.END), self.log_text.config(state="disabled")])
    StyledHovertip(self.clear_log_label, text=" -- Clear Log -- ")

    # SLNG Configure Frame
    self.slng_configure_frame = ttk.LabelFrame(self.second_row_frame, text="SLNG Configure")
    self.slng_configure_frame.grid(row=0, rowspan=2, column=1, padx=(5, 10), pady=(0,10), sticky=tk.NSEW)
    self.slng_configure_frame.columnconfigure(1, weight=1)
    # self.slng_configure_frame.rowconfigure(0, weight=1)

    grid_row = 0

    # Toggle Frame
    self.toggle_frame = ttk.Frame(self.slng_configure_frame)
    self.toggle_frame.grid(row=grid_row, column=0, columnspan=2, padx=0, pady=0, sticky="nsew")
    # self.toggle_frame.columnconfigure(0, weight=1)
    grid_row += 1

    # Reset All Toggle
    self.reset_all_var = tk.IntVar()
    self.reset_all_check = ttk.Checkbutton(self.toggle_frame, text="Reset All", variable=self.reset_all_var)
    self.reset_all_check.grid(row=0, column=0, padx=10, pady=5, sticky=tk.EW)

    # Download WSDL Toggle
    self.wsdl_var = tk.IntVar()
    self.wsdl_check = ttk.Checkbutton(self.toggle_frame, text="Download WSDL", variable=self.wsdl_var)
    self.wsdl_check.grid(row=0, column=1, padx=10, pady=5, sticky=tk.EW)
    self.wsdl_var.set(1)

    # Generate Target Model Toggle
    self.target_model_var = tk.IntVar()
    self.target_model_check = ttk.Checkbutton(self.toggle_frame, text="Generate Target Model", variable=self.target_model_var)
    self.target_model_check.grid(row=0, column=2, padx=10, pady=5, sticky=tk.EW)
    self.target_model_var.set(1)

    # Version Entry
    self.version_label = ttk.Label(self.slng_configure_frame, text="Version:")
    self.version_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky=tk.W)
    self.version_var = tk.StringVar()
    self.version_entry = ttk.Entry(self.slng_configure_frame, textvariable=self.version_var)
    self.version_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky=tk.EW)
    grid_row += 1

    # Web Service Entry
    self.ws_label = ttk.Label(self.slng_configure_frame, text="Web Service:")
    self.ws_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky=tk.W)
    self.ws_var = tk.StringVar()
    self.ws_entry = ttk.Entry(self.slng_configure_frame, textvariable=self.ws_var)
    self.ws_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky=tk.EW)
    grid_row += 1

    # Operation Entry
    self.op_label = ttk.Label(self.slng_configure_frame, text="Operation:")
    self.op_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky=tk.W)
    self.op_var = tk.StringVar()
    self.op_entry = ttk.Entry(self.slng_configure_frame, textvariable=self.op_var)
    self.op_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky=tk.EW)
    grid_row += 1

    # DCDD Entry
    self.dcdd_label = ttk.Label(self.slng_configure_frame, text="DCDD:")
    self.dcdd_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky=tk.W)
    self.dcdd_var = tk.StringVar()
    self.dcdd_entry = ttk.Entry(self.slng_configure_frame, textvariable=self.dcdd_var)
    self.dcdd_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky=tk.EW)
    grid_row += 1

    # Second Toggle Frame
    self.toggle_frame2 = ttk.Frame(self.slng_configure_frame)
    self.toggle_frame2.grid(row=grid_row, column=0, columnspan=2, padx=0, pady=0, sticky="nsew")
    self.toggle_frame2.columnconfigure(2, weight=1)
    grid_row += 1

    # DDL Load Toggle
    self.ddl_load_var = tk.IntVar()
    self.ddl_load_check = ttk.Checkbutton(self.toggle_frame2, text="Load DDL", variable=self.ddl_load_var)
    self.ddl_load_check.grid(row=0, column=0, padx=10, pady=5, sticky=tk.EW)
    self.ddl_load_var.set(1)

    # CSV Load Toggle
    self.csv_load_var = tk.IntVar()
    self.csv_load_check = ttk.Checkbutton(self.toggle_frame2, text="Load CSV", variable=self.csv_load_var)
    self.csv_load_check.grid(row=0, column=1, padx=10, pady=5, sticky=tk.EW)
    self.csv_load_var.set(1)

    # CSV Type Combobox
    self.csv_type_var = tk.StringVar()
    self.csv_type_combo = ttk.Combobox(self.toggle_frame2, textvariable=self.csv_type_var, values=[
      'Blank', 
      'Full', 
      'Minimal', 
      'Sequential', 
      'HighVol'
      ])
    self.csv_type_combo.grid(row=0, column=2, padx=10, pady=5, sticky=tk.EW)
    self.csv_type_combo.set("Sequential")

    # CSV Import Action Combobox "Append", "Replace", "Rebuild"
    self.csv_action_var = tk.StringVar()
    self.csv_action_combo = ttk.Combobox(self.toggle_frame2, textvariable=self.csv_action_var, values=[ "Append", "Replace", "Rebuild" ])
    self.csv_action_combo.grid(row=0, column=3, padx=10, pady=5, sticky=tk.EW)
    self.csv_action_combo.set("Append")
    # Read Only
    self.csv_action_combo.config(state="readonly")

    # Stored Procedure Entry
    self.sp_label = ttk.Label(self.slng_configure_frame, text="Stored Procedure:")
    self.sp_label.grid(row=grid_row, column=0, padx=10, pady=5, sticky=tk.W)
    self.sp_var = tk.StringVar()
    self.sp_entry = ttk.Entry(self.slng_configure_frame, textvariable=self.sp_var)
    self.sp_entry.grid(row=grid_row, column=1, padx=10, pady=5, sticky=tk.EW)
    grid_row += 1

    # Third Toggle Frame
    self.toggle_frame3 = ttk.Frame(self.slng_configure_frame)
    self.toggle_frame3.grid(row=grid_row, column=0, columnspan=2, padx=0, pady=0, sticky="nsew")
    self.toggle_frame3.columnconfigure(5, weight=1)
    grid_row += 1

    # Load SP Toggle
    self.sp_load_var = tk.IntVar()
    self.sp_load_check = ttk.Checkbutton(self.toggle_frame3, text="Load SP", variable=self.sp_load_var)
    self.sp_load_check.grid(row=0, column=0, padx=10, pady=5, sticky=tk.EW)
    self.sp_load_var.set(1)

    # Call SP Toggle
    self.sp_call_var = tk.IntVar()
    self.sp_call_check = ttk.Checkbutton(self.toggle_frame3, text="Call SP", variable=self.sp_call_var)
    self.sp_call_check.grid(row=0, column=1, padx=10, pady=5, sticky=tk.EW)
    self.sp_call_var.set(1)

    # Build XML Toggle
    self.xml_var = tk.IntVar()
    self.xml_check = ttk.Checkbutton(self.toggle_frame3, text="Build XML", variable=self.xml_var)
    self.xml_check.grid(row=0, column=2, padx=10, pady=5, sticky=tk.EW)
    self.xml_var.set(1)

    # Record Number SpinBox
    self.record_label = ttk.Label(self.toggle_frame3, text="Record #:")
    self.record_label.grid(row=0, column=3, padx=(5,1), pady=5, sticky=tk.W)
    self.record_var = tk.StringVar()
    self.record_spinbox = ttk.Spinbox(self.toggle_frame3, textvariable=self.record_var, from_=1, to=9999, width=5)
    self.record_spinbox.grid(row=0, column=4, padx=(1,5), pady=5, sticky=tk.W)
    # self.record_entry = ttk.Entry(self.toggle_frame3, textvariable=self.record_var, width=4)
    # self.record_entry.grid(row=0, column=4, padx=(1,5), pady=5, sticky=tk.W)
    self.record_var.set("1")

    # Horizontal Separator
    self.separator = ttk.Separator(self.slng_configure_frame, orient="horizontal")
    self.separator.grid(row=grid_row, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
    grid_row += 1

    # Execute Button
    self.execute_button = ttk.Button(self.slng_configure_frame, text="Execute", command=self.execute_slng)
    self.execute_button.grid(row=grid_row, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
    grid_row += 1

  def execute_slng(self):
    try:
      self.execute_button.config(state="disabled")
      # Setup Log
      self.log_text.config(state="normal")
      sys.stdout = TextRedirector(self.log_text, "stdout")
      sys.stderr = TextRedirector(self.log_text, "stderr")

      if self.slng_url_var.get() == "Unknown Location":
        raise Exception("Error", "Please select or enter a valid SLNG Pod URL")

      s = SLNG(url=self.slng_url_var.get(), username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get(), interactive=False) #, debug=True)
      print("SLNG Info:", s.get_db_endpoint(), "SLNG_USER:", s.get_db_user_metadata(), "Global Config:", s.get_global_config())
      
      # print(F"-----\nReset All: {self.reset_all_var.get()}")
      # print(F"Download WSDL: {self.wsdl_var.get()}")
      # print(F"Generate Target Model: {self.target_model_var.get()}")
      # print(F"Version: {self.version_var.get()}")
      # print(F"Web Service: {self.ws_var.get()}")
      # print(F"Operation: {self.op_var.get()}")
      # print(F"DCDD: {self.dcdd_var.get()}")
      # print(F"Load DDL: {self.ddl_load_var.get()}")
      # print(F"Load CSV: {self.csv_load_var.get()} - {self.csv_type_var.get()}")
      # print(F"Stored Procedure: {self.sp_var.get()}")
      # print(F"Load SP: {self.sp_load_var.get()}")
      # print(F"Call SP: {self.sp_call_var.get()}")
      # print(F"Build XML: {self.xml_var.get()}")

      if any([self.ddl_load_var.get(), self.csv_load_var.get(), self.xml_var.get()]):
        if self.dcdd_var.get() not in self.dcdds:
          raise Exception("Error", "DCDD not found in Current DCDDs list")
        d = DCDD()
        d.json_import(self.dcdds[self.dcdd_var.get()], is_path=False)

      if any([self.sp_load_var.get(), self.sp_call_var.get()]):
        if self.sp_var.get() not in self.sps:
          raise Exception("Error", "SP not found in Current Standard Procedures list")

      if self.reset_all_var.get():
        print("Resetting SLNG ... ", end="")
        self.update_idletasks()
        print(s.reset_all())
      if self.wsdl_var.get() and all([self.version_var.get(), self.ws_var.get()]):
        print(F"Downloading WSDL ({self.version_var.get()}, {self.ws_var.get()}) ... ", end="")
        self.update_idletasks()
        r = s.download_wsdls(self.version_var.get(), (self.ws_var.get() or '').split(', '))
        print(r)
      if self.version_var.get():
        s.set_wsdl_version(self.version_var.get())
      if self.target_model_var.get() and all([self.version_var.get(), self.ws_var.get(), self.op_var.get()]):
        print(F"Generating Target Model ({self.version_var.get()}, {(self.ws_var.get() or '').split(', ')[0]}, {self.op_var.get()}) ... ", end="")
        self.update_idletasks()
        r = s.generate_target_model(self.version_var.get(), {(self.ws_var.get() or '').split(', ')[0]: [self.op_var.get()]})
        print(r)
      if self.ddl_load_var.get() and self.dcdd_var.get():
        print(F"Generating and Loading DDL for {d.name}... ", end="")
        self.update_idletasks()
        ddl_data = d.to_ddl()

        if self.output_tabs.get('DDL'):
          self.output_tabs.get('DDL').destroy()
        self.output_tabs['DDL'] = ttk.Frame(self.output_notebook)
        self.output_notebook.add(self.output_tabs['DDL'], text="DDL")
        self.output_tabs['DDL'].columnconfigure(0, weight=1)
        self.output_tabs['DDL'].rowconfigure(0, weight=1)
        ddl_text = tk.Text(self.output_tabs['DDL'], wrap="word", height=10)
        ddl_text.grid(row=0, column=0, padx=0, pady=0, sticky=tk.NSEW)
        ddl_text.insert(tk.END, ddl_data)
        ddl_text.config(state="disabled")
        ddl_scrollbar = ttk.Scrollbar(self.output_tabs['DDL'], orient="vertical", command=ddl_text.yview)
        ddl_scrollbar.grid(row=0, column=1, sticky="ns", pady=0, padx=0)
        ddl_text.configure(yscrollcommand=ddl_scrollbar.set)

        r = s.transform_string(F'{d.name}_ddl.sql', ddl_data)
        print(r)
        # Get jobid and check transform status
        jobid = r.get('jobId')
        if jobid:
          r = s.get_job_status(jobid, q='transform')
          print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
          self.update_idletasks()
          while r.get('state', '') != 'completed':
            if r.get('state', '') == 'failed':
              raise Exception("Error", "DDL Transform Failed")
            time.sleep(1)
            r = s.get_job_status(jobid, q='transform')
            print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
            self.update_idletasks()
      if self.csv_load_var.get() and self.csv_type_var.get() :
        print(F"Generating and Loading CSVs ({self.csv_type_var.get()}):")
        self.update_idletasks()

        if self.output_tabs.get('CSV'):
          self.output_tabs.get('CSV').destroy()
        self.output_tabs['CSV'] = ttk.Frame(self.output_notebook)
        self.output_notebook.add(self.output_tabs['CSV'], text="CSV")
        self.output_tabs['CSV'].columnconfigure(0, weight=1)
        self.output_tabs['CSV'].rowconfigure(0, weight=1)
        csv_notebook = ScrollableNotebook(self.output_tabs['CSV'])
        csv_notebook.grid(row=0, column=0, padx=0, pady=0, sticky=tk.NSEW)

        for csv_name, csv_data in d.to_csv(self.csv_type_var.get()).items():
          csv_frame = ttk.Frame(csv_notebook)
          csv_notebook.add(csv_frame, text=csv_name)
          csv_frame.columnconfigure(0, weight=1)
          csv_frame.rowconfigure(0, weight=1)
          csv_text = tk.Text(csv_frame, wrap="word", height=10)
          csv_text.grid(row=0, column=0, padx=0, pady=0, sticky=tk.NSEW)
          csv_text.insert(tk.END, csv_data)
          csv_text.config(state="disabled")
          csv_scrollbar = ttk.Scrollbar(csv_frame, orient="vertical", command=csv_text.yview)
          csv_scrollbar.grid(row=0, column=1, sticky="ns", pady=0, padx=0)
          csv_text.configure(yscrollcommand=csv_scrollbar.set)

          # print(F"{csv_name}\n{csv_data}")
          print(F"Importing {csv_name} ... ", end="")
          self.update_idletasks()
          r = s.import_source_data(csv_name, csv_data, (self.csv_action_var.get() or 'append').lower())
          print(r)
          # Get jobid and check import status
          jobid = r.get('jobIds', [None])[0]
          if jobid:
            r = s.get_job_status(jobid, q='import')
            print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
            self.update_idletasks()
            while r.get('state', '') != 'completed':
              if r.get('state', '') == 'failed':
                raise Exception("Error", "CSV Import Failed")
              time.sleep(1)
              r = s.get_job_status(jobid, q='import')
              print("  Status:", r.get('job', {}).get('progress'), r.get('state'))  
              self.update_idletasks()
      if self.sp_load_var.get():
        print(F"Loading Stored Procedure ({self.sp_var.get()}) ... ", end="")
        self.update_idletasks()
        r = s.transform_string(F"{self.sp_var.get()}.sql", self.sps[self.sp_var.get()])
        print(r)
        # Get jobid and check transform status
        jobid = r.get('jobId')
        if jobid:
          r = s.get_job_status(jobid, q='transform')
          print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
          self.update_idletasks()
          while r.get('state', '') != 'completed':
            if r.get('state', '') == 'failed':
              raise Exception("Error", "SP Transform Failed")
            time.sleep(1)
            r = s.get_job_status(jobid, q='transform')
            print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
            self.update_idletasks()
      if self.sp_call_var.get():
        print(F"Calling Stored Procedure ({self.sp_var.get()}) ... ", end="")
        self.update_idletasks()
        r = s.call_procedure(self.sp_var.get())
        print(r)
        # Get jobid and check statement status
        jobid = r.get('jobId')
        if jobid:
          r = s.get_job_status(jobid, q='statement')
          print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
          self.update_idletasks()
          while r.get('state', '') != 'completed':
            if r.get('state', '') == 'failed':
              raise Exception("Error", "SP Call Failed")
            time.sleep(1)
            r = s.get_job_status(jobid, q='statement')
            print("  Status:", r.get('job', {}).get('progress'), r.get('state'))
            self.update_idletasks()
      if self.xml_var.get():
        print(F"Building XML ({d.version}, {d.web_services[0]}, {d.operation}) ...")
        self.update_idletasks()
        xml_data = s.build_single_xml(d.version, d.web_services[0], d.operation, self.record_var.get() or "1")
        dom = minidom.parseString(xml_data)
        pretty_xml = dom.toprettyxml(indent="  ")

        if self.output_tabs.get('XML'):
          self.output_tabs.get('XML').destroy()
        self.output_tabs['XML'] = ttk.Frame(self.output_notebook)
        self.output_notebook.add(self.output_tabs['XML'], text="XML")
        self.output_tabs['XML'].columnconfigure(0, weight=1)
        self.output_tabs['XML'].rowconfigure(0, weight=1)
        xml_text = tk.Text(self.output_tabs['XML'], wrap="word", height=10)
        xml_text.grid(row=0, column=0, padx=(10,0), pady=(0,5), sticky=tk.NSEW)
        xml_text.insert(tk.END, pretty_xml)
        xml_text.config(state="disabled")
        xml_scrollbar = ttk.Scrollbar(self.output_tabs['XML'], orient="vertical", command=xml_text.yview)
        xml_scrollbar.grid(row=0, column=1, sticky="ns", pady=(0,5), padx=(0,5))
        xml_text.configure(yscrollcommand=xml_scrollbar.set)

        # Get a file path from the user
        file_path = filedialog.asksaveasfilename(defaultextension=".xml", filetypes=[("XML files", "*.xml")], title="Save XML File", initialfile=F"{d.name}.xml")
        if file_path:
          with open(file_path, "w") as f:
            f.write(pretty_xml)
          print(F"XML saved to {file_path}")
    except Exception as e:
      # import traceback
      # traceback.print_exc()
      print("\nException:", e, '\n', file=sys.stderr)
    finally:
      # Reset Log
      self.log_text.config(state="disabled")
      sys.stdout = sys.__stdout__
      sys.stderr = sys.__stderr__
      self.execute_button.config(state="normal")

  def tree_left_click(self, event):
    tree = event.widget  # get the treeview widget
    tree_region = tree.identify_region(event.x, event.y)
    tree_column = tree.identify_column(event.x)
    # tree_column_idx = int(tree_column[1:])
    item = tree.identify('item', event.x, event.y)
    # print(tree_region, tree_column, item, str(tree.filter))
    # Filter Entry
    if tree_region == 'heading' and tree_column == str(tree.filter): #("#1" if str(tree.filter) == "dcdd" else "#0"):
      tree_offset = (tree.winfo_x(), tree.winfo_y()) # Get offset from parent 
      if len(tree.all_children) < 1:
        return
      # print(tree.yview())
      # first_item = tree.get_children()[0]
      # column_bbox = tree.bbox(first_item, column=tree_column)
      column_bbox = next(tree.bbox(x, column=tree_column) for x in tree.all_children if tree.bbox(x, column=tree_column))
      col_width = tree.column(tree_column, 'width')
      entry_filter = tk.ttk.Entry(tree.master, width=col_width, textvariable=tree.filter) # width=column_bbox[2]
      # entry_edit.edit_column_idx = column_idx
      # entry_edit.edit_item_iid = iid
      # entry_edit.insert(0, text)
      entry_filter.select_range(0, tk.END)
      entry_filter.focus()
      entry_filter.bind("<FocusOut>", lambda e: [e.widget.destroy()])
      entry_filter.bind("<Return>", lambda e: [e.widget.destroy()])
      entry_filter.place(x=tree_offset[0] + column_bbox[0], y=tree_offset[1] + column_bbox[1] - column_bbox[3] - 4, w=col_width, h=column_bbox[3] + 14) # x=tree_offset[0] + column_bbox[0], w=column_bbox[2]

  def filter_tree(self, tree):
    time_passed = (time.perf_counter_ns() // 1_000_000) - tree.filter_time.get()
    # print(time_passed)
    if time_passed > 500:
      # print(tree.filterable)
      filter = tree.filter.get()
      if filter: filter = filter.lower()
      # Detach everything
      for item in tree.all_children:
        tree.detach(item)
      # Reattach if filter matches
      for iid, name, parent in tree.filterable:
        # print(filter, iid, name, parent)
        name = name.lower()
        # ratio = difflib.SequenceMatcher(None, filter, name).ratio()
        # print(filter, name, ratio, filter in name)
        if not filter or filter in name or filter in name.replace("_", " "): # or ratio > 0.4:
          if parent and parent not in tree.get_children():
            tree.reattach(parent, '', tk.END)
            if filter: tree.item(parent, open=True)
            else: tree.item(parent, open=False)
          tree.reattach(iid, parent, tk.END)

        # if filter and filter not in name:
        # if filter and ratio < 0.2:
        #   tree.detach(iid)
        # else:
        #   tree.reattach(iid, parent, tk.END)
  
  def get_proteus_suv_url(self):
    pp = Proteus_Picker(self.root, self.root.winfo_pointerxy()) # Use the root object with the cred/config vars.
    if not pp.error: self.wait_window(pp.top)
    if pp.result:
      self.slng_url_var.set(F'{pp.result['url']}:{self.slng_suv_port_var.get()}')
  
  def on_combo_configure(self, event):
    style = ttk.Style()
    # check if the combobox already has the "postoffest" property
    current_combo_style = event.widget.cget('style') or "TCombobox"
    # if len(style.lookup(current_combo_style, 'postoffset'))>0:
    #     return
    combo_values = event.widget.cget('values')
    if len(combo_values) == 0:
        return
    longest_value = max(combo_values, key=len)
    # try:
    #   font = tkfont.nametofont(str(event.widget.cget('font')))
    # except:
    #   font = tkfont.nametofont("TkDefaultFont")
    font = tkfont.Font(font=event.widget.cget('font'))
    offset_width = font.measure(longest_value + "000") - (event.width)
    # print(longest_value, font.measure(longest_value + "000"), event.width, offset_width, event.widget.winfo_width())
    if (offset_width<0):
        # no need to make the popdown smaller
        return
    # create an unique style name using widget's id
    unique_name=F'Combobox{event.widget.winfo_id()}'
    # the new style must inherit from curret widget style (unless it's our custom style!) 
    if unique_name in current_combo_style:
        style_name = current_combo_style 
    else:
        style_name = F"{unique_name}.{current_combo_style}"
    style.configure(style_name, postoffset=(-offset_width//2,0,offset_width,0))
    event.widget.configure(style=style_name)

  def background(self, func, args=(), kwargs={}):
    th = threading.Thread(target=func, args=args, kwargs=kwargs)
    th.start()

  def refresh_dcdd(self):
    if not self.dcdd_refresh_loading:
      self.dcdd_refresh_loading = True
      self.refresh_button.config(state="disabled")
      self.dcdd_tree.delete(*self.dcdd_tree.get_children())
      self.dcdd_tree.all_children = []
      self.dcdd_tree.filterable = []
      self.dcdd_tree.insert("", "end", text="  Loading ...", values=("", ""))
      self.dcdd_tree.update()
      self.get_dcdds()

  def refresh_local_dcdd(self):
    if not self.dcdd_refresh_loading:
      self.dcdd_refresh_loading = True
      self.folder_refresh_button.config(state="disabled")
      self.dcdd_tree.delete(*self.dcdd_tree.get_children())
      self.dcdd_tree.all_children = []
      self.dcdd_tree.filterable = []
      self.dcdd_tree.insert("", "end", text="  Loading ...", values=("", ""))
      self.dcdd_tree.update()
      self.get_local_dcdds()

  def refresh_sp(self):
    if not self.sp_refresh_loading:
      self.sp_refresh_loading = True
      self.sp_refresh_button.config(state="disabled")
      self.sp_tree.delete(*self.sp_tree.get_children())
      self.sp_tree.all_children = []
      self.sp_tree.filterable = []
      self.sp_tree.insert("", "end", text="  Loading ...", values=("", ""))
      self.sp_tree.update()
      self.get_sp()

  def refresh_local_sp(self):
    if not self.sp_refresh_loading:
      self.sp_refresh_loading = True
      self.folder_sp_refresh_button.config(state="disabled")
      self.sp_tree.delete(*self.sp_tree.get_children())
      self.sp_tree.all_children = []
      self.sp_tree.filterable = []
      self.sp_tree.insert("", "end", text="  Loading ...", values=("", ""))
      self.sp_tree.update()
      self.get_local_sp()

  def dcdd_select(self, event):
    item_id = self.dcdd_tree.selection()[0] if self.dcdd_tree.selection() else None
    if not item_id: return
    item_values = self.dcdd_tree.item(item_id, "values")
    if not any(item_values):
      return
    # print("Selected item:", item_values)
    if not item_values[0] in self.dcdds:
      messagebox.showerror("Error", "DCDD not found in Current DCDDs list")
      return
    dcdd = self.dcdds[item_values[0]]
    full_name = dcdd.get('metadata', {}).get('FULL NAME', "")
    version = dcdd.get('metadata', {}).get('API VERSION', "")
    web_service = dcdd.get('metadata', {}).get('WEB SERVICE', "")
    operation = dcdd.get('metadata', {}).get('WEB SERVICE OPERATION', "")
    self.version_var.set(version)
    self.ws_var.set(web_service)
    self.op_var.set(operation)
    self.dcdd_var.set(item_values[0])
    # Check if SP related to DCDD Name is in SP Tree
    potential_sp_name = F"sp_{full_name.replace("_DCDD", "")}_DCS"
    if potential_sp_name in self.sps:
      self.sp_var.set(potential_sp_name)
      item = next((item for item in self.sp_tree.get_children() if self.sp_tree.item(item, "text") == potential_sp_name), None)
      if item: 
        self.sp_tree.selection_set(item)
        self.sp_tree.see(item)

  def sp_select(self, event):
    item_id = self.sp_tree.selection()[0] if self.sp_tree.selection() else None
    if not item_id: return
    item_text = self.sp_tree.item(item_id, "text")
    item_values = self.sp_tree.item(item_id, "values")
    if not item_text: return
    # print("Selected item:", item_text, item_values)
    if not item_text in self.sps:
      messagebox.showerror("Error", "SP not found in Current Standard Procedures list")
      return
    self.sp_var.set(item_text)

  def get_single_dcdd(self):
    if not self.single_dcdd_type.get():
      messagebox.showerror("Error", "Please select a Single DCDD Type from the dropdown box") 
      return
    # Check if the entry is empty
    if not self.single_dcdd_entry.get():
      if self.single_dcdd_type.get() == 'Local':
        file_path = filedialog.askopenfilename()
        if not file_path:
          return
        self.single_dcdd_entry.delete(0, tk.END)
        self.single_dcdd_entry.insert(0, file_path)
      elif self.single_dcdd_type.get() == 'SS ID':
        # Smartsheet Sheet Picker
        ssp = Smartsheet_Picker(self.root, ss_type='sheet', x_y=(self.single_dcdd_button.winfo_rootx(), self.single_dcdd_button.winfo_rooty()))
        self.wait_window(ssp.top)
        if not ssp.result:
          return
        self.single_dcdd_entry.delete(0, tk.END)
        self.single_dcdd_entry.insert(0, ssp.result['id'])
        # messagebox.showerror("Error", "Please enter a Smartsheet Sheet ID in the entry box")
        # return
      elif self.single_dcdd_type.get() == 'GHE':
        messagebox.showerror("Error", "Please enter a GHE URL in the entry box")
        return
    # Get the DCDD
    if self.single_dcdd_type.get() == 'GHE':
      if not self.root.vars['ad_username'].get() or not self.root.vars['ad_password'].get():
        messagebox.showerror("Error", "Please enter your AD username and password in the Home tab") 
        return
      try:
        d = DCDD(gh=unquote(self.single_dcdd_entry.get()), username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
      except Exception as e:
        messagebox.showerror("Error", F"Error loading DCDD: {e}")
        return        
    elif self.single_dcdd_type.get() == 'SS ID':
      if not self.root.vars['ss_token'].get():
        messagebox.showerror("Error", "Please enter a SS Token in the Home tab") 
        return
      try:
        d = DCDD(ss=self.single_dcdd_entry.get(), token=self.root.vars['ss_token'].get())
      except Exception as e:
        messagebox.showerror("Error", F"Error loading DCDD: {e}")
        return
    elif self.single_dcdd_type.get() == 'Local':
      if not Path(self.single_dcdd_entry.get()).exists():
        messagebox.showerror("Error", "File does not exist")
        return
      try:
        d = DCDD(json=self.single_dcdd_entry.get())
      except Exception as e:
        messagebox.showerror("Error", F"Error loading DCDD: {e}")
        return
    # print(d.name, d.version, d.permalink)
    self.dcdds = {d.name: d.to_dict()}
    # print(self.dcdds)
    self.dcdd_tree.delete(*self.dcdd_tree.get_children())
    self.dcdd_tree.all_children = []
    self.dcdd_tree.filterable = []
    iid = self.dcdd_tree.insert(parent='', index=tk.END, values=(d.name, F"""{(d.version or "")} - {d.permalink}"""))
    self.dcdd_tree.all_children.append(iid)
    self.dcdd_tree.filterable.append((iid, d.name, "")) # iid, name, parent

  def get_single_sp(self):
    if not self.single_sp_type.get():
      messagebox.showerror("Error", "Please select a Single SP Type from the dropdown box") 
      return
    # Check if the entry is empty
    if not self.single_sp_entry.get():
      if self.single_sp_type.get() == 'Local':
        file_path = filedialog.askopenfilename()
        if not file_path:
          return
        self.single_sp_entry.delete(0, tk.END)
        self.single_sp_entry.insert(0, file_path)
      elif self.single_sp_type.get() == 'GHE':
        messagebox.showerror("Error", "Please enter a GHE URL in the entry box")
        return
    # Get the SP
    if self.single_sp_type.get() == 'GHE':
      if not self.root.vars['ad_username'].get() or not self.root.vars['ad_password'].get():
        messagebox.showerror("Error", "Please enter your AD username and password in the Home tab") 
        return
      try:
        g = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
        file_data = g.get_file(unquote(self.single_sp_entry.get()))
        if not file_data:
          messagebox.showerror("Error", "File not found")
          return
      except Exception as e:
        messagebox.showerror("Error", F"Error downloading SP: {e}")
        return        
    elif self.single_sp_type.get() == 'Local':
      if not Path(self.single_sp_entry.get()).exists():
        messagebox.showerror("Error", "File does not exist")
        return
      try:
        file_data = Path(self.single_sp_entry.get()).read_text()
      except Exception as e:
        messagebox.showerror("Error", F"Error loading SP: {e}")
        return
    file_name_re = re.search(R'CREATE +PROCEDURE +`(.*)`.*', file_data, re.I+re.M)
    file_name = file_name_re.group(1) if file_name_re and file_name_re.groups() else ""
    version_re = re.search(R'version *(.*)$', file_data, re.I+re.M)
    version = version_re.group(1) if version_re and version_re.groups() else ""
    self.sps = {file_name: file_data}
    self.sp_tree.delete(*self.sp_tree.get_children())
    iid = self.sp_tree.insert(parent='', index=tk.END, text=file_name, values=(version,))
    self.sp_tree.all_children.append(iid)
    self.sp_tree.filterable.append((iid, file_name, "")) # iid, name, parent
    self.sp_refresh_loading = False
    self.sp_refresh_button.config(state="normal")

  def get_sp(self):
    if not self.sp_url_entry.get():
      messagebox.showerror("Error", "Please enter a GHE URL in the entry box")
      self.sp_refresh_loading = False
      self.sp_refresh_button.config(state="normal")
      return
    try:
      g = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
      self.sps = g.get_sqls_from_zip(url=unquote(self.sp_url_entry.get()), return_regex=R'CREATE +PROCEDURE +`(.*)`.*')
    except Exception as e:
      messagebox.showerror("Error", F"Error downloading SPs: {e}")
      self.sp_refresh_loading = False
      self.sp_refresh_button.config(state="normal")
      return
    # Clear the tree
    self.sp_tree.delete(*self.sp_tree.get_children())
    for sp in sorted(self.sps.keys()):
      version_re = re.search(R'version *(.*)$', self.sps[sp], re.I+re.M)
      version = version_re.group(1) if version_re and version_re.groups() else ""
      iid = self.sp_tree.insert(parent='', index=tk.END, text=sp, values=(version,))
      self.sp_tree.all_children.append(iid)
      self.sp_tree.filterable.append((iid, sp, "")) # iid, name, parent
    self.sp_refresh_loading = False
    self.sp_refresh_button.config(state="normal")

  def get_local_sp(self):
    folder = self.local_sp_entry.get()
    if not folder:
      folder = filedialog.askdirectory()
      if not folder:
        self.sp_refresh_loading = False
        self.folder_sp_refresh_button.config(state="normal")
        return
      self.local_sp_entry.delete(0, tk.END)
      self.local_sp_entry.insert(0, folder)

    if not Path(folder).exists():
      messagebox.showerror("Error", "Folder does not exist")
      self.sp_refresh_loading = False
      self.folder_sp_refresh_button.config(state="normal")
      return
    self.sps = {}
    # Get all the SQL files
    sql_files = [f for f in Path(folder).rglob('*.sql')]
    for f in sql_files:
      with open(f, 'r') as s:
        file_data = s.read()
        file_name_re = re.search(R'CREATE +PROCEDURE +`(.*)`.*', file_data, re.I+re.M)
        file_name = file_name_re.group(1) if file_name_re and file_name_re.groups() else f.name
        self.sps[file_name] = file_data

    # Clear the tree
    self.sp_tree.delete(*self.sp_tree.get_children())
    for sp in sorted(self.sps.keys()):
      version_re = re.search(R'version *(.*)$', self.sps[sp], re.I+re.M)
      version = version_re.group(1) if version_re and version_re.groups() else ""
      iid = self.sp_tree.insert(parent='', index=tk.END, text=sp, values=(version,))
      self.sp_tree.all_children.append(iid)
      self.sp_tree.filterable.append((iid, sp, "")) # iid, name, parent    
    self.sp_refresh_loading = False
    self.folder_sp_refresh_button.config(state="normal")

  def get_local_dcdds(self):    
    folder = self.local_json_entry.get()
    if not folder:
      folder = filedialog.askdirectory()
      if not folder:
        self.dcdd_refresh_loading = False
        self.folder_refresh_button.config(state="normal")
        return
      self.local_json_entry.delete(0, tk.END)
      self.local_json_entry.insert(0, folder)

    if not Path(folder).exists():
      messagebox.showerror("Error", "Folder does not exist")
      self.dcdd_refresh_loading = False
      self.folder_refresh_button.config(state="normal")
      return
    self.dcdds = {}
    # Get all the JSON files
    json_files = [f for f in Path(folder).rglob('*.json') if f.name != 'all.json']
    for f in json_files:
      with open(f, 'r') as j:
        dcdd = json.load(j)
        # print(f)
        self.dcdds[dcdd.get('name') or dcdd.get('metadata', {}).get('FULL NAME')] = dcdd
    # Get all the functional areas
    functional_areas = set()
    _ = [functional_areas.add(area or "Unknown Area") for dcdd in self.dcdds for area in (self.dcdds[dcdd].get('metadata', {}).get("FUNCTIONAL AREA", "") or '').split(', ')]
    functional_areas = sorted(list(functional_areas))
    # Clear the tree
    self.dcdd_tree.delete(*self.dcdd_tree.get_children())

    for area in functional_areas:
      # print(area)
      iid = self.dcdd_tree.insert(parent='', index=tk.END, iid=area, text=F"  {area}", values=("", ""))
      self.dcdd_tree.all_children.append(iid)
      for dcdd in self.dcdds:
        if area in (self.dcdds[dcdd]['metadata'].get("FUNCTIONAL AREA", "") or '').split(', '):
          # print(dcdd)
          iid = self.dcdd_tree.insert(parent=area, index=tk.END, values=(dcdd, F"""{(self.dcdds[dcdd]['metadata'].get("API VERSION", "") or "")} - {self.dcdds[dcdd]['permalink']}"""))
          self.dcdd_tree.all_children.append(iid)
          self.dcdd_tree.filterable.append((iid, dcdd, area)) # iid, name, parent

    # self.dcdd_tree.tag_configure("functional_area", background="lightgrey")
    # self.dcdd_tree.tag_configure("dcdd", background="white")

    self.dcdd_refresh_loading = False
    self.folder_refresh_button.config(state="normal")

  def get_dcdds(self):
    if not self.dcdd_url_entry.get():
      messagebox.showerror("Error", "Please enter a GHE URL in the entry box")
      self.dcdd_refresh_loading = False
      self.refresh_button.config(state="normal")
      return
    try:
      g = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
      self.dcdds = g.get_jsons_from_zip(url=unquote(self.dcdd_url_entry.get()))
    except Exception as e:
      messagebox.showerror("Error", F"Error downloading DCDDs: {e}")
      self.dcdd_refresh_loading = False
      self.refresh_button.config(state="normal")
      return
    # Get all the functional areas
    functional_areas = set()
    _ = [functional_areas.add(area or "Unknown Area") for dcdd in self.dcdds for area in (self.dcdds[dcdd]['metadata'].get("FUNCTIONAL AREA", "") or '').split(', ')]
    functional_areas = sorted(list(functional_areas))
    # Clear the tree
    self.dcdd_tree.delete(*self.dcdd_tree.get_children())

    for area in functional_areas:
      # print(area)
      iid = self.dcdd_tree.insert(parent='', index=tk.END, iid=area, text=F"  {area}", values=("", ""))
      self.dcdd_tree.all_children.append(iid)
      for dcdd in self.dcdds:
        if area in (self.dcdds[dcdd]['metadata'].get("FUNCTIONAL AREA", "") or '').split(', '):
          # print(dcdd)
          iid = self.dcdd_tree.insert(parent=area, index=tk.END, values=(dcdd, F"""{(self.dcdds[dcdd]['metadata'].get("API VERSION", "") or "")} - {self.dcdds[dcdd]['permalink']}"""))
          self.dcdd_tree.all_children.append(iid)
          self.dcdd_tree.filterable.append((iid, dcdd, area)) # iid, name, parent

    # self.dcdd_tree.tag_configure("functional_area", background="lightgrey")
    # self.dcdd_tree.tag_configure("dcdd", background="white")

    self.dcdd_refresh_loading = False
    self.refresh_button.config(state="normal")


if __name__ == "__main__":
  sys.path.append(LibPath.absolute().as_posix())

  root = tk.Tk()
  root.title(TITLE)

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')),
    'db_username':tk.StringVar(value=dict_config.get('db_username')),
    'db_password':tk.StringVar(value=dict_config.get('db_password')),
    'db_host':tk.StringVar(value=dict_config.get('db_host')),
    'db_port':tk.StringVar(value=dict_config.get('db_port')),
    'ss_token':tk.StringVar(value=dict_config.get('ss_token')),
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()