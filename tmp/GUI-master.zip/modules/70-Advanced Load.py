import tkinter as tk
from tkinter import ttk, messagebox, filedialog
# from tkinter.filedialog import askopenfilename
from pathlib import Path
import sys, json, csv
import datetime
import threading
import webbrowser 
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import StyledHovertip, data_centers, Proteus_Picker, Proteus, Advanced_Load, SLNG
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import StyledHovertip, data_centers, Proteus_Picker, Proteus, Advanced_Load, SLNG

class App(ttk.Frame):
  # client_id = None
  # client_secret = None

  def __init__(self, parent, left_file=None, right_file=None, minimum=False):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.grid_rowconfigure(1, weight=1)
    self.grid_columnconfigure(2, weight=1)

    # Label
    self.label = ttk.Label(self, text="Advanced Load API & Config", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, columnspan=99, padx=10, pady=10, sticky=tk.EW)

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=1, column=0, columnspan=99, padx=5, pady=5, sticky=tk.NSEW)

    # Register CC API Client
    # ----------------------
    self.reg_cc_api_frame = ttk.LabelFrame(self.config_frame, text="Tenant Config and CC API Client", padding=(10, 5), style="Bold.TLabelframe")
    self.reg_cc_api_frame.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky=tk.NSEW)

    reg_cc_api_row = 0

    if SLNG.base_slng_url() == "Unknown Location": # Hide on VCR
      # s = ttk.Style()
      # s.configure('tiny_button.TButton', font=('Helvetica', 8))
      # self.pp_cc_button = ttk.Button(self.reg_cc_api_frame, text="pp", width=2, command=self.get_proteus_suv, style='tiny_button.TButton')
      # self.pp_cc_button.place(relx=0.88, rely=-0.04) # .grid(row=reg_cc_api_row, column=0, padx=1, pady=1, sticky=tk.E)
      # StyledHovertip(self.pp_cc_button, text="Proteus Picker")
      # reg_cc_api_row += 1
      self.pp_cc_button = ttk.Button(self.reg_cc_api_frame, text="Import from Proteus", command=self.get_proteus_suv)
      self.pp_cc_button.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
      StyledHovertip(self.pp_cc_button, text="Choose SUV from Proteus Picker")
      reg_cc_api_row += 1


    # Import from Saved Tenants Combobox
    self.cc_tenant = tk.StringVar()
    self.cc_tenants_label = ttk.Label(self.reg_cc_api_frame, text="Import Saved CC Tenant")
    self.cc_tenants_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_tenants_entry = ttk.Combobox(self.reg_cc_api_frame, textvariable=self.cc_tenant)
    self.refresh_saved_cc_tenant_list()
    self.cc_tenants_entry.bind("<<ComboboxSelected>>", lambda e: [
      self.cc_dc.set(self.cc_tenants_entry.get().split('@')[1].split('(')[1].split(')')[0]),
      self.cc_tenant.set(self.cc_tenants_entry.get().split('@')[1].split('(')[0]),
      self.cc_ccs_username.set(self.cc_tenants_entry.get().split('@')[0]),
      self.cc_ccs_password.set(next((self.root.vars.get(F't{i}_password').get() for i in range(1, max([int(x.split('_')[0][1:]) for x in self.root.vars.keys() if x.startswith('t') and x.endswith('_username')] or [1])+1) if self.root.vars.get(F't{i}_username').get() == self.cc_tenants_entry.get().split('@')[0] and self.root.vars.get(F't{i}_name').get() == self.cc_tenants_entry.get().split('@')[1].split('(')[0] and self.root.vars.get(F't{i}_datacenter').get() == self.cc_tenants_entry.get().split('@')[1].split('(')[1].split(')')[0]), None) if self.cc_tenants_entry.get() else None),
      self.al_cc_password.set(self.cc_ccs_password.get()) if 'workdaysuv' in self.cc_dc.get() else None
    ])
    self.cc_tenants_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    # read only
    self.cc_tenants_entry.configure(state='readonly')
    # Refresh button
    self.cc_tenants_button = ttk.Button(self.reg_cc_api_frame, text="↻", width=2, command=self.refresh_saved_cc_tenant_list)
    self.cc_tenants_button.grid(row=reg_cc_api_row, column=1, padx=5, pady=(0,5), sticky=tk.W)
    StyledHovertip(self.cc_tenants_button, text="Refresh Tenants")
    reg_cc_api_row += 1

    self.cc_dc = tk.StringVar()
    self.cc_dc_label = ttk.Label(self.reg_cc_api_frame, text="Datacenter")
    self.cc_dc_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_dc_entry = ttk.Combobox(self.reg_cc_api_frame, textvariable=self.cc_dc, values=list(data_centers.keys()))
    self.cc_dc_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    reg_cc_api_row += 1

    self.cc_tenant = tk.StringVar()
    self.cc_tenant_label = ttk.Label(self.reg_cc_api_frame, text="CC Tenant Name")
    self.cc_tenant_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_tenant_entry = ttk.Entry(self.reg_cc_api_frame, textvariable=self.cc_tenant)
    self.cc_tenant_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    reg_cc_api_row += 1

    self.cc_ccs_username = tk.StringVar()
    self.cc_ccs_username_label = ttk.Label(self.reg_cc_api_frame, text="CC Security Admin Username")
    self.cc_ccs_username_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_ccs_username_entry = ttk.Entry(self.reg_cc_api_frame, textvariable=self.cc_ccs_username)
    self.cc_ccs_username_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    reg_cc_api_row += 1

    self.cc_ccs_password = tk.StringVar()
    self.cc_ccs_password_label = ttk.Label(self.reg_cc_api_frame, text="CC Security Admin Password")
    self.cc_ccs_password_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_ccs_password_entry = ttk.Entry(self.reg_cc_api_frame, show='*', textvariable=self.cc_ccs_password)
    self.cc_ccs_password_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    reg_cc_api_row += 1

    self.cc_client_name = tk.StringVar(value="DC AL Client")
    self.cc_client_name_label = ttk.Label(self.reg_cc_api_frame, text="API Client Name")
    self.cc_client_name_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_client_name_entry = ttk.Entry(self.reg_cc_api_frame, textvariable=self.cc_client_name)
    self.cc_client_name_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    reg_cc_api_row += 1

    self.cc_redirect = tk.StringVar(value="https://localhost/")
    self.cc_redirect_label = ttk.Label(self.reg_cc_api_frame, text="Redirect URL")
    self.cc_redirect_label.grid(row=reg_cc_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    reg_cc_api_row += 1
    self.cc_redirect_entry = ttk.Entry(self.reg_cc_api_frame, textvariable=self.cc_redirect)
    self.cc_redirect_entry.grid(row=reg_cc_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    reg_cc_api_row += 1

    self.cc_reg_button = ttk.Button(self.reg_cc_api_frame, text='Register Client', command=self.register_cc_api_client)
    self.cc_reg_button.grid(row=reg_cc_api_row, column=0, padx=5, pady=5, sticky=tk.NSEW)
    reg_cc_api_row += 1

    # Advance Load API
    # ----------------------
    self.al_api_frame = ttk.LabelFrame(self.config_frame, text="Advanced Load API", padding=(10, 5), style="Bold.TLabelframe")
    self.al_api_frame.grid(row=0, column=1, padx=(10, 5), pady=(10, 5), sticky=tk.NSEW)

    self.al_api_col1 = ttk.Frame(self.al_api_frame)
    self.al_api_col1.grid(row=0, column=0, padx=(0, 5), pady=0, sticky=tk.NSEW)

    self.al_api_col2 = ttk.Frame(self.al_api_frame)
    self.al_api_col2.grid(row=0, column=1, padx=0, pady=0, sticky=tk.NSEW)

    self.excel_frame = ttk.LabelFrame(self.al_api_col2, text="Excel Workbook Outputs", padding=(10, 5), style="Bold.TLabelframe")
    self.excel_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NE)

    self.directive_frame = ttk.LabelFrame(self.al_api_col2, text="Directives", padding=(10, 5), style="Bold.TLabelframe")
    self.directive_frame.grid(row=1, column=0, padx=5, pady=5, sticky=tk.NE)

    al_api_row = 0

    self.al_api_basic = tk.BooleanVar(value=0)
    self.al_api_basic_switch = ttk.Checkbutton(self.al_api_col1, text="Basic Auth", variable=self.al_api_basic, style="Switch.TCheckbutton")
    self.al_api_basic_switch.grid(row=al_api_row, column=0, padx=5, pady=5, sticky=tk.EW)
    self.al_api_basic_switch.state(['!selected'])
    al_api_row += 1

    self.al_api_import_button = ttk.Button(self.al_api_col1, text='Import Client ID/Secret', command=self.al_api_import)
    self.al_api_import_button.grid(row=al_api_row, column=0, padx=5, pady=5, sticky=tk.NSEW)
    al_api_row += 1

    self.al_api_client_id = tk.StringVar()
    self.al_api_client_id_label = ttk.Label(self.al_api_col1, text="Client ID")
    self.al_api_client_id_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_api_client_id_entry = ttk.Entry(self.al_api_col1, textvariable=self.al_api_client_id, show='*')
    self.al_api_client_id_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    al_api_row += 1

    self.al_api_client_secret = tk.StringVar()
    self.al_api_client_secret_label = ttk.Label(self.al_api_col1, text="Client Secret")
    self.al_api_client_secret_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_api_client_secret_entry = ttk.Entry(self.al_api_col1, textvariable=self.al_api_client_secret, show='*')
    self.al_api_client_secret_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    al_api_row += 1

    self.al_api_export_button = ttk.Button(self.al_api_col1, text='Save Client ID/Secret', command=self.al_api_export)
    self.al_api_export_button.grid(row=al_api_row, column=0, padx=5, pady=5, sticky=tk.NSEW)
    al_api_row += 1

    self.al_cc_username = tk.StringVar()
    self.al_cc_username_label = ttk.Label(self.al_api_col1, text="CC Username")
    self.al_cc_username_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_cc_username_entry = ttk.Entry(self.al_api_col1, textvariable=self.al_cc_username)
    self.al_cc_username_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    al_api_row += 1

    self.al_cc_password = tk.StringVar()
    self.al_cc_password_label = ttk.Label(self.al_api_col1, text="CC Password")
    self.al_cc_password_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_cc_password_entry = ttk.Entry(self.al_api_col1, show='*', textvariable=self.al_cc_password)
    self.al_cc_password_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    al_api_row += 1

    self.view_al_sets_label = ttk.Label(self.al_api_col1, justify="center", text="View AL Sets", state=tk.DISABLED) #, style='Link.TLabel', cursor='hand1')
    self.view_al_sets_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
    al_api_row += 1
    self.cc_dc.trace_add('write', self.update_al_sets_link)
    self.cc_tenant.trace_add('write', self.update_al_sets_link)

    # Start excel_frame (in Column 2)

    self.al_path_label = ttk.Label(self.excel_frame, text="AL Set & Files Location", justify="left")
    self.al_path_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.EW)
    al_api_row += 1
    self.al_path = tk.StringVar()
    # self.save_path_label = ttk.Label(self.tab1, justify="center", textvariable=self.save_path, cursor='hand1', style='Link.TLabel')
    self.al_path_entry = ttk.Combobox(self.excel_frame, justify="center", textvariable=self.al_path, postcommand=lambda:[
      self.al_path.set(filedialog.askdirectory(title=F"AL Set & File Location")), #, initialdir=Path.home())),
      self.after(1, lambda: self.al_path_entry.event_generate('<Escape>')),
      self.al_set_name.set(F"{Path(self.al_path.get()).stem} - {datetime.datetime.now()}") if self.al_path.get() and self.al_set_name.get() in ['My AL Set', '', None] else None
    ])
    self.al_path_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.EW)
    al_api_row += 1
    self.al_path_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.al_path_entry, tearoff=0)), 
      copy_menu.add_command(label='Copy Path', command=lambda: [
        self.al_path_entry.clipboard_clear(), 
        self.al_path_entry.clipboard_append(self.al_path.get())
      ]), 
      copy_menu.add_command(label='Open Folder', command=lambda: [
        webbrowser.open(F'file://{self.al_path.get()}')
      ]), 
      copy_menu.add_separator(),
      copy_menu.add_command(label='Select Folder', command=lambda: [
        self.al_path.set(filedialog.askdirectory(title=F"AL Set & File Location")), #, initialdir=Path.home())),
        self.al_set_name.set(F"{Path(self.al_path.get()).stem} - {datetime.datetime.now()}") if self.al_path.get() and self.al_set_name.get() in ['My AL Set', '', None] else None
      ]),
      copy_menu.post(e.x_root, e.y_root)
    ])

    self.al_set_name = tk.StringVar(value=F"My AL Set")
    self.al_set_name_label = ttk.Label(self.excel_frame, text="AL Set Name")
    self.al_set_name_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_set_name_entry = ttk.Entry(self.excel_frame, textvariable=self.al_set_name)
    self.al_set_name_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    al_api_row += 1

    self.al_api_load_button = ttk.Button(self.excel_frame, text='Load AL Set & Files', command=lambda:self.background(self.al_api_load))
    self.al_api_load_button.grid(row=al_api_row, column=0, padx=5, pady=5, sticky=tk.NSEW)
    al_api_row += 1

    self.al_load_status_label = ttk.Label(self.excel_frame, text=None, justify="center")
    self.al_load_status_label.grid(row=al_api_row, column=0, columnspan=2, padx=5, pady=(5,0), sticky=tk.EW)
    al_api_row += 1

    # Start Directives Frame (in Column 2)

    al_api_row = 0

    # DCDD Combobox
    self.al_dcdd = tk.StringVar()
    self.al_dcdd_label = ttk.Label(self.directive_frame, text="DCDD")
    self.al_dcdd_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_dcdd_entry = ttk.Combobox(self.directive_frame, textvariable=self.al_dcdd, postcommand=lambda:[
      self.al_dcdd.set(filedialog.askopenfilename(title=F"DCDD for Directive")), #, initialdir=Path.home())),
      self.after(1, lambda: self.al_dcdd_entry.event_generate('<Escape>')),
      self.al_directive_set_name.set(F"{Path(self.al_dcdd.get()).stem} - {datetime.datetime.now()}") if self.al_dcdd.get() and self.al_directive_set_name.get() in ['My AL Set', '', None] else None
    ])
    self.al_dcdd_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    self.al_dcdd_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.al_dcdd_entry, tearoff=0)), 
      copy_menu.add_command(label='Copy Path', command=lambda: [
        self.al_dcdd_entry.clipboard_clear(), 
        self.al_dcdd_entry.clipboard_append(self.al_dcdd.get())
      ]), 
      copy_menu.add_command(label='Open File', command=lambda: [
        webbrowser.open(F'file://{self.al_dcdd.get()}')
      ]), 
      copy_menu.add_separator(),
      copy_menu.add_command(label='Select File', command=lambda: [
        self.al_dcdd.set(filedialog.askopenfilename(title=F"DCDD for Directive")), #, initialdir=Path.home())),
        self.al_directive_set_name.set(F"{Path(self.al_dcdd.get()).stem} - {datetime.datetime.now()}") if self.al_dcdd.get() and self.al_directive_set_name.get() in ['My AL Set', '', None] else None
      ]),
      copy_menu.post(e.x_root, e.y_root)
    ])
    al_api_row += 1
    
    # Directive Combobox
    self.al_directive = tk.StringVar()
    self.al_directive_label = ttk.Label(self.directive_frame, text="Directive")
    self.al_directive_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_directive_entry = ttk.Combobox(self.directive_frame, textvariable=self.al_directive, postcommand=lambda:[
      self.al_directive.set(filedialog.askopenfilename(title=F"Directive")), #, initialdir=Path.home())),
      self.after(1, lambda: self.al_directive_entry.event_generate('<Escape>')),
      self.al_directive_set_name.set(F"{Path(self.al_directive.get()).stem} - {datetime.datetime.now()}") if self.al_directive.get() and self.al_directive_set_name.get() in ['My AL Set', '', None] else None
    ])
    self.al_directive_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    self.al_directive_entry.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
      (copy_menu := tk.Menu(self.al_directive_entry, tearoff=0)), 
      copy_menu.add_command(label='Copy Path', command=lambda: [
        self.al_directive_entry.clipboard_clear(), 
        self.al_directive_entry.clipboard_append(self.al_directive.get())
      ]), 
      copy_menu.add_command(label='Open File', command=lambda: [
        webbrowser.open(F'file://{self.al_directive.get()}')
      ]), 
      copy_menu.add_separator(),
      copy_menu.add_command(label='Select File', command=lambda: [
        self.al_directive.set(filedialog.askopenfilename(title=F"Directive")), #, initialdir=Path.home())),
        self.al_directive_set_name.set(F"{Path(self.al_directive.get()).stem} - {datetime.datetime.now()}") if self.al_directive.get() and self.al_directive_set_name.get() in ['My AL Set', '', None] else None
      ]),
      copy_menu.post(e.x_root, e.y_root)
    ])
    al_api_row += 1

    # Direct AL Set Name Entry
    self.al_directive_set_name = tk.StringVar(value=F"My AL Set")
    self.al_directive_set_name_label = ttk.Label(self.directive_frame, text="AL Set Name")
    self.al_directive_set_name_label.grid(row=al_api_row, column=0, padx=5, pady=(5,0), sticky=tk.W)
    al_api_row += 1
    self.al_directive_set_name_entry = ttk.Entry(self.directive_frame, textvariable=self.al_directive_set_name)
    self.al_directive_set_name_entry.grid(row=al_api_row, column=0, padx=5, pady=(0,5), sticky=tk.W)
    al_api_row += 1

    # Append Datetime Stamp to AL Set Name
    # self.al_directive_set_name_button = ttk.Button(self.directive_frame, text='Add Date', command=lambda:[self.al_directive_set_name.set(F"{self.al_directive_set_name.get()} - {datetime.datetime.now()}")])
    # self.al_directive_set_name_button.grid(row=al_api_row, column=0, padx=5, pady=5, sticky=tk.NSEW)
    # al_api_row += 1

    # Load Directive Button
    self.al_directive_button = ttk.Button(self.directive_frame, text='Load Directive', command=self.load_directive)
    self.al_directive_button.grid(row=al_api_row, column=0, padx=5, pady=5, sticky=tk.NSEW)
    al_api_row += 1

    # Column 3 Logging Frame with Text Box
    self.log_frame = ttk.LabelFrame(self.config_frame, text="Log", padding=(10, 5), style="Bold.TLabelframe")
    self.log_frame.grid(row=0, column=2, padx=(10,5), pady=(10,5), sticky=tk.NSEW)
    self.log_frame.grid_rowconfigure(0, weight=1)
    self.log_frame.grid_columnconfigure(0, weight=1)
    self.log_text = tk.Text(self.log_frame, wrap=tk.WORD, state=tk.DISABLED) # , font=("Courier New", 10), bg="black", fg="white")
    self.log_text.grid(row=0, column=0, padx=2, pady=2, sticky=tk.NSEW)
    self.log_text.tag_configure("error", foreground="red")

  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()

  def refresh_saved_cc_tenant_list(self):
    tenant_list = [F"{self.root.vars.get(F't{i}_username').get()}@{self.root.vars.get(F't{i}_name').get()}({self.root.vars.get(F't{i}_datacenter').get()})" for i in range(1, max([int(x.split('_')[0][1:]) for x in self.root.vars.keys() if x.startswith('t') and x.endswith('_username')] or [1])+1) if self.root.vars.get(F't{i}_cc').get() == True]
    self.cc_tenants_entry.configure(values=tenant_list)

  def update_al_sets_link(self, *kwargs):
    if all([self.cc_dc.get(),self.cc_tenant.get()]):
      self.view_al_sets_label.config(state=tk.NORMAL, style='Link.TLabel', cursor='hand1')
      base_url = data_centers.get(self.cc_dc.get(), [None, None])[1] or self.cc_dc.get()
      if not base_url.startswith('https://'): base_url = F'https://{base_url}'
      # https://i-0d32346019e71f198.workdaysuv.com/customercentral/d/task/2998$37725.htmld
      url = F"{base_url}/{self.cc_tenant.get()}/d/task/2998$37725.htmld"
      self.view_al_sets_label.bind('<ButtonRelease-1>', lambda e, url=url: webbrowser.open_new_tab(url))
      self.view_al_sets_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e, url=url: [
        (copy_menu := tk.Menu(self.view_al_sets_label, tearoff=0)), 
        copy_menu.add_command(label='Copy Link', command=lambda: [
          self.view_al_sets_label.clipboard_clear(), 
          self.view_al_sets_label.clipboard_append(url)
        ]), 
        copy_menu.add_command(label='Open Link', command=lambda: [
          webbrowser.open_new_tab(url)
        ]), 
        copy_menu.post(e.x_root, e.y_root)
      ])
    else:
      self.view_al_sets_label.config(state=tk.DISABLED, style=None, cursor='arrow')
      self.view_al_sets_label.unbind('<ButtonRelease-1>')
      self.view_al_sets_label.unbind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>')


  def get_proteus_suv(self):
    pp = Proteus_Picker(self.root, self.root.winfo_pointerxy()) # Use the root object with the cred/config vars.
    if not pp.error: self.wait_window(pp.top)
    if pp.result:
      # It's an SUV, we already know mostly what we need here
      self.cc_dc.set(pp.result['url'])
      self.cc_tenant.set('customercentral')
      self.cc_ccs_username.set('ccs')
      self.cc_ccs_password.set(pp.result['password'])
      self.al_cc_username.set('ccu')
      self.al_cc_password.set(pp.result['password'])

  def register_cc_api_client(self):
    al = Advanced_Load()
    base_url = data_centers.get(self.cc_dc.get(), [None, None])[1] or self.cc_dc.get() # Use non-service url or SUV
    if not base_url.startswith('https://'): base_url = F'https://{base_url}'
    try:
      client_id, client_secret = al.oauth.register_cc_api_client(
        base_url, self.cc_tenant.get(), self.cc_ccs_username.get(), 
        self.cc_ccs_password.get(), self.cc_client_name.get(), self.cc_redirect.get()
      )
    except Exception as e:
      messagebox.showerror(title="AL API Client Registration Error", message=F"Error registering API Client:\n{e}")
      return
    self.al_api_client_id.set(client_id)
    self.al_api_client_secret.set(client_secret)
    messagebox.showinfo(title="AL API Client Registration", message="Successfully Registered Client!\nBe sure to save the Client ID and Secret.")


  def al_api_import(self):
    client_id = None
    client_secret = None
    file_name = filedialog.askopenfilename(title=F"Select JSON or CSV File", filetypes=(("JSON or CSV Files", "*.json *.csv"), ("All Files", "*.*")))
    if not file_name:
      return
    file_name = Path(file_name)
    if not file_name.is_file():
      messagebox.showerror(title='AL API Import Error', message=F'File "{file_name}" does not exist!')
      return
    if not file_name.suffix == ".csv": # Assume JSON if not CSV
      with open(file_name) as f:
        try:
          data = json.load(f)
        except Exception as e:
          messagebox.showerror(title='AL API Import Error', message=F'Error importing JSON from "{file_name}"!\n{e}')
          return
      client_id = data.get('client_id')
      client_secret = data.get('client_secret')
      if not all([client_id, client_secret]):
        messagebox.showerror(title='AL API Import Error', message=F'Could not find Client ID and/or Secret in "{file_name}" (JSON expected)!')
        return        
    else: # Assume CSV
      with open(file_name, newline='') as f:
        reader = csv.reader(f)
        first_row = next((reader), [''])
        if first_row and 'id' in first_row[0]: # Assume header, get next row
          client_id, client_secret, *_ = next((reader), []) + [None] * 2
        elif first_row: # Assume no header
          client_id, client_secret, *_ = first_row + [None] * 2
      if not all([client_id, client_secret]):
        messagebox.showerror(title='AL API Import Error', message=F'Could not find Client ID and/or Secret in "{file_name}" (CSV expected)!')
        return
    self.al_api_client_id.set(client_id.strip())
    self.al_api_client_secret.set(client_secret.strip())

  def al_api_export(self):
    client_id = self.al_api_client_id.get()
    client_secret = self.al_api_client_secret.get()
    if not all([client_id, client_secret]):
      messagebox.showerror(title='AL API Import Error', message=F'Missing Client ID and/or Secret!')
      return
    file_name = filedialog.asksaveasfilename(title=F"Save as JSON or CSV", defaultextension=".json", filetypes=(("JSON Files", "*.json"), ("CSV Files", "*.csv"), ("All Files", "*.*")), initialfile="al_api_client_id_secret.json")
    if not file_name:
      return
    file_name = Path(file_name)
    if not file_name.suffix == '.csv': # Assume JSON if not CSV
      with open(file_name, 'w') as f:
        f.write(json.dumps({'client_id': client_id, 'client_secret': client_secret}))
    else: # Assume CSV
      with open(file_name, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['client_id', 'client_secret'])
        writer.writerow([client_id, client_secret])

  def al_api_load(self):
    self.al_api_load_button.config(state=tk.DISABLED)
    if not all([
        self.al_api_client_id.get() if not self.al_api_basic.get() else True,
        self.al_api_client_secret.get() if not self.al_api_basic.get() else True,
        self.al_path.get(),
        self.al_cc_username.get(),
        self.al_cc_password.get(),
        self.cc_tenant.get(),
        self.cc_dc.get(),
      ]):
      messagebox.showerror(title='AL API Load Error', message='Missing required fields!')
      self.al_api_load_button.config(state=tk.NORMAL)
      return

    al = Advanced_Load(self.al_api_client_id.get(), self.al_api_client_secret.get())

    base_url = data_centers.get(self.cc_dc.get(), [None, None])[1] or self.cc_dc.get() # Use non-service url or SUV
    base_service_url = data_centers.get(self.cc_dc.get(), [None])[0] or self.cc_dc.get() # Use service url or SUV
    
    try:
      # Get Token
      self.al_load_status_label.config(text=" -- Getting Token -- ")
      if self.al_api_basic.get():
        token_type, token = al.oauth.get_cc_auth_token_basic(base_service_url, self.cc_tenant.get(), self.al_cc_username.get(), self.al_cc_password.get())
      else:
        try:
          al.oauth.enable_oauth_clients(base_url, self.cc_tenant.get(), self.cc_ccs_username.get(), self.cc_ccs_password.get())
        except Exception as e:
          messagebox.showerror(title='AL API Load Error', message=F'Error enabling OAuth 2.0 clients:\n{e}')
          self.al_api_load_button.config(state=tk.NORMAL)
          return
        token_type, token = al.oauth.get_cc_auth_token(base_url, base_service_url, self.cc_tenant.get(), self.al_api_client_id.get(), self.al_api_client_secret.get(), self.al_cc_username.get(), self.al_cc_password.get())

      # AL Loadsets API call  
      self.al_load_status_label.config(text=" -- Processing Files -- ")
      loadset_data = al.process_loadset_folder(self.al_path.get())
      # print(loadset_data)

      self.al_load_status_label.config(text=" -- Uploading Files -- ")
      al.upload_files(base_url, self.cc_tenant.get(), token_type, token, loadset_data, self.al_path.get(), self.al_api_basic.get(), verify=True if self.al_api_basic.get() else False)
      # print(loadset_data)

      self.al_load_status_label.config(text=" -- Loading AL Set -- ")
      result = al.send_load_sets(base_url, self.cc_tenant.get(), token_type, token, loadset_data, self.al_set_name.get(), self.al_api_basic.get(), verify=True if self.al_api_basic.get() else False)
      messagebox.showinfo(title='AL API Load', message=F'Load Successful:\n{result}')
      self.al_load_status_label.config(text=F'Load Successful:\n{result}')
      self.al_api_load_button.config(state=tk.NORMAL)
    except Exception as e:
      messagebox.showerror(title='AL API Load Error', message=F'Error Loading AL Set & Files:\n{e}')
      self.al_load_status_label.config(text=F'Error Loading AL Set & Files:\n{e}')
      self.al_api_load_button.config(state=tk.NORMAL)

  def load_directive(self):
    if not all([self.al_dcdd.get(), self.al_directive.get(), self.al_directive_set_name.get(), self.al_cc_username.get(), self.al_cc_password.get(), self.cc_tenant.get(), self.cc_dc.get()]):
      messagebox.showerror(title='Directive Load Error', message='Missing required fields!')
      return
    base_url = data_centers.get(self.cc_dc.get(), [None, None])[1] or self.cc_dc.get() # Use non-service url or SUV
    base_service_url = data_centers.get(self.cc_dc.get(), [None])[0] or self.cc_dc.get() # Use service url or SUV
    if self.al_api_basic.get():
      al = Advanced_Load()
      try:
        token_type, token = al.oauth.get_cc_auth_token_basic(base_url, self.cc_tenant.get(), self.al_cc_username.get(), self.al_cc_password.get())
      except Exception as e:
        messagebox.showerror(title='Directive Load Error', message=F'Error getting token:\n{e}')
        return
    else:
      if not all([self.al_api_client_id.get(), self.al_api_client_secret.get()]):
        messagebox.showerror(title='Directive Load Error', message='Missing required fields!')
        return
      al = Advanced_Load(self.al_api_client_id.get(), self.al_api_client_secret.get())
      try:
        token_type, token = al.oauth.get_cc_auth_token(base_url, base_service_url, self.cc_tenant.get(), self.al_api_client_id.get(), self.al_api_client_secret.get(), self.al_cc_username.get(), self.al_cc_password.get())
      except Exception as e:
        messagebox.showerror(title='Directive Load Error', message=F'Error getting token:\n{e}')
        return
    # Load DCDD
    try:
      with open(self.al_dcdd.get(), 'r') as f:
        dcdd = json.load(f)
    except Exception as e:
      messagebox.showerror(title='Directive Load Error', message=F'Error processing DCDD:\n{e}')
      return
    # Load Directive
    try:
      with open(self.al_directive.get(), 'r') as f:
        directive = json.load(f)
    except Exception as e:  
      messagebox.showerror(title='Directive Load Error', message=F'Error processing Directive:\n{e}')
      return
    # Parse DCDD
    impl_component = dcdd.get('metadata', {}).get("IMPLEMENTATION COMPONENT")
    if not impl_component:
      messagebox.showerror(title='Directive Load Error', message=F'Implementation Component Not Found in DCDD')
      return
    version = dcdd.get('metadata', {}).get("API VERSION")
    if not version:
      messagebox.showerror(title='Directive Load Error', message=F'API Version Not Found in DCDD')
      return
    # Construct Loadset Data
    loadset_data = {
      "setName": self.al_directive_set_name.get(),
      "setDefinition": {
        "sourceType": "json",
        "content": [
          {
            "order": "a",
            "implementationType": impl_component,
            "implementationComponent": impl_component,
            "version": version,
            "directives": directive
          }
        ]
      }
    }

    # Print Loadset Data to Log
    self.log_text.configure(state=tk.NORMAL)
    self.log_text.insert(tk.END, f"Loadset Data:\n{json.dumps(loadset_data, indent=2)}\n")
    self.log_text.see(tk.END)
    self.log_text.configure(state=tk.DISABLED)
    # Send Loadset Data
    try: 
      if self.al_api_basic.get():
        r = al.send_load_sets(base_url, self.cc_tenant.get(), token_type, token, loadset_data, None, True, verify=True)
      else:
        r = al.send_load_sets(base_service_url, self.cc_tenant.get(), token_type, token, loadset_data, None, False, verify=False)
      # raise an error while in testing
      # raise Exception("Still a work in progress")
      # Print results to log
      self.log_text.configure(state=tk.NORMAL)
      self.log_text.insert(tk.END, f"Directive Load Result:\n{r}\n")
      self.log_text.see(tk.END)
      self.log_text.configure(state=tk.DISABLED)
    except Exception as e:
      # messagebox.showerror(title='Directive Load Error', message=F'Error Loading Directive:\n{e}')
      self.log_text.configure(state=tk.NORMAL)
      self.log_text.insert(tk.END, f"Directive Load Error:\n{e}\n")
      self.log_text.see(tk.END)
      self.log_text.configure(state=tk.DISABLED)


if __name__ == "__main__":
  root = tk.Tk()
  root.title("Advanced Load API & Config")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()