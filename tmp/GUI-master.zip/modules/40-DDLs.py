import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import sys, json
import threading
import webbrowser
import time
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent
try:
  from lib import GitHub, CheckboxTreeview, MySQL, InterceptorWidget, StyledHovertip, TextRedirector, DDL
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import GitHub, CheckboxTreeview, MySQL, InterceptorWidget, StyledHovertip, TextRedirector, DDL

class App(ttk.Frame):
  refresh_loading = False
  loading = False
  dcdds = {}

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(1, weight=1)
    # self.rowconfigure(1, weight=1)

    # Label
    self.label = ttk.Label(self, text="DDL Generator", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, padx=10, pady=10)

    # Current DCDDs (JSON)
    self.dcdd_frame = ttk.LabelFrame(self, text="Current DCDDs (JSON)")
    self.dcdd_frame.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
    self.dcdd_frame.columnconfigure(0, weight=1)
    # self.dcdd_frame.rowconfigure(0, weight=1)

    grid_row = 0

    # Dropdown for DCDD JSON url on GHE
    self.dcdd_url_label = ttk.Label(self.dcdd_frame, text="DCDD JSON URL (GHE):")
    self.dcdd_url_label.grid(row=grid_row, column=0, padx=10, pady=10, sticky="w")
    self.dcdd_url_entry = ttk.Entry(self.dcdd_frame, width=100)
    self.dcdd_url_entry.grid(row=grid_row, column=1, padx=10, pady=10, sticky="ew")
    self.dcdd_url_entry.insert(0, "https://ghe.megaleo.com/DTOE/DCDD_JSON/tree/master/JSONs")
    
    # Refresh button
    self.refresh_button = ttk.Button(self.dcdd_frame, text="Refresh", command=self.refresh_dcdd)
    self.refresh_button.grid(row=grid_row, column=2, padx=10, pady=10, sticky="ew")
    grid_row += 1

    # Entry for local copy of JSONs
    self.local_json_label = ttk.Label(self.dcdd_frame, text="DCDD JSON Folder:")
    self.local_json_label.grid(row=grid_row, column=0, padx=10, pady=10, sticky="w")
    self.local_json_entry = ttk.Entry(self.dcdd_frame, width=100)
    self.local_json_entry.grid(row=grid_row, column=1, padx=10, pady=10, sticky="ew")
    self.local_json_entry.insert(0, "")

    # Folder Refresh Button
    self.folder_refresh_button = ttk.Button(self.dcdd_frame, text="Refresh", command=self.refresh_local_dcdd)
    self.folder_refresh_button.grid(row=grid_row, column=2, padx=10, pady=10, sticky="ew")
    grid_row += 1

    # DCDD Tree
    self.dcdd_tree = CheckboxTreeview(self.dcdd_frame, columns=(1, 2))
    self.dcdd_tree.grid(row=grid_row, column=0, columnspan=3, padx=10, pady=10, sticky="nsew")
    self.dcdd_tree.column("#0", width=100)
    self.dcdd_tree.column(1, width=100)
    self.dcdd_tree.column(2, width=100)
    self.dcdd_tree.heading("#0", text="Functional Area")
    self.dcdd_tree.heading(1, text="DCDD Name")
    self.dcdd_tree.heading(2, text="Additional Info")

    # self.dcdd_tree.bind("<Double-1>", self.on_dcdd_double_click)

    # Interceptor
    # self.interceptor = InterceptorWidget(self)
    # self.interceptor.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")

    # Redirector
    # self.redirector = TextRedirector(self)
    # self.redirector.grid(row=3, column=0, padx=10, pady=10, sticky="nsew")

    # Export DDL Button
    self.export_ddl_button = ttk.Button(self, text="Export DDL", command=self.export_ddl)
    self.export_ddl_button.grid(row=2, column=0, padx=10, pady=10, sticky="ew")

    grid_row = 3

    # Frame for file path
    self.file_frame = ttk.Frame(self)
    self.file_frame.grid(row=grid_row, column=0, padx=0, pady=0, sticky="nsew")

    # Entry for file path
    self.file_path_label = ttk.Label(self.file_frame, text="File Path:")
    self.file_path_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
    self.file_path = tk.StringVar()
    self.file_path_entry = ttk.Entry(self.file_frame, width=100, textvariable=self.file_path)
    self.file_path_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

    grid_row += 1

    # Button to upload to Mysql
    self.upload_button = ttk.Button(self, text="Upload to MySQL", command=self.upload_to_mysql)
    self.upload_button.grid(row=grid_row, column=0, padx=10, pady=10, sticky="ew")



  def background(self, func, args=(), kwargs={}):
    th = threading.Thread(target=func, args=args, kwargs=kwargs)
    th.start()

  def refresh_dcdd(self):
    if not self.refresh_loading:
      self.refresh_loading = True
      self.refresh_button.config(state="disabled")
      self.dcdd_tree.delete(*self.dcdd_tree.get_children())
      self.dcdd_tree.insert("", "end", text="  Loading ...", values=("", ""))
      self.dcdd_tree.update()
      self.get_dcdds()

  def refresh_local_dcdd(self):
    if not self.refresh_loading:
      self.refresh_loading = True
      self.refresh_button.config(state="disabled")
      self.dcdd_tree.delete(*self.dcdd_tree.get_children())
      self.dcdd_tree.insert("", "end", text="  Loading ...", values=("", ""))
      self.dcdd_tree.update()
      self.get_local_dcdds()

  def get_local_dcdds(self):
    self.dcdds = {}
    folder = self.local_json_entry.get()
    if not folder:
      folder = filedialog.askdirectory()
      if not folder:
        self.refresh_loading = False
        self.refresh_button.config(state="normal")
        return
      self.local_json_entry.delete(0, tk.END)
      self.local_json_entry.insert(0, folder)

    if not Path(folder).exists():
      messagebox.showerror("Error", "Folder does not exist")
      self.refresh_loading = False
      self.refresh_button.config(state="normal")
      return
    # Get all the JSON files
    json_files = [f for f in Path(folder).rglob('*.json') if f.name != 'all.json']
    for f in json_files:
      with open(f, 'r') as j:
        dcdd = json.load(j)
        # print(f)
        self.dcdds[dcdd.get('name') or dcdd.get('metadata', {}).get('FULL NAME')] = dcdd
    # Get all the functional areas
    functional_areas = set()
    _ = [functional_areas.add(area or "Unknown Area") for dcdd in self.dcdds for area in (self.dcdds[dcdd].get('metadata', {}).get("FUNCTIONAL AREA", "") or '').split(', ')]
    functional_areas = sorted(list(functional_areas))
    # Clear the tree
    self.dcdd_tree.delete(*self.dcdd_tree.get_children())

    for area in functional_areas:
      # print(area)
      self.dcdd_tree.insert(parent='', index=tk.END, iid=area, text=F"  {area}", values=("", ""))
      for dcdd in self.dcdds:
        if area in (self.dcdds[dcdd]['metadata'].get("FUNCTIONAL AREA", "") or '').split(', '):
          # print(dcdd)
          self.dcdd_tree.insert(parent=area, index=tk.END, values=(dcdd, F"""{(self.dcdds[dcdd]['metadata'].get("API VERSION", "") or "")} - {self.dcdds[dcdd]['permalink']}"""))

    # self.dcdd_tree.tag_configure("functional_area", background="lightgrey")
    # self.dcdd_tree.tag_configure("dcdd", background="white")

    self.refresh_loading = False
    self.refresh_button.config(state="normal")

  def get_dcdds(self):
    g = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
    self.dcdds = g.get_jsons_from_zip(url=self.dcdd_url_entry.get())
    # Get all the functional areas
    functional_areas = set()
    _ = [functional_areas.add(area or "Unknown Area") for dcdd in self.dcdds for area in (self.dcdds[dcdd]['metadata'].get("FUNCTIONAL AREA", "") or '').split(', ')]
    functional_areas = sorted(list(functional_areas))
    # Clear the tree
    self.dcdd_tree.delete(*self.dcdd_tree.get_children())

    for area in functional_areas:
      # print(area)
      self.dcdd_tree.insert(parent='', index=tk.END, iid=area, text=F"  {area}", values=("", ""))
      for dcdd in self.dcdds:
        if area in (self.dcdds[dcdd]['metadata'].get("FUNCTIONAL AREA", "") or '').split(', '):
          # print(dcdd)
          self.dcdd_tree.insert(parent=area, index=tk.END, values=(dcdd, F"""{(self.dcdds[dcdd]['metadata'].get("API VERSION", "") or "")} - {self.dcdds[dcdd]['permalink']}"""))

    # self.dcdd_tree.tag_configure("functional_area", background="lightgrey")
    # self.dcdd_tree.tag_configure("dcdd", background="white")

    self.refresh_loading = False
    self.refresh_button.config(state="normal")

  def export_ddl(self):
    if not self.loading:
      self.loading = True
      self.export_ddl_button.config(state="disabled")

      # Get the checked DCDDs
      selected_dcdds = [i.get('values', [])[0] for i in self.dcdd_tree.get_tagged(tag_has="checked")]
      # print(selected_dcdds)
      if not selected_dcdds:
        messagebox.showerror("Error", "No DCDDs selected")
        self.loading = False
        self.export_ddl_button.config(state="normal")
        return

      # Get Save File Path
      file_path = filedialog.asksaveasfilename(defaultextension=".sql", filetypes=[("SQL Files", "*.sql")], initialfile="ddl.sql")
      if not file_path:
        self.loading = False
        self.export_ddl_button.config(state="normal")
        return
      self.file_path.set(file_path)
 
      filtered_dcdds = {k: v for k, v in self.dcdds.items() if k in selected_dcdds}
      d = DDL(dcdds=filtered_dcdds, name=None, debug=False)
      d.write_ddl_file(file_path=file_path)

      self.loading = False
      self.export_ddl_button.config(state="normal")

  def upload_to_mysql(self):
    if not self.file_path.get():
      file_path = filedialog.askopenfilename(filetypes=[("SQL Files", "*.sql")])
      if not file_path:
        return
      self.file_path.set(file_path)
    # Get contens of the file
    with open(self.file_path.get(), 'r') as f:
      contents = f.read()
    # Check if the file is empty
    if not contents:
      messagebox.showerror("Error", "File is empty")
      return
    # Check if the MySQL Connection details are filled in
    if not all([self.root.vars['db_host'].get(), self.root.vars['db_port'].get(), self.root.vars['db_username'].get(), self.root.vars['db_password'].get()]):
      messagebox.showerror("Error", "Please fill in the MySQL Connection details")
      return
    if not self.loading:
      self.loading = True
      self.upload_button.config(state="disabled")

      # Print connection details (debug)
      # print(F"Connecting to MySQL: {self.root.vars['db_host'].get()}:{self.root.vars['db_port'].get()} as {self.root.vars['db_username'].get()}@{self.root.vars['db_password'].get()}")

      # Get MySQL Connection
      m = MySQL(
        host=self.root.vars['db_host'].get(), 
        port=self.root.vars['db_port'].get(), 
        username=self.root.vars['db_username'].get(), 
        passwd=self.root.vars['db_password'].get()
      )

      # Execute the SQL File
      try:
        # m.connect(True)
        m.load_gh_sql(contents)
        messagebox.showinfo("Success", "SQL file uploaded successfully")
      except Exception as e:
        messagebox.showerror("Error", F"Error loading SQL file: {e}")
      finally:
        self.loading = False
        self.upload_button.config(state="normal")

if __name__ == "__main__":
  sys.path.append(LibPath.absolute().as_posix())

  root = tk.Tk()
  root.title("DDL Generator")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')),
    'db_username':tk.StringVar(value=dict_config.get('db_username')),
    'db_password':tk.StringVar(value=dict_config.get('db_password')),
    'db_host':tk.StringVar(value=dict_config.get('db_host')),
    'db_port':tk.StringVar(value=dict_config.get('db_port')),
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()