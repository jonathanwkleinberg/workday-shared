import tkinter as tk
from tkinter import ttk, messagebox, filedialog
# from tkinter.filedialog import askopenfilename
from pathlib import Path
import sys, json
import threading
import webbrowser
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent

try:
  from lib import StyledHovertip, Proteus_Picker, Proteus
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import StyledHovertip, Proteus_Picker, Proteus

class App(ttk.Frame):

  def __init__(self, parent, left_file=None, right_file=None, minimum=False):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.grid_rowconfigure(1, weight=1)
    self.grid_columnconfigure(0, weight=1)

    # Label
    self.label = ttk.Label(self, text="Empty Placeholder", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, columnspan=99, padx=10, pady=10, sticky=tk.EW)

    # Config Frame
    self.config_frame = ttk.Frame(self)
    self.config_frame.grid(row=1, column=0, columnspan=99, padx=5, pady=5, sticky=tk.NSEW)

  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()


if __name__ == "__main__":
  root = tk.Tk()
  root.title("Empty Placeholder")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')), 
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()