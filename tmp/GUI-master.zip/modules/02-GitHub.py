import tkinter as tk
from tkinter import ttk, filedialog
from pathlib import Path
import sys, json
import threading
import webbrowser
import time
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent
LibPath = CurrentPath.parent
try:
  from lib import GitHub, CheckboxTreeview, MySQL, InterceptorWidget
except:
  sys.path.append(LibPath.absolute().as_posix())
  from lib import GitHub, CheckboxTreeview, MySQL, InterceptorWidget

class App(ttk.Frame):
  refresh_loading = False
  loading = False

  def __init__(self, parent):
    ttk.Frame.__init__(self, parent)
    self.root = self.master.master or self.master

    self.columnconfigure(1, weight=1)
    self.rowconfigure(1, weight=1)

    # s = ttk.Style()
    # s.configure("Borderless.Treeview", borderwidth=0)

    # Label
    self.label = ttk.Label(self, text="GitHub Loader", justify="center", font=("-size", 15, "-weight", "bold"))
    self.label.grid(row=0, column=0, padx=10, pady=10)
    # Button
    self.ghe_refresh_button = ttk.Button(self, text="↻ Refresh GitHub Listings", style="Green.TButton", command=lambda:[self.refresh_github_data()])
    self.ghe_refresh_button.grid(row=0, column=1, padx=5, pady=5, )

    # Load Frame
    self.load_frame = ttk.LabelFrame(self, text="Loads", style="Bold.TLabelframe") # padding=(5, 5),
    self.load_frame.grid(row=1, column=0, padx=5, pady=(5,0), sticky=tk.NSEW)
    # Load Buttons
    self.load_all_button = ttk.Button(self.load_frame, text="Load All\nSelected", command=lambda: [self.background(self.load_to_db)])
    self.load_all_button.pack(fill='x', padx=5, pady=5)
    self.cancel_load_button = ttk.Button(self.load_frame, text="Cancel Load", state='disabled', command=self.cancel_load)
    self.cancel_load_button.pack(fill='x', padx=5, pady=5)
    self.uncheck_all_button = ttk.Button(self.load_frame, text="Uncheck All", command=lambda: [[self.tabs[t]['treeview'].click_item(i) for i in self.tabs[t]['treeview'].get_children()] for t in self.tabs])
    self.uncheck_all_button.pack(fill='x', padx=5, pady=5)
    (button4 := ttk.Button(self.load_frame, text="Save Selections", command=self.save_selections)).pack(fill='x', padx=5, pady=5)
    (button5 := ttk.Button(self.load_frame, text="Import Selections", command=self.import_selections)).pack(fill='x', padx=5, pady=5)

    # Notebook
    self.notebook = ttk.Notebook(self)
    self.notebook.grid(row=1, column=1, columnspan=99, sticky=tk.NSEW)
    # Tab Defs
    self.tabs = {
      'DDLs': {
        'url': 'https://ghe.megaleo.com/Workday-Data-Conversion/SLNG2.0-Direct/tree/master/DC_Standard/DDLs',
        'suffixes': ('.sql'),
        # 'types': ('blob'),
        # 'recursive': False,
      },
      'Validations': {
        'url': 'https://ghe.megaleo.com/Workday-Data-Conversion/SLNG2.0-Direct/tree/master/DC_Standard/Validations',
      },
      'Standard SPs': {
        'url': 'https://ghe.megaleo.com/Workday-Data-Conversion/SLNG2.0-Direct/tree/master/DC_Standard/Stored_Procedures',
        'suffixes': ('.sql'),
      },
      'CSVs': {
        'url': 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/CSVs',
      },
    }

    # --------
    # | Tabs |
    # --------
    for t in self.tabs:
      self.tabs[t]['frame'] = ttk.Frame(self.notebook)
      self.notebook.add(self.tabs[t]['frame'], text=t)

      # Tab Hyperlink
      tab_hyperlink_label = ttk.Label(self.tabs[t]['frame'], cursor='hand1', text=self.tabs[t]['url'], style='Link.TLabel')
      tab_hyperlink_label.pack(anchor=tk.NW, padx=2)
      tab_hyperlink_label.bind('<ButtonRelease-1>', lambda e: webbrowser.open_new_tab(e.widget['text']))
      tab_hyperlink_label.bind("<ButtonRelease-2>" if MAC_OS else '<ButtonRelease-3>', lambda e: [
        (copy_menu := tk.Menu(e.widget, tearoff=0)), 
        copy_menu.add_command(label='Copy Link', command=lambda: [
          e.widget.clipboard_clear(), 
          e.widget.clipboard_append(e.widget['text'])
        ]), 
        copy_menu.add_command(label='Open Link', command=lambda: [
          webbrowser.open_new_tab(e.widget['text'])
        ]), 
        copy_menu.post(e.x_root, e.y_root)
      ])
      tab_hyperlink_label.bind("<Control-ButtonRelease-1>", lambda e: [
        (copy_menu := tk.Menu(e.widget, tearoff=0)), 
        copy_menu.add_command(label='Copy Link', command=lambda: [
          e.widget.clipboard_clear(), 
          e.widget.clipboard_append(e.widget['text'])
        ]), 
        copy_menu.add_command(label='Open Link', command=lambda: [
          webbrowser.open_new_tab(e.widget['text'])
        ]), 
        copy_menu.post(e.x_root, e.y_root)
      ])
      if self.tabs[t].get('suffixes') or self.tabs[t].get('types') or self.tabs[t].get('recursive') == False:
        text = ' ( Includes: '
        add_text = []
        if self.tabs[t].get('suffixes'): add_text.append(F"files with {self.tabs[t].get('suffixes')}")
        if self.tabs[t].get('types'): add_text.append(F"types of {self.tabs[t].get('types')}")
        if self.tabs[t].get('recursive') == False: add_text.append(F"recursive is False")

        tab_params = ttk.Label(self.tabs[t]['frame'], text=text + ', '.join(add_text) + ' )')
        tab_params.pack(anchor=tk.NW, padx=2)

      # Tab Scrollbar
      tab_scrollbar = ttk.Scrollbar(self.tabs[t]['frame'])
      tab_scrollbar.pack(side="right", fill="y")

      # Tab Treeview
      self.tabs[t]['treeview'] = CheckboxTreeview(self.tabs[t]['frame'], yscrollcommand=tab_scrollbar.set, columns=(1, 2), height=10) # , selectmode="browse", padding=[-15,0,0,0]
      iw = InterceptorWidget(self)
      iw.attach_treeview(self.tabs[t]['treeview'])
      cur_treeview = self.tabs[t]['treeview']
      cur_treeview.pack(expand=True, fill="both")
      # self.tabs[t]['treeview'].config(style="Borderless.Treeview")
      tab_scrollbar.config(command=cur_treeview.yview)

      # Tab Treeview columns
      cur_treeview.column("#0", anchor="w", width=400)
      cur_treeview.column(1, anchor="w", width=200)
      cur_treeview.column(2, anchor="w", width=0)

      # Tab Treeview headings
      cur_treeview.heading("#0", text="File", anchor="center")
      cur_treeview.heading(1, text="Link", anchor="center")
      cur_treeview.heading(2, text="Path", anchor="center")

      cur_treeview['displaycolumns'] = (1)

      # Binding
      cur_treeview.bind('<ButtonRelease-1>', self.tree_left_click, add="+")
      cur_treeview.bind("<Motion>", self.hand1_cursor_on)
      cur_treeview.bind("<Leave>", self.cursor_off)
      # self.tabs[t]['treeview'].bind("<ButtonRelease-3>", lambda e: None)
      cur_treeview.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", self.tree_right_click)
      cur_treeview.bind("<Control-ButtonRelease-1>", self.tree_right_click)
      cur_treeview.bind('<Control-a>', lambda e:[self.select_all_tree(e.widget)])
      cur_treeview.bind('<Control-c>', lambda e:[self.copy_tree_selection_to_clipboard(e.widget)])

      cur_treeview.all_children = []

      # Custom Filter String
      cur_treeview.filterable = []
      cur_treeview.filter = tk.StringVar(name=t)
      cur_treeview.filter_time = tk.IntVar(value=time.perf_counter_ns() // 1_000_000)
      cur_treeview.filter.trace_add('write', lambda var, index, mode: [
        self.tabs[var]['treeview'].filter_time.set(time.perf_counter_ns() // 1_000_000),
        self.tabs[var]['treeview'].after(500, self.filter_tree, self.tabs[var]['treeview']),
      ])
      

    # ---------------
    # | Loading Tab |
    # ---------------
      
    self.loading_tab = ttk.Frame(self.notebook)
    self.notebook.add(self.loading_tab, text='Loads')

    # Loading Tab Scrollbar
    tab_scrollbar = ttk.Scrollbar(self.loading_tab)
    tab_scrollbar.pack(side="right", fill="y")

    # Loading Tab Treeview
    self.loading_tree = ttk.Treeview(self.loading_tab, yscrollcommand=tab_scrollbar.set, columns=(1, 2), height=10) # , selectmode="browse", padding=[-15,0,0,0]
    self.loading_tree.pack(expand=True, fill="both")
    self.loading_tree.config(style="Borderless.Treeview")
    tab_scrollbar.config(command=self.loading_tree.yview)

    # Loading Tab Treeview columns
    self.loading_tree.column("#0", anchor="w", width=200)
    self.loading_tree.column(1, anchor="w", width=200)
    self.loading_tree.column(2, anchor="w", width=200)

    # Loading Tab Treeview headings
    self.loading_tree.heading("#0", text="Type", anchor="center")
    self.loading_tree.heading(1, text="Item", anchor="center")
    self.loading_tree.heading(2, text="Status", anchor="center")

    self.refresh_github_data()

  def refresh_github_data(self):
    self.refresh_loading = True
    for t in self.tabs:
      self.tabs[t]['treeview'].delete(*self.tabs[t]['treeview'].get_children())
    self.background(self.process_repo)

  def animate_refresh_loading(self):
    if self.refresh_loading:
      #do something
      self.root.after(50, self.animate_refresh_loading)

  def print_element(self, event):
    tree = event.widget
    selection = [tree.item(item)["text"] for item in tree.selection()]
    print("selected items:", selection)

  def hand1_cursor_on(self, event):
    tree = event.widget  # get the treeview widget
    if tree.identify_region(event.x, event.y) != 'cell':
      tree.config(cursor='')
      return
    if tree.identify_column(event.x) != "#1":
      tree.config(cursor='')
      return
    values = tree.item(tree.identify('item', event.x, event.y))['values']
    if len(values) > 0 and values[0]:
      tree.config(cursor='hand1')
    else:
      tree.config(cursor='')
  
  def cursor_off(self, event):
    event.widget.config(cursor='')

  def background(self, func, args=()):
    th = threading.Thread(target=func, args=args)
    th.start()

  def tree_left_click(self, event):
    tree = event.widget  # get the treeview widget
    tree_region = tree.identify_region(event.x, event.y)
    tree_column = tree.identify_column(event.x)
    # tree_column_idx = int(tree_column[1:])
    item = tree.identify('item', event.x, event.y)
    # print(tree_region, tree_column, item)
    # Open Link
    if tree_region == 'cell' and tree_column == "#1":
      values = tree.item(item)['values']
      if len(values) > 0 and values[0]:
        webbrowser.open_new_tab(values[0])  # open the link in a browser tab
    # Filter Entry
    if tree_region == 'heading' and tree_column == "#0":
      tree_offset = (tree.winfo_x(), tree.winfo_y()) # Get offset from parent 
      if len(tree.get_children()) < 1:
        return
      # print(tree.yview())
      # first_item = tree.get_children()[0]
      # column_bbox = tree.bbox(first_item, column=tree_column)
      column_bbox = next(tree.bbox(x, column=tree_column) for x in tree.all_children if tree.bbox(x, column=tree_column))
      col_width = tree.column(tree_column, 'width')
      entry_filter = tk.ttk.Entry(tree.master, width=col_width, textvariable=tree.filter) # width=column_bbox[2]
      # entry_edit.edit_column_idx = column_idx
      # entry_edit.edit_item_iid = iid
      # entry_edit.insert(0, text)
      entry_filter.select_range(0, tk.END)
      entry_filter.focus()
      entry_filter.bind("<FocusOut>", lambda e: [e.widget.destroy()])
      entry_filter.bind("<Return>", lambda e: [e.widget.destroy()])
      entry_filter.place(x=tree_offset[0] + 5, y=tree_offset[1] + column_bbox[1] - column_bbox[3] - 4, w=col_width, h=column_bbox[3] + 7) # x=tree_offset[0] + column_bbox[0], w=column_bbox[2]

  def filter_tree(self, tree):
    time_passed = (time.perf_counter_ns() // 1_000_000) - tree.filter_time.get()
    # print(time_passed)
    if time_passed > 500:
      # print(tree.filterable)
      filter = tree.filter.get()
      if filter: filter = filter.lower()
      for iid, name, parent in tree.filterable:
        # print(filter, iid, name, parent)
        if filter and filter not in name.lower():
          tree.detach(iid)
        else:
          tree.reattach(iid, parent, tk.END)


  def tree_right_click(self, event):
    tree = event.widget
    if tree.identify_region(event.x, event.y) not in ['tree', 'cell']:
      return
    item = tree.identify('item', event.x, event.y)
    if item not in tree.selection():
      tree.selection_set(item)
    # print(tree.selection())
    has_multi = True if len(tree.selection()) > 1 else False
    menu = tk.Menu(tree)
    menu.add_command(label=F"Copy Item{'s' if has_multi else ''}", command=lambda:[self.copy_tree_selection_to_clipboard(tree)])
    menu.add_separator()
    menu.add_command(label=F"Check Item{'s' if has_multi else ''}", command=lambda:[
      [tree.click_item(item, True) for item in tree.selection()] 
    ])
    menu.add_command(label=F"Uncheck Item{'s' if has_multi else ''}", command=lambda:[
      [tree.click_item(item, False) for item in tree.selection()] 
    ])
    if not has_multi and len(tree.selection()) > 0 and len(tree.item(tree.selection()[0])['values']) > 1:
      menu.add_separator()
      menu.add_command(label="Copy Link", command=lambda: [
        tree.clipboard_clear(), 
        tree.clipboard_append(tree.item(tree.selection()[0])['values'][0])
      ]), 
      menu.add_command(label="Open Link", command=lambda: [
        webbrowser.open_new_tab(tree.item(tree.selection()[0])['values'][0])
      ]), 
    menu.post(event.x_root, event.y_root)

  def copy_tree_selection_to_clipboard(self, tree):
    tree.clipboard_clear(), 
    tree.clipboard_append('\n'.join('\t'.join([item, tree.item(item)['text'].strip()] + list(tree.item(item)['values'])) for item in tree.selection())),
  
  def select_all_tree(self, tree, item=None):
    for child in tree.get_children(item):
      tree.selection_add(child)
      self.select_all_tree(tree, child)

  def process_tree(self, tree, treeview, orig_url, root=None):
    # first = True
    if root:
      tree.insert(0,{'path':'', 'type':'tree'})
    for item in tree:
      if root: item['path'] = F"{root}/{item['path']}"
      split_path = item['path'].split('/')
      # if first:
      #   parent = ''
      #   first = False
      # else: 
      parent_path = '/'.join(split_path[:-1]) # if len(split_path) > 1 else ''
      parent = '' if not split_path[-1] else parent_path
      name = split_path[-1] if split_path[-1] else root
      # print(split_path, parent, name)
      web_url = F"{orig_url}{item['path']}" # {F'{root}/' if root else ''}
      iid = treeview.insert(parent=parent, index=tk.END, iid=item['path'] if split_path[-1] else root, text=F" {name}", values=(web_url, item['url'],) if item['type'] == 'blob' else ('',), open=False if parent else True)
      treeview.all_children.append(iid)
      if item['type'] == 'blob':
        treeview.filterable.append((iid, name, parent)) # .append((iid, True))
    # self.root.update()
    
  # def process_treedict(self, treedict, parent=''):
  #   # gt.get_dir(url="https://ghe.megaleo.com/DTOE/DCDD_Tools/", recursive=True)
  #   # self.process_treedict(gt.folder_tree)
  #   for item in treedict:
  #     oid = self.treeview.insert(parent, 'end', text=F" {item}", open=False)
  #     # print(item, oid)
  #     for child in treedict[item]:
  #       if type(child) == dict:
  #         self.process_treedict(child, parent=oid)
  #       else:
  #         self.treeview.insert(oid, 'end', text=F" {child[0]}", values=child[1], open=False)

  def process_repo(self):
    if not all([self.root.vars['ad_username'].get(), self.root.vars['ad_password'].get()]):
      return
    gt = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())

    for t in self.tabs:
      gt.get_tree(url=self.tabs[t]['url'], recursive=self.tabs[t].get('recursive', True))
      if self.tabs[t].get('suffixes') or self.tabs[t].get('types'):
        current_tree = [x for x in gt.current_tree if (x['type'] in self.tabs[t]['types'] if self.tabs[t].get('types') else True) and (x['path'].endswith(self.tabs[t]['suffixes']) if self.tabs[t].get('suffixes') and x['type'] == 'blob' else True)]
      else:
        current_tree = gt.current_tree
      self.process_tree(current_tree, self.tabs[t]['treeview'], gt.base_view_url, gt.url_parts['folder'])

    # self.root.update()
    self.refresh_loading = False

  def save_selections(self):
    f = filedialog.asksaveasfile(initialfile = 'Untitled.json', defaultextension=".json", filetypes=[("JSON Documents","*.json"), ("All Files","*.*")])
    # with open(f, 'w') as save_file:
    checked_items = self.get_tab_checked()
    scrubbed = [(x["type"], x["iid"]) for x in checked_items]
    json.dump(scrubbed, f)

  def import_selections(self):
    files = filedialog.askopenfiles(defaultextension=".json", filetypes=[("JSON Documents","*.json"), ("All Files","*.*")])
    for f in files:
      items = json.load(f)
      for i in items:
        tab, iid = i
        self.tabs[tab]['treeview'].click_item(iid, True)

  def get_tab_checked(self, tabs=None):
    checked_items = []
    if not tabs:
      tabs = [x for x in self.tabs.keys()]
    for t in tabs:
      item_list = [{'type':t, **x} for x in self.tabs[t]['treeview'].get_tagged(tag_has="checked")]
      checked_items.extend(item_list)
    return checked_items

  def load_to_db(self, tabs=None):
    self.load_all_button["state"] = "disabled"
    self.cancel_load_button["state"] = "normal"
    self.loading = True
    m = MySQL(user=self.root.vars['db_username'].get(), passwd=self.root.vars['db_password'].get(), host=self.root.vars['db_host'].get(), port=self.root.vars['db_port'].get())
    gt = GitHub(username=self.root.vars['ad_username'].get(), password=self.root.vars['ad_password'].get())
    load_items = self.get_tab_checked(tabs)
    # print(load_items)
    batch = time.time()
    for li in load_items:
      self.loading_tree.insert(parent='', index=tk.END, iid=F"{batch}:{li['type']}/{li['iid']}", text=li['type'], values=(li['text'].strip(), 'Pending Load',), open=False)
    self.notebook.select(next(i for i in self.notebook.tabs() if self.notebook.tab(i, option="text") == 'Loads'))
    # Load items
    for li in load_items:
      tree_item_iid = F"{batch}:{li['type']}/{li['iid']}"
      # Load item
      self.loading_tree.set(tree_item_iid, column=2, value='Loading ...')
      try:
        if not self.loading:
          raise Exception('Cancelled')
        # 1/0
        # self.loading = False
        # Get file from GitHub
        file = gt.get_blob(li['values'][1])
        if li['type'] in ['DDLs', 'Validations', 'Standard SPs']:
          m.load_gh_sql(file)
        elif li['type'] == 'CSVs':
          m.load_gh_csv(li['text'].strip(), file, truncate=True)
      except Exception as e:
        self.loading_tree.set(tree_item_iid, column=2, value=F"Error: {e}")
        continue
      self.loading_tree.set(tree_item_iid, column=2, value='Success')
    self.load_all_button["state"] = "normal"
    self.cancel_load_button["state"] = "disabled"
  
  def cancel_load(self):
    self.loading = False



if __name__ == "__main__":
  sys.path.append(LibPath.absolute().as_posix())
  # print(sys.path)
  # from lib import GitHub, CheckboxTreeview

  root = tk.Tk()
  root.title("GitHub Loader")

  # Simply set the theme
  theme_path = "themes/Azure/themes.tcl"
  root.tk.call("source", CurrentPath.parent / theme_path)
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {
    'ad_username':tk.StringVar(value=dict_config.get('ad_username')), 
    'ad_password':tk.StringVar(value=dict_config.get('ad_password')),
    'db_username':tk.StringVar(value=dict_config.get('db_username')),
    'db_password':tk.StringVar(value=dict_config.get('db_password')),
    'db_host':tk.StringVar(value=dict_config.get('db_host')),
    'db_port':tk.StringVar(value=dict_config.get('db_port')),
  }

  app = App(root)
  app.pack(fill="both", expand=True)

  # Set a minsize for the window, and place it in the middle
  root.update()
  root.minsize(root.winfo_width(), root.winfo_height())
  x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
  y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
  root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

  root.mainloop()