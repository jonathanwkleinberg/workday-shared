# GUI
Graphical User Interface for many DAI Apps &amp; Scripts

# Distributables
Windows -> [download](/dist/DAI_Apps.exe)

Mac -> [download](/dist/DAI_Apps_MacOS)