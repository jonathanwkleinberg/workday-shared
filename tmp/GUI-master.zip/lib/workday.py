import requests
import re, json
import pathlib
import sys, csv
try:
  from .constants import data_centers
except:
  from constants import data_centers
    
class Workday(object):

  class Tenant(object):
    def __init__(self, **kwargs):
      self.name = kwargs.get('name')
      self.username = kwargs.get('username')
      self.password = kwargs.get('password')
      self.datacenter = kwargs.get('datacenter')
      self.is_customercentral = kwargs.get('is_customercentral', False)
      self.url = self.parse_url(kwargs.get('url')) if kwargs.get('url') else None
      if not self.url and all([self.name, self.datacenter]):
        self.url = self.get_url_by_dc(self.name, self.datacenter)
    def __iter__(self):
      yield from vars(self).items()
    def __str__(self):
      return str(dict(self))
    def parse_url(self, url):
      if '/' in url:
        url_parts = url.split('/')
        if 'http' not in url_parts[0]: # assume we have the domain name and path only
          url_parts = ['https:', ''] + url_parts
      else: # assume we have the domain name only
        url_parts = ['https:', '', url]
      if 'workdaysuv' in url_parts[2]:
        self.datacenter = [url_parts[2], url_parts[2], url_parts[2], 'SUV']
      else:
        self.datacenter = next(((x,) + data_centers[x] for x in data_centers if url_parts[2] in x or url_parts[2] in data_centers[x][0] or url_parts[2] in data_centers[x][1]), {url_parts[2]: (url_parts[2], url_parts[2], 'SUV')})
      url_parts[2] = self.datacenter[2]
      if not self.name:
        if url_parts[3:5] == ['wday', 'authgwy'] or url_parts[3:5] == ['ccx', 'service']:
          self.name = url_parts[5]
        elif url_parts[3:]:
          self.name = url_parts[3]
        else:
          url_parts.append(None) # add a spot for a name
          self.name = 'unknown_tenant_name'
      url_parts[3] = self.name
      if self.name == 'customercentral' or self.name.endswith('_cc'):
        self.is_customercentral = True
      return '/'.join(url_parts[:4]) + '/'
    def get_url_by_dc(self, name, dc):
      if dc in data_centers:
        return F'https://{data_centers[dc][1]}/{name}'
      else:
        return None
  
  def __init__(self, tenant=None, username=None, password=None, **kwargs):
    self.debug = kwargs.get('debug', False)
    self.tenants = []
    self.tenant_index = 0
    self.add_tenant(tenant, username, password)
    self.session = requests.Session()

  def __iter__(self):
    dict = {}
    dict['tenants'] = [vars(x) for x in self.tenants]
    yield from dict.items() # vars(self)

  def __str__(self):
    return str(dict(self))
  
  def add_tenant(self, tenant=None, username=None, password=None):
    if any([tenant,username,password]):
      if isinstance(tenant, self.Tenant):
        self.tenants.append(tenant)
      else: # assume tenant url
        self.tenants.append(self.Tenant(url=tenant, username=username, password=password))

  def add_tenant_by_dc(self, name, dc, username=None, password=None):
    self.tenants.append(self.Tenant(name=name, datacenter=dc, username=username, password=password))
  
  def current_tenant(self):
    num_tenants = len(self.tenants)
    return self.tenants[self.tenant_index] if num_tenants > 0 and self.tenant_index < num_tenants else None
  
  def tenant(self, index):
    self.tenant_index = index
    return self.current_tenant()
  
  def dict_extract_by_key(self, var, key, kv_match=None):
    if hasattr(var,'items'):
      for k, v in var.items():
        if kv_match: # sibling key-value match
          km, vm = kv_match
          if key in var and km == k and vm == v: yield var[key]
        else:
          if k == key: yield v
        if isinstance(v, dict):
          for result in self.dict_extract_by_key(v, key, kv_match): yield result
        elif isinstance(v, list):
          for d in v:
            for result in self.dict_extract_by_key(d, key, kv_match): yield result
  
  def login(self):
    tenant = self.current_tenant()
    auth_url = F'https://{tenant.datacenter[0]}/wday/authgwy/{tenant.name}/login-auth.xml'
    # if self.debug: print(F"Login URL: {auth_url}")
    r = self.session.post(auth_url, headers={'X-Workday-Client': '', 'Accept': 'application/json'}, data={'userName':tenant.username, 'password':tenant.password})
    r.raise_for_status()
    if not '"result":"SUCCESS"' in r.text or 'wul:Success' in r.text:
      if 'Invalid user name or password' in r.text:
        raise Exception('Invalid user name or password.')
      if 'The URL you have provided is invalid.' in r.text:
        raise Exception('Invalid URL (cc/tenant name).')
    if self.debug: print(F"Login Result: {r.text}")

  def ftb(self, target_tenant=None, recipe=None, tags=[], skip_steps=[]):
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    # Get Home Page
    home_url = F'{tenant.url}/home.htmld'
    # if self.debug: print(F"Home URL: {home_url}")
    r = self.session.get(home_url)
    r.raise_for_status()
    # if self.debug: print(F"FTB Result: {r.json()}")
    sessionSecureToken = r.json().get('sessionSecureToken')
    # Get Tenant Dashboard URI
    tenant_dashboard_worklet = next(self.dict_extract_by_key(r.json(), 'desktopWorklet', ('label', 'Tenant Dashboard')), None)
    if not tenant_dashboard_worklet:
      raise Exception('"Tenant Dashboard" Worklet not found.')
    tenant_dashboard_uri = tenant_dashboard_worklet['uri']
    tenant_dashboard_page = self.session.get(F'{base_url}{tenant_dashboard_uri}.htmld')
    tenant_dashboard_page.raise_for_status()
    ftb_uri = next(self.dict_extract_by_key(tenant_dashboard_page.json(), 'uri', ('label', 'Foundation Tenant Build')), None)

    ftb_page = self.session.post(F'{base_url}{ftb_uri}.htmld', data={'sessionSecureToken': sessionSecureToken})
    ftb_page.raise_for_status()
    ftb_page_result = ftb_page.json()

    # Get Target Tenant Id from Prompt

    promptUriTemplate = ftb_page_result.get('promptUriTemplate')

    flowKey = next(self.dict_extract_by_key(ftb_page_result, 'flowExecutionKey'))
    sequence_task_id = next(self.dict_extract_by_key(ftb_page_result, 'id', ("propertyName", "nyw:sequence_task")))
    sessionSecureToken = next(self.dict_extract_by_key(ftb_page_result, 'sessionSecureToken'))
    contextId = next(self.dict_extract_by_key(ftb_page_result, 'contextId', ("label", "Target Tenant")))
    eventId = next(self.dict_extract_by_key(ftb_page_result, 'id', ("contextId", contextId)))
    tenant_prompt_page = self.session.post(F"{base_url}{promptUriTemplate.replace('[CONTEXT_ID]', contextId).replace('[PROMPT_IID]',eventId)}.htmld", data={'sessionSecureToken': sessionSecureToken, '_flowExecutionKey': flowKey, '_eventId_prompt': eventId})
    target_tenant_iid = next(self.dict_extract_by_key(tenant_prompt_page.json(), 'instanceId', ('text', target_tenant)), None)
    if not target_tenant_iid:
      raise Exception(F'Target Tenant "{target_tenant}" not found.')
    
    flowController_uri = next(self.dict_extract_by_key(ftb_page_result, 'requestUri'))
    flowController_url = F'{base_url}{flowController_uri}.htmld'

    # Set Target Tenant
    set_target_tenant = self.session.post(flowController_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey, 
      '_eventId_add': eventId,
      eventId: target_tenant_iid,
      F"{target_tenant_iid}_DID": target_tenant,
      F"{target_tenant_iid}_IID": target_tenant_iid,
    })
    set_target_tenant.raise_for_status()

    # Select Recipe
    recipe_id = next(self.dict_extract_by_key(ftb_page_result, 'id', ('value', recipe)), None)
    if not recipe_id:
      raise Exception(F'Recipe "{recipe}" not found.')
    
    select_recipe = self.session.post(flowController_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey, 
      '_eventId_select': recipe_id.split('/')[0],
      'selected': '1',
    })
    select_recipe.raise_for_status()

    # Submit recipe choice and get parameter page
    parameter_page = self.session.post(flowController_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    parameter_page.raise_for_status()
    parameter_page_results = parameter_page.json()

    flowKey = next(self.dict_extract_by_key(parameter_page_results, 'flowExecutionKey'))
    sessionSecureToken = next(self.dict_extract_by_key(parameter_page_results, 'sessionSecureToken'))
    sequence_task_id = next(self.dict_extract_by_key(parameter_page_results, 'id', ("propertyName", "nyw:sequence_task")))

    # Set Tags (ignore categories)
    for tag in tags:
      tag_id = next(self.dict_extract_by_key(parameter_page_results, 'id', ('value', tag)), None)
      if not tag_id:
        raise Exception(F'Tag "{tag}" not found.')
      tag_id = F"{tag_id.split('/')[0]}/wd:Add"
      set_tag = self.session.post(flowController_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey, 
        tag_id: '1',
        '_eventId_validate': tag_id,
      })
      set_tag.raise_for_status()

    # Submit Tags and get skip steps page
    skip_steps_page = self.session.post(flowController_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    skip_steps_page.raise_for_status()
    skip_steps_results = skip_steps_page.json()

    sequence_task_id = next(self.dict_extract_by_key(skip_steps_results, 'id', ("propertyName", "nyw:sequence_task")))
    chunkingUrl = next(self.dict_extract_by_key(skip_steps_results, 'chunkingUrl', ("label", "Recipe Steps")))
    deepRowCount = next(self.dict_extract_by_key(skip_steps_results, 'deepRowCount', ("label", "Recipe Steps")))
    all_steps_url = F'{base_url}{chunkingUrl}.htmld?startRow=1&maxRows={deepRowCount}'
    all_steps_page = self.session.get(all_steps_url)
    all_steps_results = all_steps_page.json()

    # Skip Steps
    for step in skip_steps:
      # Look first in the description
      step_id = next(self.dict_extract_by_key(all_steps_results, 'id', ('value', step)), None)
      if not step_id:
        # Check the Recipe Step Type
        step_id = next((r['id'] for r in all_steps_results['rows'] if next(self.dict_extract_by_key(r, 'id', ('text', step)), None)), None)
        if not step_id: # if still not
          raise Exception(F'Step "{step}" not found.')
      skip_step = self.session.post(flowController_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey, 
        step_id: '1',
        '_eventId_skip': step_id,
      })
      skip_step.raise_for_status()

    # Submit Skip Steps and get confirmation page
    confirmation_page = self.session.post(flowController_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    confirmation_page.raise_for_status()
    confirmation_results = confirmation_page.json()

    if skip_steps:
      # Handle Skip Warnings
      final_sequence_task_id = next(self.dict_extract_by_key(confirmation_results, 'id', ("propertyName", "nyw:sequence_task")), None)
      if not final_sequence_task_id:
        # Resubmit the last sequence task id
        confirmation_page = self.session.post(flowController_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_submit': sequence_task_id,
        })
        confirmation_page.raise_for_status()
        confirmation_results = confirmation_page.json()
        final_sequence_task_id = next(self.dict_extract_by_key(confirmation_results, 'id', ("propertyName", "nyw:sequence_task")), None)
        if not final_sequence_task_id:
          raise Exception('Error submitting skip steps page (not getting final sequence task).')
        
      # Submit Final Sequence Task
      final_sequence_task = self.session.post(flowController_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_submit': final_sequence_task_id,
      })
      final_sequence_task.raise_for_status()
      confirmation_results = final_sequence_task.json()

    recipe_instance = next(self.dict_extract_by_key(confirmation_results, 'instances', ('label', 'Foundation Tenant Build')), [None])[0]
    if not recipe_instance:
      raise Exception('Recipe instance not found.')
    recipe_text = recipe_instance['text']
    recipe_iid = recipe_instance['instanceId']
    recipe_uri = next(self.dict_extract_by_key(confirmation_results, 'selfUriTemplate', ('label', 'Foundation Tenant Build')), None)
    recipe_url = F"{base_url}{recipe_uri.replace('inst', 'd/inst')}.htmld"
    return {'name': recipe_text, 'iid': recipe_iid, 'url': recipe_url}
  
  def get_ftb_status(self, recipe_url):
    recipe_url = recipe_url.replace('/d/','/') # get only JSON (if /d/ present)
    ftb_page = self.session.get(recipe_url)
    ftb_page.raise_for_status()
    ftb_page_results = ftb_page.json()
    tenant_build_status = next(self.dict_extract_by_key(ftb_page_results, 'instances', ("label", "Tenant Build Status")), [{}])[0].get('text')
    percent_complete = next(self.dict_extract_by_key(ftb_page_results, 'value', ("label", "Percent Complete")), 0)
    migration_success_rate = next(self.dict_extract_by_key(ftb_page_results, 'value', ("label", "Migration Success Rate")), 0)
    time_elapsed = next(self.dict_extract_by_key(ftb_page_results, 'value', ("label", "Time Elapsed (s)")), "00:00")
    return {'status': tenant_build_status, 'percent_complete': percent_complete, 'success_rate': migration_success_rate, 'time_elapsed': time_elapsed}
  
  def search(self, search_text, exact_match=False): # Tasks and Reports Only - Exact Match
    search_url = F'https://{self.current_tenant().datacenter[0]}/wday/pex/fs/{self.current_tenant().name}/fs/v2/init?q={search_text}'
    header = {'x_wd_client_id': 'SEARCH_CLIENT'}
    search_page = self.session.get(search_url, headers=header)
    tasks_reports_re = re.compile(R'data:(.*SearchResultSet.*workday_search:workday_tasks_and_reports.*)')
    search_result_set = tasks_reports_re.search(search_page.text)
    if search_result_set:
      search_result_set = json.loads(search_result_set.group(1))
      search_results = search_result_set['results']
      # if self.debug: print(search_results)
      if exact_match:
        task = next((x['link'] for x in search_results if x['description'] == search_text), None)
        return F'https://{self.current_tenant().datacenter[0]}{task}' if task else task
      else:
        tasks = [F'https://{self.current_tenant().datacenter[0]}{x["link"]}' for x in search_results]
        return tasks if tasks else None
    else:
      return None
    
  def get_all_tenant_build_view_urls(self):
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    # tenant_builds_url = self.search('View All Tenant Builds', True)
    # tenant_builds_url = tenant_builds_url.replace('/d/','/') if tenant_builds_url else None
    tenant_builds_url = F'{tenant.url}/task/2998$32953.htmld'
    tenant_builds_page = self.session.get(tenant_builds_url)
    tenant_builds_page.raise_for_status()
    tenant_builds_results = tenant_builds_page.json()
    chunkingUrl = next(self.dict_extract_by_key(tenant_builds_results, 'chunkingUrl', ("widget", "grid")))
    deepRowCount = next(self.dict_extract_by_key(tenant_builds_results, 'deepRowCount', ("widget", "grid")))
    if self.debug: print(F"Row/Build Count: {deepRowCount}")
    all_builds_url = F'{base_url}{chunkingUrl}.htmld?startRow=1&maxRows={deepRowCount}'
    all_builds_page = self.session.get(all_builds_url)
    all_builds_results = all_builds_page.json()
    build_urls = [F'{base_url}{x}.htmld' for x in self.dict_extract_by_key(all_builds_results, 'uri', ('label', 'View'))]
    return build_urls
  
  def excel_export_tenant_build(self, url, folder):
    folder = pathlib.Path(folder)
    if not folder.exists():
      folder.mkdir(parents=True)
    
    view_tenant_build_page = self.session.get(url)
    view_tenant_build_page.raise_for_status()
    view_tenant_build_results = view_tenant_build_page.json()
    # https://i-015e837da08c049c5.workdaysuv.com/customercentral/export/c22.xlsx?page-title=Country+FIN%40wdsetup+-%3E+higheredfin&clientRequestID=4a45bfd00f8b496db04b17887cf5113a
    export_uri = next(self.dict_extract_by_key(view_tenant_build_results, 'uri', ("type", "EXPORT_EXCEL")), None)
    page_title = next(self.dict_extract_by_key(view_tenant_build_results, "value", ("key", "page-title")), None)
    export_uri = F'https://{self.current_tenant().datacenter[0]}{export_uri}?page-title={page_title}' if export_uri else None
    if self.debug: 
      print(F"Exporting: {page_title}")
      print(F"Export URI: {export_uri}")
    # {"docReadyUri":"/customercentral/doc-ready/2key.xlsx?docName=View_Tenant_Build.xlsx&instance-id=2998%2433830","widget":"backgroundProcessResponse"}
    doc_ready_page = self.session.get(export_uri)
    doc_ready_page.raise_for_status()
    doc_ready_results = doc_ready_page.json()
    doc_ready_uri = doc_ready_results['docReadyUri']
    file_name = re.search(R'docName=(.*?)&', doc_ready_uri).group(1)
    doc = self.session.get(F'https://{self.current_tenant().datacenter[0]}{doc_ready_uri}')
    (folder / F'{file_name}').write_bytes(doc.content)

  def get_legacy_impl_file(self, path=None):
    if not path:
      raise Exception('No path provided.')
    config = {}
    with open(path, newline='', encoding='utf-8-sig') as csvfile:
      implreader = csv.reader(csvfile)
      config['tenant_info'] = [x.strip() for x in next(implreader)]
      config['data_center'] = config['tenant_info'][config['tenant_info'].index('Data Center:')+1].strip()
      if config['data_center'] in data_centers:
        config['suv_url'] = None
      else:
        config['suv_url'] = config['data_center']
      config['cc_sec_admin'] = config['tenant_info'][config['tenant_info'].index('CC Sec Admin:')+1].strip()
      config['cc_sec_admin_pass'] = config['tenant_info'][config['tenant_info'].index('CC Sec Admin:')+2].strip()
      config['cc_admin'] = config['tenant_info'][config['tenant_info'].index('CC Admin:')+1].strip()
      config['cc_admin_pass'] = config['tenant_info'][config['tenant_info'].index('CC Admin:')+2].strip()
      config['tenant_user'] = config['tenant_info'][config['tenant_info'].index('Tenant User:')+1].strip()
      config['tenant_user_pass'] = config['tenant_info'][config['tenant_info'].index('Tenant User:')+2].strip()
      config['cc_name'] = config['tenant_info'][config['tenant_info'].index('Tenants:')+1].strip()
      config['tenants'] = [t.strip() for t in config['tenant_info'][config['tenant_info'].index('Tenants:')+2:] if t.strip()]
      config['headers'] = [x.strip() for x in next(implreader)]
      config['implementers'] = []
      for i in implreader:
        # Check for required fields (First, Last, Username, Password)
        impl = dict(zip(config['headers'], i))
        if impl['First Name'].strip() and impl['Last Name'].strip() and impl['Username'].strip() and impl['Password'].strip():
          config['implementers'].append(i)
        else:
          print(F"Missing required field (First, Last, Username, Password) in this row:\n{impl}\nSkipping.\n", file=sys.stderr)
    return config
  
  def get_proposed_security_admins(self, config_dict):
    return [i for i in config_dict['implementers'] if i[config_dict['headers'].index('Security Admin')].lower().strip() in ('true','yes','y','1','x')]
  
  def get_proposed_cc_admins(self, config_dict):
    return [i for i in config_dict['implementers'] if i[config_dict['headers'].index('CC Admin')].lower().strip() in ('true','yes','y','1','x')]
  
  def get_proposed_vcr_managers(self, config_dict):
    return [i for i in config_dict['implementers'] if i[config_dict['headers'].index('VCR Manager')].lower().strip() in ('true','yes','y','1','x')]
  
  def get_proposed_cc_users(self, config_dict):
    return [i for i in config_dict['implementers'] if i[config_dict['headers'].index('CC')].lower().strip() in ('true','yes','y','1','x') and i[config_dict['headers'].index('CC Admin')].lower().strip() not in ('true','yes','y','1','x')]

  def get_tenant_implementers(self):
    # implementers_url = self.search('View Implementers', True)
    implementers_url = F"{self.current_tenant().url}task/2997$1593.htmld"
    implementers_page = self.session.get(implementers_url) # .replace('/d/','/'))
    implementers_page.raise_for_status()
    implementers_results = implementers_page.json()
    implementers = [x.get('text', '').split(' / ') for x in next(self.dict_extract_by_key(implementers_results, 'instances', ("label", "System Users")), [])]
    return implementers
  
  def create_tenant_implementer(self, username, password, first_name, last_name, middle_name=None, implementer=True, vcr=True, req_new_pass=True, timeout="240"):
    flow_url = F"{self.current_tenant().url}flowController.htmld"
    # Create Implementer
    tenant_impl_url = F"{self.current_tenant().url}task/2997$308.htmld"
    tenant_impl_page = self.session.get(tenant_impl_url)
    tenant_impl_page.raise_for_status()
    tenant_impl_results = tenant_impl_page.json()
    flowKey = next(self.dict_extract_by_key(tenant_impl_results, 'flowExecutionKey'))
    sequence_task_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ("propertyName", "nyw:sequence_task")))
    sessionSecureToken = next(self.dict_extract_by_key(tenant_impl_results, 'sessionSecureToken'))
    country_instance = next(self.dict_extract_by_key(tenant_impl_results, 'instances', ('label', 'Country')), [None])[0]
    # if country_instance and not country_instance.get('text') == 'United States of America':
    if True:
      country_context_id = next(self.dict_extract_by_key(tenant_impl_results, 'contextId', ('label', 'Country')))
      country_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'Country')))
      current_country_instance = country_instance.get('instanceId')
      # Remove Current Country
      remove_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_remove': country_id,
        country_id: current_country_instance,
      })
      # Find Country
      prompt_url = F"{self.current_tenant().url}prompt/{country_context_id}/{country_id}.htmld"
      prompt_response = self.session.post(prompt_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_prompt': country_context_id,
        'q': 'United States of America',
      })
      prompt_response.raise_for_status()
      usa_country_instance = next(self.dict_extract_by_key(prompt_response.json(), 'instanceId'))
      # Set Country
      set_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_add': country_id,
        country_id: usa_country_instance,
        F"{usa_country_instance}_DID": 'United States of America',
        F"{usa_country_instance}_IID": usa_country_instance,
        F"{usa_country_instance}_V": '1',
      })
      set_country_response.raise_for_status()
      set_country_name_fields = set_country_response.json()
      flowKey = next(self.dict_extract_by_key(set_country_name_fields, 'flowKey'))
      # Set First Name
      first_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'First Name')), [None])[0]
      first_name_id = first_name_values.get('id')
      first_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': first_name_id,
        first_name_id: first_name,
      })
      first_name_response.raise_for_status()
      # Set Middle Name
      if middle_name:
        middle_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Middle Name')), [None])[0]
        middle_name_id = middle_name_values.get('id')
        middle_name_response = self.session.post(flow_url, data={
          'sessionSecureToken': sessionSecureToken,
          '_flowExecutionKey': flowKey,
          '_eventId_validate': middle_name_id,
          middle_name_id: middle_name,
        })
        middle_name_response.raise_for_status()
      # Set Last Name
      last_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Last Name')), [None])[0]
      last_name_id = last_name_values.get('id')
      last_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': last_name_id,
        last_name_id: last_name,
      })
      last_name_response.raise_for_status()
    # Check VCR
    restrict_vcr_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'Subject Implementer to VCR Restriction')))
    restrict_vcr_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': restrict_vcr_id,
      restrict_vcr_id: '1' if vcr else '0',
    })
    restrict_vcr_response.raise_for_status()
    # print(restrict_vcr_response.text)
    # Set Username
    username_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'User Name')), [None])
    username_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': username_id,
      username_id: username,
    })
    username_response.raise_for_status()
    username_response_results = username_response.json()
    error_message = next(self.dict_extract_by_key(username_response_results, 'message', ("widget", "error")), None)
    if error_message:
      raise Exception(F"User Name Error: {error_message}")
    # Check Require New Password
    req_new_pass_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'Require New Password at Next Sign In')))
    req_new_pass_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': req_new_pass_id,
      req_new_pass_id: '1' if req_new_pass else '0',
    })
    req_new_pass_response.raise_for_status()
    # Set Timeout
    timeout_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'Session Timeout Minutes')))
    timeout_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': timeout_id,
      timeout_id: timeout,
    })
    timeout_response.raise_for_status()
    # Set Password
    password_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'New Password')))
    password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': password_id,
      password_id: password,
    })
    password_response.raise_for_status()
    # Set Password Verify
    new_password_verify_id = next(self.dict_extract_by_key(tenant_impl_results, 'id', ('label', 'New Password Verify')))
    new_password_verify_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': new_password_verify_id,
      new_password_verify_id: password,
    })
    new_password_verify_response.raise_for_status()
    # Submit
    submit_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_response.raise_for_status()
    submit_response_results = submit_response.json()
    # Check for errors
    error_messages = list(self.dict_extract_by_key(submit_response_results, 'message', ("widget", "error")))
    if error_messages:
      raise Exception(F"Submit Error: {' '.join(error_messages)}")
    name_value = next(self.dict_extract_by_key(submit_response_results, 'value', ("key", "page-title")), None)
    return name_value
  
  def get_cc_security_admins(self):
    # cc_security_admins_url = self.search('Maintain Security Administrators', True)
    cc_security_admins_url = F"{self.current_tenant().url}task/2997$11465.htmld"
    cc_security_admins_page = self.session.get(cc_security_admins_url)
    cc_security_admins_page.raise_for_status()
    cc_security_admins_results = cc_security_admins_page.json()
    cc_security_admins = [x.get('text', '').split(' / ') for x in next(self.dict_extract_by_key(cc_security_admins_results, 'instances', ("label", "System Users")), [])]
    return cc_security_admins
  
  def create_cc_security_admin(self, username, password, first_name, last_name, middle_name=None, implementer=False, vcr=False, req_new_pass=True, timeout="240"):
    # Should never be an implementer or VCR restricted, but options are there
    flow_url = F"{self.current_tenant().url}flowController.htmld"
    # Create Customer Central Security Administrator
    cc_sec_admin_url = F"{self.current_tenant().url}task/2997$11321.htmld"
    cc_sec_admin_page = self.session.get(cc_sec_admin_url)
    cc_sec_admin_page.raise_for_status()
    cc_sec_admin_results = cc_sec_admin_page.json()
    flowKey = next(self.dict_extract_by_key(cc_sec_admin_results, 'flowExecutionKey'))
    sequence_task_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ("propertyName", "nyw:sequence_task")))
    sessionSecureToken = next(self.dict_extract_by_key(cc_sec_admin_results, 'sessionSecureToken'))
    country_instance = next(self.dict_extract_by_key(cc_sec_admin_results, 'instances', ('label', 'Country')), [None])[0]
    # if country_instance and not country_instance.get('text') == 'United States of America':
    if True: # Always set to USA regardless of current country
      country_context_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'contextId', ('label', 'Country')))
      country_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'Country')))
      current_country_instance = country_instance.get('instanceId')
      # Remove Current Country
      remove_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_remove': country_id,
        country_id: current_country_instance,
      })
      # Find Country
      prompt_url = F"{self.current_tenant().url}prompt/{country_context_id}/{country_id}.htmld"
      prompt_response = self.session.post(prompt_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_prompt': country_context_id,
        'q': 'United States of America',
      })
      prompt_response.raise_for_status()
      usa_country_instance = next(self.dict_extract_by_key(prompt_response.json(), 'instanceId'))
      # Set Country
      set_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_add': country_id,
        country_id: usa_country_instance,
        F"{usa_country_instance}_DID": 'United States of America',
        F"{usa_country_instance}_IID": usa_country_instance,
        F"{usa_country_instance}_V": '1',
      })
      set_country_response.raise_for_status()
      set_country_name_fields = set_country_response.json()
      flowKey = next(self.dict_extract_by_key(set_country_name_fields, 'flowKey'))
      # Set First Name
      first_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'First Name')), [None])[0]
      first_name_id = first_name_values.get('id')
      first_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': first_name_id,
        first_name_id: first_name,
      })
      first_name_response.raise_for_status()
      # Set Middle Name
      if middle_name:
        middle_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Middle Name')), [None])[0]
        middle_name_id = middle_name_values.get('id')
        middle_name_response = self.session.post(flow_url, data={
          'sessionSecureToken': sessionSecureToken,
          '_flowExecutionKey': flowKey,
          '_eventId_validate': middle_name_id,
          middle_name_id: middle_name,
        })
        middle_name_response.raise_for_status()
      # Set Last Name
      last_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Last Name')), [None])[0]
      last_name_id = last_name_values.get('id')
      last_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': last_name_id,
        last_name_id: last_name,
      })
      last_name_response.raise_for_status()
    # Check Implementer
    is_impl_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'Is this user a Workday certified implementer?')))
    is_impl_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': is_impl_id,
      is_impl_id: '1' if implementer else '0',
    })
    is_impl_response.raise_for_status()
    # Check VCR
    restrict_vcr_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'Subject User to VCR Restriction')))
    restrict_vcr_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': restrict_vcr_id,
      restrict_vcr_id: '1' if vcr else '0',
    })
    restrict_vcr_response.raise_for_status()
    # Set Username
    username_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'User Name')))
    username_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': username_id,
      username_id: username,
    })
    username_response.raise_for_status()
    username_response_results = username_response.json()
    error_message = next(self.dict_extract_by_key(username_response_results, 'message', ("widget", "error")), None)
    if error_message:
      raise Exception(F"User Name Error: {error_message}")
    # Set Require New Password at Next Sign In
    require_new_password_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'Require New Password at Next Sign In')))
    require_new_password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': require_new_password_id,
      require_new_password_id: '1' if req_new_pass else '0',
    })
    require_new_password_response.raise_for_status()
    # Set Session Timeout
    session_timeout_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'Session Timeout Minutes')))
    session_timeout_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': session_timeout_id,
      session_timeout_id: timeout,
    })
    session_timeout_response.raise_for_status()
    # Set Password
    password_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'New Password')))
    password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': password_id,
      password_id: password,
    })
    password_response.raise_for_status()
    # New Password Verify
    new_password_verify_id = next(self.dict_extract_by_key(cc_sec_admin_results, 'id', ('label', 'New Password Verify')))
    new_password_verify_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': new_password_verify_id,
      new_password_verify_id: password,
    })
    new_password_verify_response.raise_for_status()
    # Submit
    submit_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_response.raise_for_status()
    submit_response_results = submit_response.json()
    # Check for errors
    error_messages = list(self.dict_extract_by_key(submit_response_results, 'message', ("widget", "error")))
    if error_messages:
      raise Exception(F"Submit Error: {' '.join(error_messages)}")
    name_value = next(self.dict_extract_by_key(submit_response_results, 'value', ("key", "page-title")), None)
    return name_value
  
  def get_cc_admins(self):
    # cc_admins_url = self.search('Maintain Customer Central Administrators', True)
    cc_admins_url = F"{self.current_tenant().url}task/2997$11448.htmld"
    cc_admins_page = self.session.get(cc_admins_url)
    cc_admins_page.raise_for_status()
    cc_admins_results = cc_admins_page.json()
    cc_admins = [x.get('text', '').split(' / ') for x in next(self.dict_extract_by_key(cc_admins_results, 'instances', ("label", "System Users")), [])]
    return cc_admins
  
  def create_cc_admin(self, username, password, first_name, last_name, middle_name=None, implementer=True, vcr=False, req_new_pass=True, timeout="240"):
    # Should be an implementer, but not VCR restricted, but options are there
    flow_url = F"{self.current_tenant().url}flowController.htmld"
    # Create Customer Central Administrator
    cc_admin_url = F"{self.current_tenant().url}task/2997$11320.htmld"
    cc_admin_page = self.session.get(cc_admin_url)
    cc_admin_page.raise_for_status()
    cc_admin_results = cc_admin_page.json()
    flowKey = next(self.dict_extract_by_key(cc_admin_results, 'flowExecutionKey'))
    sequence_task_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ("propertyName", "nyw:sequence_task")))
    sessionSecureToken = next(self.dict_extract_by_key(cc_admin_results, 'sessionSecureToken'))
    country_instance = next(self.dict_extract_by_key(cc_admin_results, 'instances', ('label', 'Country')), [None])[0]
    # if country_instance and not country_instance.get('text') == 'United States of America':
    if True:
      country_context_id = next(self.dict_extract_by_key(cc_admin_results, 'contextId', ('label', 'Country')))
      country_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'Country')))
      current_country_instance = country_instance.get('instanceId')
      # Remove Current Country
      remove_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_remove': country_id,
        country_id: current_country_instance,
      })
      # Find Country
      prompt_url = F"{self.current_tenant().url}prompt/{country_context_id}/{country_id}.htmld"
      prompt_response = self.session.post(prompt_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_prompt': country_context_id,
        'q': 'United States of America',
      })
      prompt_response.raise_for_status()
      usa_country_instance = next(self.dict_extract_by_key(prompt_response.json(), 'instanceId'))
      # Set Country
      set_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_add': country_id,
        country_id: usa_country_instance,
        F"{usa_country_instance}_DID": 'United States of America',
        F"{usa_country_instance}_IID": usa_country_instance,
        F"{usa_country_instance}_V": '1',
      })
      set_country_response.raise_for_status()
      set_country_name_fields = set_country_response.json()
      flowKey = next(self.dict_extract_by_key(set_country_name_fields, 'flowKey'))
      # Set First Name
      first_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'First Name')), [None])[0]
      first_name_id = first_name_values.get('id')
      first_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': first_name_id,
        first_name_id: first_name,
      })
      first_name_response.raise_for_status()
      # Set Middle Name
      if middle_name:
        middle_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Middle Name')), [None])[0]
        middle_name_id = middle_name_values.get('id')
        middle_name_response = self.session.post(flow_url, data={
          'sessionSecureToken': sessionSecureToken,
          '_flowExecutionKey': flowKey,
          '_eventId_validate': middle_name_id,
          middle_name_id: middle_name,
        })
        middle_name_response.raise_for_status()
      # Set Last Name
      last_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Last Name')), [None])[0]
      last_name_id = last_name_values.get('id')
      last_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': last_name_id,
        last_name_id: last_name,
      })
      last_name_response.raise_for_status()
    # Check Implementer
    is_impl_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'Is this user a Workday certified implementer?')))
    is_impl_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': is_impl_id,
      is_impl_id: '1' if implementer else '0',
    })
    is_impl_response.raise_for_status()
    # Check VCR
    restrict_vcr_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'Subject User to VCR Restriction')))
    restrict_vcr_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': restrict_vcr_id,
      restrict_vcr_id: '1' if vcr else '0',
    })
    restrict_vcr_response.raise_for_status()
    # Set Username
    username_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'User Name')))
    username_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': username_id,
      username_id: username,
    })
    username_response.raise_for_status()
    username_response_results = username_response.json()
    error_message = next(self.dict_extract_by_key(username_response_results, 'message', ("widget", "error")), None)
    if error_message:
      raise Exception(F"User Name Error: {error_message}")
    # Set Require New Password at Next Sign In
    require_new_password_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'Require New Password at Next Sign In')))
    require_new_password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': require_new_password_id,
      require_new_password_id: '1' if req_new_pass else '0',
    })
    require_new_password_response.raise_for_status()
    # Set Session Timeout
    session_timeout_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'Session Timeout Minutes')))
    session_timeout_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': session_timeout_id,
      session_timeout_id: timeout,
    })
    session_timeout_response.raise_for_status()
    # Set Password
    password_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'New Password')))
    password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': password_id,
      password_id: password,
    })
    password_response.raise_for_status()
    # New Password Verify
    new_password_verify_id = next(self.dict_extract_by_key(cc_admin_results, 'id', ('label', 'New Password Verify')))
    new_password_verify_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': new_password_verify_id,
      new_password_verify_id: password,
    })
    new_password_verify_response.raise_for_status()
    # Submit
    submit_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_response.raise_for_status()
    submit_response_results = submit_response.json()
    # Check for errors
    error_messages = list(self.dict_extract_by_key(submit_response_results, 'message', ("widget", "error")))
    if error_messages:
      raise Exception(F"Submit Error: {' '.join(error_messages)}")
    name_value = next(self.dict_extract_by_key(submit_response_results, 'value', ("key", "page-title")), None)
    return name_value
  
  def get_vcr_managers(self):
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    # vcr_managers_url = self.search('Maintain Customer Central VCR Managers', True)
    vcr_managers_url = F"{tenant.url}task/2997$12048.htmld"
    vcr_managers_page = self.session.get(vcr_managers_url)
    vcr_managers_page.raise_for_status()
    vcr_managers_results = vcr_managers_page.json()
    chunkingUrl = next(self.dict_extract_by_key(vcr_managers_results, 'chunkingUrl', ("widget", "chunkedEditGrid")))
    deepRowCount = next(self.dict_extract_by_key(vcr_managers_results, 'deepRowCount', ("widget", "chunkedEditGrid")))
    all_vcr_managers_url = F'{base_url}{chunkingUrl}.htmld?startRow=1&maxRows={deepRowCount}'
    all_vcr_managers_page = self.session.get(all_vcr_managers_url)
    all_vcr_managers_page.raise_for_status()
    all_vcr_managers_results = all_vcr_managers_page.json()
    all_vcr_managers = [next(self.dict_extract_by_key(r, 'text'), '').split(' / ') for r in all_vcr_managers_results['rows'] if r.get('selected')]
    # all_vcr_managers = [x[0].get('text', '').split(' / ') for x in self.dict_extract_by_key(all_vcr_managers_results, 'instances', ("label", "Customer Central VCR Restriction Manager"))]
    return all_vcr_managers
  
  def set_vcr_manager(self, usernames):
    if type(usernames) is not list:
      usernames = [usernames]
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    flow_url = F"{tenant.url}flowController.htmld"
    # vcr_managers_url = self.search('Maintain Customer Central VCR Managers', True)
    vcr_managers_url = F"{tenant.url}task/2997$12048.htmld"
    vcr_managers_page = self.session.get(vcr_managers_url)
    vcr_managers_page.raise_for_status()
    vcr_managers_results = vcr_managers_page.json()
    flowKey = next(self.dict_extract_by_key(vcr_managers_results, 'flowExecutionKey'))
    secureToken = next(self.dict_extract_by_key(vcr_managers_results, 'sessionSecureToken'))
    sequence_task_id = next(self.dict_extract_by_key(vcr_managers_results, 'id', ("propertyName", "nyw:sequence_task")))
    chunkingUrl = next(self.dict_extract_by_key(vcr_managers_results, 'chunkingUrl', ("widget", "chunkedEditGrid")))
    deepRowCount = next(self.dict_extract_by_key(vcr_managers_results, 'deepRowCount', ("widget", "chunkedEditGrid")))
    all_vcr_managers_url = F'{base_url}{chunkingUrl}.htmld?startRow=1&maxRows={deepRowCount}'
    all_vcr_managers_page = self.session.get(all_vcr_managers_url)
    all_vcr_managers_results = all_vcr_managers_page.json()
    # Get ID of usernames
    all_vcr_manager_usernames = {next(self.dict_extract_by_key(r, 'text'), '').split(' / ')[0]:r.get('id') for r in all_vcr_managers_results['rows']}
    for username in usernames:
      if username in all_vcr_manager_usernames:
        select_response = self.session.post(flow_url, data={
          'sessionSecureToken': secureToken,
          '_flowExecutionKey': flowKey,
          '_eventId_select': all_vcr_manager_usernames[username],
          'selected': '1',
        })
        select_response.raise_for_status()
    submit_response = self.session.post(flow_url, data={
      'sessionSecureToken': secureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_response.raise_for_status()
    submit_response_results = submit_response.json()
    flowKey = next(self.dict_extract_by_key(submit_response_results, 'flowExecutionKey'))
    secureToken = next(self.dict_extract_by_key(submit_response_results, 'sessionSecureToken'))
    sequence_task_id = next(self.dict_extract_by_key(submit_response_results, 'id', ("propertyName", "nyw:sequence_task")))
    submit_final_response = self.session.post(flow_url, data={
      'sessionSecureToken': secureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_final_response.raise_for_status()
    return next(self.dict_extract_by_key(submit_final_response.json(), 'text', ("widget", "note")))

  def get_tenant_vcr_managers(self):
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    # tenant_vcr_managers_url = self.search('Maintain VCR Restriction Managers', True)
    tenant_vcr_managers_url = F"{tenant.url}task/2997$11334.htmld"
    tenant_vcr_managers_page = self.session.get(tenant_vcr_managers_url)
    tenant_vcr_managers_page.raise_for_status()
    tenant_vcr_managers_results = tenant_vcr_managers_page.json()
    tenant_vcr_managers = [x.get('text', '').split(' / ') for x in next(self.dict_extract_by_key(tenant_vcr_managers_results, 'instances', ("label", "VCR Restriction Manager")), [])]
    return tenant_vcr_managers
  
  def set_tenant_vcr_manager(self, usernames):
    if type(usernames) is not list:
      usernames = [usernames]
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    flow_url = F"{tenant.url}flowController.htmld"
    # tenant_vcr_managers_url = self.search('Maintain VCR Restriction Managers', True)
    tenant_vcr_managers_url = F"{tenant.url}task/2997$11334.htmld"
    tenant_vcr_managers_page = self.session.get(tenant_vcr_managers_url)
    tenant_vcr_managers_page.raise_for_status()
    tenant_vcr_managers_results = tenant_vcr_managers_page.json()
    flowKey = next(self.dict_extract_by_key(tenant_vcr_managers_results, 'flowExecutionKey'))
    secureToken = next(self.dict_extract_by_key(tenant_vcr_managers_results, 'sessionSecureToken'))
    sequence_task_id = next(self.dict_extract_by_key(tenant_vcr_managers_results, 'id', ("propertyName", "nyw:sequence_task")))
    vcr_context_id = next(self.dict_extract_by_key(tenant_vcr_managers_results, 'contextId', ('label', 'VCR Restriction Manager')))
    vcr_id = next(self.dict_extract_by_key(tenant_vcr_managers_results, 'id', ('label', 'VCR Restriction Manager')))
    prompt_url = F"{self.current_tenant().url}prompt/{vcr_context_id}/{vcr_id}.htmld"
    for user in usernames:
      prompt_response = self.session.post(prompt_url, data={
        'sessionSecureToken': secureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_prompt': vcr_id,
        'q': user,
      })
      prompt_response.raise_for_status()
      prompt_results = prompt_response.json()
      user_instance = next(self.dict_extract_by_key(prompt_results, 'instanceId'))
      user_text = next(self.dict_extract_by_key(prompt_results, 'text'))
      # Set User
      set_user_response = self.session.post(flow_url, data={
        'sessionSecureToken': secureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_add': vcr_id,
        vcr_id: user_instance,
        F"{user_instance}_DID": user_text,
        F"{user_instance}_IID": user_instance,
        F"{user_instance}_V": '1',
        F"{user_instance}_PV": '1',
      })
      set_user_response.raise_for_status()
    submit_response = self.session.post(flow_url, data={
      'sessionSecureToken': secureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_response.raise_for_status()
    # submit_response_results = submit_response.json()
    return submit_response.text
  
  def get_cc_users(self):
    tenant = self.current_tenant()
    base_url = F'https://{tenant.datacenter[0]}'
    # cc_users_url = self.search('Maintain Customer Central Users', True)
    cc_users_url = F"{tenant.url}task/2997$11431.htmld"
    cc_users_page = self.session.get(cc_users_url)
    cc_users_page.raise_for_status()
    # print(cc_users_page.text)
    cc_users_results = cc_users_page.json()
    cc_users = [x.get('text', '').split(' / ') for x in next(self.dict_extract_by_key(cc_users_results, 'instances', ("label", "System Users")), [])]
    return cc_users
  
  def create_cc_user(self, username, password, first_name, last_name, middle_name=None, implementer=True, vcr=True, req_new_pass=True, timeout="240"):
    # Should always be an implementer and usually VCR restricted, but options are there
    flow_url = F"{self.current_tenant().url}flowController.htmld"
    # Create Customer Central User
    cc_user_url = F"{self.current_tenant().url}task/2997$11322.htmld"
    cc_user_page = self.session.get(cc_user_url)
    cc_user_page.raise_for_status()
    # print(cc_user_page.text)
    cc_user_results = cc_user_page.json()
    flowKey = next(self.dict_extract_by_key(cc_user_results, 'flowExecutionKey'))
    sequence_task_id = next(self.dict_extract_by_key(cc_user_results, 'id', ("propertyName", "nyw:sequence_task")))
    sessionSecureToken = next(self.dict_extract_by_key(cc_user_results, 'sessionSecureToken'))
    country_instance = next(self.dict_extract_by_key(cc_user_results, 'instances', ('label', 'Country')), [None])[0]
    # if country_instance and not country_instance.get('text') == 'United States of America':
    if True:
      country_context_id = next(self.dict_extract_by_key(cc_user_results, 'contextId', ('label', 'Country')))
      country_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'Country')))
      current_country_instance = country_instance.get('instanceId')
      # Remove Current Country
      remove_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_remove': country_id,
        country_id: current_country_instance,
      })
      # Find Country
      prompt_url = F"{self.current_tenant().url}prompt/{country_context_id}/{country_id}.htmld"
      prompt_response = self.session.post(prompt_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_prompt': country_context_id,
        'q': 'United States of America',
      })
      prompt_response.raise_for_status()
      usa_country_instance = next(self.dict_extract_by_key(prompt_response.json(), 'instanceId'))
      # Set Country
      set_country_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_add': country_id,
        country_id: usa_country_instance,
        F"{usa_country_instance}_DID": 'United States of America',
        F"{usa_country_instance}_IID": usa_country_instance,
        F"{usa_country_instance}_V": '1',
      })
      set_country_response.raise_for_status()
      set_country_name_fields = set_country_response.json()
      flowKey = next(self.dict_extract_by_key(set_country_name_fields, 'flowKey'))
      # Set First Name
      first_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'First Name')), [None])[0]
      first_name_id = first_name_values.get('id')
      first_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': first_name_id,
        first_name_id: first_name,
      })
      first_name_response.raise_for_status()
      # Set Middle Name
      if middle_name:
        middle_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Middle Name')), [None])[0]
        middle_name_id = middle_name_values.get('id')
        middle_name_response = self.session.post(flow_url, data={
          'sessionSecureToken': sessionSecureToken,
          '_flowExecutionKey': flowKey,
          '_eventId_validate': middle_name_id,
          middle_name_id: middle_name,
        })
        middle_name_response.raise_for_status()
      # Set Last Name
      last_name_values = next(self.dict_extract_by_key(set_country_name_fields, 'values', ('label', 'Last Name')), [None])[0]
      last_name_id = last_name_values.get('id')
      last_name_response = self.session.post(flow_url, data={
        'sessionSecureToken': sessionSecureToken,
        '_flowExecutionKey': flowKey,
        '_eventId_validate': last_name_id,
        last_name_id: last_name,
      })
      last_name_response.raise_for_status()
    # Check Implementer
    is_impl_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'Is this user a Workday certified implementer?')))
    is_impl_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': is_impl_id,
      is_impl_id: '1' if implementer else '0',
    })
    is_impl_response.raise_for_status()
    # Check VCR
    restrict_vcr_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'Subject User to VCR Restriction')))
    restrict_vcr_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': restrict_vcr_id,
      restrict_vcr_id: '1' if vcr else '0',
    })
    restrict_vcr_response.raise_for_status()
    # Set Username
    username_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'User Name')))
    username_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': username_id,
      username_id: username,
    })
    username_response.raise_for_status()
    username_response_results = username_response.json()
    error_message = next(self.dict_extract_by_key(username_response_results, 'message', ("widget", "error")), None)
    if error_message:
      raise Exception(F"User Name Error: {error_message}")
    # Set Require New Password at Next Sign In
    require_new_password_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'Require New Password at Next Sign In')))
    require_new_password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': require_new_password_id,
      require_new_password_id: '1' if req_new_pass else '0',
    })
    require_new_password_response.raise_for_status()
    # Set Session Timeout
    session_timeout_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'Session Timeout Minutes')))
    session_timeout_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': session_timeout_id,
      session_timeout_id: timeout,
    })
    session_timeout_response.raise_for_status()
    # Set Password
    password_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'New Password')))
    password_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': password_id,
      password_id: password,
    })
    password_response.raise_for_status()
    # New Password Verify
    new_password_verify_id = next(self.dict_extract_by_key(cc_user_results, 'id', ('label', 'New Password Verify')))
    new_password_verify_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_validate': new_password_verify_id,
      new_password_verify_id: password,
    })
    new_password_verify_response.raise_for_status()
    # Submit
    submit_response = self.session.post(flow_url, data={
      'sessionSecureToken': sessionSecureToken,
      '_flowExecutionKey': flowKey,
      '_eventId_submit': sequence_task_id,
    })
    submit_response.raise_for_status()
    submit_response_results = submit_response.json()
    # Check for errors
    error_messages = list(self.dict_extract_by_key(submit_response_results, 'message', ("widget", "error")))
    if error_messages:
      raise Exception(F"Submit Error: {' '.join(error_messages)}")
    name_value = next(self.dict_extract_by_key(submit_response_results, 'value', ("key", "page-title")), None)
    return name_value


if __name__ == "__main__":
  # base_url = 'https://n-ibhnk1o3ckup6dge2fidi.workdaysuv.com'
  # cc = 'customercentral'
  # tenant = 'vacant'
  # cc_sec = 'ccs'
  # cc_admin = 'cca'
  # user = 'ccu'
  # password = 'Lq+8JoXYzDUnrd67'
  # w = Workday(debug=False) 
  # w.add_tenant(F'{base_url}/{cc}/', cc_admin, password) # Index 0
  # w.add_tenant(F'{base_url}/{tenant}/', user, password) # Index 1
  # w.add_tenant(F'{base_url}/{cc}/', cc_sec, password) # Index 2
  # w.add_tenant(F'{base_url}/{cc}/', "wd-tenantowner", password) # Index 3
  # w.add_tenant(F'{base_url}/{tenant}/', tenant, password) # Index 5
  # print(w)

  # print(w.current_tenant())
  # w.login()

  # --- Tenant Recipes ---

  # ** Get Tenant Builds **
  # w.tenant_index = 0 # Use CC
  # w.login()
  # tenant_build_urls = w.get_all_tenant_build_view_urls()
  # print(tenant_build_urls)
  # for build_url in tenant_build_urls:
  #   print(build_url)
  #   w.excel_export_tenant_build(build_url, R'C:\Users\andy.parker\Downloads\tenant_builds')

  # ** Task Search **
  # task_searches = ['Create Customer Central User', 'Create Implementer', 'View All Tenant Builds']
  # for search_text in task_searches:
  #   task = w.search(search_text, True)
  #   print(F"Task ({search_text}): {task}")
  
  # ** FTB **
  # w.tenant_index = 0 # Use CC
  # w.login()
  # import time
  # target_tenant = 'hcmtest'
  # -- Option 1 --
  # recipe = 'Baseline Foundation Recipes'
  # tags = ['Launch - HCM'] # categories are ignored - need to make sure all tags are unique?
  # -- Option 2 --
  # recipe = 'Country HCM'
  # tags = ['HCM United States of America'] 
  # -- Option 3 --
  # recipe = 'Industry'
  # tags = ['HCM Core-Commercial']
  # skip_steps = []
  # ftb = w.ftb(target_tenant, recipe, tags, skip_steps)
  # print(ftb)
  # -- Wait for FTB to complete --
  # finished_states = ['Completed', 'Failed', 'Skipped', 'Aborted', 'Stopped', 'Stopped - Validation Failed', 'Completed With Errors']
  # running_states = ['In Progress', 'Not Started', 'Reprocessing']
  # ftb_status = w.get_ftb_status(ftb['url'])
  # print(ftb_status)
  # while ftb_status['status'] in running_states:
  #   time.sleep(30)
  #   ftb_status = w.get_ftb_status(ftb['url'])
  #   print(ftb_status)




  # --- Implementers, Admins, etc. ---

  w = Workday(debug=False)

  # ** Import Legacy File ** 
  impl_file_path = pathlib.Path(__file__).parent.parent.parent / 'impl-creator/impl-list (demo).csv'
  # impl_file_path = pathlib.Path(__file__).parent.parent.parent / 'impl-creator/impl-list (Lx).csv'

  print("Importing Legacy File:", impl_file_path)
  config = w.get_legacy_impl_file(impl_file_path)

  # print("DataCenter or SUV:", config['data_center'], config['suv_url'])
  # if not config['suv_url']:
  #   print("DataCenterURL:", w.Tenant().get_url_by_dc(name='test', dc=config['data_center']))
  # print(w.Tenant(url=F"{config['data_center']}/{config['cc_name']}"))
  # Index 0 - CC with Sec Admin
  w.add_tenant(F"{config['data_center']}/{config['cc_name']}", config['cc_sec_admin'], config['cc_sec_admin_pass'])
  print(w.tenants[0])
  # Index 1 - CC with Admin
  w.add_tenant(F"{config['data_center']}/{config['cc_name']}", config['cc_admin'], config['cc_admin_pass'])
  print(w.tenants[1])

  proposed_security_admins = w.get_proposed_security_admins(config)
  print("Proposed Sec Admins:", [F"{pccs[5]}-sec-admin" for pccs in proposed_security_admins])
  proposed_cc_admins = w.get_proposed_cc_admins(config)
  print("Proposed CC Admins:", [pcca[5] for pcca in proposed_cc_admins])
  proposed_vcr_managers = w.get_proposed_vcr_managers(config)
  print("Proposed VCR Managers:", [pvcr[5] for pvcr in proposed_vcr_managers])
  proposed_cc_users = w.get_proposed_cc_users(config)
  print("Proposed CC Users:", [pccu[5] for pccu in proposed_cc_users], "\n")


  # ** Get All CC Security Admins **
  w.tenant_index = 0 # Use CC with Sec Admin
  try:
    w.login()
    cc_security_admins = w.get_cc_security_admins()
  except Exception as e:
    print("Get CC Security Admins Error:", e)
    exit()
  print("CC Security Admins:", [ccs[0] for ccs in cc_security_admins])
  existing_cc_sec_admins = [ccs[0] for ccs in cc_security_admins]
  for pccs in proposed_security_admins:
    try:
      if F"{pccs[5]}-sec-admin" in existing_cc_sec_admins:
        print("CC Security Admin already exists:", F"{pccs[5]}-sec-admin")
        continue
      print("Creating CC Security Admin:", F"{pccs[5]}-sec-admin")
      name = w.create_cc_security_admin(username=F"{pccs[5]}-sec-admin", password=pccs[6], first_name=pccs[2], middle_name=pccs[3], last_name=pccs[4], req_new_pass=True, timeout="240")
      print("New CC Security Admin:", name)
    except Exception as e:
      print("Create CC Security Admin Error:", e)

  # ** Get All CC Admins **
  w.tenant_index = 0 # Use CC w/ tenant owner or cc admin
  w.login()
  cc_admins = w.get_cc_admins()
  print("CC Admins:", [cca[0] for cca in cc_admins])
  existing_cc_admins = [cca[0] for cca in cc_admins]
  for pcca in proposed_cc_admins:
    try:
      if pcca[5] in existing_cc_admins:
        print("CC Admin already exists:", pcca[5])
        continue
      print("Creating CC Admin:", pcca[5])
      name = w.create_cc_admin(username=pcca[5], password=pcca[6], first_name=pcca[2], middle_name=pcca[3], last_name=pcca[4], implementer=True, req_new_pass=True, timeout="240")
      print("New CC Admin:", name)
    except Exception as e:
      print("Create CC Admin Error:", e)

  # ** Get CC VCR Managers **
  w.tenant_index = 0 # Use CC w/ tenant owner or vcr manager
  w.login()
  vcr_managers = w.get_vcr_managers()
  print("CC VCR Managers:", [vcr_man[0] for vcr_man in vcr_managers])
  existing_vcr_managers = [vcr_man[0] for vcr_man in vcr_managers]
  print("CC VCR Managers already existing:", [x[5] for x in proposed_vcr_managers if x[5] in existing_vcr_managers])
  vcr_managers_to_set = [x[5] for x in proposed_vcr_managers if x[5] not in existing_vcr_managers]
  print("CC VCR Managers to set:", vcr_managers_to_set)
  if vcr_managers_to_set:
    try:
      result = w.set_vcr_manager(vcr_managers_to_set)
      print("Result:", result)
    except Exception as e:
      print("Set CC VCR Manager Error:", e)

  # ** Get CC Users **
  w.tenant_index = 1 # Use CC w/ admin
  w.login()
  cc_users = w.get_cc_users()
  print("CC Users:", [ccu[0] for ccu in cc_users])
  existing_cc_users = [ccu[0] for ccu in cc_users]
  for pccu in proposed_cc_users:
    pccu_dict = dict(zip(config['headers'], pccu))
    try:
      if pccu[5] in existing_cc_users:
        print("CC User already exists:", pccu[5])
        continue
      print("Creating CC User:", pccu[5])
      name = w.create_cc_user(username=pccu[5], password=pccu[6], first_name=pccu[2], middle_name=pccu[3], last_name=pccu[4], implementer=True, req_new_pass=pccu_dict['Req Pass Next Signin'].lower().strip() in ['true','yes','y','1','x'], vcr=pccu_dict['VCR Restricted'].lower().strip() in ['true','yes','y','1','x'], timeout="240")
      print("New CC User:", name)
    except Exception as e:
      print("Create CC User Error:", e)

  # ** Get All Tenants **
  print("Available Tenants:", config['tenants'])

  for t in config['tenants']:
    # find out if we have any users to create in this tenant
    tenant_header = config['headers'][config['tenant_info'].index(t,config['tenant_info'].index("Tenants:"))]
    implementers = [i for i in config['implementers'] if i[config['headers'].index(tenant_header)].lower().strip() in ('true','yes','y','1','x')]
    proposed_ten_vcr_man = [i for i in config['implementers'] if i[config['headers'].index(tenant_header)].lower().strip() in ('true','yes','y','1','x') and i[config['headers'].index('VCR Manager')].lower().strip() in ('true','yes','y','1','x')]

    print(F"Proposed Tenant ({t}) Implementers:", [i[5] for i in implementers])
    print(F"Proposed Tenant ({t}) VCR Managers:", [i[5] for i in proposed_ten_vcr_man])

    if not implementers and not proposed_ten_vcr_man:
      print(F"Skipping Tenant ({t}) as no implmenters or VCR managers to create.")
      continue

    # Index ??
    if config['tenant_user'] == 'wd-tenantowner' and 'workdaysuv.com' in config['data_center']:
      tenant_user = t
    else:
      tenant_user = config['tenant_user']
    w.add_tenant(F"{config['data_center']}/{t}", tenant_user, config['tenant_user_pass'])
    print(next(tenant for tenant in w.tenants if tenant.name == t))

    # ** Get All Implementers **
    if implementers:
      w.tenant_index = (next(i for i, tenant in enumerate(w.tenants) if tenant.name == t)) # Use Tenant Owner or Implementer
      try:
        w.login()
      except Exception as e:
        print(F"Login Failed to Tenant {t}:", e)
        exit()
      try:
        tenant_implementers = w.get_tenant_implementers()
        print("Tenant Implmenters:", [impl[0] for impl in tenant_implementers])
        existing_implementers = [impl[0] for impl in tenant_implementers]
      except Exception as e:
        print(F"Get Tenant Implementers Error:", e)
        exit()
      try:
        for impl in implementers:
          impl_dict = dict(zip(config['headers'], impl))
          # print(impl_dict)
          if impl[5] in existing_implementers:
            print("Implementer already exists:", impl[5])
            continue
          print("Creating Implementer:", impl[5])
          name = w.create_tenant_implementer(username=impl[5], password=impl[6], first_name=impl[2], middle_name=impl[3], last_name=impl[4], implementer=True, req_new_pass=impl_dict['Req Pass Next Signin'].lower().strip() in ['true','yes','y','1','x'], vcr=impl_dict['VCR Restricted'].lower().strip() in ['true','yes','y','1','x'], timeout="240")
          print("New Implementer:", name)
      except Exception as e:
        print("Create Implementer Error:", e)
      
    # ** Get Tenant VCR Managers **
    if proposed_ten_vcr_man:
      w.tenant_index = (next(i for i, tenant in enumerate(w.tenants) if tenant.name == t)) # Use Tenant Owner or VCR Manager
      try:
        w.login()
      except Exception as e:
        print(F"Login Failed to Tenant {t}:", e)
        exit()
      try:
        tenant_vcr_managers = w.get_tenant_vcr_managers()
        print("Tenant VCR Managers:", [ten_vcr_man[0] for ten_vcr_man in tenant_vcr_managers])
      except Exception as e:
        print(F"Get Tenant VCR Managers Error:", e)
        exit()
      existing_tenant_vcr_managers = [ten_vcr_man[0] for ten_vcr_man in tenant_vcr_managers]
      print("Tenant VCR Managers already existing:", [x[5] for x in proposed_ten_vcr_man if x[5] in existing_tenant_vcr_managers])
      ten_vcr_managers_to_set = [x[5] for x in proposed_ten_vcr_man if x[5] not in existing_tenant_vcr_managers]
      print("Tenant VCR Managers to set:", ten_vcr_managers_to_set)
      if ten_vcr_managers_to_set:
        try:
          result = w.set_tenant_vcr_manager(ten_vcr_managers_to_set)
          # print("Result:", result)
        except Exception as e:
          print("Set Tenant VCR Manager Error:", e)
      


  