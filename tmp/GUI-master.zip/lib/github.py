import requests
import json
import base64, re
import zipfile, io
import pathlib
import datetime

class GitHub(object):

  base_url = 'https://ghe.megaleo.com/api/v3'
  base_view_url = None
  url_parts = {
    'owner': '',
    'repo': '',
    'branch': '',
    'folder': '',
  }
  retries = 3
  folder_tree = {}
  current_dir = ''
  current_sha = None
  current_tree = []

  def __init__(self, **kwargs):
    self.username = kwargs.get('username')
    self.password = kwargs.get('password')
    self._auth = requests.auth.HTTPBasicAuth(self.username, self.password)

  def split_url(self, url):
    url_split = url.split('/')
    own = (url_split[3:4] or [None])[0]
    repo = (url_split[4:5] or [None])[0]
    branch = (url_split[6:7] or ['master'])[0]
    self.base_view_url = F"{'/'.join(url_split[:3])}/{own}/{repo}/tree/{branch}/"
    folder = '/'.join(url_split[7:]) # Get path after tree/BRANCH (if any)
    self.url_parts = {'owner': own, 'repo': repo, 'branch': branch, 'folder': folder, }
    return (own, repo, branch, folder)

  def get_sha(self, own=None, repo=None, branch=None, url=None):
    if url: # override own, repo and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
    if not all([own, repo]):
      print(F"Bad params -> own:{own}, repo:{repo} ")
      return # []
    # Get Repo Info
    repo_info = F"{self.base_url}/repos/{own}/{repo}/branches/{branch}"
    r = requests.get(repo_info, auth=self._auth)
    if not r.ok: r.raise_for_status()
    self.current_sha = json.loads(r.text)['commit']['sha']
    return self.current_sha
  
  def get_tree_with_sha(self, own=None, repo=None, folder=None, sha=None, url=None, recursive=True):
    if not sha: sha = self.current_sha
    if url: # override own, repo and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
      sha = self.current_sha = self.get_sha(own, repo, branch)
    if not all([own, repo]) or not sha:
      return
    tree = F"{self.base_url}/repos/{own}/{repo}/git/trees/{sha}{'?recursive=1' if recursive else ''}"
    r = requests.get(tree, auth=self._auth)
    if not r.ok: r.raise_for_status()
    self.current_tree = json.loads(r.text)['tree'] if not folder else [x for x in json.loads(r.text)['tree'] if x['path'].startswith(folder)]
    return
  
  def get_tree(self, own=None, repo=None, folder=None, url=None, recursive=True):
    if url: # override own, repo and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
    if not all([own, repo]):
      return
    tree = F"{self.base_url}/repos/{own}/{repo}/git/trees/{requests.utils.quote(branch)}:{requests.utils.quote(folder)}{'?recursive=1' if recursive else ''}"
    # print(tree)
    r = requests.get(tree, auth=self._auth)
    if not r.ok: r.raise_for_status()
    self.current_tree = json.loads(r.text)['tree']
    return

  def get_dir(self, own=None, repo=None, folder='', url=None, recursive=False, node=None):
    # Get files of specified directory - recurse as needed
    if url: # override own, repo and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
    if not all([own, repo]):
      print(F"Bad params -> own:{own}, repo:{repo} ")
      return # []
    self.current_dir = F"{self.base_url}/repos/{own}/{repo}/contents/{folder}"
    print(F"Getting {self.current_dir} ...")
    if node is None:
      self.folder_tree = {folder.split('/')[-1] or '/': []}
      node = self.folder_tree[folder.split('/')[-1] or '/']
    # Send the api call to get the repo/folder contents
    for i in range(self.retries): # try X times
      try:
        r = requests.get(self.current_dir, auth=self._auth)
        if not r.ok: r.raise_for_status()
        d = json.loads(r.text)
        # files = []
        for item in d:
          if item['type'] == 'file':
            # files.append(item['path'])
            node.append((item['name'], item['path']))
          elif recursive and item['type'] == 'dir':
            new_node = {item['name']:[]}
            node.append(new_node)
            # recursive_files = self.get_dir(own=own, repo=repo, folder=item['path'], recursive=recursive, node=new_node[item['name']])
            self.get_dir(own=own, repo=repo, folder=item['path'], recursive=recursive, node=new_node[item['name']])
            # files.extend(recursive_files)
        break
      except Exception as e:
        if i == self.retries-1:
          print(F"Tried {self.retries} times:", e)
          return # []

    return # files
  
  def get_file(self, own=None, repo=None, file_path=None, url=None):
    if url: # override own, repo and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, file_path = self.split_url(url)
    if not all([own, repo, file_path]):
      return
    file_url = F"{self.base_url}/repos/{own}/{repo}/contents/{file_path}"
    # print(F"Getting {file_url} ...")
    r = requests.get(file_url, auth=self._auth)
    if not r.ok: r.raise_for_status()
    d = json.loads(r.text)
    c = base64.b64decode(d['content'])
    return c
  
  def get_blob(self, blob_url):
    r = requests.get(blob_url, auth=self._auth)
    if not r.ok: r.raise_for_status()
    d = json.loads(r.text)
    c = base64.b64decode(d['content'])
    return c
  
  def get_zip(self, own=None, repo=None, branch='master', url=None, debug=False):
    if url: # override own, repo, branch and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
    if not all([own, repo]):
      return
    zip_url = F"{self.base_url}/repos/{own}/{repo}/zipball/{branch}"
    if debug: starttime = datetime.datetime.now()
    r = requests.get(zip_url, auth=self._auth)
    if debug: print('Time to get zipball:', datetime.datetime.now() - starttime)
    if r.ok:
      return zipfile.ZipFile(io.BytesIO(r.content))
    else:
      r.raise_for_status()
    
  def get_jsons_from_zip(self, own=None, repo=None, branch='master', folder=None, regex=None, url=None, debug=False):
    if url: # override own, repo, branch and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
    if not all([own, repo]):
      return
    z = self.get_zip(own, repo, branch, debug=debug)
    if not regex:
      regex = FR"/{folder or ''}/.*\.json$"
    file_regex = re.compile(regex, re.IGNORECASE)
    z_namelist_matches = [name for name in z.namelist() if file_regex.search(name) and not name.endswith('all.json')]
    # if debug: print(z_namelist_matches)
    # if debug:
    #   for name in z_namelist_matches:
    #     print(name)
    #     _ = json.loads(z.read(name))
    return {pathlib.PurePosixPath(name).stem:json.loads(z.read(name)) for name in z_namelist_matches}
  
  def get_sqls_from_zip(self, own=None, repo=None, branch='master', folder=None, regex=None, url=None, return_regex=None, debug=False):
    if url: # override own, repo, branch and folder - ex. 'https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/VALIDATIONs'
      own, repo, branch, folder = self.split_url(url)
    if not all([own, repo]):
      return
    z = self.get_zip(own, repo, branch, debug=debug)
    if not regex:
      regex = FR"/{folder or ''}/.*\.sql$"
    file_regex = re.compile(regex, re.IGNORECASE)
    z_namelist_matches = [name for name in z.namelist() if file_regex.search(name)]
    # if debug: print(z_namelist_matches)
    # if debug:
    #   for name in z_namelist_matches:
    #     print(name)
    #     _ = z.read(name)
    if not return_regex:
      return {pathlib.PurePosixPath(name).stem:z.read(name).decode() for name in z_namelist_matches}
    else:
      return_data = {}
      for name in z_namelist_matches:
        file_data = z.read(name).decode()
        match = re.search(return_regex, file_data, re.I+re.M)
        if match:
          return_data[match.group(1)] = file_data
        else:
          return_data[pathlib.PurePosixPath(name).stem] = file_data
      return return_data

  
if __name__ == "__main__":
  import keyring, zlib
  starttime = datetime.datetime.now()
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  g = GitHub(username=dict_config['ad_username'], password=dict_config['ad_password'])
  # g.get_tree_with_sha(url='https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/DDLs')
  # print(g.current_tree)
  # g.get_tree(url='https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/JSONs')
  # print(g.current_tree)

  ## Too Slow !! ~ 15 minutes ##
  # all_dcdds = {}
  # for j in g.current_tree:
  #   if j['type'] != 'blob':
  #     continue
  #   dcdd = g.get_blob(j['url'])
  #   json_dcdd = json.loads(g.get_blob(j['url']))
  #   all_dcdds[json_dcdd['metadata']['FULL NAME']] = json_dcdd

  # print('Getting zip and parsing JSONs ...')
  # # all_dcdds = g.get_jsons_from_zip(url='https://ghe.megaleo.com/DTOE/DCDD_Tools/tree/master/JSONs', debug=True)
  # all_dcdds = g.get_jsons_from_zip(url='https://ghe.megaleo.com/DTOE/DCDD_JSON/tree/master/JSONs', debug=True)
  # print('Time Elapsed:', datetime.datetime.now() - starttime)

  # print('Getting zip and parsing SQLs ...')
  # all_sqls = g.get_sqls_from_zip(url='https://ghe.megaleo.com/DTOE/Stored_Procedures/tree/master/SPs/v43 - Skeleton Key WIP', debug=True)
  # print(all_sqls.keys())
  # for sql in sorted(list(all_sqls.keys())):
  #   print(sql)
  #   print(all_sqls[sql])
    # print(re.search(R'CREATE +PROCEDURE +`(.*)`.*', all_sqls[sql], re.I+re.M).group(1) if re.search(R'CREATE +PROCEDURE +`(.*)`.*', all_sqls[sql], re.I+re.M) else 'No Match')
    # print('---------------------------------')
  # print('Time Elapsed:', datetime.datetime.now() - starttime)

  # Get File:
  # file_data = g.get_file(url='https://ghe.megaleo.com/DTOE/DCDD_JSON/blob/master/JSONs/absence/AddUpdate_Employee_Leave_Of_Absence_DCDD.json')
  # print(json.loads(file_data))

  # print('Getting webservice and operations stats ...')
  # # Assume that all DCDDs have the same column order (can't really do that, but they should be)
  # item = next(iter(all_dcdds.values()))
  # XPATH_COL_IDX = item['columns'].index('XPATH')
  # TMPATH_COL_IDX = item['columns'].index('TMPATH')
  # all_web_services = {ws for d in all_dcdds for ws in (all_dcdds[d]['metadata']['WEB SERVICE'] or '').split(', ')}
  # # print(all_web_services)
  # all_operations = {all_dcdds[d]['metadata']['WEB SERVICE OPERATION'] for d in all_dcdds}
  # # print(all_operations)
  # print(len(all_dcdds), "DCDDs", len(all_web_services), "Web Services", len(all_operations), "Operations")
  # print('Time Elapsed:', datetime.datetime.now() - starttime)

  # print('Finding missing XPATHs or TMPATHs ...')
  # for d in sorted(all_dcdds):
  #   dcdd = all_dcdds[d]
  #   XPATH_COL_IDX = dcdd['columns'].index('XPATH')
  #   TMPATH_COL_IDX = dcdd['columns'].index('TMPATH')

  #   # print([[r[XPATH_COL_IDX], r[TMPATH_COL_IDX]] for r in dcdd['rows']])

  #   missing_rows = len([r for r in dcdd['rows'] if not (r[XPATH_COL_IDX] and r[TMPATH_COL_IDX])])
  #   if missing_rows > 0:
  #     print(d, "|", dcdd['short_name'])
  #     print("\t", missing_rows, 'rows missing XPATH or TMPATH')
  #     print("\t",
  #     (dcdd['metadata']['CATEGORY'] or '').split(', '),
  #     (dcdd['metadata']['FUNCTIONAL AREA'] or '').split(', '),
  #     d, # dcdd['metadata']['FULL NAME'],
  #     dcdd['metadata']['API VERSION'],
  #     (dcdd['metadata']['WEB SERVICE'] or '').split(', '),
  #     dcdd['metadata']['WEB SERVICE OPERATION'],
  #   )

  # Get missing csv File Name DCDDS
  # _ = [print(d) for d in all_dcdds if not any(r[all_dcdds[d]['columns'].index('csv File Name')] for r in all_dcdds[d]['rows'])]
  
  print('Completed:', datetime.datetime.now() - starttime)