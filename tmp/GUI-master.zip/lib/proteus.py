import requests
import getpass
import base64
import datetime

# https://wd5-suv.megaleo.com/proteus/api-docs/index.html?urls.primaryName=proteus_api#/

class Proteus(object):
  debug = False

  def __init__(self, **kwargs):
    self.base_url = kwargs.get('url') or "https://wd5-suv.megaleo.com/proteus/api/v2"
    self.username = kwargs.get('username') or (getpass.getuser() if kwargs.get('interactive') else None)
    self.password = kwargs.get('password') or (getpass.getpass()  if kwargs.get('interactive') else None)
    self.debug = bool(kwargs.get('debug', self.debug))
    self._basic_auth = F"""Basic {base64.b64encode(F"{self.username}:{self.password}".encode("utf-8", errors="ignore")).decode("ascii")}"""
    self._header = {"Content-Type": "application/json", "Authorization":self._basic_auth}
    self.suv_man_token = None

  def get(self, path, data=None):
    r = requests.get(F"""{self.base_url}{path}""", headers=self._header, json=data)
    if not r.ok: 
      if self.debug: return r.json().get('msg') 
      else: return r.raise_for_status() 
    return r.json()
  
  def put(self, path, data=None):
    r = requests.put(F"""{self.base_url}{path}""", headers=self._header, json=data)
    if not r.ok: 
      if self.debug: return r.json().get('msg') 
      else: return r.raise_for_status() 
    return r.json()
  
  def get_suv_instances(self, params=None):
    return self.get("/search/suv/instances", params)
  
  def get_projects(self):
    return self.get("/projects")
  
  def get_project_id_by_name(self, name):
    all_projects = self.get_projects()
    if self.debug: print(json.dumps(all_projects, indent=2))
    project_id = next((x['id'] for x in all_projects if x['name'] == name), None)
    return project_id
  
  def get_project_pools(self, project_name=None, project_id=None):
    if not (project_id or project_name): return []
    if not project_id:
      project_id = self.get_project_id_by_name(project_name)
      if not project_id: return []
    return self.get(F"/projects/{project_id}/suv_pools")
  
  def get_pool_id_by_project_pool_names(self, project, pool):
    project_pools = self.get_project_pools(project_name=project)
    if self.debug: print(json.dumps(project_pools, indent=2))
    pool_id = next(x['id'] for x in project_pools if x['name'] == pool)
    return pool_id
  
  def set_stage_and_description(self, pool=None, instance=None, stage='READY', description='SUV PREP'):
    if not all([pool, instance, stage, description]):
      return {}
    return self.put(F"/suv_pools/{pool}/instances/{instance}/push", {'toStage':stage, 'description':description})
  
  def set_description_stage_by_id(self, id, description=None, stage=None):
    all_instances = self.get_suv_instances()
    if self.debug: print(json.dumps(all_instances, indent=2))
    instance_data = next((x for x in all_instances if x['instanceId'] == id), None)
    if not instance_data:
      return {"error":F"Instance ID ({id}) not found!"}
    pool_id = self.get_pool_id_by_project_pool_names(instance_data['wdAdditionalTags']['projectName'], instance_data['wdAdditionalTags']['poolName'])
    description = instance_data['description'] if description is None else description
    stage = instance_data['poolStage'] if stage is None else stage
    return self.put(F"/suv_pools/{pool_id}/instances/{instance_data['instanceId']}/push", {'toStage':stage, 'description':description})
  
  def get_suv_man_instance_by_id(self, id):
    # Get token
    if not self.suv_man_token or datetime.datetime.strptime(self.suv_man_token['timeToLive'], '%Y-%m-%dT%H:%M:%S.%f%z') <= datetime.datetime.now().astimezone():
      # Narada URL
      n_url = "https://narada.inday.io/narada/token?clientId=chromemanager&clientKey=DC5E4FDB24284EEDEEAE18C76B259"
      data = { "username": self.username, "password": self.password }
      r = requests.post(n_url, json=data)
      if not r.ok: return r.raise_for_status()
      self.suv_man_token = r.json()
      # print(self.suv_man_token)
    suv_man_url = F"https://api-suv.megaleo.com/suvapi/instances/{id}?authtoken={self.suv_man_token['token']}&clientId=chromemanager"
    r = requests.get(suv_man_url)
    if not r.ok: return r.raise_for_status()
    return r.json()
  
  def add_suv_man_ssh_key(self, id, username): # Doesn't work for non-owned instances
    # Get token
    if not self.suv_man_token or datetime.datetime.strptime(self.suv_man_token['timeToLive'], '%Y-%m-%dT%H:%M:%S.%f%z') <= datetime.datetime.now().astimezone():
      # Narada URL
      n_url = "https://narada.inday.io/narada/token?clientId=chromemanager&clientKey=DC5E4FDB24284EEDEEAE18C76B259"
      data = { "username": self.username, "password": self.password }
      r = requests.post(n_url, json=data)
      if not r.ok: return r.raise_for_status()
      self.suv_man_token = r.json()
      # print(self.suv_man_token)
    suv_man_url = F"https://api-suv.megaleo.com/suvapi/instances/{id}/pubkeys?authtoken={self.suv_man_token['token']}&clientId=chromemanager"
    data = { "wdAddPubKeyUserList": username }
    r = requests.put(suv_man_url, json=data)
    if not r.ok: 
      print(r.text)
      return r.raise_for_status()
    return r.json()
  
  def get_suv_man_public_key(self, username):
    n_url = F"https://narada.inday.io/narada/users/{username}/publickey?clientId=chromemanager&clientKey=DC5E4FDB24284EEDEEAE18C76B259"
    r = requests.get(n_url)
    if not r.ok: 
      print(r.text)
      return r.raise_for_status()
    return r.text

    

if __name__ == "__main__":
  import keyring, json, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  p = Proteus(username=dict_config['ad_username'], password=dict_config['ad_password'], interactive=True, debug=False)

  # all_instances = p.get_suv_instances()
  # important_details = [{x['instanceId']:[
  #   x['wdAdditionalTags']['projectName'],
  #   x['wdAdditionalTags']['poolName'],
  #   x['description'],
  #   x['poolStage'],
  #   x['password'],
  #   x['url'],
  # ]} for x in all_instances]
  # print(json.dumps(important_details, indent=2))

  # Set Description/Stage
  # pool = 1625 # DTOE Training (dtoe-training)
  # r = p.set_stage_and_description(pool, 'i-00e5abb24479b660b', 'READY', 'SLNG Available (rc-2024.03)')
  # print(json.dumps(r, indent=2))

  # Set Description
  # r = p.set_description_stage_by_id('i-00e5abb24479b660b', 'SLNG John Lau (rc-2024.03)')
  # print(json.dumps(r, indent=2))

  # SUV Manager access to get instance data
  # print(json.dumps(p.get_suv_man_instance_by_id('n-fbak4jml65325hgn6b7c'), indent=2)) 

  # SUV Manager access to add SSH key
  # print(json.dumps(p.add_suv_man_ssh_key('n-fbak4jml65325hgn6b7c', 'svc-cas-jenkins'), indent=2))

  # SUV Manager access to get public key
  # print(p.get_suv_man_public_key('svc-cas-jenkins'))