import requests
import json
import pathlib
import re, uuid
import xml.etree.ElementTree as ET
import traceback
import csv
import difflib
try:
  from .wsdl_overrides import schema_overrides_table, schema_overrides_column
except:
  from wsdl_overrides import schema_overrides_table, schema_overrides_column

ns = {
  'wsdl': 'http://schemas.xmlsoap.org/wsdl/',
  'xsd': 'http://www.w3.org/2001/XMLSchema',
  'wd': 'urn:com.workday/bsvc'
}

re_ns = re.compile('{.*?}')
re_id = re.compile(R'([\W_])Id(\W_)*')

class WSDLException(Exception): pass

class WSDL_Element:
  def __init__(self, name=None, type=None, cardinality=None, documentation=None, xpath=None, slngpath=None, parent=None): #, children=[]):
    self.name = name
    self.type = type 
    self.cardinality = cardinality
    self.documentation = documentation
    self.xpath = xpath
    self.slngpath = slngpath
    self.parent = parent
    # self.children = children

class WSDL(object):
  WEB_SERVICES = [
    'Absence_Management',
    'ACA_Partner_Integrations',
    'Academic_Advising',    'Academic_Advising_Implementation',
    'Academic_Foundation',    'Academic_Foundation_Implementation',
    'Admissions',    'Admissions_Implementation',
    'Adoption',    'Adoption_Implementation',
    'ALM_Versioned',
    'Assistant_Implementation_Service',
    'Benefits_Administration',
    'Benefits_Partner_Program_Integrations',
    'Blog_Implementation',
    'Campus_Engagement',    'Campus_Engagement_Implementation',
    'Cash_Management',
    'Compensation',
    'Compensation_Review',
    'Core_Implementation_Service',
    'DaaS_Implementation_Service',
    'Document_Layout_Implementation_Service',
    'Drive',    'Drive_Implementation_Service',
    'Dynamic_Document_Generation',
    'External_Integrations',
    'Financial_Aid',    'Financial_Aid_Implementation',
    'Financial_Management',    'Financials_Implementation_Service',
    'Formatting_Style_Implementation',
    'Get_Bank_Connectivity_Reference_Data_Mapping',
    'Gigs_Implementation',
    'HCM_Implementation_Service',    'HCM_Implementation_Service_Versioned',
    'Help_Implementation',
    'Human_Resources',
    'Identity_Management',
    'Integrations',
    'Inventory',
    'Learning',    'Learning_Implementation',
    'Metadata_Translations',
    'Moments',
    'Notification',    'Notification_Designer_Implementation_Service',
    'Org_Studio',
    'Payroll',
    'Payroll_AUS',
    'Payroll_CAN',
    'Payroll_FRA',    'Payroll_FRA_Implementation',
    'Payroll_GBR',
    'Payroll_Implementation_Service',
    'Payroll_Interface',    'Payroll_Interface_Implementation_Service',
    'Performance_Management',
    'Planning_Implementation_Service',
    'Professional_Services_Automation',
    'Put_Bank_Connectivity_Reference_Data_Mapping',
    'Put_Withholding_Tax_Rate_V29.0',
    'Recruiting',    'Recruiting_Campaign_Implementation',    'Recruiting_Implementation',    'Recruiting_Landing_Pages_Implementation',
    'Resource_Management',
    'Revenue_Management',
    'Scheduling',    'Scheduling_Implementation',
    'Settlement_Services',
    'Severance',
    'Staffing',
    'Student_Core',    'Student_Core_Implementation',
    'Student_Finance',    'Student_Finance_Implementation',
    'Student_Records',    'Student_Records_Implementation',
    'Student_Recruiting',    'Student_Recruiting_Implementation',
    'Student_Transfer_Credit',    'Student_Transfer_Credit_Implementation',
    'Talent',
    'Tenant_Data_Translation',
    'Time_Tracking',    'Time_Tracking_Implementation_Service',
    'Training_Implementation',
    'Training_Internal',
    'User_Success_Platform_Implementation',
    'Workday_Connect',
    'Workday_Extensibility',
    'Workforce_Planning',
  ]
  VERSIONS = [
    # 'v51.2','v51.1','v51.0',
    # 'v50.2','v50.1','v50.0',
    # 'v49.2','v49.1','v49.0',
    # 'v48.2','v48.1','v48.0',
    # 'v47.2','v47.1','v47.0',
    # 'v46.2','v46.1','v46.0',
    # 'v45.2','v45.1','v45.0',
    # 'v44.2','v44.1',
    'v44.0',
    'v43.2','v43.1','v43.0',
    'v42.2','v42.1','v42.0',
    'v41.2','v41.1','v41.0',
    'v40.2','v40.1','v40.0',
    'v39.2','v39.1','v39.0',
    'v38.2','v38.1','v38.0',
  ]
  
  EXCLUDED_PREFIXES = ('Cancel_', 'Get', 'Find', 'Launch')
  EXCLUDED_TYPES = ('WID',)
  SHORT_SUBS = {
    "Default":      "Def",    "Compensation": "Comp",     "Reference_ID": "RefID",
    "Reference":    "Ref",    "Supplier":     "Sup",      "Payment":      "Pay",
    "Account":      "Acct",   "Customer":     "Cust",     "Employee":     "Emp",
    "Enrollment":   "Enroll", "Election":     "Elect",    "Professional": "Prof",
    "Allocation":   "Alloc",  "Organization": "Org",      "Payroll":      "PAY",
    "Collective":   "Coll",   "Agreement":    "Agree",    "Schedule":     "Sched",
    "Government":   "Gov",    "Information":  "Info",     "Assignment":   "Assign",
    "Assignments":  "Assign", "Requisition":  "REQ",      "Learning":     "LRN",
    "Accounting":   "Acctng", "Amendment":    "Amend",    "Transactions": "Trnxs",
    "Student":      "STU",    "Employment":   "Empl",     "Eligibility":  "Eligib",
    "Probation":    "Probtn", "Membership":   "Membrshp", "Calculation":  "Calc",
    "Related":      "Rel",    "Component":    "Cmpnt",    "Accumulation": "Accmltn",

  }
  ALWAYS_SUBS = {
    "-": "_",
    "__+": "_",
  }
  TYPE_SUBS = {
    R"^string( \(.*\))?$": "Text",
    R"^decimal( \(.*\).*)?$": "Number",
    "^boolean$": "Boolean",
    "^date$": "YYYY-MM-DD",
    "^dateTime$": "YYYY-MM-DD",
    "^base64Binary$": "Base64",
    "^(.*)ISO_3166-1_Alpha-2_Code, ISO_3166-1_Alpha-3_Code(.*)$": R"\1ISO_3166-1_Alpha-3_Code, ISO_3166-1_Alpha-2_Code\2",
    # "^(.*)Contingent_Worker_ID, Employee_ID(.*)$": R"\1Employee_ID, Contingent_Worker_ID\2",
    "^(.*), Employee_ID(,?.*)$": R"Employee_ID, \1\2", # Bring Employee_ID to the front
  }

  def __init__(self, **kwargs):
    self.base_url = self.tenant = self.web_service = self.version = None
    if kwargs.get('url'):
      self.base_url, self.tenant, self.web_service, self.version = self._url_split(kwargs.get('url'))
    self.base_url = kwargs.get('base_url') or 'https://wd2-impl-services1.workday.com/ccx/service'
    self.tenant = kwargs.get('tenant') or self.tenant or 'workdayproserv_dpt2'
    self.web_service = kwargs.get('web_service') or self.web_service
    self.operation = kwargs.get('operation')
    self.version = kwargs.get('version') or self.version or self.VERSIONS[0]
    if self.version:
      if not self.version.startswith('v'):
        self.version = 'v' + self.version
    self.root = None
    self.data_frame = None
    self.data = None

  def _url_split(self, url):
    # service_url = "https://wd2-impl-services1.workday.com/ccx/service/workdayproserv_dpt2/Absence_Management/v42.0?wsdl"
    if not '/ccx/service/' in url:
      raise WSDLException(F'Not a valid service url: {url}')
    base_url    = '/'.join(url.split('/')[0:5])
    tenant      = '/'.join(url.split('/')[5:6])
    web_service = '/'.join(url.split('/')[6:7])
    version = '/'.join(url.split('/')[7:8])
    version = version if '?' not in version else version.split('?')[0]
    return base_url, tenant, web_service, version
  
  def _build_url(self):
    url = F"{self.base_url}/{self.tenant}/{self.web_service}/{self.version}?wsdl"
    if not all([self.base_url, self.tenant, self.web_service, self.version]):
      raise WSDLException(F'Missing WSDL URL Element(s): {url}')
    return url
  
  def get_wsdl(self, save=False):
    r = requests.get(self._build_url())
    if not r.ok:
      r.raise_for_status()
    # if save:
    # file_name = F"{self.web_service}_{self.version}.wsdl"
    #   with open(file_name, mode="wb") as file:
    #     file.write(r.content)
    self.root = ET.fromstring(r.content)
    return self.root
    
  def list_all_operations(self, filter=True):
    return [op.get('name') for op in self.get_operations(filter=filter)]
  
  def get_operations(self, operation_list=[], filter=True):
    if self.root is None:
      self.get_wsdl()
    exclude_prefixes_lower = tuple(x.lower() for x in self.EXCLUDED_PREFIXES)
    return [op for op in self.root.find('wsdl:portType', ns).findall('wsdl:operation',ns) if ((not op.get('name').lower().startswith(exclude_prefixes_lower)) if filter else True) and (operation_list==[] or op.get('name') in operation_list)]
  
  def get_operation_docs(self, operation_list=[], filter=True):
    return {op.get('name'):{re_ns.sub('', x.tag): x.text for x in op.find('wsdl:documentation', ns).iter()} for op in self.get_operations(operation_list, filter)}
  
  def get_operation_input_elements(self, operation_list=[], filter=True):
    return {op.get('name'):self.root.find(F'''wsdl:message[@name="{op.find('wsdl:input', ns).get('message', ':').split(':')[-1]}"]''', ns).find('wsdl:part', ns).get('element').split(':')[-1] for op in self.get_operations(operation_list, filter)}
  
  def get_operation_input_types(self, operation_list=[], filter=True):
    if self.root is None:
      self.get_wsdl()
    schema = self.root.find('wsdl:types', ns).find('xsd:schema', ns)
    operation_input_elements = self.get_operation_input_elements(operation_list, filter)
    return {op: schema.find(F'''xsd:element[@name="{operation_input_elements[op]}"]''', ns).get('type').split(':')[-1] for op in operation_input_elements}

  def get_name(self):
    if self.root is None:
      self.get_wsdl()
    return self.root.get('name')
  
  def get_version(self):
    if self.root is None:
      self.get_wsdl()
    return self.root.find('.//xsd:attribute[@wd:fixed]', ns).get('{'+ns['wd']+'}'+'fixed')
  
  def get_type(self, type_name=None):
    schema = self.root.find('wsdl:types', ns).find('xsd:schema', ns)
    t = schema.find(F'xsd:complexType[@name="{type_name}"]', ns)
    if t is not None: return t
    t = schema.find(F'xsd:simpleType[@name="{type_name}"]', ns)
    if t is not None: return t
    t = schema.find(F'xsd:element[@name="{type_name}"]', ns)
    return t
    # Changed in version 3.12: Testing the truth value of an Element emits DeprecationWarning. Testing the truth value of an Element is deprecated and will raise an exception in Python 3.14.
    # return schema.find(F'xsd:complexType[@name="{type_name}"]', ns) or schema.find(F'xsd:simpleType[@name="{type_name}"]', ns) or schema.find(F'xsd:element[@name="{type_name}"]', ns)

  def get_cardinality(self, element=None):
    if not element.get('minOccurs') and (not element.get('maxOccurs') or element.get('maxOccurs') == "1"):
      cardinality = '[1..1]'
    elif element.get('minOccurs') == "0" and element.get('maxOccurs') == "unbounded":
      cardinality = '[0..*]'
    elif element.get('minOccurs') == "0" and (not element.get('maxOccurs') or element.get('maxOccurs') == "1"):
      cardinality = '[0..1]'
    elif not element.get('minOccurs') and element.get('maxOccurs') == "unbounded":
      cardinality = '[1..*]'
    else:
      cardinality = None
    return cardinality
  
  def get_element_type_fields(self, operation_name=None, type_name=None, path=None, slng_path=None, type_path=None, cardinality=None, parent=None):
      # print(operation_name, type_name, path, slng_path, type_path)
      if operation_name and not type_name:
        # First run uses only operation name, next will only use type_name
        # This will also get the WSDL if not already downloaded.
        type_name = self.get_operation_input_types([operation_name])[operation_name]
        self.operation = operation_name

      path_split = type_path.parts if type_path else [] # slng_path.parts if slng_path else [] # path.split('/') if path else []
      path_split_set = set(path_split)
      if len(path_split) != len(path_split_set): 
        # print("Possible Circular:", path_split[1].split(':')[1], path_split[-1].split(':')[1])
        print("Possible Circular:", path_split[1], path_split[-1])
        return []
      try:
        # if debug: print("Parent:", json.dumps([parent.__dict__[x] for x in parent.__dict__ if x != 'parent'] if parent else None, default=vars, indent=2))
        # if debug: print("Parent:", json.dumps(parent, default=vars, indent=2))
        fields = []
        current_wsdl_object = WSDL_Element(cardinality=cardinality, xpath=path, parent=parent)
        if not path:
          element_name = self.get_operation_input_elements(operation_name)[operation_name]
          path = F'/wd:{element_name}'
          # print('Type Name:', type_name, 'Op Input Element:', operation_input_elements.get(op))
          slng_path = pathlib.PurePosixPath('/' + re.sub(R'([\W_]+|Type$)', '', (type_name or element_name)))
          type_path =  pathlib.PurePosixPath('/' +  type_name)
          fields.append(('Name', 'Type', 'Documentation', 'Cardinality', 'Xpath', 'ETpath', 'SLNGpath', 'SLNG_Table_Name', 'SLNG_Orig_Table_Name', 'Parent_Type|Element', 'Element', 'Element_Type', 'Override_Table_Name', 'Code_Search_Type'))
        # if debug: print('path:', path, 'type_name:', type_name)
        ele_type = self.get_type(type_name)
        if ele_type is None:
          return fields
        # if debug: print('type name:', ele_type.get('name'))
        current_wsdl_object.name = ele_type.get('name')
        wd_name = ('wd:' if 'wd:' not in ele_type.get('name') else '') + ele_type.get('name')
        current_wsdl_object.xpath = path + '/' + wd_name
        ele_type_doc_obj = ele_type.find('xsd:annotation', ns).find('xsd:documentation', ns) if ele_type.find('xsd:annotation', ns) is not None else None
        ele_type_doc = ele_type_doc_obj.text if ele_type_doc_obj is not None else ''
        current_wsdl_object.documentation = ele_type_doc
        # ---------------------
        # Do we have Attributes
        # ---------------------
        search_type = "ComplexAttribute"
        ele_attributes = ele_type.findall('xsd:attribute', ns)
        # if debug: print('len attributes:', len(ele_attributes))
        for ele in ele_attributes:
          ele_doc_obj = ele.find('xsd:annotation', ns).find('xsd:documentation', ns) if ele.find('xsd:annotation', ns) is not None else None
          ele_doc = ele_doc_obj.text if ele_doc_obj is not None else ''
          slng_parent_type = current_wsdl_object.parent.parent.parent.type if current_wsdl_object.parent and current_wsdl_object.parent.parent and current_wsdl_object.parent.parent.parent and current_wsdl_object.parent.parent.parent else ''
          slng_element = current_wsdl_object.parent.name if current_wsdl_object.parent else re.sub(R'Type$', '', current_wsdl_object.name)
          slng_parent_type_element = F"{slng_parent_type}|{slng_element}"
          slng_table = re.sub(R'([\W_]+|Type$)', '', current_wsdl_object.name)
          if ele.attrib.get('ref'):
            # slng_name = re.sub(R'[\W_]+', '', ele.get('ref'))
            # current_slng_path = slng_path / slng_name
            # wd_ref = ('wd:' if 'wd:' not in ele.get('ref') else '') + ele.get('ref')
            # fields.append((ele.get('ref').split(':')[-1], 'string', ele_doc or 'Web Service version', '[0..1]', path + '@' + wd_ref, current_slng_path, slng_name, slng_table, slng_parent_type_element, schema_overrides_column.get(slng_parent_type_element, ''), schema_overrides_table.get(slng_parent_type_element, ''), search_type ))
            pass # We don't need/want this as it seems to only refer to the version attribute which is not needed in the DCDD
          elif ele.attrib.get('name'):
            if ele.attrib.get('name') != "Descriptor":
              slng_name = re.sub(R'[\W_]+', '', ele.get('name'))
              current_slng_path = slng_path / slng_name
              # Overrides
              override_table =  schema_overrides_table.get(slng_parent_type_element, '')
              override_column = schema_overrides_column.get(slng_parent_type_element, '')
              override_table_name = F"{override_table}.{override_column}" if override_table or override_column else None
              slng_orig_table_name = F"{slng_table}.{slng_name}" if override_table_name else None
              if override_table:
                slng_table_name = F"{override_table}.{(override_table + 'ID') if slng_name.endswith('ID') else (override_table + 'IDType') if slng_name.endswith('IDType') else slng_name}"
                current_slng_path = current_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
              elif override_column:
                slng_table_name = F"{slng_table}.{(override_column + 'ID') if slng_name.endswith('ID') else (override_column + 'IDType') if slng_name.endswith('IDType') else slng_name}"
                current_slng_path = current_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
              else:
                slng_table_name = F"{slng_table}.{slng_name}"
              fields.append((ele.get('name'), ele.get('type', '').split(':')[-1], ele_doc, '[0..1]', path + '@' + ele.get('name'), type_path / type_name, current_slng_path, slng_table_name, slng_orig_table_name, slng_parent_type_element, slng_element, type_name, override_table_name, search_type ))
        # ----------------------------
        # Do we have Sequence Elements
        # ----------------------------
        search_type = "ComplexElement"
        if ele_type.find('xsd:sequence', ns) is not None:
          child_elements = ele_type.find('xsd:sequence', ns).findall('xsd:element', ns) or []
          for choice in ele_type.find('xsd:sequence', ns).findall('xsd:choice', ns):
            child_elements.extend(choice.findall('xsd:element', ns))
          # if debug: print('len child element:', len(child_elements))
          for child in child_elements:
            child_cardinality = self.get_cardinality(child)
            child_doc_obj = child.find('xsd:annotation', ns).find('xsd:documentation', ns) if child.find('xsd:annotation', ns) is not None else None
            child_doc = child_doc_obj.text if child_doc_obj is not None else ''
            child_name = path.split('/')[-1].replace('wd:', '') + '_ID' if child.get('name') == 'ID' else child.get('name')
            slng_name = re.sub(R'[\W_]+', '', child.get('name'))
            slng_parent_type = current_wsdl_object.parent.type if current_wsdl_object.parent else ''
            slng_element = child.get('name')
            slng_parent_type_element = F"{slng_parent_type}|{slng_element}"
            wd_child_name = ('wd:' if 'wd:' not in child.get('name') else '') + child.get('name')
            child_path = path + '/' + wd_child_name
            child_type_name = child.get('type').split(':')[-1] if child.get('type') else None
            element_type = child.get('type') or (child.find('xsd:simpleType', ns).find('xsd:restriction', ns).get('base') if child.find('xsd:simpleType', ns) is not None else None)
            slng_type_name = re.sub(R'([\W_]+|Type$)', '', child_type_name or slng_name)
            if child_cardinality in ['[0..*]','[1..*]']:
              slng_table = re.sub(R'([\W_]+|Type$)', '', child_type_name)
            else: slng_table = re.sub(R'([\W_]+|Type$)', '', current_wsdl_object.name)
            
            child_wsdl_object = WSDL_Element(name=child_name, cardinality=child_cardinality, documentation=child_doc, xpath=None, parent=current_wsdl_object)
            if child.get('type') and 'wd:' in child.get('type') and 'complexType' in self.get_type(child_type_name).tag:
              child_slng_path = (slng_path / slng_type_name) if slng_path.stem != slng_type_name else slng_path # slng_path if slng_path.stem == slng_type_name and len(slng_path.parts) == 2 else (slng_path / slng_type_name)
              child_wsdl_object.type = child_type_name
              child_type_path = type_path / child.get('type').split(':')[-1]
              child_fields = self.get_element_type_fields(type_name=child_type_name, path=child_path, slng_path=child_slng_path, type_path=child_type_path, cardinality=child_cardinality, parent=child_wsdl_object)
              fields.extend(child_fields)
            else:
              child_slng_path = slng_path / slng_name
              if child.get('type') and child.get('type')[-11:] == 'Enumeration':
                child_enum = self.get_type(child_type_name)
                child_type = ', '.join([x.get('value') for x in child_enum.findall('.//wd:enumeration', ns) if x.get('value') not in self.EXCLUDED_TYPES])
              elif child.get('type') is None and child.find('xsd:simpleType', ns) is not None:
                child_type = child.find('xsd:simpleType', ns).find('xsd:restriction', ns).get('base').split(':')[-1] 
                child_type_values = [x.get('value') for x in child.find('xsd:simpleType', ns).find('xsd:restriction', ns).iter() if x.get('value')]
                if not child_type_values:
                  pass
                elif len(child_type_values) < 3 or len(child_type_values) < 3:
                  child_type = child_type + ' (' + ', '.join(child_type_values) + ')'
                elif len(child_type_values) == 3:
                  child_type = child_type + F' ({child_type_values[0]}, {child_type_values[2]}) > {child_type_values[1]}'
              elif child.get('type') and 'wd:' in child.get('type') and 'simpleType' in self.get_type(child_type_name).tag:
                child_type = self.get_type(child_type_name).find('xsd:restriction', ns).get('base').split(':')[-1]
              else:
                child_type = child_type_name
              # Overrides
              override_table =  schema_overrides_table.get(slng_parent_type_element, '')
              override_column = schema_overrides_column.get(slng_parent_type_element, '')
              override_table_name = F"{override_table}.{override_column}" if override_table or override_column else None
              slng_orig_table_name = F"{slng_table}.{slng_name}" if override_table_name else None
              if override_table:
                slng_table_name = F"{override_table}.{(override_table + 'ID') if slng_name.endswith('ID') else (override_table + 'IDType') if slng_name.endswith('IDType') else slng_name}"
                child_slng_path = child_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
              elif override_column:
                slng_table_name = F"{slng_table}.{(override_column + 'ID') if slng_name.endswith('ID') else (override_column + 'IDType') if slng_name.endswith('IDType') else slng_name}"
                child_slng_path = child_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
              else:
                slng_table_name = F"{slng_table}.{slng_name}"
              fields.append((child_name, child_type, child_doc, child_cardinality, child_path, type_path / element_type, child_slng_path, slng_table_name, slng_orig_table_name, slng_parent_type_element, slng_element, element_type, override_table_name, search_type ))
              child_wsdl_object.type = child_type
        # ------------------------
        # Do we have simpleContent
        # ------------------------
        search_type = "SimpleElement"
        if ele_type.find('xsd:simpleContent', ns) is not None:
          # if debug: print('simpleContent:', )
          # name = '_'.join([x.replace('wd:','') for x in path.split('/')[-2:]]) if path[-6:] == '/wd:ID' else ele_type.get('name')
          ext = ele_type.find('xsd:simpleContent', ns).find('xsd:extension', ns)
          ext_type = ext.attrib.get('base').split(':')[-1]
          slng_parent_type = current_wsdl_object.parent.parent.parent.parent.parent.type if current_wsdl_object.parent.parent.parent.parent.parent else current_wsdl_object.parent.parent.parent.parent.name
          slng_element = current_wsdl_object.parent.parent.parent.name
          slng_parent_type_element = F"{slng_parent_type}|{slng_element}"
          current_slng_path = slng_path
          if path[-6:] == '/wd:ID':
            name = '_'.join([x.replace('wd:','') for x in path.split('/')[-2:]]) 
            # if debug: print("Current WSDL Object:", json.dumps(current_wsdl_object, default=vars, indent=2))
            doc = current_wsdl_object.parent.parent.parent.documentation # Get Documentation of parent's parent's parent
            cardinality = current_wsdl_object.parent.parent.parent.cardinality # Get Cardinality of parent's parent's parent
            if cardinality in ['[0..*]', '[1..*]']:
              slng_name = re.sub(R'Type$', '', current_wsdl_object.parent.type)
              slng_table = current_wsdl_object.parent.parent.parent.type
            elif current_wsdl_object.name == 'IDType':
              slng_name = re.sub(R'Type$', '', current_wsdl_object.parent.type)
              slng_table = current_wsdl_object.parent.type
            else:
              slng_name = name
              slng_table = current_wsdl_object.parent.parent.parent.parent.name
            # if debug: print(name, cardinality, slng_name, slng_table, current_wsdl_object.name, current_wsdl_object.cardinality)
            slng_name = re.sub(R'[\W_]+', '', slng_name)
            if cardinality in ['[0..*]', '[1..*]']:
              current_slng_path = slng_path.parent / slng_name
            else:
              current_slng_path = slng_path.parent.parent / slng_name
          else:
            name = '_'.join([x.replace('wd:','') for x in path.split('/')[-1:]])
            doc = ele_type.find('xsd:annotation', ns).find('xsd:documentation', ns).text if ele_type.find('xsd:annotation', ns) is not None and ele_type.find('xsd:annotation', ns).find('xsd:documentation', ns) is not None else ''
            if cardinality in ['[0..*]', '[1..*]']:
              slng_name = re.sub(R'Type$', '', current_wsdl_object.parent.type)
              # Add the parent type to the slng path only in this case
              #print(F"SimpleElement - something to many: {current_slng_path} | {re.sub(R'[\W_]+', '', slng_name)}")
              current_slng_path /= re.sub(R'[\W_]+', '', slng_name)
            else:
              slng_name = name
            slng_table = current_wsdl_object.name
            slng_name = re.sub(R'[\W_]+', '', slng_name)
          slng_table = re.sub(R'([\W_]+|Type$)', '', slng_table)
          # Overrides
          override_table =  schema_overrides_table.get(slng_parent_type_element, '')
          override_column = schema_overrides_column.get(slng_parent_type_element, '')
          override_table_name = F"{override_table}.{override_column}" if override_table or override_column else None
          slng_orig_table_name = F"{slng_table}.{slng_name}" if override_table_name else None
          if override_table:
            slng_table_name = F"{override_table}.{(override_table + 'ID') if slng_name.endswith('ID') else (override_table + 'IDType') if slng_name.endswith('IDType') else slng_name}"
            current_slng_path = current_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
          elif override_column:
            slng_table_name = F"{slng_table}.{(override_column + 'ID') if slng_name.endswith('ID') else (override_column + 'IDType') if slng_name.endswith('IDType') else slng_name}"
            current_slng_path = current_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
          else:
            slng_table_name = F"{slng_table}.{slng_name}"
          fields.append((name, ext_type, doc, cardinality, path, type_path, current_slng_path, slng_table_name, slng_orig_table_name, slng_parent_type_element, slng_element, current_wsdl_object.parent.type, override_table_name, search_type ))
          # -----------------------------------
          # Do we have simpleContent Attributes
          # -----------------------------------
          search_type = "SimpleAttribute"
          ext_attribs = ext.findall('xsd:attribute', ns)
          slng_parent_type = current_wsdl_object.parent.parent.parent.parent.parent.type if current_wsdl_object.parent.parent.parent.parent.parent else current_wsdl_object.parent.parent.parent.parent.name
          slng_element = current_wsdl_object.parent.parent.parent.name
          element_type = current_wsdl_object.parent.parent.parent.type
          slng_parent_type_element = F"{slng_parent_type}|{slng_element}"
          for ext_attrib in ext_attribs:
            ext_doc = ext_attrib.find('xsd:annotation', ns).find('xsd:documentation', ns).text if ext_attrib.find('xsd:annotation', ns) is not None else ''
            ext_name = ext_attrib.get('name')
            slng_name = re.sub(R'[\W_]+', '', ext_name)
            slng_table = current_wsdl_object.name
            current_slng_path = slng_path / slng_name
            if path[-6:] == '/wd:ID':
              attrib_name = re_id.sub(R'\1ID\2' ,ext_attrib.get('name','').title())
              ext_name = path.split('/')[-2].replace('wd:','') + '_ID_' + attrib_name
              slng_name = ext_name
              if attrib_name.lower() in ["type", "parent_id", "parent_type"]:
                ext_doc = current_wsdl_object.parent.parent.parent.documentation # Get Documentation of parent's parent's parent
                cardinality = current_wsdl_object.parent.parent.parent.cardinality # Get Cardinality of parent's parent's parent
                if cardinality in ['[0..*]', '[1..*]']:
                  slng_name = re.sub(R'Type$', '', current_wsdl_object.parent.type) + attrib_name
                  slng_table = current_wsdl_object.parent.parent.parent.type
                else:
                  slng_table = current_wsdl_object.parent.parent.parent.parent.name
              elif attrib_name.lower() in ['system_id']:
                slng_name = ext_attrib.get('name')
              slng_name = re.sub(R'[\W_]+', '', slng_name)
              if cardinality in ['[0..*]', '[1..*]']:
                current_slng_path = slng_path.parent / slng_name
              else:
                current_slng_path = slng_path.parent.parent / slng_name
            if ext_attrib.get('type', '')[-11:] == 'Enumeration':
              ext_enum = self.get_type(ext_attrib.get('type').split(':')[-1])
              ext_attr_type = ', '.join([x.get('value') for x in ext_enum.findall('.//wd:enumeration', ns) if x.get('value') not in self.EXCLUDED_TYPES])
            elif not ext_attrib.get('type'):
              ext_attr_type = ', '.join([x.get('value') for x in ext_attrib.findall('.//wd:enumeration', ns) if x.get('value') not in self.EXCLUDED_TYPES])
            else:
              ext_attr_type = ext_attrib.get('type').split(':')[-1]
            slng_name = re.sub(R'[\W_]+', '', slng_name)
            slng_table = re.sub(R'([\W_]+|Type$)', '', slng_table)
            # Overrides
            override_table =  schema_overrides_table.get(slng_parent_type_element, '')
            override_column = schema_overrides_column.get(slng_parent_type_element, '')
            override_table_name = F"{override_table}.{override_column}" if override_table or override_column else None
            slng_orig_table_name = F"{slng_table}.{slng_name}" if override_table_name else None
            if override_table:
              slng_table_name = F"{override_table}.{(override_table + 'ID') if slng_name.endswith('ID') else (override_table + 'IDType') if slng_name.endswith('IDType') else slng_name}"
              current_slng_path = current_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
            elif override_column:
              slng_table_name = F"{slng_table}.{(override_column + 'ID') if slng_name.endswith('ID') else (override_column + 'IDType') if slng_name.endswith('IDType') else slng_name}"
              current_slng_path = current_slng_path.parent.parent / '/'.join(slng_table_name.split('.'))
            else:
              slng_table_name = F"{slng_table}.{slng_name}"
            fields.append((ext_name, ext_attr_type, ext_doc, cardinality, path + '@' + ext_attrib.get('name'), type_path / ext_attrib.get('type', '').split(':')[-1], current_slng_path, slng_table_name, slng_orig_table_name, slng_parent_type_element, slng_element, ext_attrib.get('type', '').split(':')[-1], override_table_name, search_type ))
        # -------------------------
        # Do we have complexContent
        # -------------------------
        if ele_type.find('xsd:complexContent', ns) is not None:
          ext = ele_type.find('xsd:complexContent', ns).find('xsd:extension', ns)
          ext_base = ext.get('base', '')
          slng_table = re.sub(R'([\W_]+|Type$)', '', current_wsdl_object.name)
          new_slng_path = (slng_path / slng_table) if slng_path.stem != slng_table else slng_path # slng_path if slng_path.stem == slng_table and len(slng_path.parts) == 2 else (slng_path / slng_table)
          if 'wd:' in ext_base:
            ext_fields = self.get_element_type_fields(type_name=ext_base.split(':')[-1], path=path, slng_path=new_slng_path, type_path=type_path/ext_base.split(':')[-1], parent=current_wsdl_object)
            fields.extend(ext_fields)
      except Exception as e:
        print(type(e), e)
        traceback.print_exc()
      finally:
        return fields
      
  def _get_common_substring(self, string_list):
    string_list = [F'_{x}_' for x in string_list] # Mark beginning and end of strings/words
    substring_counts={}
    for i in range(0, len(string_list)):
      for j in range(i+1,len(string_list)):
        string1 = string_list[i]
        string2 = string_list[j]
        match = difflib.SequenceMatcher(None, string1, string2).find_longest_match(0, len(string1), 0, len(string2))
        matching_substring=string1[match.a:match.a+match.size]
        if(matching_substring not in substring_counts):
          substring_counts[matching_substring]=1
        else:
          substring_counts[matching_substring]+=1
    # if debug: print(json.dumps(string_list, indent=2), json.dumps(substring_counts, indent=2), "-------------")
    max_match = max(substring_counts, key=substring_counts.get)
    common_substring = F"{'_'.join(max_match.split('_')[1:-1])}" # Keep full words at beginning and end
    return common_substring if substring_counts[max_match] / len(string_list) > 0.5 else ''
  
  def get_proposed_dcdd(self, operation_name):
    self.operation = operation_name
    operation_fields = self.get_element_type_fields(operation_name=operation_name)

    # Manipulate the Output
    columns = list(operation_fields[0]) #
    rows = operation_fields[1:] #
    name_col = columns.index('Name') #
    xpath_col = columns.index('Xpath') #
    etpath = columns.index('ETpath') #
    tmpath_col = columns.index('SLNGpath') #
    type_col = columns.index('Type') #

    modified_rows = rows.copy()
    # modified_rows = []

    # for r in rows:
    #   new_row = r.copy()
    #   if False:
    #     pass
    #   elif r[name_col] is not None:
    #     new_row[name_col] == r[name_col]
    #     modified_rows.append(new_row)
    #   else:
    #     modified_rows.append(new_row)

    # Proposed Name ---
    # Get dups (and only single instance of dups)
    seen = set() #
    dups = [x for x in [r[name_col] for r in modified_rows] if x in seen or seen.add(x)] #
    # print('dups:', dups)
    proposed_dup_changes = {} #

    for d in dups:
      # if debug: print("dup:", d)
      dup_xpaths = [r[xpath_col] for r in rows if r[name_col] == d] #

      if dup_xpaths[0].endswith('wd:ID'): #
        split_end = -2 #
      elif dup_xpaths[0].endswith('@type'): #
        split_end = -3 #
      else: #
        split_end = -1 #

      for i in range(-split_end+1,21):
        i_change = ['_'.join([y[:-5] if y.lower().endswith("_data") else y for y in re.split('/wd:|@', x)][-i:split_end]) for x in dup_xpaths] #
        ic_seen = set() #
        ic_dups = [x for x in i_change if x in ic_seen or ic_seen.add(x)] #
        
        if not any(ic_dups): #
          # print('dup:', d, 'ichange:',i_change)
          
          common_substring = self._get_common_substring(i_change) # 
          i_change = [x.replace(common_substring, '_') if common_substring else x for x in i_change] #
          # print('common:', common_substring, i_change)

          # Substitutions to always run
          for sub in self.ALWAYS_SUBS.items(): #
            i_change = [re.sub(*sub, x) for x in i_change] #

          # No Repeats
          for j in range(1,4): #
            i_change = ['_'.join([y for i,y in enumerate(x.split('_')) if (i == len(x.split('_')) or [y] != x.split('_')[i+j:i+j+1]) ]) for x in i_change] #
          # print('dup:', d, 'no repeats ichange:',i_change)

          for sub in self.ALWAYS_SUBS.items(): #
            sub_name = re.sub(*sub, d) #
          for sub in self.SHORT_SUBS.items(): #
            short_sub_name = re.sub(*sub, sub_name) #
          long_i_change = [x + '_' + sub_name if not x.endswith(sub_name) else x for x in i_change] #
          for i, lic in enumerate(long_i_change): #
            if len(lic) > 63: #
              for sub in self.SHORT_SUBS.items(): #
                lic = re.sub(*sub, lic) #
              long_i_change[i] = lic + '_' + short_sub_name #

          # print('dup:', d, 'long_i_change:', long_i_change)
          proposed_dup_changes.update({dup_xpaths[i]:x for i,x in enumerate(long_i_change)}) #
          # print('dup:', d, 'proposed_dup_changes:', proposed_dup_changes)
          
          break # No more duplicates, move along
    proposed = [proposed_dup_changes.get(r[xpath_col]) or r[name_col] for r in modified_rows] #
    # print('proposed:', proposed)

    for sub in self.ALWAYS_SUBS.items(): #
      proposed = [re.sub(*sub, p) for p in proposed] #
    proposed = [p.strip('_') for p in proposed] #
    for i, p in enumerate(proposed): #
      if len(p) > 63: #
        for sub in self.SHORT_SUBS.items(): #
          p = re.sub(*sub, p) #
        proposed[i] = p #
    proposed = [p[:63].rstrip('_') if len(p) > 63 else p for p in proposed] #

    # Proposed Type ---
    proposed_type = [r[type_col] for r in rows]
    for sub in self.TYPE_SUBS.items(): #
      proposed_type = [re.sub(*sub, pt) for pt in proposed_type] #
    
    # Map the ID_Type Types to the ID row
    # type_update = df['Proposed Type'].where(df['Name'].str.endswith('ID_Type')).dropna()
    # [b in a if a.endswith('ID_Type') else False for a,b in zip(df['Name'], df['Name'].shift(1).fillna(''))]
    # type_update = df['Proposed Type'].where([b in a if a.endswith('ID_Type') else False for a,b in zip(df['Name'], df['Name'].shift(1).fillna(''))]).dropna()
    # type_update.index -= 1
    # df['Proposed Type'].loc[type_update.index] = type_update
    # df.loc[type_update.index, 'Proposed Type'] = type_update
    proposed_type = [proposed_type[i+1] if i < len(rows)-1 and pt and rows[i+1][name_col].endswith('ID_Type') and rows[i][name_col] in rows[i+1][name_col] else pt for i,pt in enumerate(proposed_type)] #

    # Remove Descriptor if only thing in table
    rows =  [r for r in rows if not (r[tmpath_col].stem == 'Descriptor' and len([r2 for r2 in rows if r[tmpath_col].parent == r2[tmpath_col].parent]) == 1)] #

    # ('Name', 'Type', 'Documentation', 'Cardinality', 'Xpath', 'SLNGpath', 'SLNG_Table_Name', 'SLNG_Orig_Table_Name', 'Parent_Type|Element', 'Element', 'Element_Type', 'Override_Table_Name', 'Code_Search_Type')
    columns.insert(1, 'Proposed')
    columns.insert(3, 'Proposed Type')
    columns.append('parentKey')
    columns.append('isParent')
    rows = [
      [
        r[0], # 'Name',
        proposed[i], 
        r[1], # 'Type',
        proposed_type[i],
        r[2], # 'Documentation', 
        r[3], # 'Cardinality', 
        r[4].replace('@type', '@Type'), # 'Xpath', # Xpath manipulations
        str(r[5]), # 'ETpath - Convert to plain string (for JSON dumps)
        str(r[6]), # 'SLNGpath', # TMpath - Convert to plain string (for JSON dumps)
        r[7], # 'SLNG_Table_Name', 
        r[8], # 'SLNG_Orig_Table_Name', 
        r[9], # 'Parent_Type|Element', 
        r[10], # 'Element',
        r[11], # 'Element_Type',
        r[12], # 'Override_Table_Name', 
        r[13], # 'Code_Search_Type'
        F"{r[5].parent.parent.stem}_SLNG_ID" if r[5].parent.parent.stem else '', # SLNG Parent ID
        any(len(x.parts) > len(r[5].parts) for x in [r[tmpath_col] for r in rows] if str(x).startswith(str(r[5].parent))), # SLNG Table has Children
      ] 
      for i,r in enumerate(rows)
    ]
    self.data = {'columns': columns, 'rows':rows}
    return self.data
  
  def save_to_csv(self, path):
    # Write to File
    if self.data is not None: 
      with open(path, 'w', newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(self.data['columns'])
        csv_writer.writerows(self.data['rows'])

  def save_to_json(self, path, full_name=None, short_name=None):
    if self.data is not None:
      full_name = full_name or F"{self.operation}_DCDD"
      short_name = short_name or F"{self.operation}_DCDD"[:50]
      json_data = {
        "uuid": str(uuid.uuid4()), # Unique ID (would normall point to Smartsheet ID)
        "name": full_name, # Full/Long Name (used on tracking sheets)
        "short_name": short_name, # Short Name for limited character lengths (ie. Smartsheet)
        "full_sheet_id": "f4ke$h3et1d",
        "permalink": "https://app.smartsheet.com/sheets/f4ke$h3et1d",
        "areas": None, # Functional Areas (from the tracking sheet, so blank here)
        "metadata": {
          "Population Scope / Selection Criteria": None,
          "Notes": None,
          "PRIMARY TABLE": None,
          "SECONDARY TABLES": None,
          "JOIN LOGIC": None,
          "WHERE LOGIC": None,
          "REFERENCE TYPES": None,
          "MANUAL CODE TO RUN AFTER": None,
          "MANUAL CODE TO RUN PRIOR": None,
          "DECLARED VALUES": "@conversionDate = ''",
          "FULL NAME": full_name, # Operation + "_DCDD",
          "FUNCTIONAL AREA": None,
          "CATEGORY": None,
          "ORDER": None,
          "WEB SERVICE": self.web_service,
          "WEB SERVICE OPERATION": self.operation,
          "STANDARD SP": None,
          "PARAMETERS": None,
          "API VERSION": self.version,
        },
        "columns": [
          "WD Field Name",
          "csv File Name",
          "csv Header",
          "Required/Optional",
          "Type Value",
          "Sample Value",
          "Conversion Notes",
          "Field Description and Guidance",
          "SOURCETABLE.FIELD",
          "TRANSFORMATION LOGIC",
          "VALIDATIONS",
          "CATEGORY",
          "WS Description",
          "Cardinality",
          "XPATH",
          "ETPATH",
          "TMPATH"
        ],
        "rows": [],
      }

      # ('Name', 'Proposed', 'Type', 'Proposed Type', 'Documentation', 'Cardinality', 'Xpath', 'ETpath', 'SLNGpath', 'SLNG_Table_Name', 'SLNG_Orig_Table_Name', 'Parent_Type|Element', 'Element', 'Element_Type', 'Override_Table_Name', 'Code_Search_Type', 'parentKey', 'isParent')
      for r in self.data['rows']:
        if r[0].lower().endswith('_type'):
          req_opt = 'Reference'
        elif 'add_only' in r[0].lower() and r[3] == 'Boolean':
          req_opt = 'Do Not Populate'
        elif r[5].startswith('[1'):
          req_opt = 'Required'
        elif r[5].startswith('[0'):
          req_opt = 'Optional'
        else:
          req_opt = 'Do Not Populate'
        new_row = [
          r[0], None, r[1], req_opt, r[3], None, None, None, None, None, None, None, r[4], r[5], r[6], r[7], r[8]
        ]
        json_data['rows'].append(new_row)

      # json_data['rows'] = [[
      #   r[0], None, r[1], 'Required', r[3], None, None, None, None, None, None, None, r[4], r[5], r[6], r[7], r[8]
      # ] for r in self.data['rows']]

      with open(path, "w", encoding='utf-8') as f:
        f.write(json.dumps(json_data, indent=2))

  def save_to_upgraded_json(self, path, current_dcdd, full_name=None, short_name=None):
    if not self.data or not current_dcdd:
      return
    # print(current_dcdd)
    dcdd = current_dcdd
    # COLUMN INDEXES
    # print('columns:', dcdd['columns'])
    # columns: ['WD Field Name', 'csv File Name', 'csv Header', 'Required/Optional', 'Type Value', 'Sample Value', 'Conversion Notes', 'Field Description and Guidance', 'SOURCETABLE.FIELD', 'TRANSFORMATION LOGIC', 'VALIDATIONS', 'CATEGORY', 'WS Description', 'Cardinality', 'XPATH', 'ETPATH', 'TMPATH']

    # If ETPATH not in columns, add it
    if 'ETPATH' not in dcdd['columns']:
      missing_etpath = True
      dcdd['columns'].append('ETPATH')
    else: missing_etpath = False

    dcdd_columns = {c:i for i, c in enumerate(dcdd['columns'])}
    XPATH_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'XPATH'), None)
    ETPATH_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'ETPATH'), None)
    TMPATH_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'TMPATH'), None)
    NAME_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'WD Field Name'), None)
    HEAD_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'csv Header'), None)
    TYPE_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'Type Value'), None)
    DESC_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'WS Description'), None)
    CARD_IDX = next((dcdd_columns[c] for c in dcdd_columns if c == 'Cardinality'), None)
    dcdd_rows_by_xpath = {x[XPATH_IDX]: x for x in dcdd['rows']}

    wsdl_dcdd = self.data
    # COLUMN INDEXES
    # print('wsdl_columns:', wsdl_dcdd['columns'])
    # wsdl_columns: ['Name', 'Proposed', 'Type', 'Proposed Type', 'Documentation', 'Cardinality', 'Xpath', 'SLNGpath', 'SLNG_Table_Name', 'SLNG_Orig_Table_Name', 'Parent_Type|Element', 'Override_Table_Name', 'Code_Search_Type']
    wsdl_dcdd_columns = {c:i for i, c in enumerate(wsdl_dcdd['columns'])}
    WSDL_XPATH_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'Xpath'), None)
    WSDL_ETPATH_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'ETpath'), None)
    WSDL_TMPATH_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'SLNGpath'), None)
    WSDL_NAME_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'Name'), None)
    WSDL_HEAD_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'Proposed'), None)
    WSDL_TYPE_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'Proposed Type'), None)
    WSDL_DESC_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'Documentation'), None)
    WSDL_CARD_IDX = next((wsdl_dcdd_columns[c] for c in wsdl_dcdd_columns if c == 'Cardinality'), None)

    # Prep new_dcdd structure
    new_dcdd = {}
    new_dcdd['uuid'] = dcdd.get('uuid')
    new_dcdd['name'] = full_name or dcdd.get('name')
    new_dcdd['short_name'] = short_name or dcdd.get('short_name')
    new_dcdd['full_sheet_id'] = dcdd.get('full_sheet_id') or "f4keSh3et1d"
    new_dcdd['permalink'] = dcdd.get('permalink') or "https://app.smartsheet.com/sheets/f4keSh3et1d"
    new_dcdd['areas'] = dcdd.get('areas')
    new_dcdd['metadata'] = dcdd.get('metadata', {})
    new_dcdd['metadata']['API VERSION'] = self.version
    if full_name: new_dcdd['metadata']['FULL NAME'] = full_name
    new_dcdd['columns'] = dcdd['columns']
    new_dcdd['rows'] = []

    # START COMPARING
    dcdd_xpaths = [r[XPATH_IDX] for r in dcdd['rows']]
    wsdl_xpaths = [r[WSDL_XPATH_IDX] for r in wsdl_dcdd['rows']]

    dcdd_non_matching_xpaths = set(dcdd_xpaths) - set(wsdl_xpaths)
    dcdd_non_match_rows = [r for r in dcdd['rows'] if r[XPATH_IDX] in dcdd_non_matching_xpaths]
    dcdd_non_match_names = [x[NAME_IDX] for x in dcdd_non_match_rows]
    # print("Non-matching-names:", dcdd_non_match_names)


    for i, wsdl_row in enumerate(wsdl_dcdd['rows'], 1): # Start at 1 (no header)
      wsdl_row_xpath = wsdl_row[WSDL_XPATH_IDX]
      if not wsdl_row_xpath:
        continue
      # temp_row = dcdd_rows_by_xpath.get(wsdl_row_xpath)
      temp_rows = [r for r in dcdd['rows'] if r[XPATH_IDX] == wsdl_row_xpath]
      if temp_rows: # XAPTH matches (so name, header should still be good)
        for temp_row in temp_rows:
          # print(F'Row {i}: xpath in current DCDD')
          # Update with latest WSDL data
          if len(temp_rows) < 2: temp_row[TYPE_IDX] = wsdl_row[WSDL_TYPE_IDX] # Keep original type if multiple xpath matches
          temp_row[DESC_IDX] = wsdl_row[WSDL_DESC_IDX]
          temp_row[CARD_IDX] = wsdl_row[WSDL_CARD_IDX]
          if missing_etpath: temp_row.append(None) # temp filler
          temp_row[ETPATH_IDX] = wsdl_row[WSDL_ETPATH_IDX]
          temp_row[TMPATH_IDX] = wsdl_row[WSDL_TMPATH_IDX]
          new_dcdd['rows'].append(temp_row)
      else:
        no_match = True
        # See if we have unmatched xpaths in source
        if dcdd_non_match_rows:
          if wsdl_row[WSDL_NAME_IDX] in dcdd_non_match_names:
            if dcdd_non_match_names.count(wsdl_row[WSDL_NAME_IDX]) < 2:
              # print(F'Row {i}: No Xpath, but Yes Single Name -> Name: {wsdl_row[WSDL_NAME_IDX]}, XPATH: {wsdl_row[WSDL_XPATH_IDX]}')
              temp_row = next(row for row in dcdd_non_match_rows if row[NAME_IDX] == wsdl_row[WSDL_NAME_IDX]).copy()
              temp_row[TYPE_IDX] = wsdl_row[WSDL_TYPE_IDX]
              temp_row[DESC_IDX] = wsdl_row[WSDL_DESC_IDX]
              temp_row[CARD_IDX] = wsdl_row[WSDL_CARD_IDX]
              temp_row[XPATH_IDX] = wsdl_row[WSDL_XPATH_IDX] # Important
              if missing_etpath: temp_row.append(None) # temp filler
              temp_row[ETPATH_IDX] = wsdl_row[WSDL_ETPATH_IDX]
              temp_row[TMPATH_IDX] = wsdl_row[WSDL_TMPATH_IDX]
              new_dcdd['rows'].append(temp_row)
              no_match = False
            else: # multiple rows have the same name / wd header
              # print(wsdl_row[WSDL_NAME_IDX], 'COUNT:', dcdd_non_match_names.count(wsdl_row[WSDL_NAME_IDX]))
              # parse Xpath parts
              new_parts = pathlib.PurePosixPath(wsdl_row_xpath).parts
              # print('New Xpath Parts:', new_parts)
              matching_old_rows = [row for row in dcdd_non_match_rows if row[NAME_IDX] == wsdl_row[WSDL_NAME_IDX]]
              for m_old_row in matching_old_rows:
                old_parts = pathlib.PurePosixPath(m_old_row[XPATH_IDX] or '').parts
                # print('  Old Xpath Parts:', old_parts)
                add_diff = [x for x in new_parts if x not in old_parts]
                # print('Differences (added to new):', add_diff)
                # Only 1, not the field name, and not more than one in path
                if len(add_diff) == 1 and add_diff[0] != new_parts[-1] and new_parts.count(add_diff[0]) == 1: # probably have a single new table
                  # make sure beginning and end are the same
                  new_node_idx = new_parts.index(add_diff[0])
                  if new_parts[:new_node_idx] + new_parts[new_node_idx+1:] == old_parts: 
                    # print('  Matched (added table):', add_diff[0], '\n')
                    temp_row = m_old_row.copy()
                    temp_row[TYPE_IDX] = wsdl_row[WSDL_TYPE_IDX]
                    temp_row[DESC_IDX] = wsdl_row[WSDL_DESC_IDX]
                    temp_row[CARD_IDX] = wsdl_row[WSDL_CARD_IDX]
                    temp_row[XPATH_IDX] = wsdl_row[WSDL_XPATH_IDX] # Important
                    if missing_etpath: temp_row.append(None) # temp filler
                    temp_row[ETPATH_IDX] = wsdl_row[WSDL_ETPATH_IDX]
                    temp_row[TMPATH_IDX] = wsdl_row[WSDL_TMPATH_IDX]
                    no_match = False
                    break
                
                removed_diff = [x for x in old_parts if x not in new_parts]
                # print('Differences (removed from new):', removed_diff)
                # Only 1, not the field name, and not more than one in path
                if len(removed_diff) == 1 and removed_diff[0] != old_parts[-1] and old_parts.count(removed_diff[0]) ==1: # probably have a single removed table
                  # make sure beginning and end are the same
                  old_node_idx = old_parts.index(removed_diff[0])
                  if old_parts[:old_node_idx] + old_parts[old_node_idx+1:] == new_parts: 
                    # print('  Matched (removed table):', removed_diff[0], '\n')
                    temp_row = m_old_row.copy()
                    temp_row[TYPE_IDX] = wsdl_row[WSDL_TYPE_IDX]
                    temp_row[DESC_IDX] = wsdl_row[WSDL_DESC_IDX]
                    temp_row[CARD_IDX] = wsdl_row[WSDL_CARD_IDX]
                    temp_row[XPATH_IDX] = wsdl_row[WSDL_XPATH_IDX] # Important
                    if missing_etpath: temp_row.append(None) # temp filler
                    temp_row[ETPATH_IDX] = wsdl_row[WSDL_ETPATH_IDX]
                    temp_row[TMPATH_IDX] = wsdl_row[WSDL_TMPATH_IDX]
                    no_match = False
                    break

        if no_match:
          # print(F'Row {i}: Xpath NOT found -> Name: {wsdl_row[WSDL_NAME_IDX]} Proposed Header: {wsdl_row[WSDL_HEAD_IDX]} COUNT: {dcdd_non_match_names.count(wsdl_row[WSDL_NAME_IDX])} XPATH: {wsdl_row[WSDL_XPATH_IDX]}\n')
          # columns: ['WD Field Name', 'csv File Name', 'csv Header', 'Required/Optional', 'Type Value', 'Sample Value', 'Conversion Notes', 'Field Description and Guidance', 'SOURCETABLE.FIELD', 'TRANSFORMATION LOGIC', 'VALIDATIONS', 'CATEGORY', 'WS Description', 'Cardinality', 'XPATH', 'TMPATH']
          new_dcdd['rows'].append([wsdl_row[WSDL_NAME_IDX], None, wsdl_row[WSDL_HEAD_IDX], 'Do Not Populate', wsdl_row[WSDL_TYPE_IDX], None, None, None, None, None, None, None, wsdl_row[WSDL_DESC_IDX], wsdl_row[WSDL_CARD_IDX], wsdl_row[WSDL_XPATH_IDX], wsdl_row[WSDL_ETPATH_IDX] if WSDL_ETPATH_IDX else None, wsdl_row[WSDL_TMPATH_IDX]])

    # print(json.dumps(new_dcdd, indent=2))
    with open(path, "w", encoding='utf-8') as f:
      f.write(json.dumps(new_dcdd, indent=2))



if __name__ == "__main__":

  import datetime
  then = datetime.datetime.now()
  w = WSDL(web_service="Absence_Management", version="42.0")
  print("URL:", w._build_url())
  print(F"WSDL Name: ({w.get_name()}), Version: ({w.get_version()})")
  print("Operations:", w.list_all_operations())
  web_service_operation = 'Enter_Time_Off'
  print("Documentation:", w.get_operation_docs([web_service_operation]))
  print("Input Element:", w.get_operation_input_elements([web_service_operation]))
  print("Input Type:", w.get_operation_input_types([web_service_operation]))
  # print("Fields:", w.get_element_type_fields(operation_name=web_service_operation))
  print(w.get_proposed_dcdd(web_service_operation))
  print('Time:', datetime.datetime.now() - then)
  