import requests
import datetime
import re
import pathlib, zipfile
import xml.etree.ElementTree as ET
try:
  from .oauth import OAuth #, Workday 
except:
  from oauth import OAuth #, Workday

class Advanced_Load(object):

  def __init__(self, client_id=None, client_secret=None):
    self.client_id = client_id
    self.client_secret = client_secret
    self.oauth = OAuth(self.client_id, self.client_secret)

  def parse_xlsx(self, fname, use_row_dict=True):
    z = zipfile.ZipFile(fname)
    strings = [el.text for e, el in ET.iterparse(z.open('xl/sharedStrings.xml')) if el.tag.endswith('}t')]
    sheet_names = {next(y[1] for y in x.attrib.items() if y[0].endswith('}id')).replace('rId',''):x.attrib.get('name') for _, x in ET.iterparse(z.open(R'xl/workbook.xml')) if x.tag.endswith('sheet')}
    sheets = {}
    rows = []
    # Init element vars
    row = {} if use_row_dict else []
    value = ''
    # for sheet in [x for x in z.namelist() if re.search('xl/worksheets/sheet*.xml', x)]:
    for idx, sheet_name in sheet_names.items():
      sheet = F'xl/worksheets/sheet{idx}.xml'
      for e, el in ET.iterparse(z.open(sheet)):
        if el.tag.endswith('}v'): value = el.text # <v>84</v>
        if el.tag.endswith('}c'):  # <c r="A3" t="s"><v>84</v></c>
          if el.attrib.get('t') == 's': value = strings[int(value)]
          column_name = ''.join(x for x in el.attrib['r'] if not x.isdigit())  # AZ22
          if use_row_dict: row[column_name] = value
          else: row.append(value)
          value = ''
        if el.tag.endswith('}row'):
          rows.append(row)
          row = {} if use_row_dict else []
      sheets[sheet_name] = rows
    return sheets

  def process_loadset_folder(self, files_path):
    files_path = pathlib.Path(files_path)
    if not files_path.is_dir():
      raise Exception(F'Folder {files_path} does not exist!')
    set_def_file = files_path / 'Set Definition.xlsx'
    if not set_def_file.is_file():
      raise Exception('Missing file "Set Definition.xlsx"')
    sheets = self.parse_xlsx(set_def_file)
    if not 'Set Definition' in sheets:
      raise Exception('Missing sheet "Set Definition" from file.')
    
    set_def_iter = iter(sheets['Set Definition'])
    headers = next(set_def_iter)

    file_name_col = next(x for x in headers if 'File Name' in headers[x])
    impl_type_col = next(x for x in headers if 'Implementation Type' in headers[x])
    impl_comp_col = next(x for x in headers if 'Implementation Component' in headers[x])
    version_col   = next(x for x in headers if 'Web Service Version' in headers[x])
    
    content = []
    loadSetFiles = []
    order = 0
    for row in set_def_iter:
      file_name = row.get(file_name_col)
      impl_type = row.get(impl_type_col)
      impl_comp = row.get(impl_comp_col)
      version   = row.get(version_col)

      if file_name and (files_path / file_name).is_file():
        order += 1
        add_content = {
          "order": order,
          "fileName": file_name,
        }
        if impl_type: add_content['implementationType'] = impl_type
        if impl_comp: add_content['implementationComponent'] = impl_comp
        if version: add_content['version'] = version
        content.append(add_content)
        add_loadSetFile = {
          "sourceType": "fileUpload",
          "fileName": file_name,
          "id": "TBD"
        }
        loadSetFiles.append(add_loadSetFile)
      else:
        continue

    loadset_data = {
      "setName": F"My Advanced Load Set - {datetime.datetime.now()}",
      "setDefinition": {
        "sourceType": "json",
        "content": content
        # [{ "order": "a",
        #    "fileName": "Visa ID Types.xlsx",
        #    "implementationType": "Visa ID Types",
        #    "version": "v41.1" }]
      },
      "loadSetFiles": loadSetFiles
      # [{"sourceType": "fileUpload", "fileName": "Visa ID Types.xlsx", "id": "qwer-asdf-zxcv"}]
    }
    return loadset_data

  def upload_files(self, base_url, cc_tenant, token_type, token, loadset_data, files_dir, basic_auth=False, verify=True):
    files_dir = pathlib.Path(files_dir)
    for file_data in loadset_data['loadSetFiles']:
      if basic_auth:
        files_url = F"{base_url}/data-loader/implementation/v1alpha/files/{file_data['fileName']}"
      else:
        # https://[suv_id].workdaysuv.com:11714/impl/v1alpha/files  for HTTPS (might give TLS issues)
        # http://[suv_id].workdaysuv.com:11710/impl/v1alpha/files  for plain HTTP
        files_url = F"{base_url}/impl/v1alpha/files/{file_data['fileName']}"
      headers = {
        'Authorization': F"{token_type} {token}",
        'X-Tenant':cc_tenant,
        'Content-Type':'application/octet-stream', 
        'Originator': 'DAI Script'
      } 
      with open(files_dir / file_data['fileName'], 'rb') as f:
        data = f.read()
      r = requests.post(files_url, headers=headers, data=data, verify=verify)
      r.raise_for_status()
      try:
        rj = r.json()
        # print(rj)
        file_data['id'] = rj['id']
      except Exception as e:
        e.add_note('Error Uploading File or Retrieving ID')
        raise(e)

  def send_load_sets(self, base_url, cc_tenant, token_type, token, loadset_data, set_name=None, basic_auth=False, verify=False):
    if set_name:
      loadset_data['setName'] = set_name
    if basic_auth:
      loadsets_url = F'{base_url}/data-loader/implementation/v1alpha/loadsets'
    else:
      # https://[suv_id].workdaysuv.com:11714/impl/v1alpha/loadsets  for HTTPS (might give TLS issues)
      # http://[suv_id].workdaysuv.com:11710/impl/v1alpha/loadsets  for plain HTTP
      loadsets_url = F"{base_url}/impl/v1alpha/loadsets"
    headers = {
      'Authorization': F"{token_type} {token}",
      'X-Tenant': cc_tenant,
      # 'Content-Type':'application/json', 
      # 'Accept': 'application/json',
      'Originator': 'DAI Script'
    } 
    r = requests.post(loadsets_url, headers=headers, json=loadset_data, verify=verify)
    r.raise_for_status()
    return r.text
  
  def send_schemacontexts(self):
    #https://{{suvid}}.workdaysuv.com/data-loader/schemacontexts
    #X-Target-Tenant: {{tenant}}
    headers = {
      'Authorization': F"{token_type} {token}",
      # 'Content-Type':'application/json',
      'X-Tenant': cc_tenant,
      'X-Target-Tenant': F"{cc_tenant}"
    }
    # "implementationComponentId": "ba6ba85fb7621000079e11e0af7c0024",
    # "workdayVersion": "v43.0",
    # "showDetails": true,
    pass


if __name__ == "__main__":
  base_url = 'https://n-wjq4ghqftjvn53kni5hf8.workdaysuv.com'
  service_base_url = base_url
  cc_tenant = 'customercentral'
  ccs_username = 'ccs' # CC Security Admin
  ccs_password = '4y5DZ+PmBMcqTgLa'
  username = 'ccu' # CC User / Implementer
  password = ccs_password
  client_name = F'DAI AL API Client - {datetime.datetime.now()}'
  redirect_uri = 'https://127.0.0.1/'

  basic_auth = True

  client_id = None
  client_secret = None
  # client_id = 'ZGIzNjAxYjUtN2RhMC00ODkwLTgwYTMtZDJlYTUwNzNlYTI5'
  # client_secret = 'ot6pt4p59khrl085ev0ia2gv437a5dirgonnzwlas24i6e9m1265a200534xdwe5h8o2ngg7lavfnr1pj7t4bdn9awydbkr4kfx'

  al = Advanced_Load(client_id, client_secret)

  # current_dir = pathlib.Path(__file__).parent
  # files_dir = current_dir / 'files'
  files_dir = pathlib.Path.home() / 'Downloads' / 'hcm_al_set'

  # Enable OAuth2.0 Clients
  # try:
  #   al.oauth.enable_oauth_clients(base_url, cc_tenant, ccs_username, ccs_password)
  # except Exception as e:
  #   e.add_note('Error enabling OAuth 2.0 Clients')
  #   raise(e)
  # print('OAuth 2.0 Clients Enabled')

  # Register API Client
  if not basic_auth and not client_id:
    client_id, client_secret = al.oauth.register_cc_api_client(base_url, cc_tenant, ccs_username, ccs_password, client_name, redirect_uri)
    print(client_id, client_secret)
  
  # Get Token
  if basic_auth:
    token_type, token = al.oauth.get_cc_auth_token_basic(base_url, cc_tenant, username, password)
  else:
    token_type, token = al.oauth.get_cc_auth_token(base_url, service_base_url, cc_tenant, client_id, client_secret, username, password)
  print(token_type, token)

  # AL Loadsets API call  
  # loadset_data = al.process_loadset_folder(files_dir)
  # print(loadset_data)

  # al.upload_files(base_url, cc_tenant, token_type, token, loadset_data, files_dir, basic_auth, verify=True if basic_auth else False)
  # print(loadset_data)

  loadset_data = {
    "setName": F"My Advanced Load Set - {datetime.datetime.now()}",
    "setDefinition": {
      "sourceType": "json",
      "content": [
        {
          "order": "a",
          "implementationType": "Locations",
          "implementationComponent": "Locations",
          "version": "v43.0",
          "directives": [
            {
              "type": "DENORMALIZE",
              "elementType": "Compensation_Change_DataType",
              "hiddenElementNames": [
                "Allowance_Plan_Data",
                "Bonus_Plan_Data",
                "Calculated_Plan_Data",
                "Commission_Plan_Data",
                "Merit_Plan_Data",
                "Period_Salary_Plan_Data",
                "Remove_Plan_Data",
                "Stock_Plan_Data",
                "Unit_Allowance_Plan_Data",
                "Unit_Salary_Plan_Data"
              ]
            }
          ]
        }
      ]
    },
  }

  # {
  #   "setName": "Base Pay 4",
  #   "setDefinition": {
  #     "sourceType": "json",
  #     "content": [
  #       {
  #         "order": "a",
  #         "implementationType": "Request Compensation Change",
  #         "implementationComponent": "Request Compensation Change",
  #         "version": "v43.0",
  #         "directives": []
  #       }
  #     ]
  #   }
  # }

  r = al.send_load_sets(base_url, cc_tenant, token_type, token, loadset_data, None, basic_auth, verify=True if basic_auth else False)
  print(r)