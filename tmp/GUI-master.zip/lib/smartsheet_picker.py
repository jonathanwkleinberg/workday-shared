import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import sys, getpass
import webbrowser
import base64
try:
  from .smartsheet_lib import SmartsheetLib
  from .constants import raw_wd_ico_png
except:
  from smartsheet_lib import SmartsheetLib
  from constants import raw_wd_ico_png
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent

class Smartsheet_Picker(object):
  result = None
  # root_tree = []

  def __init__(self, parent, ss_type='folder', x_y=None):
    self.ss_type = ss_type
    self.ss_types = ['folder', 'workspace', 'home'] if ss_type == 'folder' else ['sheet']
    if not all([parent.vars.get('ss_token')]):
      messagebox.showerror("Error", F"Missing Smartsheet Token")
      return
    self.ss = SmartsheetLib( token=parent.vars['ss_token'].get() )

    self.top = tk.Toplevel(parent)
    self.top.withdraw()
    self.photo = tk.PhotoImage(data=base64.b64decode(raw_wd_ico_png))
    self.top.iconphoto(False, self.photo)
    self.top.grab_set() # Disable root/parent window interaction
    self.top.columnconfigure(0, weight=1)
    self.top.rowconfigure(0, weight=1)
    # self.top.rowconfigure(3, weight=1)

    self.Frame = ttk.Frame(self.top)
    self.Frame.grid(row=0, column=0, sticky=tk.NSEW)
    self.Frame.columnconfigure(0, weight=1)
    self.Frame.rowconfigure(1, weight=1)

    topLabel = tk.Label(self.Frame, text=F' -- Select a {'Sheet' if ss_type=='sheet' else 'Folder'} -- ', font=("-size", 15, "-weight", "bold"))
    topLabel.grid(row=0, column=0, columnspan=2, padx=5, pady=5, sticky=tk.NSEW)

    self.sizegrip = tk.ttk.Sizegrip(self.Frame)
    self.sizegrip.grid(row=4, column=1, padx=(0, 5), pady=(0, 5), sticky=tk.SE)

    # Y Scrollbar
    self.y_scrollbar = ttk.Scrollbar(self.Frame)
    self.y_scrollbar.grid(row=1, column=1, padx=7, pady=7, sticky=tk.NS)
    # X Scrollbar
    self.x_scrollbar = ttk.Scrollbar(self.Frame, orient=tk.HORIZONTAL)
    self.x_scrollbar.grid(row=2, column=0, padx=7, pady=7, sticky=tk.EW)
    
    # Treeview
    self.treeview = ttk.Treeview(
      self.Frame,
      selectmode="browse",
      yscrollcommand=self.y_scrollbar.set,
      xscrollcommand=self.x_scrollbar.set,
      columns=(1, 2),
      height=10,
    )
    self.treeview.grid(row=1, column=0, padx=5, pady=5, sticky=tk.NSEW)

    self.y_scrollbar.config(command=self.treeview.yview)
    self.x_scrollbar.config(command=self.treeview.xview)

    # default horizontal scroll is 1 unit (1 pixel)
    self.treeview.bind('<Shift-MouseWheel>', lambda e: e.widget.xview_scroll(int(e.delta/120)*-30, "units"))

    # enable button if selection is an SUV (and not a project/pool)
    self.treeview.bind('<<TreeviewSelect>>', lambda e: [self.select_button.config(state=tk.NORMAL) if any(sst in self.treeview.item(self.treeview.selection()[0], 'tags') for sst in self.ss_types) else self.select_button.config(state=tk.DISABLED)])

    # load children (if any)
    self.treeview.bind('<<TreeviewOpen>>', self.item_open)

    # Binding
    self.treeview.bind('<ButtonRelease-1>', self.tree_left_click, add="+")
    self.treeview.bind("<Motion>", self.hand1_cursor_on)
    self.treeview.bind("<Leave>", self.cursor_off)
    # self.tabs[t]['treeview'].bind("<ButtonRelease-3>", lambda e: None)
    self.treeview.bind("<ButtonRelease-2>" if MAC_OS else "<ButtonRelease-3>", self.tree_right_click)
    self.treeview.bind("<Control-ButtonRelease-1>", self.tree_right_click)
    # self.treeview.bind('<Control-a>', lambda e: None)
    self.treeview.bind('<Control-c>', lambda e:[self.copy_tree_selection_to_clipboard(e.widget)])

    # Treeview columns
    self.treeview.column("#0", anchor="w", width=240, stretch=False)
    self.treeview.column(1, anchor="w", width=120, stretch=False)
    self.treeview.column(2, anchor="w", width=120, stretch=False)

    # Treeview headings
    self.treeview.heading("#0", text="Name", anchor="center")
    self.treeview.heading(1, text="ID", anchor="center")
    self.treeview.heading(2, text="Link", anchor="center")

    # Populate Treeview
    self.refresh_tree()

    # Buttons
    self.button_frame = ttk.Frame(self.Frame)
    self.button_frame.grid(row=3, column=0, columnspan=2, sticky=tk.NSEW)
    self.button_frame.columnconfigure(0, weight=1)
    self.button_frame.columnconfigure(1, weight=1)

    self.select_button = ttk.Button(self.button_frame, text='Select', command=self.send_selection, state=tk.DISABLED)
    self.select_button.grid(row=0, column=0, padx=5, pady=5)

    self.cancel_button = ttk.Button(self.button_frame, text='Cancel', command=self.top.destroy)
    self.cancel_button.grid(row=0, column=1, padx=5, pady=5)
    
    # Set a minsize for the window, and place it in the middle
    self.top.update()
    # self.top.update_idletasks()
    # parent.update_idletasks()
    # parent.update()
    self.top.minsize(self.top.winfo_width(), self.top.winfo_height())
    if not x_y:
      x_cordinate = int((self.top.winfo_screenwidth() / 2) - (self.top.winfo_width() / 2))
      y_cordinate = int((self.top.winfo_screenheight() / 2) - (self.top.winfo_height() / 2)) - 20
    else:
      x, y = x_y
      x_cordinate = x - int(self.top.winfo_width() / 2)
      y_cordinate = y - int(self.top.winfo_height() / 2) - 20
    self.top.geometry("+{}+{}".format(x_cordinate, y_cordinate))

    self.top.deiconify()

  def send_selection(self):
    iid = self.treeview.selection()[0]
    item = self.treeview.item(iid)
    # print(self.treeview.selection()[0])
    if item['values']:
      selection = {'id':item['values'][0], 'type': [x for x in item['tags'] if x not in ['Unloaded', 'Loaded']][0]}
      self.result = selection
      self.top.destroy()

  def refresh_tree(self, parent=None):
    # print("parent:", parent)
    self.treeview.delete(*self.treeview.get_children(parent))
    parent_tags = self.treeview.item(parent, 'tags') if parent else None
    # print("parent_tags:", parent_tags)
    parent_type = [x for x in parent_tags if x not in ['Unloaded', 'Loaded']][0] if parent_tags else None
    # print("parent_type:", parent_type)
    ss_data = ss_sheet_data = []
    try:
      if not parent:
        ss_data = self.ss.get_root_tree()
      else:
        ss_data = self.ss.get_tree_folders(parent, parent_type)
        if self.ss_type == 'sheet':
          ss_data.extend(self.ss.get_tree_sheets(parent, parent_type))
    except Exception as e:
      messagebox.showerror("Error", e)
      return
    # Define treeview data
    #(ParentId, Id, Name, ("Value 1", "Value 2")),
    treeview_data = [(parent if parent else '', x['id'], x['name'], (x['id'], x['permalink']), (x['type'], 'Unloaded' if x['type'] in ['workspace', 'folder', 'home'] else None)) for x in ss_data]
    # Add "Loading ..." children
    treeview_data.extend([(x['id'], F"{x['id']}-Loading", "Loading ...", (), ()) for x in ss_data if x['type'] in ['workspace', 'folder', 'home']])

    self.insert_tree_data(treeview_data)
    
  def insert_tree_data(self, treeview_data):
    # Insert treeview data
    # treeview_data = [
    #     ("", 1, "Parent", ("Item 1", "Value 1"), ('tag1', 'tag2')),
    #     (1, 2, "Child", ("Subitem 1.1", "Value 1.1"), ('tag1', 'tag2')),
    # ]
    for item in treeview_data:
      self.treeview.insert(
        parent=item[0], index="end", iid=item[1], text=item[2], values=item[3], tags=item[4]
      )
      # if item[0] == "":
      #   self.treeview.item(item[1], open=True)  # Open top parents
  
  def item_open(self, event):
    iid = self.treeview.selection()[0]
    item = self.treeview.item(iid)
    # print(current_selection)
    if 'Unloaded' in item.get('tags'):
      self.refresh_tree(item['values'][0])
      tags = list(item.get('tags'))
      tags.remove('Unloaded')
      self.treeview.item(iid, tags=tags)

  def hand1_cursor_on(self, event):
    tree = event.widget  # get the treeview widget
    if tree.identify_region(event.x, event.y) != 'cell':
      tree.config(cursor='')
      return
    if tree.identify_column(event.x) != "#2":
      tree.config(cursor='')
      return
    values = tree.item(tree.identify('item', event.x, event.y))['values']
    if len(values) > 0 and values[0]:
      tree.config(cursor='hand1')
    else:
      tree.config(cursor='')
  
  def cursor_off(self, event):
    event.widget.config(cursor='')

  def tree_left_click(self, event):
    tree = event.widget  # get the treeview widget
    tree_region = tree.identify_region(event.x, event.y)
    tree_column = tree.identify_column(event.x)
    # tree_column_idx = int(tree_column[1:])
    item = tree.identify('item', event.x, event.y)
    # print(tree_region, tree_column, item)
    # Open Link
    if tree_region == 'cell' and tree_column == "#2":
      values = tree.item(item)['values']
      if len(values) > 1 and values[1]:
        webbrowser.open_new_tab(values[1])  # open the link in a browser tab
    # Filter Entry
    if tree_region == 'heading' and tree_column == "#0":
      tree_offset = (tree.winfo_x(), tree.winfo_y()) # Get offset from parent 
      if len(tree.get_children()) < 1:
        return
      # print(tree.yview())
      # first_item = tree.get_children()[0]
      # column_bbox = tree.bbox(first_item, column=tree_column)
      column_bbox = next(tree.bbox(x, column=tree_column) for x in tree.all_children if tree.bbox(x, column=tree_column))
      col_width = tree.column(tree_column, 'width')
      entry_filter = tk.ttk.Entry(tree.master, width=col_width, textvariable=tree.filter) # width=column_bbox[2]
      # entry_edit.edit_column_idx = column_idx
      # entry_edit.edit_item_iid = iid
      # entry_edit.insert(0, text)
      entry_filter.select_range(0, tk.END)
      entry_filter.focus()
      entry_filter.bind("<FocusOut>", lambda e: [e.widget.destroy()])
      entry_filter.bind("<Return>", lambda e: [e.widget.destroy()])
      entry_filter.place(x=tree_offset[0] + 5, y=tree_offset[1] + column_bbox[1] - column_bbox[3] - 4, w=col_width, h=column_bbox[3] + 7) # x=tree_offset[0] + column_bbox[0], w=column_bbox[2]

  def tree_right_click(self, event):
    tree = event.widget
    if tree.identify_region(event.x, event.y) not in ['tree', 'cell']:
      return
    item = tree.identify('item', event.x, event.y)
    if item not in tree.selection():
      tree.selection_set(item)
    # print(tree.selection())
    has_multi = True if len(tree.selection()) > 1 else False
    menu = tk.Menu(tree)
    menu.add_command(label=F"Copy Item{'s' if has_multi else ''}", command=lambda:[self.copy_tree_selection_to_clipboard(tree)])
    menu.add_separator()
    menu.add_command(label="Copy ID", command=lambda: [
      tree.clipboard_clear(),
      tree.clipboard_append('\n'.join(tree.selection()))
    ]), 
    if not has_multi and len(tree.selection()) > 0 and len(tree.item(tree.selection()[0])['values']) > 1:
      menu.add_separator()
      menu.add_command(label="Copy Link", command=lambda: [
        tree.clipboard_clear(), 
        tree.clipboard_append(tree.item(tree.selection()[0])['values'][1])
      ]), 
      menu.add_command(label="Open Link", command=lambda: [
        webbrowser.open_new_tab(tree.item(tree.selection()[0])['values'][1])
      ]), 
    menu.post(event.x_root, event.y_root)

  def copy_tree_selection_to_clipboard(self, tree):
    tree.clipboard_clear(), 
    tree.clipboard_append('\n'.join('\t'.join([item, tree.item(item, 'text').strip()] + [str(x) for x in tree.item(item, 'values')] + list(tree.item(item, 'tags'))) for item in tree.selection())),

if __name__ == "__main__":
  root = tk.Tk()
  root.title("Smart Sheet Picker")
  root.geometry('360x240')

  # Simply set the theme
  root.tk.call("source", "../themes/Azure/themes.tcl")
  root.tk.call("set_theme", "azure-dark")

  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  root.vars = {'ss_token':tk.StringVar(value=dict_config.get('ss_token'))}

  def onClick(ss_type='folder'):
    ssp = Smartsheet_Picker(root, ss_type)
    root.wait_window(ssp.top)
    if ssp.result:
      # selectLabel.config(text = pp.result)
      selectLabel.configure(state=tk.NORMAL)
      selectLabel.delete("1.0", tk.END)
      selectLabel.insert(tk.END, json.dumps(ssp.result, indent=2))
      selectLabel.configure(state=tk.DISABLED)

  mainLabel = tk.Label(root, text='Smartsheet Picker Demo')
  mainLabel.pack()

  FolderButton = ttk.Button(root, text='Select Folder', command=onClick)
  FolderButton.pack()
  SheetButton = ttk.Button(root, text='Select Sheet', command=lambda: onClick('sheet'))
  SheetButton.pack()

  selectLabel = tk.Text(root, wrap=tk.WORD, highlightthickness=0, relief=tk.FLAT, font=("-size", 15, "-weight", "bold"), state=tk.DISABLED)
  selectLabel.bind("<1>", lambda e: e.widget.focus_set())
  selectLabel.pack(fill=tk.BOTH, expand=True)

  if not sys.flags.interactive:
    root.mainloop()
  