import tkinter as tk
from tkinter import ttk
from idlelib import tooltip
import uuid
import sys
from pathlib import Path
import platform

MAC_OS = platform.system() == 'Darwin'

CurrentPath = Path(__file__).parent

class StyledHovertip(tooltip.OnHoverTooltipBase):
  def __init__(self, anchor_widget, text, hover_delay=1000):
    super().__init__(anchor_widget, hover_delay=hover_delay)
    self.text = text
  def showcontents(self):
    # label = ttk.Label(self.tipwindow, text=self.text, justify=tk.LEFT, background="#ffffe0", relief=tk.SOLID, borderwidth=1)
    label = ttk.Label(self.tipwindow, text=self.text, justify=tk.LEFT, relief=tk.SOLID, borderwidth=1)
    label.pack()

class VerticalScrolledFrame(tk.ttk.Frame):
  """A pure Tkinter scrollable frame.
  * Use the 'interior' attribute to place widgets inside the scrollable frame.
  * Construct and pack/place/grid normally.
  * This frame only allows vertical scrolling.
  """
  def __init__(self, parent, *args, **kw):
    tk.ttk.LabelFrame.__init__(self, parent, *args, **kw)

    # Create a canvas object and a vertical scrollbar for scrolling it.
    vscrollbar = tk.ttk.Scrollbar(self, orient=tk.VERTICAL)
    # vscrollbar.pack(fill=tk.Y, side=tk.RIGHT, expand=tk.FALSE)
    vscrollbar.grid(column=1, row=0, sticky=tk.NSEW)
    canvas = tk.Canvas(self, yscrollcommand=vscrollbar.set, bd=0, highlightthickness=0) #, bg='black', 
    # canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=tk.TRUE)
    canvas.grid(column=0, row=0, sticky=tk.NSEW)
    vscrollbar.config(command=canvas.yview)

    def toggle_scrollbar():
      # print(('f',self.winfo_height(),self.winfo_width()), ('i',interior.winfo_height(),interior.winfo_width()), ('c',canvas.winfo_height(),canvas.winfo_width()))
      if self.winfo_height() <= interior.winfo_height():
        vscrollbar.grid()
      else:
        vscrollbar.grid_remove()

    # Reset the view
    canvas.xview_moveto(0)
    canvas.yview_moveto(0)

    # Create a frame inside the canvas which will be scrolled with it.
    self.interior = interior = tk.ttk.Frame(canvas)
    interior_id = canvas.create_window(0, 0, window=interior, anchor=tk.NW)

    # Track changes to the canvas and frame width and sync them,
    # also updating the scrollbar.
    def _configure_interior(event):
      toggle_scrollbar()
      # Update the scrollbars to match the size of the inner frame.
      canvas.config(scrollregion=interior.bbox("all"))
      if interior.winfo_reqwidth() != canvas.winfo_width():
        # Update the canvas's width to fit the inner frame.
        canvas.config(width=interior.winfo_reqwidth())
      # print("Interior:", "int -", interior.bbox("all"), "can -", canvas.bbox("all"), "sel -", self.bbox("all"), self.winfo_height())
    interior.bind('<Configure>', _configure_interior)

    def _configure_canvas(event):
      toggle_scrollbar()
      if interior.winfo_reqwidth() != canvas.winfo_width():
        # Update the inner frame's width to fill the canvas.
        canvas.itemconfigure(interior_id, width=canvas.winfo_width())
      # print("Canvas:", "int -", interior.bbox("all"), "can -", canvas.bbox("all"), "sel -", self.bbox("all"), self.winfo_height())
    canvas.bind('<Configure>', _configure_canvas)

    def _configure_self(event):
      toggle_scrollbar()
      if interior.winfo_height() > canvas.winfo_height():
        canvas.config(height=interior.winfo_height())
      # print("Self:", "int -", interior.bbox("all"), "can -", canvas.bbox("all"), "sel -", self.bbox("all"), self.winfo_height())
    self.bind('<Configure>', _configure_self)

    def _bound_to_mousewheel(event):
      canvas.bind_all("<MouseWheel>", _on_mousewheel)
    def _unbound_to_mousewheel(event):
      canvas.unbind_all("<MouseWheel>")
    def _on_mousewheel(event):
      if self.winfo_height() < interior.winfo_height():
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    # canvas.bind_all("<MouseWheel>", _on_mousewheel)
    interior.bind('<Enter>', _bound_to_mousewheel)
    interior.bind('<Leave>', _unbound_to_mousewheel)


class TreeviewEdit(tk.ttk.Treeview):
  """A JSON Treeview Editor
  * Construct and pack/place/grid normally.
  """
  expand_all = False
  def __init__(self, master, **kw):
    super().__init__(master, **kw)

    self.popup_menu = tk.Menu(self, tearoff=0)

    self.bind("<Double-1>", self.on_double_click)
    self.bind("<Button-2>" if MAC_OS else "<Button-3>", self.popup)
    self.bind("<Control-Button-1>", self.popup)
    self.bind("<ButtonRelease-1>", self.button_release)
    self.bind("<KeyRelease-Delete>", self.selection_delete)
    self.bind("<Control-a>", self.select_all)
    self.bind("<Escape>", self.unselect_all)

  def unselect_all(self, event):
    if self.selection(): self.selection_remove(self.selection())
    
  def button_release(self, event):
    region = self.identify_region(event.x, event.y)
    if region in ["nothing"]:
      self.selection_remove(self.selection())
    elif region in ['heading']:
      if self.identify_column(event.x) == "#0":
        self.toggle_expand_all()

  def toggle_expand_all(self, parent=None):
    if not parent: self.expand_all = False if self.expand_all else True
    for child in self.get_children(parent):
      self.item(child, open=self.expand_all)
      self.toggle_expand_all(child)

  def select_all(self, event, parent=None):
    for child in self.get_children(parent):
      self.selection_add(child)
      self.select_all(event, child)

  def selection_delete(self, event):
    if self.selection():
      self.delete_item(self.selection())
  
  def on_double_click(self, event):
    region = self.identify_region(event.x, event.y)
    if region not in ["tree", "cell"]:
      return
    column = self.identify_column(event.x)
    column_idx = int(column[1:])
    iid = self.focus()
    values = self.item(iid)
    if column == "#0":
      # don't edit index name of lists
      if self.parent(iid) and str(self.item(self.parent(iid)).get("text"))[-2:] in ["[]"]:
        return
      # strip the list/dict indicator
      text = values.get("text") if str(values.get("text"))[-2:] not in ["[]", "{}"] else values.get("text")[:-2]
    else:
      if len(self.get_children(iid)) > 0 or str(values.get("text"))[-2:] in ["[]", "{}"]:
        return
      values = values.get("values")
      text = values[column_idx-1] if values and len(values) >= column_idx else ''
    self_offset = (self.winfo_x()+1, self.winfo_y()+1) # Get offset from parent and add to account for border
    column_bbox = self.bbox(iid, column)
    entry_edit = tk.ttk.Entry(self.master, width=column_bbox[2])
    entry_edit.edit_column_idx = column_idx
    entry_edit.edit_item_iid = iid
    entry_edit.insert(0, text)
    entry_edit.select_range(0, tk.END)
    entry_edit.focus()
    entry_edit.bind("<FocusOut>",self.on_focus_out)
    entry_edit.bind("<Return>", self.on_enter_pressed)
    entry_edit.place(x=self_offset[0] + column_bbox[0], y=self_offset[1] + column_bbox[1], w=column_bbox[2], h=column_bbox[3])

  def popup(self, event):
    region = self.identify_region(event.x, event.y)
    # print(region)
    if region not in ["tree", "cell", "nothing"]:
      return
    iid = self.identify_row(event.y)
    if iid or region == 'nothing':
      self.selection_set(iid)
      item = self.item(iid)
      item_idx = self.index(iid)
      item_type = 'array/list' if str(item['text'])[-2:] == "[]" else 'object/dict' if str(item['text'])[-2:] == "{}" else 'value'
      has_children = len(self.get_children(iid)) > 0
      parent = self.parent(iid)
      parent_text = self.item(parent)['text'] if parent else None
      parent_type = 'array/list' if parent and str(parent_text)[-2:] == "[]" else 'object/dict'
    else:
      return
    self.popup_menu.delete(0, tk.END)
    if iid:
      self.popup_menu.add_cascade(label="Add Item Below Selection",
        menu=(item_menu := tk.Menu(self.popup_menu, tearoff=0))
      )
      item_menu.add_command(label='Key/Value Pair' if parent_type == 'object/dict' else 'Value', command=lambda: self.add_item(parent, item_idx+1, 'kv'))
      item_menu.add_command(label='Array/List', command=lambda: self.add_item(parent, item_idx+1, 'list'))
      item_menu.add_command(label='Object/Dict', command=lambda: self.add_item(parent, item_idx+1, 'dict'))
    if has_children or item_type in ['array/list', 'object/dict'] or not iid:
      self.popup_menu.add_cascade(label=F"Add to Selected {item_type.title()}" if iid else "Add to Root Object",
        menu=(item_menu := tk.Menu(self.popup_menu, tearoff=0))
      )
      item_menu.add_command(label='Key/Value Pair' if item_type == 'object/dict' or not iid else 'Value', command=lambda: self.add_item(iid, 0 if iid else tk.END, 'kv'))
      item_menu.add_command(label='Array/List', command=lambda: self.add_item(iid, 0 if iid else tk.END, 'list'))
      item_menu.add_command(label='Object/Dict', command=lambda: self.add_item(iid, 0 if iid else tk.END, 'dict'))  

    if iid: self.popup_menu.add_command(label="Delete Selected Item", command=lambda: self.delete_item(iid))
    if not has_children:
      self.popup_menu.add_cascade(label="Update Tag",
        menu=(tag_menu := tk.Menu(self.popup_menu, tearoff=0))
      )
      tag_menu.add_command(label=F"none {'✔️' if not item['tags'] else ''}", command=lambda: [self.update_tag(iid, '')])
      tag_menu.add_command(label=F"bool {'✔️' if 'bool' in item['tags'] else ''}", command=lambda: [self.update_tag(iid, 'bool')])
      tag_menu.add_command(label=F"str {'✔️' if 'str' in item['tags'] else ''}", command=lambda: [self.update_tag(iid, 'str')])
      tag_menu.add_command(label=F"num {'✔️' if 'num' in item['tags'] else ''}", command=lambda: [self.update_tag(iid, 'num')])
      tag_menu.add_command(label=F"null {'✔️' if 'null' in item['tags'] else ''}", command=lambda: [self.update_tag(iid, 'null')])
    if iid: self.popup_menu.add_command(label="Duplicate Selected Item", command=lambda: [self.duplicate_item(iid, item_type, item_idx, parent)])

    self.popup_menu.post(event.x_root, event.y_root)

  def add_item(self, parent=None, index=None, item_type=None):
    parent_text = self.item(parent)['text'] if parent else None
    parent_type = 'array/list' if parent and str(parent_text)[-2:] == "[]" else 'object/dict'
    uid = uuid.uuid4()
    if item_type in [None, 'kv']:
      self.insert(parent,index,uid,text=F'NewItem')
      if parent_type == 'array/list':
        self.renumerate_children(parent)
      self.item(parent, open=True)
      self.selection_set(uid)
    else:
      insert_text = F'New{"List[]" if item_type == "list" else "Object{}"}'
      self.insert(parent,index,uid,text=insert_text, open=True)
      if parent_type == 'array/list':
        self.renumerate_children(parent)
      child_uid = uuid.uuid4()
      self.insert(uid,tk.END,child_uid,text="0" if item_type == "list" else "NewItem")
      self.selection_set((uid,child_uid))

  def renumerate_children(self, parent):
    if self.item(parent)['text'][-2:] != "[]": return
    for i, child in enumerate(self.get_children(parent)):
      if str(self.item(child)['text'])[-2:] == "[]":
        i = str(i)+"[]"
      if str(self.item(child)['text'])[-2:] == "{}":
        i = str(i)+"{}"
      self.item(child, text=i)

  def delete_item(self, iids):
    if not isinstance(iids, tuple):
      iids = (iids,)
    if tk.messagebox.askyesno(title="Confirmation", message=F"Are you sure you want to delete {'this item' if len(iids) < 2 else 'these items'}?"):
      for iid in iids:
        if self.exists(iid):
          parent = self.parent(iid)
          parent_text = self.item(parent)['text'] if parent else None
          parent_type = 'array/list' if parent and str(parent_text)[-2:] == "[]" else 'object/dict'
          self.delete(iid)
          if parent_type == 'array/list':
            self.renumerate_children(parent)

  def duplicate_item(self, iid, item_type, item_idx, parent):
    item_type = 'list' if item_type == 'array/list' else 'dict' if item_type == 'object/dict' else item_type
    item_text = self.item(iid)['text'][:-2] if item_type in ['list','dict'] else None
    dup_item = self.convert_tree(iid, item_type, item_text)
    # print(dup_item)
    self.json_tree(parent, dup_item, item_idx+1)

  def update_tag(self, iid, tag=None):
    self.item(iid, tags=(tag,) if tag else '')

  def on_focus_out(self, event):
    event.widget.destroy()

  def on_enter_pressed(self, event):
    new_text = event.widget.get()
    iid = event.widget.edit_item_iid
    column_idx = event.widget.edit_column_idx
    if column_idx == 0:
      if self.item(iid).get("text")[-2:] == "[]":
        new_text = new_text + "[]"
      if self.item(iid).get("text")[-2:] == "{}":
        new_text = new_text + "{}"
      self.item(iid, text=new_text)
    else:
      cur_values = self.item(iid).get("values") or [None] * column_idx
      cur_values[column_idx-1] = new_text
      self.item(iid, values=cur_values)
    event.widget.destroy()

  def json_tree(self, parent, dictionary, index=tk.END):
    renumerate = False
    if isinstance(dictionary, list):
      dictionary = {x:y for x,y in enumerate(dictionary)}
      renumerate = True
    for key in dictionary:
      uid = uuid.uuid4()
      if isinstance(dictionary[key], dict):
        self.insert(parent, index, uid, text=str(key) + '{}')
        self.json_tree(uid, dictionary[key])
      elif isinstance(dictionary[key], list):
        self.insert(parent, index, uid, text=str(key) + '[]')
        self.json_tree(uid, dict(enumerate(dictionary[key])))
      else:
        value = dictionary[key]
        if value == None:
          value = ''
        tag = ('bool',) if isinstance(dictionary[key], bool) else ('null',) if dictionary[key] == None else ('str',) if isinstance(dictionary[key], str) else ('num',) if isinstance(dictionary[key], (int, float)) else ''
        self.insert(parent, index, uid, text=key, value=(value,), tags=tag)
      if renumerate or index != tk.END: self.renumerate_children(parent)

  def convert_tree(self, index=None, type='dict', wrapper=None):
    # print(index, self.item(index)['text'] if index else '', type, wrapper)
    parent_type = None
    missing_children = False
    if not index:
      children = self.get_children()
    else:
      children = self.get_children(index)
    if not children: # We have a value, get parent
      missing_children = True
      parent = self.parent(index)
      parent_text = self.item(parent)['text'] if parent else None
      parent_type = 'list' if parent and str(parent_text)[-2:] == "[]" else 'dict'
      children = [index]
    value = {} if type == 'dict' else [] if type == 'list' else {} if parent_type == 'dict' else [] if parent_type == 'list' else None
    for child in children:
      item = self.item(child)
      key = item['text']
      if str(key)[-2:] == '[]':
        key = key[:-2]
        if not missing_children:
          if type == 'dict' or parent_type == 'dict':
            value[key] = self.convert_tree(child, type='list')
          else:
            value.append(self.convert_tree(child, type='list'))
      else: # not a list
        if len(self.get_children(child)) > 0 or str(key)[-2:] == '{}':
          if str(key)[-2:] == '{}':
            key = key[:-2]
          if not missing_children:
            if type == 'dict' or parent_type == 'dict':
              value[key] = self.convert_tree(child, type='dict')
            else:
              value.append(self.convert_tree(child, type='dict'))
        else:
          values_value = item['values'][0] if item['values'] else None
          if 'bool' in item['tags']:
            values_value = values_value.lower() in ("true", "t", "yes", "y", "1") if isinstance(values_value, str) else bool(values_value)
          elif 'null' in item['tags']:
            values_value = None if not values_value else values_value
          elif 'str' in item['tags']:
            values_value = str(values_value)
          elif 'num' in item['tags'] or not item['tags']:
            try: # int
              values_value = int(values_value)
            except: # float
              try:
                values_value = float(values_value)
              except: # as is
                values_value = values_value
          if type == 'dict' or parent_type == 'dict':
            value[key] = values_value
          else:
            value.append(values_value)
    return value if not wrapper else {wrapper:value}
  
# IM_CHECKED = Path(CurrentPath, "../themes/Azure/theme/azure-light/check-accent.png")
# IM_UNCHECKED = Path(CurrentPath, "../themes/Azure/theme/generic-light/box-basic.png")
# IM_TRISTATE = Path(CurrentPath, "../themes/Azure/theme/azure-light/check-tri-accent.png")

class CheckboxTreeview(ttk.Treeview):
  """
  :class:`ttk.Treeview` widget with checkboxes left of each item.

  .. note::
    The checkboxes are done via the image attribute of the item,
    so to keep the checkbox, you cannot add an image to the item.
  """

  def __init__(self, master=None, **kw):
    """
    Create a CheckboxTreeview.

    :param master: master widget
    :type master: widget
    :param kw: options to be passed on to the :class:`ttk.Treeview` initializer
    """
    ttk.Treeview.__init__(self, master, **kw) # style='Checkbox.Treeview',
    # style (make a noticeable disabled style)
    # style = ttk.Style(self)
    # style.map("Checkbox.Treeview",
    #      fieldbackground=[("disabled", '#E6E6E6')],
    #      foreground=[("disabled", 'gray40')],
    #      background=[("disabled", '#E6E6E6')])
    # checkboxes are implemented with pictures

    # self.im_checked = tk.PhotoImage(file=IM_CHECKED, master=self).subsample(2)
    # self.im_unchecked = tk.PhotoImage(file=IM_UNCHECKED, master=self).subsample(2)
    # self.im_tristate = tk.PhotoImage(file=IM_TRISTATE, master=self).subsample(2)
    # self.tag_configure("unchecked", image=self.im_unchecked)
    # self.tag_configure("tristate", image=self.im_tristate)
    # self.tag_configure("checked", image=self.im_checked)
    self.switch_theme()

    # check / uncheck boxes on click
    self.bind("<Button-1>", self._box_click, True)

  def switch_theme(self):
    theme = self.tk.call("ttk::style", "theme", "use")
    # Expecting name-light_dark
    light_dark = theme.split('-')[1]
    NEW_IM_CHECKED = CurrentPath.parent / F"themes/Azure/theme/{theme}/check-accent.png"
    NEW_IM_UNCHECKED = CurrentPath.parent / F"themes/Azure/theme/generic-{light_dark}/box-basic.png"
    NEW_IM_TRISTATE = CurrentPath.parent / F"themes/Azure/theme/{theme}/check-tri-accent.png"
    self.im_checked = tk.PhotoImage(file=NEW_IM_CHECKED, master=self).subsample(2)
    self.im_unchecked = tk.PhotoImage(file=NEW_IM_UNCHECKED, master=self).subsample(2)
    self.im_tristate = tk.PhotoImage(file=NEW_IM_TRISTATE, master=self).subsample(2)
    self.tag_configure("unchecked", image=self.im_unchecked)
    self.tag_configure("tristate", image=self.im_tristate)
    self.tag_configure("checked", image=self.im_checked)

  def _expand_collapse_all(self, open):
    """Expand or collapse all items."""

    def aux(item):
      if item:
        self.item(item, open=open)
      children = self.get_children(item)
      for c in children:
        aux(c)
    aux("")

  def expand_all(self):
    """Expand all items."""

    self._expand_collapse_all(open=True)

  def collapse_all(self):
    """Collapse all items."""

    self._expand_collapse_all(open=False)

  def _check_uncheck_all(self, state):
    """Check or uncheck all items."""

    def aux(item):
      if item:
        self.change_state(item, state)
      children = self.get_children(item)
      for c in children:
        aux(c)

    aux("")

  def check_all(self):
    """Check all items."""

    self._check_uncheck_all(state="checked")

  def uncheck_all(self):
    """Uncheck all items."""

    self._check_uncheck_all(state="unchecked")

  def state(self, statespec=None):
    """
    Modify or inquire widget state.

    :param statespec: Widget state is returned if `statespec` is None,
             otherwise it is set according to the statespec
             flags and then a new state spec is returned
             indicating which flags were changed.
    :type statespec: None or sequence[str]
    """
    if statespec:
      if "disabled" in statespec:
        self.bind('<Button-1>', lambda e: 'break')
      elif "!disabled" in statespec:
        self.unbind("<Button-1>")
        self.bind("<Button-1>", self._box_click, True)
      return ttk.Treeview.state(self, statespec)
    else:
      return ttk.Treeview.state(self)

  def change_state(self, item, state):
    """
    Replace the current state of the item.

    i.e. replace the current state tag but keeps the other tags.

    :param item: item id
    :type item: str
    :param state: "checked", "unchecked" or "tristate": new state of the item
    :type state: str
    """
    tags = self.item(item, "tags")
    states = ("checked", "unchecked", "tristate")
    new_tags = [t for t in tags if t not in states]
    new_tags.append(state)
    self.item(item, tags=tuple(new_tags))

  def tag_add(self, item, tag):
    """
    Add tag to the tags of item.

    :param item: item identifier
    :type item: str
    :param tag: tag name
    :type tag: str
    """
    tags = self.item(item, "tags")
    self.item(item, tags=tags + (tag,))

  def tag_del(self, item, tag):
    """
    Remove tag from the tags of item.

    :param item: item identifier
    :type item: str
    :param tag: tag name
    :type tag: str
    """
    tags = list(self.item(item, "tags"))
    if tag in tags:
      tags.remove(tag)
      self.item(item, tags=tuple(tags))

  def insert(self, parent, index, iid=None, **kw):
    """
    Creates a new item and return the item identifier of the newly created item.

    :param parent: identifier of the parent item
    :type parent: str
    :param index: where in the list of parent's children to insert the new item
    :type index: int or "end"
    :param iid: item identifier, iid must not already exist in the tree. If iid is None a new unique identifier is generated.
    :type iid: None or str
    :param kw: other options to be passed on to the :meth:`ttk.Treeview.insert` method

    :return: the item identifier of the newly created item
    :rtype: str

    .. note:: Same method as for the standard :class:`ttk.Treeview` but
         add the tag for the box state accordingly to the parent
         state if no tag among
         ('checked', 'unchecked', 'tristate') is given.
    """
    if self.tag_has("checked", parent):
      tag = "checked"
    else:
      tag = 'unchecked'
    if "tags" not in kw:
      kw["tags"] = (tag,)
    elif not ("unchecked" in kw["tags"] or "checked" in kw["tags"] or
         "tristate" in kw["tags"]):
      kw["tags"] += (tag,)

    return ttk.Treeview.insert(self, parent, index, iid, **kw)

  def get_checked(self):
    """Return the list of checked items that do not have any child."""
    checked = []

    def get_checked_children(item):
      if not self.tag_has("unchecked", item):
        ch = self.get_children(item)
        if not ch and self.tag_has("checked", item):
          checked.append(item)
        else:
          for c in ch:
            get_checked_children(c)

    ch = self.get_children("")
    for c in ch:
      get_checked_children(c)
    return checked

  def _check_descendant(self, item):
    """Check the boxes of item's descendants."""
    children = self.get_children(item)
    for iid in children:
      self.change_state(iid, "checked")
      self._check_descendant(iid)

  def _check_ancestor(self, item):
    """
    Check the box of item and change the state of the boxes of item's
    ancestors accordingly.
    """
    self.change_state(item, "checked")
    parent = self.parent(item)
    if parent:
      children = self.get_children(parent)
      b = ["checked" in self.item(c, "tags") for c in children]
      if False in b:
        # at least one box is not checked and item's box is checked
        self._tristate_parent(parent)
      else:
        # all boxes of the children are checked
        self._check_ancestor(parent)

  def _tristate_parent(self, item):
    """
    Put the box of item in tristate and change the state of the boxes of
    item's ancestors accordingly.
    """
    self.change_state(item, "tristate")
    parent = self.parent(item)
    if parent:
      self._tristate_parent(parent)

  def _uncheck_descendant(self, item):
    """Uncheck the boxes of item's descendant."""
    children = self.get_children(item)
    for iid in children:
      self.change_state(iid, "unchecked")
      self._uncheck_descendant(iid)

  def _uncheck_ancestor(self, item):
    """
    Uncheck the box of item and change the state of the boxes of item's
    ancestors accordingly.
    """
    self.change_state(item, "unchecked")
    parent = self.parent(item)
    if parent:
      children = self.get_children(parent)
      b = ["unchecked" in self.item(c, "tags") for c in children]
      if False in b:
        # at least one box is checked and item's box is unchecked
        self._tristate_parent(parent)
      else:
        # no box is checked
        self._uncheck_ancestor(parent)

  def _box_click(self, event):
    """Check or uncheck box when clicked."""
    x, y, widget = event.x, event.y, event.widget
    elem = widget.identify("element", x, y)
    if "image" in elem:
      # a box was clicked
      item = self.identify_row(y)
      if self.tag_has("unchecked", item) or self.tag_has("tristate", item):
        self._check_ancestor(item)
        self._check_descendant(item)
      else:
        self._uncheck_descendant(item)
        self._uncheck_ancestor(item)
      # print/assign currently checked items
      # print(self.get_tagged(tag_has="checked"))
      # self.switch_theme()
      # self.update_idletasks()
        
  def click_item(self, item, check=False):
    if check:
      self._check_ancestor(item)
      self._check_descendant(item)
    else:
      self._uncheck_descendant(item)
      self._uncheck_ancestor(item)
    # self.switch_theme()
    # self.update_idletasks()

  def get_tagged(self, item=None, tag_has=None, include_parent=False):
    values = []
    for x in self.get_children(item):
      if not tag_has or (tag_has and self.tag_has(tag_has, x)):
        if self.get_children(x):
          if include_parent: values.append(self.item(x))
        else:
          values.append({'iid':x,**self.item(x)})
      values.extend(self.get_tagged(x, tag_has, include_parent=include_parent))
    return values
  
class TextLineNumbers(tk.Canvas):
  def __init__(self, *args, **kwargs):
    tk.Canvas.__init__(self, *args, **kwargs)
    self.textwidget = None
    # self.fill = "#FFFFFF"
    self.fill = "#000000" if 'light' in self.tk.call("ttk::style", "theme", "use") else "#FFFFFF"

  def attach(self, text_widget):
    self.textwidget = text_widget
      
  def redraw(self, *args):
    '''redraw line numbers'''
    self.delete("all")
    # for widget in self.winfo_children():
    #   widget.destroy()

    i = self.textwidget.index("@0,0")
    # y = self.textwidget.winfo_height()
    # x = self.textwidget.winfo_width()
    x2 = self.winfo_width()
    # print('x:', x2)
    # bd = int(self.textwidget.cget("borderwidth"))
    # start_index = self.textwidget.index(f"@0,{bd} linestart")
    # end_index = self.textwidget.index(f"@0,{y} linestart")
    while True:
      dline= self.textwidget.dlineinfo(i)
      if dline is None: break
      y = dline[1]
      # print("y:", y)
      linenum = str(i).split(".")[0]
      # self.create_text(2, y, anchor=tk.NW, text=linenum, fill='white')
      self.create_text(x2-3, y, anchor=tk.NE, text=linenum, fill=self.fill)
      # label = ttk.Label(self, text=linenum, anchor=tk.NW)
      # label.place(x=2,y=y)

      i = self.textwidget.index(F"{i}+1line")

class InterceptorWidget(ttk.Label):
  def __init__(self, *args, **kwargs):
    ttk.Label.__init__(self, *args, **kwargs)
    # create a proxy for the underlying widget
    self._orig = self._w + "_orig"
    self.tk.call("rename", self._w, self._orig)
    self.tk.createcommand(self._w, self._proxy)
    self.line_widget1 = None
    self.line_widget2 = None
    self.treeview_widget = None

  def attach_line_numbers(self, w1, w2):
    self.line_widget1 = w1
    self.line_widget2 = w2

  def attach_treeview(self, w):
    self.treeview_widget = w

  def _proxy(self, *args):
    # let the actual widget perform the requested action
    cmd = (self._orig,) + args
    # print("CMD:", cmd)

    if args[0:2] == ('configure', '-foreground'):
      # fg = self.tk.call('ttk::style configure -foreground')
      # fg = self.line_widget1.cget('textcolor')
      # print(fg)
      if self.line_widget1:
        self.line_widget1.fill = "#000000" if 'light' in self.tk.call("ttk::style", "theme", "use") else "#FFFFFF"
        self.line_widget1.redraw()
        # print(self.line_widget1.fill)
      if self.line_widget2:
        self.line_widget2.fill = "#000000" if 'light' in self.tk.call("ttk::style", "theme", "use") else "#FFFFFF"
        self.line_widget2.redraw()
        # print(self.line_widget2.fill)
      if self.treeview_widget:
        self.treeview_widget.switch_theme()


    try:
      result = self.tk.call(cmd)
      # print("RESULT:", result)
      return result
    except tk.TclError:
      return ""
    
class TextRedirector(object):
  def __init__(self, widget, tag="stdout"):
    self.widget = widget
    self.tag = tag
  def __getattr__(self, attr):
    return getattr(sys.stdout, attr)
  def write(self, str):
    self.widget.insert("end", str, (self.tag,))
    self.widget.see("end")
  def flush(self): pass


class ScrollableNotebook(ttk.Frame):
  def __init__(self,parent,wheelscroll=False,tabmenu=False,*args,**kwargs):
    ttk.Frame.__init__(self, parent, *args)
    self.xLocation = 0
    self.timer = None
    self.notebookContent = ttk.Notebook(self,**kwargs)
    self.notebookContent.pack(fill="both", expand=True)
    self.notebookTab = ttk.Notebook(self,**kwargs)
    self.notebookTab.bind("<<NotebookTabChanged>>",self._tabChanger)
    if wheelscroll==True: self.notebookTab.bind("<MouseWheel>", self._wheelscroll)
    slideFrame = ttk.Frame(self)
    slideFrame.place(relx=1.0, x=0, y=1, anchor=tk.NE)
    self.menuSpace=30
    if tabmenu==True:
      self.menuSpace=50
      bottomTab = ttk.Label(slideFrame, text="\u2630")
      bottomTab.bind("<ButtonPress-1>",self._bottomMenu)
      bottomTab.pack(side=tk.RIGHT)
    leftArrow = ttk.Label(slideFrame, text=" \u276E")
    leftArrow.bind("<ButtonPress-1>",self._leftSlideStart)
    leftArrow.bind("<ButtonRelease-1>",self._slideStop)
    leftArrow.pack(side=tk.LEFT)
    rightArrow = ttk.Label(slideFrame, text=" \u276F")
    rightArrow.bind("<ButtonPress-1>",self._rightSlideStart)
    rightArrow.bind("<ButtonRelease-1>",self._slideStop)
    rightArrow.pack(side=tk.RIGHT)
    self.notebookContent.bind("<Configure>", self._resetSlide)
    self.contentsManaged = []

  def _wheelscroll(self, event):
    if event.delta > 0:
      self._leftSlide(event)
    else:
      self._rightSlide(event)

  def _bottomMenu(self, event):
    tabListMenu = tk.Menu(self, tearoff = 0)
    for tab in self.notebookTab.tabs():
      tabListMenu.add_command(label=self.notebookTab.tab(tab, option="text"),command= lambda temp=tab: self.select(temp))
    try:
      tabListMenu.tk_popup(event.x_root, event.y_root)
    finally:
      tabListMenu.grab_release()

  def _tabChanger(self, event):
    try: self.notebookContent.select(self.notebookTab.index("current"))
    except: pass

  def _rightSlideStart(self, event=None):
    if self._rightSlide(event):
      self.timer = self.after(100, self._rightSlideStart)

  def _rightSlide(self, event):
    if self.notebookTab.winfo_width()>self.notebookContent.winfo_width()-self.menuSpace:
      if (self.notebookContent.winfo_width()-(self.notebookTab.winfo_width()+self.notebookTab.winfo_x()))<=self.menuSpace+5:
        self.xLocation-=20
        self.notebookTab.place(x=self.xLocation,y=0)
        return True
    return False

  def _leftSlideStart(self, event=None):
    if self._leftSlide(event):
      self.timer = self.after(100, self._leftSlideStart)

  def _leftSlide(self, event):
    if not self.notebookTab.winfo_x()== 0:
      self.xLocation+=20
      self.notebookTab.place(x=self.xLocation,y=0)
      return True
    return False

  def _slideStop(self, event):
    if self.timer != None:
      self.after_cancel(self.timer)
      self.timer = None

  def _resetSlide(self,event=None):
    self.notebookTab.place(x=0,y=0)
    self.xLocation = 0

  def add(self,frame,**kwargs):
    if len(self.notebookTab.winfo_children())!=0:
      self.notebookContent.add(frame, text="",state="hidden")
    else:
      self.notebookContent.add(frame, text="")
    self.notebookTab.add(ttk.Frame(self.notebookTab),**kwargs)
    self.contentsManaged.append(frame)

  def forget(self,tab_id):
    index = self.notebookTab.index(tab_id)
    self.notebookContent.forget(self.__ContentTabID(tab_id))
    self.notebookTab.forget(tab_id)
    self.contentsManaged[index].destroy()
    self.contentsManaged.pop(index)

  def hide(self,tab_id):
    self.notebookContent.hide(self.__ContentTabID(tab_id))
    self.notebookTab.hide(tab_id)

  def identify(self,x, y):
    return self.notebookTab.identify(x,y)

  def index(self,tab_id):
    return self.notebookTab.index(tab_id)

  def __ContentTabID(self,tab_id):
    return self.notebookContent.tabs()[self.notebookTab.tabs().index(tab_id)]

  def insert(self,pos,frame, **kwargs):
    self.notebookContent.insert(pos,frame, **kwargs)
    self.notebookTab.insert(pos,frame,**kwargs)

  def select(self,tab_id):
    ## self.notebookContent.select(self.__ContentTabID(tab_id))
    self.notebookTab.select(tab_id)

  def tab(self,tab_id, option=None, **kwargs):
    kwargs_Content = kwargs.copy()
    kwargs_Content["text"] = "" # important
    self.notebookContent.tab(self.__ContentTabID(tab_id), option=None, **kwargs_Content)
    return self.notebookTab.tab(tab_id, option=None, **kwargs)

  def tabs(self):
    ## return self.notebookContent.tabs()
    return self.notebookTab.tabs()

  def enable_traversal(self):
    self.notebookContent.enable_traversal()
    self.notebookTab.enable_traversal()