raw_wd_ico_png = b'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABhWlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TtSIVBTuIOGSoTlZERTpKFYtgobQVWnUwufRDaNKQpLg4Cq4FBz8Wqw4uzro6uAqC4AeIq4uToouU+L+k0CLGg+N+vLv3uHsHCPUyU82OCUDVLCMVj4nZ3IoYeEUXguhHFOMSM/VEeiEDz/F1Dx9f7yI8y/vcn6NXyZsM8InEs0w3LOJ14plNS+e8TxxiJUkhPiceM+iCxI9cl11+41x0WOCZISOTmiMOEYvFNpbbmJUMlXiaOKyoGuULWZcVzluc1XKVNe/JXxjMa8tprtMcRhyLSCAJETKq2EAZFiK0aqSYSNF+zMM/5PiT5JLJtQFGjnlUoEJy/OB/8LtbszA16SYFY0Dni21/jACBXaBRs+3vY9tunAD+Z+BKa/krdSD6SXqtpYWPgL5t4OK6pcl7wOUOMPikS4bkSH6aQqEAvJ/RN+WAgVugZ9XtrbmP0wcgQ10t3QAHh8BokbLXPN7d3d7bv2ea/f0A5VVy1VI7CXIAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfnBgwRMC4cdzn5AAACT0lEQVQ4y3XSP4hcZRQF8N97MzvjuDvPNdgFlSBsqgjGBQOKne4LBEEbkVkUtLGxzGChTcq3aYMgaKGOREFtFGd2l5hGGyEISiApjGuxjaA7Mzs7O38/i3ljhmBu9fFxzr3nnHsjeXUycVI3bWcqEe/grQdL1kLgaORmxIf4IKkbzrEQLZI7mdP4rrrqie6B2/gRMZ6vrjrVPfAbLiR1e3NO1MlESV3oZB4O/FouODmceC2pu2qhOpk3l8s+6g3cwtmk7qiTiWLRTAXeS6pODibOz8ndLXF3SwxJ3ce9gVeridOo55wYtDOV3mWhk9nJicV7pkfdLYX8faOTaXeyGaYI7cny8YrjS9MQtxipRLOAbDbz6el0eFmAYVi6GEfTsyfqk7H/q6/fX4/cp668uxHf+xfBiTe+jEehuB5Efx1+8vIdUGuWcAZjkZs+S0ew8vo3a5GwEoJfDj99ZVqEv8dJWWRHsIcn8+YXlFa+IjDsvYBdtebS4cQ2YiGcmqW42Yo10r5gW1w4o9Z8NBeXGh0x7E2wkTdds1R5HLs+Pz9RaxViIcx9XVN+yF0FYUOYXsUPeCnHPKVUhWaOEZMnznXTCTyt1nzEA6uP4Qt8r1BaU2tW8ZzjA/g554SiRjpvcNugvY9nsWfchxu4o7RMf/gi1k2GtzTSWdCNdDqTv9kqaKQTXMM5vG08+EMj/RO/6/+zj4v5VnbyLRXunmII87XuKpYTpZVz//lspF38pLT8jKVKCduLdzAPMLcRrhsP2sIUWgu4b4kY9fcX/E/hX+sr6Q7tfBXJAAAAAElFTkSuQmCC'

def motivate(de=False):
  import random, base64, getpass
  de = not de if base64.b64encode(getpass.getuser().encode()).decode() in ['cm9iZXJ0LmdvcmRvbg==', 'am9obi5sYXU=', 'YnJ5YW4ucGVwaQ==', 'Z2VvcmdlLnNhbQ==', 'am9uYXRoYW4ua2xlaW5iZXJn'] else de # 'YW5keS5wYXJrZXI='
  speech = F""""{' '.join([base64.b64decode(random.choice(x).encode()).decode() for x in [['Q2hhbXAs', 'RmFjdDo=', 'RXZlcnlib2R5IHNheXM=', 'RGFuZyAuLi4=', 'Q2hlY2sgaXQ6', 'SnVzdCBzYXlpbmcgLi4u', 'U3VwZXJzdGFyLA==', 'VGlnZXIs', 'U2VsZiw=', 'S25vdyB0aGlzOg==', 'TmV3cyBhbGVydDo=', 'R2lybCw=', 'QWNlLA==', 'RXhjdXNlIG1lLCBidXQ=', 'RXhwZXJ0cyBhZ3JlZTo=', 'SW4gbXkgb3Bpbmlvbiw=', 'SGVhciB5ZSwgaGVhciB5ZTo=', 'T2theSwgbGlzdGVuIHVwOg=='],['dGhlIG1lcmUgaWRlYSBvZiB5b3U=', 'eW91ciBzb3Vs', 'eW91ciBoYWlyIHRvZGF5', 'ZXZlcnl0aGluZyB5b3UgZG8=', 'eW91ciBwZXJzb25hbCBzdHlsZQ==', 'ZXZlcnkgdGhvdWdodCB5b3UgaGF2ZQ==', 'dGhhdCBzcGFya2xlIGluIHlvdXIgZXll', 'eW91ciBwcmVzZW5jZSBoZXJl', 'd2hhdCB5b3UgZ290IGdvaW5nIG9u', 'dGhlIGVzc2VudGlhbCB5b3U=', 'eW91ciBsaWZlJ3Mgam91cm5leQ==', 'dGhhdCBzYXVjeSBwZXJzb25hbGl0eQ==', 'eW91ciBETkE=', 'dGhhdCBicmFpbiBvZiB5b3Vycw==', 'eW91ciBjaG9pY2Ugb2YgYXR0aXJl', 'dGhlIHdheSB5b3Ugcm9sbA==', 'd2hhdGV2ZXIgeW91ciBzZWNyZXQgaXM=', 'YWxsIG9mIHknYWxs'],['aGFzIHNlcmlvdXMgZ2FtZSw=', 'cmFpc2VzIG1hZ2ljLA==', 'ZGVzZXJ2ZXMgdGhlIE5vYmVsIFByaXplLA==', 'cmFpc2VzIHRoZSByb29mLA==', 'YnJlZWRzIG1pcmFjbGVzLA==', 'aXMgcGF5aW5nIG9mZiBiaWcgdGltZSw=', 'c2hvd3MgbWFkIHNraWxscyw=', 'anVzdCBzaGltbWVycyw=', 'aXMgYSBuYXRpb25hbCB0cmVhc3VyZSw=', 'Z2V0cyB0aGUgcGFydHkgaG9wcGluZyw=', 'aXMgdGhlIG5leHQgYmlnIHRoaW5nLA==', 'cm9hcnMgbGlrZSBhIGxpb24s', 'aXMgYSByYWluYm93IGZhY3Rvcnks', 'aXMgbWFkZSBvZiBkaWFtb25kcyw=', 'bWFrZXMgYmlyZHMgc2luZyw=', 'c2hvdWxkIGJlIHRhdWdodCBpbiBzY2hvb2ws', 'bWFrZXMgbXkgd29ybGQgZ28gJ3JvdW5kLA==', 'aXMgMTAwJSBsZWdpdCw='],['MjQvNy4=', 'Y2FuIEkgZ2V0IGFuIGFtZW4/', 'YW5kIHRoYXQncyBhIGZhY3Qu', 'c28gdHJlYXQgeW91cnNlbGYu', 'eW91IGZlZWwgbWU/', 'dGhhdCdzIGp1c3Qgc2NpZW5jZS4=', 'd291bGQgSSBsaWU/', 'Zm9yIHJlYWxzLg==', 'bWljIGRyb3Au', 'eW91IGhpZGRlbiBnZW0u', 'c251Z2dsZSBiZWFyLg==', 'cGVyaW9kLg==', 'YW0gSSByaWdodD8=', 'bm93IGxldCdzIGRhbmNlLg==', 'aGlnaCBmaXZlLg==', 'c2F5IGl0IGFnYWluIQ==', 'YWNjb3JkaW5nIHRvIENOTi4=', 'c28gZ2V0IHVzZWQgdG8gaXQu'],['IC0tIFBlcCBUYWxrIEdlbmVyYXRvcg==']]]).replace('  --', '" --')}""" if not de else F""""{' '.join([base64.b64decode(random.choice(x).encode()).decode() for x in [['TWV0aGluaydzdCB0aG91IGFydCB0aGU=', 'SSBkbyB3aXNoIHRob3Ugd2VydCB0aGU=', 'R28sIHll', 'QXdheSwgdGhvdQ==', 'SG93IGRvc3QgdGhvdSw=', 'VGhvdSBkZWxpYmVyYXRl', 'UGVhY2UsIHll', 'TGVuZCBtZSB5b3VyIGVhcnMsIHRob3U=', 'V2VsbCBiZSB3aXRoIHlvdSwgeWU=', 'Qmxlc3MgdGhlZSwgdGhvdQ==', 'R29vZCBkYXksIHRob3U=', 'VGhlIGdvb2QgdGltZSBvZiBkYXkgdG8geW91LA==', 'R29vZCBtb3Jyb3csIHRob3U=', 'SGFpbCB0byB5b3VyIGdyYWNlLCB0aG91', 'V2VsY29tZSwgdGhvdQ==', 'QWRpZXUsIHRob3U=', 'R29vZCBuaWdodCwgdGhvdQ==', 'R2l2ZSBtZSBub3cgbGVhdmUsIHll', 'R28gdGh5IHdheXMsIHRob3U=', 'SG93IGZhcmUgdGhlZSwgdGhvdQ==', 'SSBhbSBub3QgYm91bmQgdG8gcGxlYXNlIHRoZWUs', 'SSBzY29ybiB5b3UsIHll', 'T3V0IG9mIG15IHNpZ2h0LCB0aG91', 'SGUncyBhIG1vc3Qgbm90YWJsZQ==', 'R29vZCBtb3JuaW5nLCB0aG91'],['YWJvbWluYWJsZQ==', 'Z29hdGlzaA==', 'c2F1Y3k=', 'aWRsZS1oZWFkZWQ=', 'bW9zdCBkZWdlbmVyYXRl', 'c3BvbmdleQ==', 'aW5mZWN0aW91cw==', 'Z3JlYXN5', 'cmFzY2FsbHk=', 'bW9udW1lbnRhbA==', 'Z29yYmVsbGllZA==', 'cm9ndWlzaA==', 'aW1wZXJ0aW5lbnQ=', 'ZnJvdGh5', 'Ymxvb2RzdWNraW5n', 'YmVlZi13aXR0ZWQ=', 'c2hhZy1oYWlyZWQ=', 'bmV2ZXItZW5kaW5n', 'bXVtYmxpbmc=', 'dW5tdXp6bGVk', 'dG9hZC1zcG90dGVk', 'ZmFuZ2Vk', 'ZHJvbmluZw==', 'bGlseS1saXZlcidk', 'bG9uZy10b25ndWVk'],['cGx1bWUtcGx1Y2tlZA==', 'Y3Jvb2stcGF0ZWQ=', 'Y29tbW9uLWtpc3Npbmc=', 'd2VhdGhlciBiaXR0ZW4=', 'Zm9sbHktZmFsbGVu', 'cHVrZS1zdG9ja2luZ2Vk', 'ZGl6enktZXllZA==', 'dGFsbG93LWZhY2Vk', 'ZG9naGVhcnRlZA==', 'dGFyZHktZ2FpdGVk', 'cHVycGxlLWh1ZWQ=', 'ZWxmLXNraW5uZWQ=', 'YmVldGxlLWhlYWRlZA==', 'ZnJvc3R5LXNwaXJpdGVk', 'YmVzbHViYmVyaW5n', 'bW90bGV5LW1pbmRlZA==', 'c29kZGVuLXdpdHRlZA==', 'dGlja2xlLWJyYWluZWQ=', 'c2hlZXAtYml0aW5n', 'ZmxhcC1tb3V0aGVk', 'YmFjb24tZmVk', 'Y2xhcHBlci1jbGF3ZWQ=', 'cnVkZS1ncm93aW5n', 'dXJjaGluLXNub3V0ZWQ=', 'b25pb24tZXllZA=='],['cGlnbnV0IQ==', 'aW5nZXN0ZWQtbHVtcCE=', 'ZGlzZWFzZSBvZiBhIGZyaWVuZCE=', 'bWlsZGV3ZWQtZWFyIQ==', 'c2VycGVudHMtZWdnIQ==', 'c2x1ZyE=', 'b2RvcmlmZXJvdXMgc3RlbmNoIQ==', 'd3JpdGhsZWQgc2hyaW1wIQ==', 'c2tpbWJsZS1za2FtYmxlIQ==', 'ZmlzaG1vbmdlciE=', 'bW91bnRhaW4gZ29hdCE=', 'Y2xvYWstYmFnIG9mIGd1dHMhIA==', 'd2FndGFpbCE=', 'aHlwZXJib2xpY2FsIGZpZW5kIQ==', 'dG9vdGhsZXNzIGJhYmJvb24h', 'bWFsdC13b3JtIQ==', 'YmFybmFjbGUhIA==', 'dGhpbmcgb2Ygbm8gYm93ZWxzIQ==', 'cGlnZW9uLWVnZyE=', 'ZHVuZ2hpbGwh', 'dGhyZWUgaW5jaCBmb29sIQ==', 'Z2lkZHkgZ29vc2Uh', 'Y2Fua2VyLWJsb3Nzb20h', 'aHVnZ2VyLW11Z2dlciE=', 'bHVtcCBvZiBmb3VsIGRlZm9ybWl0eSE='],['LS0gU2hha2VzcGVhcmVhbiBJbnN1bHQgR2VuZXJhdG9y']]]).replace(' --', '" --')}"""
  a = speech
  b = ''.join({**dict(enumerate(a)), **dict((y,z) if x%2==0 else (y,z.upper()) for x,(y,z) in enumerate((i,x.lower()) for i,x in enumerate(a) if x.isalpha()))}.values())
  c = ''.join([x.upper() if i % 2 == 0 else x.lower() for i, x in [(i if x.isalpha() else i-1 ,x) for i, x in enumerate(a)]])
  speech = random.choice([a,a.title(),a.upper(),a.lower(),b,c])
  return speech

slng_urls = [
  "https://slng-us.workdayinternal.com",
  "https://slng-us-res.workdayinternal.com",
  "https://slng-ca.workdayinternal.com",
  "https://slng-5e.workdayinternal.com",
  "https://slng-eu.workdayinternal.com",
  "https://slng-eu-res.workdayinternal.com",
  "https://slng-au.workdayinternal.com",
  "https://slng-sgp.workdayinternal.com",
]

# Data Centers SQL
'''
SELECT "data_centers = {" AS TEXT
UNION ALL
SELECT CONCAT("  '", `data_center`, "': ('", SUBSTRING_INDEX(SUBSTRING_INDEX(`url_soap`,'/',3),'/',-1), "','", SUBSTRING_INDEX(`url_web`,'/',-1), "','", `level`, "'),") FROM hellboy.slng_data_centers
WHERE `data_center` NOT LIKE "SUV%" 
UNION ALL
SELECT "}";
'''
data_centers = {
  'Impl - Atlanta (wd2)': ('wd2-impl-services1.workday.com','impl.workday.com','Impl'),
  'Impl - Dublin (wd3)': ('wd3-impl-services1.workday.com','wd3-impl.workday.com','Impl'),
  'Impl - Portland (wd5)': ('wd5-impl-services1.workday.com','wd5-impl.workday.com','Impl'),
  'Impl - AWS Montreal (wd10)': ('impl-services1.wd10.myworkday.com','impl.wd10.myworkday.com','Impl'),
  'Impl - AWS Oregon (wd12)': ('impl-services1.wd12.myworkday.com','impl.wd12.myworkday.com','Impl'),
  'Impl - AWS ap-southeast-1 (WD102)': ('impl-services1.wd102.myworkday.com','impl.wd102.myworkday.com','Impl'),
  'Impl - AWS eu-central-1 (WD103)': ('impl-services1.wd103.myworkday.com','impl.wd103.myworkday.com','Impl'),
  'Impl - AWS us-east-2 (WD104)': ('impl-services1.wd104.myworkdaygov.com','impl.wd104.myworkdaygov.com','Impl'),
  'Impl - AWS ap-southeast-2 (WD105)': ('impl-services1.wd105.myworkday.com','impl.wd105.myworkday.com','Impl'),
  'Impl - AWS us-west-2 (WD107)': ('impl-services1.wd107.myworkday.com','impl.wd107.myworkday.com','Impl'),
  'Impl - AWS us-east-2 (WD108)': ('impl-services1.wd108.myworkday.com','impl.wd108.myworkday.com','Impl'),
  'Impl - GCP US (WD501)': ('impl-services1.wd501.myworkday.com','impl.wd501.myworkday.com','Impl'),
  'Prod - Ashburn (www)': ('services1.myworkday.com','www.myworkday.com','Prod'),
  'Prod - Dublin (wd3)': ('wd3-services1.myworkday.com','wd3.myworkday.com','Prod'),
  'Prod - Portland (wd5)': ('wd5-services1.myworkday.com','wd5.myworkday.com','Prod'),
  'Prod - AWS Montreal (wd10)': ('services1.wd10.myworkday.com','wd10.myworkday.com','Prod'),
  'Prod - AWS Columbus (wd12)': ('services1.wd12.myworkday.com','wd12.myworkday.com','Prod'),
  'Prod - AWS ap-southeast-1 (WD102)': ('services1.wd102.myworkday.com','wd102.myworkday.com','Prod'),
  'Prod - AWS eu-central-1 (WD103)': ('services1.wd103.myworkday.com','wd103.myworkday.com','Prod'),
  'Prod - AWS us-east-2 (WD104)': ('services1.wd104.myworkdaygov.com','wd104.myworkdaygov.com','Prod'),
  'Prod - AWS ap-southeast-2 (WD105)': ('services1.wd105.myworkday.com','wd105.myworkday.com','Prod'),
  'Prod - AWS us-west-2 (WD107)': ('services1.wd107.myworkday.com','wd107.myworkday.com','Prod'),
  'Prod - AWS us-west-2 (WD108)': ('services1.wd108.myworkday.com','wd108.myworkday.com','Prod'),
  'Prod - GCP US (WD501)': ('services1.wd501.myworkday.com','wd501.myworkday.com','Prod'),
}