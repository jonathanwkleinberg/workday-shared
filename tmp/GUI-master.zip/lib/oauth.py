import requests
import datetime
import re
import xml.etree.ElementTree as ET

class OAuth(object):

  def __init__(self, client_id=None, client_secret=None):
    self.client_id = client_id
    self.client_secret = client_secret

  def dict_extract_by_key(self, var, key, kv_match=None):
    if hasattr(var,'items'):
      for k, v in var.items():
        if kv_match:
          km, vm = kv_match
          if key in var and km == k and vm == v: yield var[key]
        else:
          if k == key: yield v
        if isinstance(v, dict):
          for result in self.dict_extract_by_key(v, key, kv_match): yield result
        elif isinstance(v, list):
          for d in v:
            for result in self.dict_extract_by_key(d, key, kv_match): yield result

  def login(self, base_url, tenant, username, password):
    auth_url = F'{base_url}/wday/authgwy/{tenant}/login-auth.xml'
    rs = requests.Session()
    r = rs.post(auth_url, headers={'X-Workday-Client': ''}, data={'userName':username, 'password':password})
    r.raise_for_status()
    if not '"result":"SUCCESS"' in r.text:
      if 'Invalid user name or password' in r.text:
        raise Exception('Invalid user name or password.')
      if 'The URL you have provided is invalid.' in r.text:
        raise Exception('Invalid URL (cc/tenant name).')
    # print(r.json())
    return rs
  
  def register_cc_api_client(self, base_url, cc_tenant, username, password, client_name, redirect_uri):
    rs = self.login(base_url, cc_tenant, username, password)

    client_api_url = F'{base_url}/{cc_tenant}/task/2997$20813.htmld' # no /d/ to get json
    try:
      AL_API_Client_Result = rs.get(client_api_url).json()
    except:
      raise Exception('Error accessing Advanced Load API Client - Setup page!')
    try:
      flowKey = next(self.dict_extract_by_key(AL_API_Client_Result, 'flowExecutionKey'))
      sessionSecureToken = next(self.dict_extract_by_key(AL_API_Client_Result, 'sessionSecureToken'))
      sequence_task_id = next(self.dict_extract_by_key(AL_API_Client_Result, 'id', ("propertyName", "nyw:sequence_task"))) # ??? ("widget", "vbox")
      client_name_id = next(self.dict_extract_by_key(AL_API_Client_Result, 'id', ("label", "Client Name")))
      redirect_uri_id = next(self.dict_extract_by_key(AL_API_Client_Result, 'id', ("label", "Redirection URI")))
    except StopIteration as si:
      si.add_note('Element not found on AL API Client - Setup page!')
      raise si
    # print(flowKey, sessionSecureToken, client_name_id, redirect_uri_id, sequence_task_id)
    # print(list(dict_extract_by_key(AL_API_Client_Result, 'id')))
    # ['90/wd:OAuth_2.0_Client_Name', '90/wd:OAuth_2.0_Redirect_URI', '90/wd:URL_from_Address_Bar', '90/wd:OAuth_2.0_Client_Disabled', '89', 'max-length-row', 'max-length-row', '90.79', '95']

    flowController_url = F'{base_url}/{cc_tenant}/flowController.htmld'

    # Set Client Name
    data = {
      '_flowExecutionKey': flowKey, # e0s1
      client_name_id: client_name, # 90/wd:OAuth_2.0_Client_Name': 'DAI AL API Client'
      '_eventId_validate': client_name_id, # 90/wd:OAuth_2.0_Client_Name'
      'sessionSecureToken': sessionSecureToken,
      # 'clientRequestID': 'cac5267fdd1449f183cf7af4aa170739',
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Set Redirect URI
    data = {
      '_flowExecutionKey': flowKey, #e0s1
      redirect_uri_id: redirect_uri, # '90/wd:OAuth_2.0_Redirect_URI': 'https://127.0.0.1/'
      '_eventId_validate': redirect_uri_id, # '90/wd:OAuth_2.0_Redirect_URI'
      'sessionSecureToken': sessionSecureToken,
      # 'clientRequestID': '41b98d99ccca405ebef10aa5df57f0a0',
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Submit Form and Get Client ID & Secret
    data = {
      '_flowExecutionKey': flowKey, #e0s1
      '_eventId_submit': sequence_task_id, # '95'
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: d88ed90ca0ca481fa8317add193a5dc3
    }
    r = rs.post(flowController_url, data=data)
    try:
      rj = r.json()
    except:
      raise Exception('Error retrieving Client ID & Secret!')
    # print(list(dict_extract_by_key(rj, 'value')))
    # ['DAI AL API Client', 'https://127.0.0.1/', False, 'Below is your Client ID and Client Secret.', 'M2E4MzBhN2ItZWE3NC00ZTNmLWFmNzMtNjY3MzYzMDlhOGQ1', 'o3j6zxfahok9b0fudf34c4varmxdvwoozhrq1llr443s0qbvdk30h1ysy52n6nd7ituq6wmbj84aw70w9qoppridpf73fieng42', 'Advanced Load API Client - Setup', 'Advanced Load API Client - Setup']
    client_id = next(self.dict_extract_by_key(rj, 'value', ('label', 'Client ID')))
    client_secret = next(self.dict_extract_by_key(rj, 'value', ('label', 'Client Secret')))
    return client_id, client_secret

  def get_cc_auth_token(self, base_url, service_base_url, cc_tenant, client_id, client_secret, username, password):
    rs = self.login(base_url, cc_tenant, username, password)

    code_url = F'{base_url}/wday/authgwy/{cc_tenant}/authorize?response_type=code&client_id={client_id}'
    r = rs.post(code_url, headers={'X-Workday-Client': ''}, allow_redirects=False) # Stop the redirect, we just want the code
    r.raise_for_status()
    if 'Auth Gateway Error' in r.text:
      raise Exception('Error getting Authentication Code - Check your Client ID')
    if 'consentOAuth' in r.text:
      sessionSecureToken = re.findall('(?:sessionSecureToken="(.*))"|$', r.text)[0]
      # print(sessionSecureToken)

      # Send consent
      data = {'consent': 'Allow', 'sessionSecureToken': sessionSecureToken}
      # https://i-01500fc70881f5f19.workdaysuv.com/wday/authgwy/customercentral/consentOAuth
      consent_url = F'{base_url}/wday/authgwy/{cc_tenant}/consentOAuth'
      r = rs.post(consent_url, data=data, allow_redirects=False) # Stop the redirect, we just want the code

    # print(r.text)
    # print(r.next.path_url)
    code = r.next.path_url.split('=')[-1]

    # Get Token
    oauth_url = F'{service_base_url}/ccx/oauth2/{cc_tenant}/token'
    data = {'grant_type': 'authorization_code', 'code': code}
    r = rs.post(oauth_url, auth=(client_id, client_secret), data=data)
    r.raise_for_status()
    # print(r.text)
    rj = r.json()
    return rj['token_type'], rj['access_token']

  def get_cc_auth_token_basic(self, service_base_url, cc_tenant, username, password):
    auth_url = F'{service_base_url}/ots/{cc_tenant}/services/security/v1/authIdToken'
    token = requests.get(auth_url, auth=(username,password)).json().get('encodedToken')
    return 'ID', token
  
  def enable_oauth_clients(self, base_url, tenant, username, password):
    rs = self.login(base_url, tenant, username, password)

    client_api_url = F'{base_url}/{tenant}/task/2997$3659.htmld' # “Edit Tenant Setup - Security” no /d to get json

    # Get "OAuth 2.0 Clients Enabled" value
    r = rs.get(client_api_url)
    r.raise_for_status()
    try: 
      rj = r.json()
    except:
      raise Exception('Error accessing Tenant Setup - Security page!')
    
    try:
      flowKey = next(self.dict_extract_by_key(rj, 'flowExecutionKey'))
      sessionSecureToken = next(self.dict_extract_by_key(rj, 'sessionSecureToken'))
      sequence_task_id = next(self.dict_extract_by_key(rj, 'id', ("propertyName", "nyw:sequence_task"))) # ??? ("widget", "vbox")
      oauth_clients_enabled_id = next(self.dict_extract_by_key(rj, 'id', ("label", "OAuth 2.0 Clients Enabled")))
      oauth_clients_enabled_value = next(self.dict_extract_by_key(rj, 'value', ("label", "OAuth 2.0 Clients Enabled")))      
    except StopIteration as si:
      si.add_note('Element not found on Tenant Setup - Security page!')
      raise si
    
    flowController_url = F'{base_url}/{tenant}/flowController.htmld'

    if oauth_clients_enabled_value == True:
      return # Already enabled
    else:
      # Enable "OAuth 2.0 Clients Enabled"
      data = {
        '_flowExecutionKey': flowKey, # e0s1
        oauth_clients_enabled_id: 1, # '647/wd:OAuth_2.0_Clients_Enabled_for_Tenant': 1
        '_eventId_validate': oauth_clients_enabled_id, # '647/wd:OAuth_2.0_Clients_Enabled_for_Tenant'
        'sessionSecureToken': sessionSecureToken,
        # 'clientRequestID': 'cac5267fdd1449f183cf7af4aa170739',
      }
      r = rs.post(flowController_url, data=data)
      r.raise_for_status()

      # Submit
      data = {
        '_flowExecutionKey': flowKey, #e0s1
        '_eventId_submit': sequence_task_id, # '651'
        'sessionSecureToken': sessionSecureToken,
        # 'clientRequestID': 'd88ed90ca0ca481fa8317add193a5dc3',
      }
      r = rs.post(flowController_url, data=data)

      # Check that we are enabled
      try:
        rj = r.json()
      except:
        raise Exception('Error verifying that OAuth Enabled!')
      enabled = next(self.dict_extract_by_key(rj, 'value', ('label', 'OAuth 2.0 Clients Enabled')))
      if enabled != True:
        raise Exception('Error enabling OAuth 2.0 Clients!')
      return

  def register_api_client(self, base_url, tenant, username, password, client_name, redirect_uri):
    rs = self.login(base_url, tenant, username, password)

    client_api_url = F'{base_url}/{tenant}/task/2997$5571.htmld' # “Register API Client” no /d/ to get json
    try:
      rj = rs.get(client_api_url).json()
    except:
      raise Exception('Error accessing Register API Client page!')
    try:
      flowKey = next(self.dict_extract_by_key(rj, 'flowExecutionKey'))
      sessionSecureToken = next(self.dict_extract_by_key(rj, 'sessionSecureToken'))
      sequence_task_id = next(self.dict_extract_by_key(rj, 'id', ("propertyName", "nyw:sequence_task"))) # 273
      client_name_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Client Name")))
      client_grant_type_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Client Grant Type"))) # 261
      # auth_code_grant_id = next(self.dict_extract_by_key(rj, 'id', ("text", "Authorization Code Grant"))) # '261.277'
      # auth_code_grant_id_split = auth_code_grant_id.split('.')[0] # '261'
      auth_code_grant_instance_id = next(self.dict_extract_by_key(rj, 'instanceId', ("text", "Authorization Code Grant"))) # '8779$2'
      support_proof_key_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Support Proof Key for Code Exchange (PKCE)"))) # '268/wd:Support_Proof_Key_for_Code_Exchange__PKCE_'
      access_token_type_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Access Token Type"))) # 259
      bearer_instance_id = next(self.dict_extract_by_key(rj, 'instanceId', ("text", "Bearer"))) # '8780$1'
      redirect_uri_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Redirection URI")))
      inc_wd_scope_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Include Workday Owned Scope"))) # '268/wd:Include_Workday_Owned_Scope'
      scope_functional_areas_id = next(self.dict_extract_by_key(rj, 'id', ("label", "Scope (Functional Areas)"))) # '265'
      scope_context_id = next(self.dict_extract_by_key(rj, 'contextId', ("label", "Scope (Functional Areas)"))) # 'c0'
    except StopIteration as si:
      si.add_note('Element not found on Register API Client page!')
      raise si
    
    flowController_url = F'{base_url}/{tenant}/flowController.htmld'

    # Set Client Name
    data = {
      '_flowExecutionKey': flowKey, # e3s1
      client_name_id: client_name, # 268/wd:OAuth_2.0_Client_Name: My+Client
      '_eventId_validate': client_name_id, # 268/wd:OAuth_2.0_Client_Name
      'sessionSecureToken': sessionSecureToken,
      # 'clientRequestID': 'cac5267fdd1449f183cf7af4aa170739',
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Set Client Grant Type: Authorization Code Grant
    data = {
      '_flowExecutionKey': flowKey, # e3s1
      '_eventId_add': client_grant_type_id, #261
      client_grant_type_id: auth_code_grant_instance_id, # 261: 8779$2
      F'{auth_code_grant_instance_id}_DID': 'Authorization Code Grant', # 8779$2_DID: Authorization Code Grant
      F'{auth_code_grant_instance_id}_IID': auth_code_grant_instance_id, # 8779$2_IID: 8779$2
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: 487aafe952ed4d5393fc2a364f966cac
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Support Proof Key for Code Exchange (PKCE): Check this box
    data = {
      '_flowExecutionKey': flowKey, # e6s1
      support_proof_key_id: 1, # 268/wd:Support_Proof_Key_for_Code_Exchange__PKCE_: 1
      '_eventId_validate': support_proof_key_id, # 268/wd:Support_Proof_Key_for_Code_Exchange__PKCE_
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: 095998c97df44845b86534b177484a9a
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Access Token Type: Bearer (should already be set)
    data = {
      '_flowExecutionKey': flowKey, # e6s1
      'eventId_add': access_token_type_id, # 259
      access_token_type_id: bearer_instance_id, # 259: 8780$1
      F'{bearer_instance_id}_DID': 'Bearer',
      F'{bearer_instance_id}_IID': bearer_instance_id,
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: 095998c97df44845b86534b177484a9a
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Redirection URI
    data = {
      '_flowExecutionKey': flowKey, # e6s1
      redirect_uri_id: redirect_uri, # 268/wd:OAuth_2.0_Redirect_URI: https://
      '_eventId_validate': redirect_uri_id, # 268/wd:OAuth_2.0_Redirect_URI
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: 095998c97df44845b86534b177484a9a
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Include Workday Owned Scope: Check this box
    data = {
      '_flowExecutionKey': flowKey, # e6s1
      inc_wd_scope_id: 1, # 268/wd:Include_Workday_Owned_Scope: 1
      '_eventId_validate': inc_wd_scope_id, # 268/wd:Include_Workday_Owned_Scope
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: 095998c97df44845b86534b177484a9a
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Scope (Function Areas)
    scopes_url = F'{base_url}/{tenant}/prompt/{scope_context_id}/{scope_functional_areas_id}.htmld' # “Register API Client - Scopes” no /d/ to get json
    try:
      scopes_json = rs.get(scopes_url).json()
    except:
      raise Exception('Error accessing Register API Client - Scopes (Functional Areas) page!')
    custom_objects_instance_id = next(self.dict_extract_by_key(scopes_json, 'instanceId', ('text', 'Custom Objects'))) # "45$9226"
    data = {
      '_flowExecutionKey': flowKey, # e0s1
      '_eventId_prompt': scope_functional_areas_id, # 265
      'prompt': custom_objects_instance_id, # 45$9226
      'sessionSecureToken': sessionSecureToken,
    }
    r = rs.post(scopes_url, data=data)
    r.raise_for_status()
    # print(r.text)
    scope_list = r.json()['items']
    data = [
      ('_flowExecutionKey', flowKey), # e0s1
      ('_eventId_add', scope_functional_areas_id), # 265
      ('sessionSecureToken', sessionSecureToken),
    ]
    for scope in scope_list:
      scope_id = scope.get('instanceId')
      # print(F"Scope: {scope.get('text')}")
      data.append((scope_functional_areas_id, scope_id))
      data.append((F'{scope_id}_DID', scope.get('text')))
      data.append((F'{scope_id}_IID', scope_id))
      data.append((F'{scope_id}_V', 1 if scope.get('v') else 0))
      data.append((F'{scope_id}_PV', 1 if scope.get('pv') else 0))
    
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Submit
    data = {
      '_flowExecutionKey': flowKey, # e0s1
      '_eventId_submit': sequence_task_id, # 273
      'sessionSecureToken': sessionSecureToken,
      # clientRequestID: 095998c97df44845b86534b177484a9a
    }
    r = rs.post(flowController_url, data=data)
    r.raise_for_status()
    # print(r.text)

    # Get Client ID
    try:  
      rj = r.json()
    except:
      raise Exception('Error retrieving Client ID!')
    client_id = next(self.dict_extract_by_key(rj, 'value', ('label', 'Client ID')))
    return client_id

  def get_api_client_ids(self, base_url, tenant, username, password):
    rs = self.login(base_url, tenant, username, password)
    view_client_api_url = F'{base_url}/{tenant}/task/2998$15010.htmld' # “View API Clients” no /d/ to get json
    try:
      rj = rs.get(view_client_api_url).json()
    except Exception as e:
      raise Exception(F'Error accessing View API Clients page!\n{e}')
    # Get chunking url
    chunkingUrl = next(self.dict_extract_by_key(rj, 'chunkingUrl', ("label", "API Clients")))
    deepRowCount = next(self.dict_extract_by_key(rj, 'deepRowCount', ("label", "API Clients")))

    all_clients_url = F'{base_url}{chunkingUrl}.htmld?startRow=1&maxRows={deepRowCount}'
    all_clients_page = rs.get(all_clients_url)
    all_clients_results = all_clients_page.json()

    api_clients = []

    if all_clients_results.get('rows') is not None:
      for row in all_clients_results['rows']:
        # row['value'] = row.get('value', None)
        client_name = next((self.dict_extract_by_key(row, 'value', ("label", "Client Name"))), None)
        client_redirect_uri = next((self.dict_extract_by_key(row, 'value', ("label", "Redirection URI"))), None)
        client_id = next((self.dict_extract_by_key(row, 'value', ("label", "Client ID"))), None)
        api_clients.append([
          client_name, # Client Name
          client_redirect_uri, # Redirection URI
          client_id, # Client ID
        ])
    return api_clients    
  
if __name__ == "__main__":
  base_url = 'https://n-ddq4isgar85t2kke4481l.workdaysuv.com'
  service_base_url = base_url
  cc_tenant = 'customercentral'
  tenant = 'vacant'
  ccs_username = 'ccs' # CC Security Admin
  ccs_password = 'MIxBOg3uN@wdjDs8'
  username = 'ccu' # CC User / Implementer
  password = ccs_password
  cc_client_name = F'DAI AL API Client - {datetime.datetime.now()}'
  cc_redirect_uri = 'https://127.0.0.1/'
  tenant_client_name = F'DAI SLNG API Client - {str(datetime.datetime.now()).replace(':', '_')}'
  tenant_redirect_uri = F'{base_url}:3443/tenant/get-tokens/{tenant}'

  basic_auth = False

  client_id = None
  client_secret = None
  # client_id = 'YTIxNWRjYTYtZjgzNy00MjNjLTk3NmMtOTFiYWE3NjU4MmRh'
  # client_secret = '8fqtzsxrs1nvvlizcok6rp7ugh62trrt54todc83rah1tn5jljygepial6ud3wsgo8l94o27genpqy9965qit913v3empsu174b'

  oa = OAuth(client_id, client_secret)

  # # Register CC API Client
  # if not basic_auth and not client_id:
  #   cc_client_id, cc_client_secret = oa.register_cc_api_client(base_url, cc_tenant, ccs_username, ccs_password, cc_client_name, cc_redirect_uri)
  #   print(cc_client_id, cc_client_secret)
  
  # # Get CC Token
  # if basic_auth:
  #   token_type, token = oa.get_cc_auth_token_basic(service_base_url, cc_tenant, username, password)
  # else:
  #   token_type, token = oa.get_cc_auth_token(base_url, service_base_url, cc_tenant, client_id, client_secret, username, password)
  # print(token_type, token)

  # --------------------------------------

  # # Enable OAuth 2.0 Clients in a tenant
  # try:
  #   oa.enable_oauth_clients(base_url, tenant, username, password)
  # except Exception as e:
  #   e.add_note('Error enabling OAuth 2.0 Clients')
  #   raise(e)
  # print('OAuth 2.0 Clients Enabled')

  # # Get API Client IDs
  # try:
  #   api_client_ids = oa.get_api_client_ids(base_url, tenant, username, password)
  # except Exception as e:
  #   e.add_note('Error getting API Client IDs')
  #   raise(e)
  # print(api_client_ids)

  # # Register API Client in a tenant
  # try:
  #   client_id = oa.register_api_client(base_url, tenant, username, password, tenant_client_name, tenant_redirect_uri)
  # except Exception as e:
  #   e.add_note('Error registering API Client')
  #   raise(e)
  # print(client_id)
