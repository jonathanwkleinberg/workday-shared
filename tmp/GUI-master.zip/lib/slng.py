import requests
requests.packages.urllib3.disable_warnings()
import getpass
import time
import os, sys
import json
import pathlib

CurrentPath = pathlib.Path(__file__).parent
LibPath = CurrentPath

class TargetModelPaths(object):

    def __init__(self, data, inc_keys=True):
        """
        Discover file paths in the given data. If the data is JSON string,
        decode it. If already decoded into Python structures, use it directly.
        """
        self.inc_keys = inc_keys
        self.paths = []
        if isinstance(data, str):
            data = json.loads(data)
        self.traverse(data)
        # self.paths = reversed(self.paths)

    def traverse(self, n, prefix="/"):
        """
        Traverse the data tree. On terminal nodes, add columns/keys and tables
        found to self.paths
        """
        prefix = pathlib.PurePosixPath(prefix)
        if isinstance(n, list):
            for item in n:
                self.traverse(item, prefix)
        elif isinstance(n, dict):
            nodetype = n['type']
            nodename = n['title']
            if nodetype == 'TABLE':
                children = n.get('children')
                if children:
                    for c in children:
                        self.traverse(c, prefix / nodename)
                else:
                    self.paths.append(F"{prefix}/$")
            elif nodetype in (['COLUMN', 'PRIMARY_KEY', 'PARENT_KEY'] if self.inc_keys else ['COLUMN']):
                self.paths.append(prefix / F"{'*' if nodetype == 'PRIMARY_KEY' else '^' if nodetype == 'PARENT_KEY' else ''}{nodename}")
            # else:
            #     raise ValueError(F"didn't understand node named {nodename}, type {nodetype}")
        # else:
        #     raise ValueError(F"didn't understand node {n}")

class SLNG(object):
  mysql_host = None
  mysql_port = None
  session = None
  dc_id = None
  tenant = None
  suv = None
  suv_password = None
  debug = False

  def __init__(self, **kwargs):
    self.base_url = kwargs.get('url') or self.base_slng_url()
    self.base_url = '/'.join(self.base_url.split('/')[:3])
    if 'workdaysuv.com' in self.base_url:
      self.suv = self.base_url.split('/')[-1].split(':')[0]
      self.suv_password = kwargs.get('suv_password')
    self.username = kwargs.get('username') or getpass.getuser()
    self.password = kwargs.get('password') or (getpass.getpass()  if kwargs.get('interactive') else None)
    self.mysql_username = kwargs.get('mysql_username') or 'slng_user'
    self.mysql_password = kwargs.get('mysql_password') or (getpass.getpass("MySQL Password: ") if kwargs.get('interactive') else None)
    self.verify = False if 'workdaysuv.com' in self.base_url or 'localhost' in self.base_url or 'workdayinternal.com' in self.base_url else None
    self.debug = bool(kwargs.get('debug', self.debug))
    self.reset_session()

  @staticmethod
  def base_slng_url():
    os_computername = os.getenv('computername', '')
    os_location = os.getenv('location', '')
    if os_location == 'US' and 'PSR' in os_computername: # US Restricted VCR: 'US3P-XAP-PSR010'
      slng_url = "https://slng-us-res.workdayinternal.com"
    elif os_location == 'US': # US VCR: 'US3P-XAP-PS043'
      slng_url = "https://slng-us.workdayinternal.com"
    elif os_location == "CAN" and 'PSR' in os_computername: # CAN 5eyes VCR: 'CC1A-XAP-PSR11' ?? Haven't tested.
      slng_url = "https://slng-5e.workdayinternal.com"
    elif os_location == "CAN": # CAN VCR: 'CC1A-XAP-PS17'
      slng_url = "https://slng-ca.workdayinternal.com"
    elif os_location == "EU" and 'PSR' in os_computername: # EMEA Restricted VCR: 'NL1P-XAP-PSR010'
      slng_url = "https://slng-eu-res.workdayinternal.com "
    elif os_location == "EU": # EMEA VCR: 'NL1P-XAP-PS014'
      slng_url = "https://slng-eu.workdayinternal.com"
    elif os_location == "AUS": # AUS VCR: 'AS2A-XAP-PS12' ??? always AS2A ???
      slng_url = "https://slng-au.workdayinternal.com"
    elif os_location == "SGP": # SGP VCR: 'AS1B-XAP-PS11' ??? always AS1B ???
      slng_url = "https://slng-sgp.workdayinternal.com"
    else: # Default
      slng_url = "Unknown Location"
    return slng_url
  
  def base_checker_url():
    os_computername = os.getenv('computername', '')
    os_location = os.getenv('location', '')
    if os_location == 'US' and 'PSR' in os_computername: # US Restricted VCR: 'US3P-XAP-PSR010'
      checker_url = "https://checker-us-res.workdayinternal.com"
    elif os_location == 'US': # US VCR: 'US3P-XAP-PS043'
      checker_url = "https://checker-us.workdayinternal.com"
    elif os_location == "CAN" and 'PSR' in os_computername: # CAN 5eyes VCR: 'CC1A-XAP-PSR11' ?? Haven't tested.
      checker_url = "https://checker-5e.workdayinternal.com"
    elif os_location == "CAN": # CAN VCR: 'CC1A-XAP-PS17'
      checker_url = "https://checker-ca.workdayinternal.com"
    elif os_location == "EU" and 'PSR' in os_computername: # EMEA Restricted VCR: 'NL1P-XAP-PSR010'
      checker_url = "https://checker-eu-res.workdayinternal.com "
    elif os_location == "EU": # EMEA VCR: 'NL1P-XAP-PS014'
      checker_url = "https://checker-eu.workdayinternal.com"
    elif os_location == "AUS": # AUS VCR: 'AS2A-XAP-PS12' ??? always AS2A ???
      checker_url = "https://checker-au.workdayinternal.com"
    elif os_location == "SGP": # SGP VCR: 'AS1B-XAP-PS11' ??? always AS1B ???
      checker_url = "https://checker-sgp.workdayinternal.com"
    else: # Default
      checker_url = "Unknown Location"
    return checker_url

  def reset_session(self):
    self.session = requests.Session()
    self.login()

  def login(self):
    if 'workdaysuv.com' in self.base_url:
        return True
    if all([self.username, self.password]):
      response = self.post("/authenticate/login", {'username': self.username,'password': self.password})
      # Successfull login will not contain the login error message in the text
      if "Invalid user name or password" in response:
        raise Exception('Invalid Username or Password')
      return response
    else:
      raise Exception('Missing Username or Password')

  def cookie_expired(self):
    if not self.session.cookies: return True
    return time.time() >= next(x for x in self.session.cookies if x.name == 'slng_cookie').expires
  
  def return_r(self, r):
    if not r.ok: 
      if self.debug: return r.json().get('msg') 
      else: r.raise_for_status() 
    try: r_return = r.json()
    except: r_return = r.text
    return r_return
  
  def get(self, path):
    if self.cookie_expired(): self.login()
    r = self.session.get(F"{self.base_url}{path}", verify=self.verify)
    return self.return_r(r)
  
  def post(self, path, payload=None, files=None):
    if not '/authenticate/login' in path and self.cookie_expired(): self.login()
    r = self.session.post(F"{self.base_url}{path}", json=payload, files=files, verify=self.verify)
    return self.return_r(r)
  
  def delete(self, path):
    if self.cookie_expired(): self.login()
    r = self.session.delete(F"{self.base_url}{path}", verify=self.verify)
    return self.return_r(r)

  def get_db_user_metadata(self):
    return self.get("/db-info/db-user-metadata?user=slng_user")
  
  def get_db_endpoint(self):
    r_json = self.get("/db-info/db-endpoint")
    self.mysql_host = r_json['mysqlHost']
    self.mysql_port = r_json['mysqlPort']
    return r_json
  
  def get_data_centers(self):
    return self.get("/tenant/data-centers")
      
  def get_global_config(self):
    return self.get("/project/global-config")
  
  def get_sftp_config(self):
    return self.get("/sftp/sftp-config")
  
  def get_connections(self):
    return self.get("/connections")
  
  def set_db_password(self):
    return self.post("/db-info/db-set-password", {"password": self.mysql_password, "user": self.mysql_username})
  
  def get_web_services(self):
    return self.get("/tenant/web-services")

  def get_target_model_tree(self, table):
    return self.get(F'/target-model/tree?table={table}')
  
  def get_operations_in_scope(self):
    return self.get('/project/operations-in-scope')
  
  def get_all_operations(self): # Will fail if not all WSDLs downloaded.
    return self.get('/project/all-operations')
  
  def get_all_wsdl_list(self):
    web_services = [ws['service'] for ws in self.get_web_services()['webServices']]
    if self.debug: print(web_services)
    return self.get_wsdl_list(web_services)
  
  def get_wsdl_list(self, services=[]):
    return self.post('/project/get-wsdl-list', {'services':services})
  
  def get_job_status(self, job_id, q='transform'):
    # /jobs?q=statement&id=34
    # transform, import, statement
    return self.get(F'/jobs?q={q}&id={job_id}')
  
  def generate_target_model(self, version, operations):
    return self.post('/target-model/generate', {"version":version, "operations": operations}) # {"Staffing": ["Put_Applicant"]}
  
  def set_wsdl_version(self, version):
    return self.post('/project/update-global-config', {'wsdlVersion': version})
  
  def set_suv_data_center(self, host=None):
    host = host if host else self.base_url.split('/')[-1].split(':')[0]
    if not 'workdaysuv.com' in host:
      return False
    file_string = """
REPLACE INTO slng_data_centers (slng_id, data_center, url_soap, url_loadapi, url_blobitory, url_web, level)
VALUES
  (
    (SELECT * FROM (SELECT slng_id FROM slng_data_centers WHERE url_web LIKE '%$SUV_HOST%' LIMIT 1) z),
    CONCAT('SUV - ', SUBSTRING_INDEX('$SUV_HOST', '.', 1)),
    'https://$SUV_HOST/ccx/service',
    'https://$SUV_HOST/ccx/LoadAPI',
    'https://$SUV_HOST/ccx/cc-blobitory',
    'https://$SUV_HOST/',
    'Non-Prod'
  );
"""
    file_string = file_string.replace('$SUV_HOST', host)
    return self.transform_string('slng_data_centers.sql', file_string)

  def set_sales_data_centers(self):
    sql = """
REPLACE INTO slng_data_centers (slng_id, data_center, url_soap, url_loadapi, url_blobitory, url_web, level)
VALUES
  (
    (SELECT * FROM (SELECT slng_id FROM slng_data_centers WHERE data_center = 'Sales-100 (WD99)' LIMIT 1) z),
    'Sales-100 (WD99)',
    'https://sales100-services1.wd99.myworkday.net/ccx/service',
    'https://sales100-enterprise-services1.wd99.myworkday.net/ccx/LoadAPI',
    'https://sales100-services1.wd99.myworkday.net/ccx/cc-blobitory',
    'https://sales100.wd99.myworkday.net',
    'Impl'
  ),
  (
    (SELECT * FROM (SELECT slng_id FROM slng_data_centers WHERE data_center = 'Sales-200 (WD99)' LIMIT 1) z),
    'Sales-200 (WD99)',
    'https://sales200-services1.wd99.myworkday.net/ccx/service',
    'https://sales200-enterprise-services1.wd99.myworkday.net/ccx/LoadAPI',
    'https://sales200-services1.wd99.myworkday.net/ccx/cc-blobitory',
    'https://sales200.wd99.myworkday.net',
    'Impl'
  );
"""
    return self.transform_string('sales_data_centers.sql', sql)

  def set_suv_connection(self, dc_id=None, tenant=None, username='ccu', password=None):
    if dc_id: self.dc_id = dc_id
    if tenant: self.tenant = tenant
    if self.dc_id or not self.tenant:
      self.set_dc_id_tenant(self.dc_id, self.tenant)
    if password: self.suv_password = password
    data = {
      "connections": [
        {
          "name":F"SUV ({username}@{self.tenant})",
          "tenant":self.tenant,
          "dataCenterId":self.dc_id,
          "username":username,
          "password":self.suv_password,
          "unescapedPassword":self.suv_password,
          "clientId":"",
          "isConnectionSuccessful":True,
          "isDefault":True,
          "uuid":"SLNG_LIB_SUV_CONNECTION",
          "tenantLevel":"Non-Prod",
          "msg":"",
          "valid":False}
      ],"deletedConnections":[]
    }
    r = self.post('/connections', payload=data)
    if self.debug: print(r)
    return r

  def set_suv_sftp(self, host=None, port='22', username='root'):
    host = host if host else self.base_url.split('/')[-1].split(':')[0]
    data = {
      "defaultErrorDir":"",
      "defaultWorkerDocsDir":"",
      "defaultImportDir":"",
      "defaultTransformDir":"",
      "defaultXmlDir":"",
      "defaultBackupDir":"",
      "defaultRestoreDir":"",
      "defaultMiscellaneousDir":"",
      "host":host,
      "port":str(port),
      "username":username
    }
    r = self.post('/sftp/sftp-config', payload=data)
    if self.debug: print(r)
    return r

  def transform_string(self, file_name, file_string):
    files = {'files': (file_name, file_string)}
    r = self.post('/uploads?uploadType=transform&replace=1', files=files)
    if self.debug: print(r)
    r = self.post('/uploads/transform-data')
    if self.debug: print(r)
    return r

  def import_source_data(self, file_name, file_string, action='append'):
    files = {'files': (file_name, file_string)}
    r = self.post('/uploads?uploadType=import&replace=0', files=files)
    if self.debug: print(r)
    file_path = pathlib.PurePosixPath(r[0]['path'])
    file_size = r[0]['size']
    # data = {"clientId":"10f35401-3e91-4989-842c-8ac3196b4729","mappings":[{"action":"append","delimiter":",","encoding":"utf8","escape":"\"","quote":"\"","linebreak":"\r\n","aborted":false,"truncated":false,"cursor":2975,"completed":false,"error":null,"fname":"addupdate_employee_leave_of_absence.csv","fpath":"uploads/import","tableName":"src_addupdate_employee_leave_of_absence","working":false}],"tenantSettings":{"tenant":"vacant","tenantConnection":"","dataCenterId":"25","username":"ccu","unescapedPassword":"OtG4JCo+xSNM8nZm","connected":true,"password":"OtG4JCo+xSNM8nZm"}}
    data = {"mappings":[{"action":action,"delimiter":",","encoding":"utf8","escape":'"',"quote":'"',"linebreak":"\r\n","aborted":False,"truncated":False,"cursor":2975,"completed":False,"error":None,"fname":file_name,"fpath":str(file_path.parent),"tableName":F"src_{file_path.stem}","working":False}]}
    r = self.post('/uploads/persist-source-files', payload=data)
    if self.debug: print(r)
    return r

  def call_procedure(self, procedure_name, parameters=[]):
    # {"procedures":[{"procedureName":"sp_AddUpdate_Employee_Leave_of_Absence_DCS","parameters":[],"id":"387423ab-fd3d-4ee5-8c5f-7ef262ecc94f","isRecentAddition":true}],"common":{"clientId":"321eab68-1a88-4dbd-a1c8-382e8d7303ca"},"tenantSettings":{"tenant":"super","tenantConnection":"","dataCenterId":"25","username":"ccu","unescapedPassword":"OtG4JCo+xSNM8nZm","connected":true,"password":"OtG4JCo+xSNM8nZm"}}
    r = self.post('/uploads/call-procedure', payload={"procedures":[{"procedureName":procedure_name,"parameters":parameters}]})
    if self.debug: print(r)
    return r

  def build_single_xml(self, version, service, operation, record="1"):
    r = self.post('/wws-xml/build-single-xml', {"version":version, "service":service, "operation":operation, "where":str(record)})
    if self.debug: print(F'["ok": {r["ok"]}]')
    return r['xml']

  def download_wsdls(self, version, web_services=()):
    if not self.dc_id or not self.tenant:
      self.set_dc_id_tenant(self.dc_id, self.tenant)
    if not self.dc_id or not self.tenant:
      return {'Error':'Missing Data Center ID or Tenant'}

    if not version:
      global_config = self.get_global_config()
      if global_config['config']['wsdlVersion']:
        version = global_config['config']['wsdlVersion']
        if self.debug: print('version:', version)
    else:
      r = self.set_wsdl_version(version)
      if self.debug: print(r)
    if not version:
      return {'Error': 'Missing WSDL Version'}
    
    # Get Web Services
    ws_json = self.get_web_services()
    wsdl_json = self.get_all_wsdl_list()
    wsdl_dict = {wsdl['service']:json.loads(wsdl['response_text']) for wsdl in wsdl_json['wsdlInfos'] if wsdl['result'] == 'Success'}
    if self.debug: print(wsdl_dict)
    # Filter out service not in the param (or all) and that have not already been downloaded
    ws = [x['service'] for x in ws_json.get('webServices') if ((x['service'] in web_services) if web_services else True) and not wsdl_dict[x['service']]]
    if self.debug: print(ws)
    # ws = [ws[0]] # testing
    r_return = []
    for w in ws:
      r = self.download_wsdl({
        'service': w,
        'settings': {
          'dataCenterId': self.dc_id,
          'tenant': self.tenant,
        },
        'version': version,
      })
      if self.debug: print(r)
      r_return.append(r)
    return r_return
      
  def download_wsdl(self, data):
    return self.post('/project/download-wsdl', payload=data)

  def set_dc_id_tenant(self, dc_id=None, tenant=None):
    if not dc_id and 'workdaysuv.com' in self.base_url:
      dcs = self.get_data_centers().get('dataCenters', [])
      self.dc_id = next((x['id'] for x in dcs if self.suv in x['urlWeb']), None)
      if not self.dc_id: # SUV not found
        self.set_suv_data_center()
        dcs = self.get_data_centers().get('dataCenters', [])
        self.dc_id = next((x['id'] for x in dcs if self.suv in x['urlWeb']), None)
        if not self.dc_id: return
    elif dc_id: self.dc_id = dc_id
    else: self.dc_id = self.get_data_centers().get('dataCenters', [{'id':0}])[0]['id'] # default in VCR?
    if not tenant and 'workdaysuv.com' in self.base_url: self.tenant = 'super'
    elif tenant: self.tenant = tenant
    else: self.tenant = 'wdprofservices_ldp1' # default in VCR?

  def reset_all(self):
    return_data = {}
    # Delete WSDLs, files
    return_data['wsdls'] = self.delete('/project/objects?object=wsdls')
    return_data['files'] = self.delete('/project/files')
    return_data['init'] = self.post('/project/initialize-db')
    # SUV Only
    if 'workdaysuv.com' in self.base_url: 
      return_data['suv_dc'] = self.set_suv_data_center()
      return_data['suv_conn'] = self.set_suv_connection()
      return_data['suv_sftp'] = self.set_suv_sftp()
    return return_data

  def task_save_all_web_service_operations(self, version, path=None):
    if not version:
      return []
    self.reset_all()
    # Setup SUV (dc_id and tenant) if needed:
    if 'workdaysuv.com' in self.base_url:
      self.set_dc_id_tenant()
    # Download ALL WSDLs
    self.download_wsdls(version)
    # Get All Operations
    srvc_ops = self.get_all_operations().get('operations', {}).get('response_text', [])
    op_dict = {op:[srvc['service'] for srvc in srvc_ops if srvc['operation'] == op] for op in [srvc_op['operation'] for srvc_op in srvc_ops]}
    if path:
      with open(path, "w") as f:
        f.write(json.dumps(op_dict, indent=2))
    else:
      return op_dict
    
  def task_get_target_model(self, version, service, operation, inc_keys=True):
    if not all([version, service, operation]):
      return []
    self.reset_all()
    # Download WSDL
    self.download_wsdls(version, web_services=(service,) )
    # Generate Target Model
    self.generate_target_model(version, {service:[operation]})
    # Get Target Model Tree
    operation_main_table = self.get_operations_in_scope().get('operations')[0]['mainTable']
    tree = self.get_target_model_tree(operation_main_table).get('tree')
    if self.debug: print(tree)
    tree_paths = TargetModelPaths(tree, inc_keys=inc_keys)
    return tree_paths.paths


if __name__ == "__main__":
  import keyring, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  ad_user, ad_pass, db_pass = tuple(map(dict_config.get, ('ad_username', 'ad_password', 'db_password')))
  # s = SLNG(password=ad_pass, mysql_password=db_pass, url="https://n-vud3vapvg863ebglkjme.workdaysuv.com:3443", suv_password='OtG4JCo+xSNM8nZm', interactive=True, debug=False)
  # s = SLNG(password=ad_pass, mysql_password=db_pass, url="https://n-zdd3vapvg863ebglkjmd.workdaysuv.com:3443", suv_password='7Y+PRxVr0csnyQD5', interactive=True, debug=True)
  # s = SLNG(url="https://n-ibhnk1o3ckup6dge2fidi.workdaysuv.com:3443", suv_password='Lq+8JoXYzDUnrd67', debug=False)

  # VCR
  # s = SLNG(password=ad_pass, mysql_password=db_pass, debug=True)

  # Localhost
  s = SLNG(username=ad_user, password=ad_pass, mysql_password=db_pass, url="https://localhost", debug=False)
  # Localhost SUV DataCenter
  s.set_suv_data_center(host='n-ddq4isgar85t2kke4481l.workdaysuv.com')

  # Reset SLNG pod to default (will erase everything), if SUV, will set database and default connection
  # print("Resetting SLNG ...")
  # r = s.reset_all()
  # print(r)

  # print("Info:", s.get_db_endpoint(), "SLNG_USER:", s.get_db_user_metadata(), "Global Config:", s.get_global_config())

  # Update SUV with Sales Data Centers
  # print("Setting Sales Data Centers ...")
  # r = s.set_sales_data_centers() # Transform Type
  # jid = r.get('jobId')
  # print(jid, end=': ')
  # j = s.get_job_status(jid, 'transform')
  # if type(j) == dict and j.get('state') == 'completed':
  #   print('Job Completed')
  # else:
  #   print(j)

  # try:
  #   from dcdd import DCDD
  #   from github import GitHub
  # except:
  #   sys.path.append(LibPath.absolute().as_posix())
  #   from dcdd import DCDD
  #   from github import GitHub

  # g = GitHub(username=dict_config['ad_username'], password=dict_config['ad_password'])
  # print("Getting Stored Procedure ...")
  # sp = g.get_file(url='https://ghe.megaleo.com/Workday-Data-Conversion/SLNG2.0-Direct/blob/master/DC_Standard/Stored_Procedures/sp_AddUpdate_Employee_Leave_of_Absence_DCS.sql')
  # print("Getting DCDD ...")
  # d = DCDD(json=R'C:\Users\andy.parker\Documents\GitHub\DCDD_JSON\JSONs\absence\AddUpdate_Employee_Leave_Of_Absence_DCDD.json')
  # # d = DCDD(ss='gG984GvRJ8XMM3J7qpfGX8J4R5268fPPQRwMxVJ1', token=dict_config['ss_token'])
  # # d = DCDD(gh='https://ghe.megaleo.com/DTOE/DCDD_JSON/blob/master/JSONs/absence/Put_Period_Schedule_DCDD.json', username=dict_config['ad_username'], password=dict_config['ad_password'])
  # print("Downloading WSDLs ...")
  # print(d.version, d.web_services, d.operation)
  # s.download_wsdls(d.version, d.web_services)
  # print("Generating Target Model ...")
  # s.generate_target_model(d.version, {d.web_services[0]:[d.operation]})
  # print("Loading DDL ...")
  # s.transform_string(F'{d.name}_ddl.sql', d.to_ddl())
  # for csv_name, csv_data in d.to_csv(format='sequential').items():
  #   # print(F"{csv_name}\n{csv_data}")
  #   print(F"Importing {csv_name} ...")
  #   s.import_source_data(csv_name, csv_data)
  # print("Loading Stored Procedure ...")
  # s.transform_string('sp_AddUpdate_Employee_Leave_of_Absence_DCS.sql', sp)
  # print("Calling Stored Procedure ...")
  # s.call_procedure('sp_AddUpdate_Employee_Leave_of_Absence_DCS')
  # print("Building XML ...\n")
  # xml_data = s.build_single_xml(d.version, d.web_services[0], d.operation)
  # # print(xml_data)
  # from xml.dom import minidom
  # dom = minidom.parseString(xml_data)
  # pretty_xml = dom.toprettyxml(indent="  ")
  # print(pretty_xml)


  # version = 'v41.2'
  # operations = {
  #   'Staffing': [
  #     'Put_Applicant',
  #     'Change_Job',
  #   ],
  # }

  # Download specific WSDLs
  # s.download_wsdls(version, tuple(operations.keys()))
  # Download ALL WSDLs
  # s.download_wsdls(version)

  # Get All Operations
  # r = s.get_all_operations()
  # print(r)

  # Generate specific target models
  # r = s.generate_target_model(version, operations)
  # print(r)

  # operations_in_scope = s.get_operations_in_scope().get('operations')

  # def parse_tree(node, table=None):
  #   output = []
  #   if node['type'] in ['TABLE', 'TREE']:
  #     new_table = node['title']
  #   if node['type'] in ['COLUMN']:
  #     # print(table, node['title'])
  #     output.append((table, node['title']))
  #   children = node.get('children')
  #   if children:
  #     # for c in children: parse_tree(c, new_table)
  #     for c in children: output.extend(parse_tree(c, new_table))
  #   return output

  # for op in operations_in_scope:
  #   tree = s.get_target_model_tree(op['mainTable']).get('tree')
  #   print('---------', op, '---------')
  #   fields = parse_tree(tree)
  #   _ = [print(x, y) for x, y in fields]


  # Create a JSON file for the DCDD updater
  # VERSIONS = [
    # 'v45.2','v45.1','v45.0',
    # 'v44.2','v44.1','v44.0',
    # 'v43.2','v43.1','v43.0',
    # 'v42.2','v42.1','v42.0',
    # 'v41.2','v41.1','v41.0',
    # 'v40.2','v40.1','v40.0',
    # 'v39.2','v39.1','v39.0',
    # 'v38.2','v38.1','v38.0',
  # ]
  # for version in VERSIONS:
  #   json_path = pathlib.Path(__file__).parent.parent.parent / 'DCDD_Tools' / 'Tools' / 'DCDD_Updater_Resources' / F'operations_{version}.json'
  #   print(json_path)
  #   s.task_save_all_web_service_operations(version, json_path)


  # Get Target Model Paths
  # version = 'v42.0'
  # service = 'Resource_Management'
  # operation = 'Put_Supplier'
  # tmpaths = s.task_get_target_model(version, service, operation, inc_keys=False)
  # # _ = [print(x) for x in paths]
  # path = pathlib.Path(__file__).parent.parent.parent / 'DCDD_Tools' / 'Tools' / 'DCDD_Updater_Resources' / F'{version}_{operation}_tmpaths.csv'
  # with open(path, "w") as f: 
  #   for x in tmpaths: f.write(F'{x}\n')
  # print(path)

