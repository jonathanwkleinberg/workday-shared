import mysql.connector # mysql-connector-python
import os, csv, sys

class MySQL(object):

  cnx_config = {
    'host': '',
    'port': '',
    'user': "slng_user",
    'passwd': '',
    'database': "hellboy",
    'autocommit': True,
  }
  authenticated = False
  cnx = None

  def __init__(self, **kwargs):
    if kwargs.get('host'): self.cnx_config['host'] = kwargs.get('host')
    if kwargs.get('port'): self.cnx_config['port'] = kwargs.get('port')
    if kwargs.get('user'): self.cnx_config['user'] = kwargs.get('user')
    if kwargs.get('passwd'): self.cnx_config['passwd'] = kwargs.get('passwd')
    if kwargs.get('password'): self.cnx_config['passwd'] = kwargs.get('password') # just in case someone uses password instead of passwd
    if kwargs.get('database'): self.cnx_config['database'] = kwargs.get('database')
    if kwargs.get('autocommit'): self.cnx_config['autocommit'] = kwargs.get('autocommit')

  def connect(self, stay_alive=False):
    try: 
      self.cnx = mysql.connector.connect(**self.cnx_config)
    except:
      self.authenticated = False
      self.cnx = None
      raise
    else:
      self.authenticated = True
      if not stay_alive:
        self.cnx.close()
        self.cnx = None

  def close(self):
    if self.cnx:
      self.cnx.close()
      self.cnx = None

  def load_gh_sql(self, file):
    if not self.cnx: self.connect(stay_alive=True)
    if not self.authenticated:
      return
    crsr = self.cnx.cursor()
    results = crsr.execute(file, multi=True)
    try: 
      for result in results:
        pass
    except Exception as e:
      print(e, file=sys.stderr)
    crsr.close()

  def load_gh_csv(self, name, file, truncate=False):
    if not self.cnx: self.connect(stay_alive=True)
    if not self.authenticated:
      return
    crsr = self.cnx.cursor()
    tablename = 'src_' + os.path.basename(name)[:os.path.basename(name).find('.csv')].lower()

    if truncate:
      # print(F"  Truncating {tablename} and inserting data ...")
      crsr.execute(F"TRUNCATE {tablename}")
    else:
      # print(F"  Dropping existing  {tablename} and re-inserting data into DB...")
      crsr.execute(F"DROP TABLE IF EXISTS `{tablename}`")
      crsr.execute(F"CREATE TABLE IF NOT EXISTS `{tablename}` ( {col_list} )")
    csv_data = csv.reader(file.decode("utf-8").splitlines())
    header = next(csv_data)
    col_list = ', '.join([F"`{x}` TEXT" for x in header])
    for row in csv_data:
      crsr.execute(F"""INSERT IGNORE INTO {tablename}({",".join([F"`{x}`" for x in header])}) VALUES({', '.join([*len(row)*('%s',)])})""",tuple(row))

if __name__ == "__main__":
  import keyring, json, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  m = MySQL(user=dict_config['db_username'], passwd=dict_config['db_password'], host=dict_config['db_host'], port=dict_config['db_port'])
  # m = MySQL(user='root', passwd='myDbPassword', host=dict_config['db_host'], port=dict_config['db_port'])
  print(m.cnx_config)
  m.connect()
  print('Authenticated:', m.authenticated)