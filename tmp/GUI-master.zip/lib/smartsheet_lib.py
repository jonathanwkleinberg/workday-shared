import requests, sys
try:
  import smartsheet # smartsheet-python-sdk
  import smartsheet.models
  import smartsheet.workspaces
except:
  pass

class SmartsheetLib(object):

  def __init__(self, token):
    if not token:
      raise Exception('Missing Smartsheet Token')
    self.client = smartsheet.Smartsheet(token)

  def get_folder_hierarchy(self, folder_id):
    folders = self.client.Folders.list_folders(folder_id).data
    for folder in folders:
      folder.sub_folders = self.get_folder_hierarchy(folder.id)
    return folders
  
  def get_tracking_sheet(self, tracking_sheet_id, require_hyperlink=True, require_ready=True):
    tracking_sheet_data = self.client.Sheets.get_sheet(tracking_sheet_id)
    # print("Loaded Sheet: " + tracking_sheet_data.name)
    tracking_sheet_url_id = tracking_sheet_id
    self.tracking_sheet_id = tracking_sheet_data.id # Get real ID (if not already)
    self.tracking_sheet_columns = {x.title:y for y,x in enumerate(tracking_sheet_data.columns)} # Indexes
    self.tracking_sheet_columns_ids = {x.title:x.id for x in tracking_sheet_data.columns}  # IDs
    CAT_COL = next(c for c in self.tracking_sheet_columns if c.lower() in ['category'])
    DCDD_COL = next(c for c in self.tracking_sheet_columns if c.lower() in ['dcdd', 'dcdds', 'file name (dcdd name)', 'file name'])
    SKU_COL = next((c for c in self.tracking_sheet_columns if c.lower() in ['functional area', 'workstream (fa)', 'workstream', 'skus', 'sku']), None)
    if require_ready:
      IN_SCOPE_COL = next((c for c in self.tracking_sheet_columns if c.lower() in ['dcdd ready', 'in scope for build?', 'in scope']), None) # this is a checkbox - don't use .display_value
    else: IN_SCOPE_COL = None
    ORDER_COL = next((c for c in self.tracking_sheet_columns if c.lower() in ['load order', 'order', 'priority order', 'priority', 'prioritization']), None)
    LINK_ID = "LINK_ID"
    self.tracking_sheet_column_names = {
      'CAT_COL': CAT_COL,
      'DCDD_COL': DCDD_COL,
      'SKU_COL': SKU_COL,
      'IN_SCOPE_COL': IN_SCOPE_COL,
      'ORDER_COL': ORDER_COL,
      'LINK_ID': LINK_ID,
    }
    self.tracking_sheet_rows = [{
      **{LINK_ID:(r.cells[self.tracking_sheet_columns[DCDD_COL]].hyperlink and r.cells[self.tracking_sheet_columns[DCDD_COL]].hyperlink.url.split('/')[-1].split('?')[0] ) or None},
      **{"ROW_ID":r.id},
      **{c: r.cells[self.tracking_sheet_columns[c]].display_value if r.cells[self.tracking_sheet_columns[c]].display_value else r.cells[self.tracking_sheet_columns[c]].value for c in self.tracking_sheet_columns} 
    } for r in tracking_sheet_data.rows if ((r.cells[self.tracking_sheet_columns[DCDD_COL]].hyperlink and r.cells[self.tracking_sheet_columns[DCDD_COL]].hyperlink.url) if require_hyperlink else True) and (r.cells[self.tracking_sheet_columns[IN_SCOPE_COL]].value if IN_SCOPE_COL else True)]

  def get_sheet_data(self, sheet_id):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    dcdd_sheet = self.client.Sheets.get_sheet(sheet_id)
    sheet_id = dcdd_sheet.id # Get real ID (if not already)
    dcdd_columns = {x.title:y for y,x in enumerate(dcdd_sheet.columns)}
    dcdd_columns_ids = {x.title:x.id for x in dcdd_sheet.columns}
    dcdd_rows = [{c: r.cells[dcdd_columns[c]].display_value if r.cells[dcdd_columns[c]].display_value else r.cells[dcdd_columns[c]].value for c in dcdd_columns} for r in dcdd_sheet.rows]
    # get summary data
    dcdd_summary = self.client.Sheets.get_sheet_summary_fields(sheet_id, include_all=True)
    summary_data = {f.title: str(f.object_value.value).replace(u'\ufeff', '').strip() if f.object_value and hasattr(f.object_value, 'value') else None for f in dcdd_summary.data}
    self.client.raise_exceptions = current_raise_exceptions
    sheet_dict = {
      'sheet_id': sheet_id,
      'columns': dcdd_columns_ids,
      'rows': dcdd_rows,
      'summary': summary_data,
      'permalink': dcdd_sheet.permalink,
      'name': dcdd_sheet.name
    }
    return sheet_dict

  def copy_sheet(self, sheet_id, destination_id, destination_type='folder', sheet_name=None, ):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    if sheet_name is None:
      sheet_name = self.client.Sheets.get_sheet(sheet_id).name
    new_sheet = self.client.Sheets.copy_sheet(
      sheet_id,
      smartsheet.models.ContainerDestination({
        'destination_type': destination_type,         
        'destination_id': destination_id, 
        'new_name': sheet_name
      }),
      include='data'
    )
    self.client.raise_exceptions = current_raise_exceptions
    return new_sheet
  
  def move_sheet(self, sheet_id, destination_id, destination_type='folder'):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    new_sheet = self.client.Sheets.move_sheet(
      sheet_id,
      smartsheet.models.ContainerDestination({
        'destination_type': destination_type,         
        'destination_id': destination_id, 
      })
    )
    self.client.raise_exceptions = current_raise_exceptions
    return new_sheet
  
  def create_folder(self, parent_id, parent_type, folder_name):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    if parent_type == 'workspace':
      new_folder = self.client.Workspaces.create_folder_in_workspace(parent_id, folder_name)
    elif parent_type == 'folder':
      new_folder = self.client.Folders.create_folder_in_folder(parent_id, folder_name)
    else: # home
      new_folder = self.client.Home.create_folder(folder_name)
    self.client.raise_exceptions = current_raise_exceptions
    return new_folder
  
  def copy_folder(self, folder_id, target_id, target_type='folder', new_name=None, log=False):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    # Get current folder
    ss_folder = self.client.Folders.get_folder(folder_id)
    # Use current name if new_name is None
    if not new_name: new_name = ss_folder.name
    # Sheet count
    num_sheets = len(ss_folder.sheets)

    # Copy Folder if < 100
    if num_sheets < 100:
      new_folder = self.client.Folders.copy_folder(
        folder_id, 
        self.client.models.ContainerDestination({
          **({'destination_id': target_id} if target_type != 'home' else {}),
          'destination_type': target_type,
          'new_name': new_name
        })
      )
    else:
      new_folder = self.create_folder(target_id, target_type, new_name)
      for i, sheet in enumerate(ss_folder.sheets, 1):
        if log: print(F"Copying Sheet {i} of {num_sheets}")
        self.copy_sheet(sheet.id, new_folder.result.id, 'folder', sheet_name=sheet.name)
    self.client.raise_exceptions = current_raise_exceptions
    return new_folder.result
  
  def move_folder_sheets(self, folder_id, target_id, target_type='folder', new_name=None, log=False):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    # Get number of sheets in folder
    ss_folder = self.client.Folders.get_folder(folder_id)
    num_sheets = len(ss_folder.sheets)

    # Move sheets
    if new_name:
      new_folder_result = self.create_folder(target_id, target_type, new_name)
      new_folder = new_folder_result.result
      new_folder_id = new_folder.id
    else:
      new_folder = ss_folder
      new_folder_id = target_id
    for i, sheet in enumerate(ss_folder.sheets, 1):
      if log: print(F"Copying Sheet {i} of {num_sheets}")
      self.move_sheet(sheet.id, new_folder_id, 'folder')
    self.client.raise_exceptions = current_raise_exceptions
    return new_folder
  
  def get_url_from_sheet_id(self, sheet_id):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    sheet = self.client.Sheets.get_sheet(sheet_id)
    self.client.raise_exceptions = current_raise_exceptions
    return sheet.permalink
  
  def get_url_from_folder_id(self, folder_id, folder_type='folder'):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    if folder_type == 'workspace':
      folder = self.client.Workspaces.get_workspace(folder_id)
    elif folder_type == 'folder':
      folder = self.client.Folders.get_folder(folder_id)
    else: # home
      folder = type('x', (object,), {"permalink":"https://app.smartsheet.com/folders/personal"})
    self.client.raise_exceptions = current_raise_exceptions
    return folder.permalink

  def get_root_tree(self):
    response = self.client.Workspaces.list_workspaces(include_all=True)
    workspaces = response.data
    return [{'type':'workspace', **x.to_dict()} for x in workspaces] + [{'type':'home', 'name':'Sheets', 'id':'/folders/personal', 'permalink': 'https://app.smartsheet.com/folders/personal'}]

  def get_tree_folders(self, id, type='folder'):
    tree_list = []
    # print(id, type)
    if type == 'workspace':
      response = self.client.Workspaces.list_folders(
        id,       # workspace_id
        include_all=True)
      workspace_folders = response.data
      tree_list = [{'type':'folder', **x.to_dict()} for x in workspace_folders]
    elif type == 'folder':
      response = self.client.Folders.list_folders(
        id,       # folder_id
        include_all=True)
      folder_folders = response.data
      tree_list = [{'type':'folder', **x.to_dict()} for x in folder_folders]
    elif type == 'home':
      response = self.client.Home.list_folders(include_all=True)
      home_folders = response.data
      tree_list = [{'type':'folder', **x.to_dict()} for x in home_folders]
    return tree_list
  
  def get_tree_sheets(self, id, type='folder'):
    tree_list = []
    # print(id, type)
    if type == 'workspace':
      workspace = self.client.Workspaces.get_workspace(id) # workspace_id
      tree_list = [{'type':'sheet', **x.to_dict()} for x in workspace.sheets]
    elif type == 'folder':
      folder = self.client.Folders.get_folder(id) # folder_id
      tree_list = [{'type':'sheet', **x.to_dict()} for x in folder.sheets]
    elif type == 'home':
      _headers = {"Content-Type": "application/json", "Authorization": F"Bearer {self.client._access_token}"}
      r = requests.get('https://api.smartsheet.com/2.0/folders/personal', headers=_headers)
      home_sheets = r.json().get('sheets', []) if r.ok else []
      tree_list = [{'type':'sheet', **x} for x in home_sheets]
    return tree_list
  
  def update_tracking_sheet(self, tracking_sheet_id, source_folder_id, source_folder_type, long_short_names={}):
    current_raise_exceptions = self.client.raise_exceptions
    self.client.raise_exceptions = True
    # print(F"Tracking Sheet ID: {tracking_sheet_id},\nSource: {source_folder_id},\nSource Type: {source_folder_type},\nShort/Long: {long_short_names}")
    # Get Sheets from source folder
    self.client.raise_exceptions = True
    if source_folder_type == 'workspace':
      source_folder = self.client.Workspaces.get_workspace(source_folder_id)
    elif source_folder_type == 'folder':
      source_folder = self.client.Folders.get_folder(source_folder_id)
  
    source_sheets = source_folder.sheets if source_folder_type != 'home' else self.client.Home.list_sheets().data
    source_sheets_dict = {x.name:x.id for x in source_sheets}
    # print(F"Source Sheets: {source_sheets_dict}")

    # Get Tracking Sheet
    self.get_tracking_sheet(tracking_sheet_id, require_hyperlink=False, require_ready=False)

    # Get DCDD_Col ID
    DCDD_COL_ID = self.tracking_sheet_columns_ids[self.tracking_sheet_column_names['DCDD_COL']]
    # print(F"DCDD_COL_ID: {DCDD_COL_ID}")

    # Get Tracking Sheet DCDD Column Links and Values
    tracking_dcdd_row_ids = {x[self.tracking_sheet_column_names['DCDD_COL']]:x['ROW_ID'] for x in self.tracking_sheet_rows}
    # print(F"Tracking DCDD Row IDs: {tracking_dcdd_row_ids}")

    rows_to_update = []
    rows_with_no_link = []

    for t_long_name, t_row_id in tracking_dcdd_row_ids.items():
      # get short name if any (from original json data - would not have untracked DCDDs)
      short_name = long_short_names.get(t_long_name)
      # get source sheet id if any (try short name first and see if long name matches in folder - will not match if short name != long name)
      source_sheet_id = source_sheets_dict.pop(short_name or t_long_name, None)

      print(F"Updating: {t_long_name} (RowID: {t_row_id}) with {short_name} (SheetID: {source_sheet_id})")

      # Track rows not found in source folder
      if not source_sheet_id:
        rows_with_no_link.append(short_name or t_long_name)

      # update link on tracking sheet row and add to rows_to_update
      cell = smartsheet.models.Cell({
        'column_id': DCDD_COL_ID,
        'value': t_long_name or smartsheet.models.ExplicitNull(),
        'hyperlink': {'sheet_id': source_sheet_id} if source_sheet_id else smartsheet.models.ExplicitNull()
      })
      row = smartsheet.models.Row({
        'id': t_row_id,
        'cells': [cell]
      })
      rows_to_update.append(row)
    # update tracking sheet
    print(F"\nUpdating {len(rows_to_update)} Rows ...")
    self.client.Sheets.update_rows(tracking_sheet_id, rows_to_update)

    # list sheets not in source folder, but on tracking sheet
    print("\nSheets in tracking, but not found in source:")
    print(F"{rows_with_no_link}\n", file=sys.stderr)

    # list sheets not found in tracking sheet, but in source folder
    print("Sheets in source, but not added:")
    print(F"{source_sheets_dict}\n", file=sys.stderr)

if __name__ == "__main__":
  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  token = dict_config.get('ss_token')
  ss = SmartsheetLib(token)

  # print(ss.get_url_from_folder_id('227890882209668', folder_type='folder'))
  # print(ss.get_url_from_sheet_id('8678320964429700'))
  # print(ss.get_url_from_folder_id('/folders/personal', folder_type='home'))
  # print(ss.get_url_from_folder_id('1375854086383492', folder_type='workspace'))

  ss.get_tracking_sheet('2658688556814212', False, False) # DCDD_Tracking (copy 20241205)
  ss.get_tracking_sheet('6535507065759620', False, False) # DCDD_Tracking
  # print(len(ss.tracking_sheet_rows))
  # _ = [print(json.dumps(x, indent=2)) for x in ss.tracking_sheet_rows]
  _ = [print(x['LINK_ID'], x['DCDD']) for x in ss.tracking_sheet_rows]