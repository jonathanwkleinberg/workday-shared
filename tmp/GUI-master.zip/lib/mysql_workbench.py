import subprocess
import getpass, os
import xml.etree.ElementTree as ET
import io, pathlib
import platform

MACOS = platform.system() == 'Darwin'

# -------------------
# | MYSQL WORKBENCH |
# -------------------
# Open MYSQL WORKBENCH (with credentials)

class MySQL_Workbench(object):

  cnx_config = {}
  debug = False
  

  def __init__(self, **kwargs):
    if kwargs.get('host'): self.cnx_config['host'] = kwargs.get('host')
    self.cnx_config['port'] = kwargs.get('port') if kwargs.get('port') else '3306'
    self.cnx_config['user'] = kwargs.get('user') if kwargs.get('user') else 'slng_user'
    if kwargs.get('passwd'): self.cnx_config['passwd'] = kwargs.get('passwd')
    if kwargs.get('debug'): self.debug = kwargs.get('debug')
    self.system_usr = getpass.getuser()


  # print(F"""Starting MySQLWorkbench with new connection paramenters ({self.cnx_config['host']}:{cnx_config['port']}) ...""")
  def is_running(self):
    call = ['pgrep', '-l', 'MySQLWorkbench'] if MACOS else ['TASKLIST', '/FI', 'imagename eq MySQLWorkbench.exe', '/FI', F'username eq {self.system_usr}']
    output_check = 'MySQLWorkbench' if MACOS else 'MySQLWorkbench.exe'
    try:
      output = subprocess.check_output(call).decode()
    except subprocess.CalledProcessError:
      # Assume MACOS and that it isn't running
      output = ''
    if output_check in output:
      if self.debug: print('-- MySQLWorkbench is still running! --')
      return True
    else:
      if self.debug: print('-- MySQLWorkbench is NOT running! --')
      return False
    
  def kill(self):
    if self.is_running():
      try:
        kill_output = ["pkill", 'MySQLWorkbench'] if MACOS else ["TASKKILL","/IM",'MySQLWorkbench.exe',"/F", '/FI', F'username eq {self.system_usr}']
        _ = subprocess.check_output(kill_output)
      except Exception as e: #if 'Access is denied.' in kill_output:
        # Probably good to go
        process_name = 'MySQLWorkbench' if MACOS else 'MySQLWorkbench.exe'
        if self.debug: print(F'Got an "{e.output}" when attempting to close {process_name}, but should be good to go.')

  def update_connections(self, name=None, host=None, port=None, user=None, passwd=None, kill=False, run=False):
    if kill:
      self.kill()
    elif self.is_running():
      message = "Can't update as process is still running!"
      if self.debug: print(message)
      return message
    name = name or 'Auto Initialized Connection'
    host = host or self.cnx_config.get('host', '')
    port = port or self.cnx_config.get('port', '')
    user = user or self.cnx_config.get('user', '')
    passwd = passwd or self.cnx_config.get('passwd', '')
    # %AppData%\MySQL\Workbench\connections.xml  ... server_instances.xml
    # xml_file = RF'\\workdayinternal\ctx-ps\AppData\{self.system_usr}\MySQL\Workbench\connections.xml'
    if MACOS:
      xml_file = pathlib.Path('~/Library/Application Support/MySQL/Workbench/connections.xml').expanduser()
    else:
      xml_file = pathlib.Path(RF'{os.getenv('APPDATA')}\MySQL\Workbench\connections.xml')
    if not xml_file.is_file():
      message = F"Couldn't find {xml_file}!"
      if self.debug: print(message)
      return message
    tree = ET.parse(xml_file)
    # v = tree.getroot().findall(".//value")
    # n = next((x for x in v if x.attrib.get('key') == 'name' and x.text == 'Auto Initialized Connection'), None)
    n = tree.getroot().find(F".//value[value='{name}']")
    if n is None:
      # didn't find the auto config, create it
      if self.debug: print('Creating MySQL Workbench Connection')
      cnx_xml = F"""
          <value type="object" struct-name="db.mgmt.Connection" id="{{1234567890}}" struct-checksum="0x96ba47d8">
            <link type="object" struct-name="db.mgmt.Driver" key="driver">com.mysql.rdbms.mysql.driver.native</link>
            <value type="string" key="hostIdentifier">Mysql@{host}:{port}</value>
            <value type="int" key="isDefault">0</value>
            <value _ptr_="" type="dict" key="modules"/>
            <value _ptr_="" type="dict" key="parameterValues">
              <value type="string" key="SQL_MODE"></value>
              <value type="string" key="hostName">{host}</value>
              <value type="string" key="password">{passwd}</value>
              <value type="int" key="port">{port}</value>
              <value type="string" key="schema"></value>
              <value type="string" key="sslCA"></value>
              <value type="string" key="sslCert"></value>
              <value type="string" key="sslCipher"></value>
              <value type="string" key="sslKey"></value>
              <value type="int" key="useSSL">1</value>
              <value type="string" key="userName">{user}</value>
              <value type="int" key="OPT_LOCAL_INFILE">1</value>
            </value>
            <value type="string" key="name">{name}</value>
          </value>
      """
      new_tree = ET.parse(io.StringIO(cnx_xml))
      tree.getroot().find("value").insert(0, new_tree.getroot())
      tree.write(xml_file)
    else:
      # found the auto config, update it
      if self.debug: print('Updating MySQL Workbench Connection')
      tree.getroot().find(F".//value[value='{name}']/value[@key='hostIdentifier']").text = F"""Mysql@{host}:{port}"""
      tree.getroot().find(F".//value[value='{name}']/value/value[@key='hostName']").text = host
      tree.getroot().find(F".//value[value='{name}']/value/value[@key='password']").text = passwd
      tree.getroot().find(F".//value[value='{name}']/value/value[@key='port']").text = port
      tree.getroot().find(F".//value[value='{name}']/value/value[@key='userName']").text = user
      tree.write(xml_file)  

    if MACOS:
      mysqlwbexe = pathlib.Path('/Applications/MySQLWorkbench.app/Contents/MacOS/MySQLWorkbench')
    else:
      mysqlwbexe = pathlib.Path(R"C:\Program Files\MySQL\MySQL Workbench 8.0 CE\MySQLWorkbench.exe")
    if not mysqlwbexe.is_file():
      message = F"Couldn't find {mysqlwbexe}!"
      if self.debug: print(message)
      return message
    if run:
      message = F"Running/Opening Workbench"
      if self.debug: print(message)
      subprocess.Popen([mysqlwbexe, "--query", name, "--script", R"."])
      return None

if __name__ == '__main__':
  mywb = MySQL_Workbench(host='127.0.0.1', port='3309', passwd='blah_blah_blah', debug=True)
  # mywb.update_connections()
  mywb.update_connections(kill=True)
