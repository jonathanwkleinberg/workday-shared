import pathlib
import sys
import json
import csv
import re
from io import StringIO

CurrentPath = pathlib.Path(__file__).parent
LibPath = CurrentPath

try:
  from .github import GitHub
  from .smartsheet_lib import SmartsheetLib
  from .ddl import DDL
except:
  sys.path.append(LibPath.absolute().as_posix())
  from github import GitHub
  from smartsheet_lib import SmartsheetLib
  from ddl import DDL

class DCDD(object):

  id = None # Smartsheet ID
  name = None # Full Name
  short_name = None # Short Name
  full_sheet_id = None # Smartsheet ID 
  permalink = None # Smartsheet Permalink
  areas = [] # Functional Areas / SKUs from DCDD Tracking Sheet
  version = None # Web Service Version
  web_services = [] # Web Service Names (could be multiple)
  operation = None # Web Service Operation
  metadata = {} # Metadata from DCDD Summary
  columns = [] # Column Headers (order not guaranteed)
  rows = [] # Data Rows

  def __init__(self, **kwargs):
    self.debug = kwargs.get('debug', False)
    if kwargs.get('json'): # path to json file
      self.json_import(kwargs.get('json'))
    if kwargs.get('ss') or kwargs.get('smartsheet'): # smartsheet sheet id - must also have token
      self.smartsheet_import(kwargs.get('ss') or kwargs.get('smartsheet'), kwargs.get('token'))
    if kwargs.get('gh') or kwargs.get('github'): # github url - must also have user/pass
      self.github_import(kwargs.get('gh') or kwargs.get('github'), kwargs.get('username'), kwargs.get('password'))

  def format_slng_table_name(self, filename):
    return f"src_{filename.lower().replace('.sql','').replace('.csv','').replace('_dcdd','').replace('_DCDD','').strip()}"

  def json_import(self, json_file, is_path=True, is_string=False):
    if is_path:
      if not pathlib.Path(json_file).exists():
        raise FileNotFoundError(F"File not found: {json_file}")
      json_data = json.loads(pathlib.Path(json_file).read_text())
    elif is_string:
      json_data = json.loads(json_file)
    else: # is dictionary
      json_data = json_file
    self.id = json_data.get('uuid')
    self.name = json_data.get('name')
    self.short_name = json_data.get('short_name')
    self.full_sheet_id = json_data.get('full_sheet_id')
    self.permalink = json_data.get('permalink')
    self.areas = json_data.get('areas', '').split(', ')
    self.version = json_data.get('metadata', {}).get('API VERSION')
    self.web_services = json_data.get('metadata', {}).get('WEB SERVICE', '').split(', ')
    self.operation = json_data.get('metadata', {}).get('WEB SERVICE OPERATION')
    self.metadata = json_data.get('metadata', {})
    self.columns = json_data.get('columns', [])
    self.rows = json_data.get('rows', [])

  def smartsheet_import(self, sheet_id, token):
    ss = SmartsheetLib(token)
    sheet_data = ss.get_sheet_data(sheet_id)
    self.id = sheet_data.get('sheet_id')
    self.name = sheet_data.get('summary', {}).get('FULL NAME')
    self.short_name = sheet_data.get('name')
    self.full_sheet_id = sheet_data.get('permalink', '').split('/')[-1]
    self.permalink = sheet_data.get('permalink')
    self.areas = sheet_data.get('summary', {}).get('FUNCTIONAL AREA', '').split(', ')
    self.version = sheet_data.get('summary', {}).get('API VERSION')
    self.web_services = sheet_data.get('summary', {}).get('WEB SERVICE', '').split(', ')
    self.operation = sheet_data.get('summary', {}).get('WEB SERVICE OPERATION')
    self.metadata = sheet_data.get('summary', {})
    self.columns = list(sheet_data.get('columns', {}).keys())
    self.rows = [list(x.values()) for x in sheet_data.get('rows', [])] # rows are dictionaries here

  def github_import(self, url, username, password):
    g = GitHub(username=username, password=password)
    raw_data = g.get_file(url=url)
    json_data = json.loads(raw_data)
    self.id = json_data.get('uuid')
    self.name = json_data.get('name')
    self.short_name = json_data.get('short_name')
    self.full_sheet_id = json_data.get('full_sheet_id')
    self.permalink = json_data.get('permalink')
    self.areas = json_data.get('areas', '').split(', ')
    self.version = json_data.get('metadata', {}).get('API VERSION')
    self.web_services = json_data.get('metadata', {}).get('WEB SERVICE', '').split(', ')
    self.operation = json_data.get('metadata', {}).get('WEB SERVICE OPERATION')
    self.metadata = json_data.get('metadata', {})
    self.columns = json_data.get('columns', [])
    self.rows = json_data.get('rows', [])

  def to_csv_def(self):
    meta_csv = StringIO()
    writer = csv.writer(meta_csv)
    writer.writerow(self.metadata.keys())
    writer.writerow(self.metadata.values())
    data_csv = StringIO()
    writer = csv.writer(data_csv)
    writer.writerow(self.columns)
    writer.writerows(self.rows)
    return meta_csv.getvalue(), data_csv.getvalue()


  def to_csv(self, format='blank'):
    default_csv_name = (self.metadata.get('FULL NAME') or 'Unnamed_Dataset').replace(" ", "_")
    if default_csv_name.endswith('_DCDD'):
        default_csv_name = default_csv_name[:-5]
    default_csv_name += ".csv"
    columns = self.columns
    rows = self.rows
    csv_header_index = next((i for i, col in enumerate(columns) if col.lower() == "csv Header".lower()), None)
    sample_value_index = next((i for i, col in enumerate(columns) if col.lower() == "Sample Value".lower()), None)
    required_optional_index = next((i for i, col in enumerate(columns) if col.lower() == "Required/Optional".lower()), None)
    file_name_index = next((i for i, col in enumerate(columns) if col.lower() == "csv File Name".lower()), None)

    primary_keys = {'headers': [], 'required_optionals': [], 'samples': []}
    files_data = {}
    keys = []
    has_csv_file_name = file_name_index is not None and any(row[file_name_index] for row in rows)

    for row_num, row in enumerate(rows):
      if not csv_header_index or not row[csv_header_index]: continue # Can't do anything without a csv Header
      if has_csv_file_name and not row[file_name_index]: continue # Skip rows without a csv file name if there is one in any other row
      csv_file_names = row[file_name_index].split(',') if file_name_index is not None and row[file_name_index] else [default_csv_name]
      header = (row_num, row[csv_header_index] if csv_header_index is not None and csv_header_index < len(row) else "")
      sample = (row_num, row[sample_value_index] if sample_value_index is not None and sample_value_index < len(row) else "")
      required_optional = (row_num, row[required_optional_index] if required_optional_index is not None and required_optional_index < len(row) else "")

      for csv_file_name in csv_file_names:
        csv_file_name = csv_file_name.strip().lower()  # Remove leading/trailing whitespace and set to lowercase
        if not csv_file_name == "all csvs":
          if not csv_file_name.endswith('.csv'):
            csv_file_name += ".csv"
          # Remove DCDD if there
          if csv_file_name.split('.')[0].endswith('_dcdd'):
            csv_file_name = '.'.join([csv_file_name.split('.')[0][:-5], csv_file_name.split('.')[1]])

        if (csv_file_name == "all csvs" or len(csv_file_names) > 1) and header:
          keys.append(header[1])

        if csv_file_name == "all csvs":
          primary_keys['headers'].append(header)
          primary_keys['required_optionals'].append(required_optional)
          primary_keys['samples'].append(sample)
        else:
          data = files_data.setdefault(csv_file_name, {'headers': [], 'required_optionals': [], 'samples': []})
          data['headers'].append(header)
          data['required_optionals'].append(required_optional)
          data['samples'].append(sample)

    if self.debug: print("keys: ", keys)
    csv_outputs = {}

    for csv_file_name, data in files_data.items():
      full_headers = [x[1] for x in sorted(primary_keys['headers'] + data['headers'])]
      full_required_optionals = [x[1] for x in sorted(primary_keys['required_optionals'] + data['required_optionals'])]
      full_samples = [x[1] for x in sorted(primary_keys['samples'] + data['samples'])]
      csv_file_path = csv_file_name # csv_dir / csv_file_name
    
      # write_csv(csv_file_path, headers, required_optional=[], samples=[], additional_rows=[])
      if format.lower() == 'blank':
        # write_csv(csv_file_path, full_headers)
        filtered_data = [(header, '', '', '') for header in full_headers if header]
      elif format.lower() == 'full':
        # write_csv(csv_file_path, full_headers, full_required_optionals, full_samples)
        filtered_data = [
          (header, req_opt, sample, '') 
          for header, req_opt, sample in zip(full_headers, full_required_optionals, full_samples) 
          if header and (req_opt or sample)
        ]
      elif format.lower() == 'highvol':
        HIGHVOL = 10
        raw_data = []
        additional_rows = []
        for hv in range(1, HIGHVOL + 1):
          raw_row = []
          for i, (header, sample, req_opt) in enumerate(zip(full_headers, full_samples, full_required_optionals), start=1):
            if sample:
              raw_row.append(sample)
            else:
              # Only use the specific placeholder if the required/optional value is not 'Reference' or 'Do Not Populate'
              if req_opt not in ["Reference", "Do Not Populate"]:
                #raw_row.append(f'FIELD_(#{i})')
                raw_row.append(f'{header}_(#{i})') 
              else:
                raw_row.append('')  # Leave the field empty
          if raw_row:
            raw_row[0] = f"ID{str(hv).zfill(5)}_(#1)"  # Ensuring the ID field is always populated
            raw_data.append(raw_row)
        # write_csv(csv_file_path, full_headers, full_required_optionals, full_samples, additional_rows=raw_data)
        filtered_data = [
          (header, req_opt, sample, *additional_row) 
          for header, req_opt, sample, *additional_row in zip(full_headers, full_required_optionals, full_samples, *raw_data) 
          if header and (req_opt or sample)
        ]
      elif format.lower() == 'minimal':
        # write_csv(csv_file_path, full_headers, full_samples)
        filtered_data = [
          (header, req_opt, '', '') 
          for header, req_opt in zip(full_headers, full_samples) 
          if header and req_opt and req_opt not in ["Reference", "Do Not Populate"]
        ]
      elif format.lower() == 'sequential':
        seq_sample_1 = []
        seq_sample_2 = []
        seq_sample_3 = []
        seq_headers = [F"{x if x else header}_(#{i+1 if x not in keys else "KEY"})" for i, (x, header) in enumerate(zip(full_headers, full_samples))]
        # if self.debug: print("seq_headers: ", seq_headers)
        for i, (header, sample) in enumerate(zip(full_headers, full_samples)):
          if header and sample is not None and not str(sample).lower() in ['true', 'false', 'none']:
            if re.match(R'^\d+$', sample):  
              if len(str(int(sample))) > 1:  # Check if it's a multi-digit integer
                seq_sample_1.append(str(int(sample) + 1))
                seq_sample_2.append(str(int(sample) + 2))
                seq_sample_3.append(str(int(sample) + 3))
              else:
                seq_sample_1.append(str(int(sample)))
                seq_sample_2.append(str(int(sample)))
                seq_sample_3.append(str(int(sample)))
            elif re.match(R'^[ECPJA]{1,3}[^A-Za-z]*\d{2}$', sample) and len(sample) >= 4:
              last_two_digits = int(sample[-2:])
              new_sample = sample[:-2] + str(last_two_digits + 1).zfill(2)
              seq_sample_1.append(new_sample)
              new_sample = sample[:-2] + str(last_two_digits + 2).zfill(2)
              seq_sample_2.append(new_sample)
              new_sample = sample[:-2] + str(last_two_digits + 3).zfill(2)
              seq_sample_3.append(new_sample)
            else:
              seq_sample_1.append(sample)
              seq_sample_2.append(sample)
              seq_sample_3.append(sample)
          elif header and sample is not None and str(sample).lower() in ['true', 'false', 'none']:  # Append 'True' or 'False' when sample is a boolean
            seq_sample_1.append(str(sample))  
            seq_sample_2.append(str(sample))
            seq_sample_3.append(str(sample))
          elif header and sample is None:   # Append an empty string when there is no sample, but still a header
            seq_sample_1.append('')
            seq_sample_2.append('')
            seq_sample_3.append('')
        additional_rows = []
        if seq_sample_1: additional_rows.append(seq_sample_1)
        if seq_sample_2: additional_rows.append(seq_sample_2)
        if seq_sample_3: additional_rows.append(seq_sample_3)
        # write_csv(csv_file_path, full_headers, seq_headers, full_samples, additional_rows)
        filtered_data = [
          (header, req_opt, sample, *additional_row) 
          for header, req_opt, sample, *additional_row in zip(full_headers, seq_headers, full_samples, *additional_rows) 
          if header and (req_opt or sample)
        ]
      # If all headers are empty, skip writing this file
      if filtered_data:
        filtered_headers, filtered_required_optional, filtered_samples, *filtered_additional_rows = zip(*filtered_data)
      else:
        if self.debug: print(f"No data to write for: {csv_file_path}")
        continue
      
      csv_out = StringIO()
      writer = csv.writer(csv_out)
      writer.writerow(filtered_headers)
      if format.lower() not in ['blank'] and any(filtered_required_optional):
        writer.writerow(filtered_required_optional)
      if format.lower() not in ["blank", "minimal"] and any(filtered_samples):
        writer.writerow(filtered_samples)
      if any([any(x) for x in filtered_additional_rows]):
        writer.writerows(filtered_additional_rows)
      csv_outputs[csv_file_name] = csv_out.getvalue()

    return csv_outputs
    
  def to_dict(self):
    return {
      "uuid": self.id,
      "name": self.name,
      "short_name": self.short_name,
      "full_sheet_id": self.full_sheet_id,
      "permalink": self.permalink,
      "areas": ", ".join(self.areas),
      "metadata": self.metadata, 
      "columns": self.columns,
      "rows": self.rows
    }

  def to_ddl(self):
    d = DDL(dcdds={self.name:self.to_dict()}, name=self.name, debug=self.debug)
    d.create_ddl()
    return d.ddl

  def to_sql(self):
    sql_text = ''
    meta_headers = self.metadata.keys()
    meta_rows = [self.metadata.values()]
    data_headers = self.columns
    data_rows = self.rows
    full_sheet_id = self.full_sheet_id
    table_name = self.name
    meta_table_name = table_name.replace("_DCDD", "_META")
    newline = ",\n  "
    
    # Write metadata table creation and insertion
    sql_text = F'''/*
    DCDD Table: {table_name}     
    Version: AutoCreated     
    Comments: SQL created from https://app.smartsheet.com/sheets/{full_sheet_id}?view=grid
*/

DROP TABLE IF EXISTS `{meta_table_name}`;
CREATE TABLE `{meta_table_name}`(
  {newline.join([F'`{x}` TEXT' for x in meta_headers])}
);
INSERT INTO `{meta_table_name}`
  ({', '.join([F'`{x}`' for x in meta_headers])})
  VALUES
  ({', '.join([F"""'{x.replace("'","''")}'""" if x else 'NULL' for row in meta_rows for x in row])})
;'''

    # Write main table creation
    sql_text += F'''

DROP TABLE IF EXISTS `{table_name}`;
CREATE TABLE `{table_name}`(
  {newline.join([F'`{x}` TEXT' for x in data_headers])}
);
INSERT INTO `{table_name}`
  ({', '.join([F'`{x}`' for x in data_headers])})
  VALUES'''

    # Write insert statements for each row in main table
    for i, row in enumerate(data_rows):
      sql_text += F'''
  ({', '.join([F"""'{x.replace("'","''")}'""" if x else 'NULL' for x in row])})'''
    sql_text += '\n;\n'
    return sql_text

if __name__ == "__main__":
  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())

  # d = DCDD(json=R'C:\Users\andy.parker\Documents\GitHub\DCDD_JSON\JSONs\absence\AddUpdate_Employee_Leave_Of_Absence_DCDD.json')
  d = DCDD(ss='VvWQm9fRwf4jXg25MGQgGmMWP64rmXM7QFwPcwv1', token=dict_config['ss_token'], debug=True)
  # d = DCDD(gh='https://ghe.megaleo.com/DTOE/DCDD_JSON/blob/master/JSONs/absence/Put_Period_Schedule_DCDD.json', username=dict_config['ad_username'], password=dict_config['ad_password'])

  # print(d.name, d.short_name, d.full_sheet_id, d.permalink, d.areas, d.version, d.web_services, d.operation, d.metadata, d.columns)
  # print(d.to_ddl())
  # print(d.to_sql())
  # meta_csv, data_csv = d.to_csv_def()
  # print(meta_csv)
  # print(data_csv)
  # for csv_name, csv_data in d.to_csv(format='blank').items():
  #   print(F"{csv_name}\n{csv_data}")
  # for csv_name, csv_data in d.to_csv(format='full').items():
  #   print(F"{csv_name}\n{csv_data}")
  # for csv_name, csv_data in d.to_csv(format='minimal').items():
  #   print(F"{csv_name}\n{csv_data}")
  for csv_name, csv_data in d.to_csv(format='sequential').items():
    print(F"{csv_name}\n{csv_data}")
  # for csv_name, csv_data in d.to_csv(format='highvol').items():
  #   print(F"{csv_name}\n{csv_data}")
