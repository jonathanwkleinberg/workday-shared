import requests
import getpass
import base64
import pathlib
import re

class Jenkins(object):
  debug = False

  def __init__(self, **kwargs):
    self.base_url = kwargs.get('url') or "https://kube-jenkins.kj-gcp.gowday.com/cas-jenkins"
    self.username = kwargs.get('username') or (getpass.getuser() if kwargs.get('interactive') else None)
    self.password = kwargs.get('password') or (getpass.getpass() if kwargs.get('interactive') else None)
    self.debug = bool(kwargs.get('debug', self.debug))
    self._basic_auth = F"""Basic {base64.b64encode(F"{self.username}:{self.password}".encode("utf-8", errors="ignore")).decode("ascii")}"""
    self._header = {"Content-Type": "application/json", "Authorization":self._basic_auth}
    self.suv_man_token = None
  
  def backup_all_jobs(self, path):
    path = pathlib.Path(path)
    if not path.is_dir(): path.mkdir(parents=True)
    r = requests.get(F'{self.base_url}/api/json', auth=(self.username, self.password))
    jenkins_json = r.json()
    job_urls = [(x.get('name'),x.get('url')) for x in jenkins_json.get('jobs')]
    if self.debug: print(job_urls)
    for job_name, job_url in job_urls:
      if self.debug: print(F'Getting {job_name} config.xml ...')
      job_config = requests.get(F'{job_url}/config.xml', auth=(self.username, self.password))
      # Save config to file
      with open(path / F'{job_name}.xml', 'w') as f:
        f.write(job_config.text)  
  
  def restore_all_jobs(self, path):
    path = pathlib.Path(path)
    if not path.is_dir(): raise FileNotFoundError(F"Path not found: {path}")
    job_config_url = F'{self.base_url}/job/[JOB]/config.xml'
    job_create_url = F'{self.base_url}/createItem?name='

    job_files = list(path.glob('*.xml'))
    if self.debug: 
      print(job_files)
      print(job_create_url)

    jenkins_session = requests.Session() # Use session to keep crumb in cookies

    # Get crumb for authentication/security
    crumb_url = F'{self.base_url}/crumbIssuer/api/json'
    r = jenkins_session.get(crumb_url, auth=(self.username, self.password))
    crumb_request_field = r.json()['crumbRequestField']
    crumb = r.json()['crumb']

    for job_file in job_files:
      job_name = job_file.stem
      job_path = job_file
      job_update_url = job_config_url.replace('[JOB]', job_name)
      job_create_url = F'{job_create_url}{job_name}'
      if self.debug: 
        print(job_update_url)
        print(job_create_url)

      # Update/Restore job config
      headers = {'Content-Type': 'application/xml', crumb_request_field: crumb}
      r = jenkins_session.post(job_create_url, auth=(self.username, self.password), data=job_path.read_text(), headers=headers)
      if self.debug: print(r.text)

  def build_job_with_params(self, job_name, params):
    jenkins_session = requests.Session() # Use session to keep crumb in cookies
    # Get crumb for authentication/security
    crumb_url = F'{self.base_url}/crumbIssuer/api/json'
    r = jenkins_session.get(crumb_url, auth=(self.username, self.password))
    crumb_request_field = r.json()['crumbRequestField']
    crumb = r.json()['crumb']
    headers = {crumb_request_field: crumb}
    r = jenkins_session.post(F'{self.base_url}/job/{job_name}/buildWithParameters', auth=(self.username, self.password), data=params, headers=headers)
    r.raise_for_status()
    if self.debug: print(F"{r.status_code}: {r.reason} ({r.headers.get('Location', '')})")
    return r
  
  def get_last_build(self, job_name):
    r = requests.get(F'{self.base_url}/job/{job_name}/lastBuild/api/json', auth=(self.username, self.password))
    if self.debug and r.status_code >= 400:
      print(r.text)
    r.raise_for_status()
    if self.debug: print(r.json())
    return r.json()
  
  def update_job(self, job_name, string, replace):
    if not job_name: raise ValueError("job_name is required")
    jenkins_session = requests.Session() # Use session to keep crumb in cookies
    job_config_url = F'{self.base_url}/job/{job_name}/config.xml'
    r = jenkins_session.get(job_config_url, auth=(self.username, self.password))
    if self.debug and r.status_code >= 400:
      print(r.text)
    r.raise_for_status()
    if self.debug: print(r.text)
    if re.search(string, r.text):
      orig_xml = r.text
      # Get crumb for authentication/security
      crumb_url = F'{self.base_url}/crumbIssuer/api/json'
      r = jenkins_session.get(crumb_url, auth=(self.username, self.password))
      crumb_request_field = r.json()['crumbRequestField']
      crumb = r.json()['crumb']
      headers = {'Content-Type': 'application/xml', crumb_request_field: crumb}
      new_xml = re.sub(string, replace, orig_xml)
      r = jenkins_session.post(job_config_url, auth=(self.username, self.password), data=new_xml, headers=headers)
      if self.debug and r.status_code >= 400:
        print(r.text)
      r.raise_for_status()
    else:
      raise ValueError(F"String {string} not found in {job_name} config.xml")
    return r
  
  def enable_job(self, job_name):
    string = '<disabled>true</disabled>'
    replace = '<disabled>false</disabled>'
    return self.update_job(job_name, string, replace)

  def disable_job(self, job_name):
    string = '<disabled>false</disabled>'
    replace = '<disabled>true</disabled>'
    return self.update_job(job_name, string, replace)
    

if __name__ == "__main__":
  import keyring, json, zlib, base64
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  j = Jenkins(username=dict_config['ad_username'], password=dict_config['ad_password'], debug=True)

  # Backup Jobs
  # j.backup_all_jobs(R'C:\Users\andy.parker\Documents\GitHub\DAI_Tools\Jenkins\Jobs')

  # Restore Jobs
  # j.restore_all_jobs(R'C:\Users\andy.parker\Documents\GitHub\DAI_Tools\Jenkins\Jobs')

  # Get Last Build
  # j.get_last_build('SLNG_SUV')

  # Build Job with Parameters
  # r = j.build_job_with_params('SLNG_SUV', {'SUV_HOST':'n-cwkh3dfbmsq9hgbgalb7e', 'BUILD_VERSION':'rc-2024.09'})

  # Disable Job
  # j.disable_job('zzz_testering')

  # Enable Job
  # j.enable_job('zzz_testering')

  # Jobs to disable
  # job_list = ['DCDD Scraper Orchestrator','DCDD_Audits','DCDD_Backup_Daily','DCDD_Backup_Monthly','DCDD_Backup_Weekly','DCDD_Data_Checklist_Creator','DCDD_Distributor','DCDD_Scraper','DCDD_to_Partner','DCDD_Updater','DCDD_Validation_Updater','DEPWB_Autobot_Updater','GHE_DDL_SLNG2.0-Direct','GHE_DEPWB_SLNG2.0-Direct','GHE_JSON_SLNG2.0-Direct','GHE_Sync_DC_Team_Access','GHE_VALIDATIONs_SLNG2.0-Direct','SLNGShot_Backup_Daily','SLNGShot_Backup_Monthly','SLNGShot_Backup_Weekly']
  # for job in job_list:
  #   try:
  #     j.disable_job(job)
  #   except Exception as e:
  #     print(e)

  # Jobs to enable
  # for job in job_list:
  #   try:
  #     j.enable_job(job)
  #   except Exception as e:
  #     print(e)