import pathlib

CurrentPath = pathlib.Path(__file__).parent
LibPath = CurrentPath

class DDL(object):

  name = 'my_custom'
  ddl = ''

  def __init__(self, **kwargs):
    self.name = (kwargs.get('name', self.name) or self.name)
    self.dcdds = kwargs.get('dcdds', {})
    self.debug = kwargs.get('debug', False)

  def format_slng_table_name(self, filename):
    return f"src_{filename.lower().replace('.sql','').replace('.csv','').replace('_dcdd','').replace('_DCDD','').strip()}"
  
  def create_ddl(self):
    all_dcdd_data = self.dcdds
    ddl_name = self.name
    self.ddl = F"""/*
    Staging Table: {ddl_name}
    Version: AutoCreated
    Comments: DDL created from the DAI App
*/
"""
    # Loop through all the data and write it to the file
    if isinstance(all_dcdd_data, dict):
      for filename, data_details in all_dcdd_data.items():
        if self.debug: print(f"Processing {filename} ...")
        data_headers = data_details.get('columns', [])
        # if self.debug: print(f"  Columns: {data_headers}")
        data_rows = data_details.get('rows', [])
        if self.debug: print(f"  Number of rows: {len(data_rows)}")
        full_sheet_id = data_details.get('full_sheet_id', '')
        slng_dcdd_files_set = set()
        formatted_slng_filename = self.format_slng_table_name(filename)
        
        if 'csv File Name' in data_headers:  # multiple tables
          csv_fn_index = data_headers.index('csv File Name')
          valid_csv_files = [row[csv_fn_index].strip() for row in data_rows if row[csv_fn_index] and row[csv_fn_index].strip()]
          
          if valid_csv_files:  # Check if there are any valid csv filenames
            for csv_files in valid_csv_files:
              for csv_file in [x.strip() for x in csv_files.split(',')]:
                if csv_file.lower() != 'all csvs':
                  slng_dcdd_files_set.add(self.format_slng_table_name(csv_file))
          else:  # If no valid csv filenames, use the formatted filename from JSON file
            slng_dcdd_files_set.add(formatted_slng_filename)
        else:  # If the csv File Name column does not exist
          slng_dcdd_files_set.add(formatted_slng_filename)
        
        slng_dcdd_files = sorted([x for x in slng_dcdd_files_set if 'all csv' not in x.lower()])

        self.ddl += f"\n/*** Start of {pathlib.Path(filename).stem} Section created from https://app.smartsheet.com/sheets/{full_sheet_id}?view=grid ***/\n"
        for slng_dcdd_file in slng_dcdd_files:
          self.ddl += f"\nDROP TABLE IF EXISTS `{slng_dcdd_file}`;\nCREATE TABLE `{slng_dcdd_file}`(\n"
          if 'csv Header' in data_headers:
            csv_headers_index = data_headers.index('csv Header')
            csv_fn_index = data_headers.index('csv File Name')
            csv_headers = [row[csv_headers_index] for row in data_rows if row[csv_headers_index] and row[csv_headers_index] is not None and row[csv_fn_index] is not None and (slng_dcdd_file.replace("src_", "") in [x.lower().replace('.sql','').replace('.csv','').strip() for x in row[csv_fn_index].split(',')] or 'all csv' in row[csv_fn_index].lower())]
            # if self.debug: print(f"  Number of csv headers: {len(csv_headers)}")
            temp_str = ",\n".join([F"  `{csv_header}` TEXT" for csv_header in csv_headers]) + "\n"
            self.ddl += temp_str
          self.ddl += ") ENGINE=InnoDB ENCRYPTION='Y' COMMENT '';\n\n"
        self.ddl += F"""/*** End of {pathlib.Path(filename).stem} Section ***/\n\n"""
    else:
      if self.debug: print(f"Error: Expected dcdd data in a dictionary format, received {type(all_dcdd_data)}")
    self.ddl += """\n/* END OF DDL */\n"""
    return # self.ddl

  def write_ddl_file(self, file_path):
    file_path = pathlib.Path(file_path)
    if self.debug: print(F'Writing {file_path} ...')
    file_path.parent.mkdir(exist_ok=True)
    self.create_ddl()
    with open(file_path, 'w', encoding='utf-8') as f:
      f.write(self.ddl)
      f.close()
      if self.debug: print(f"DDL file written: {file_path}")

if __name__ == "__main__":
  import sys
  try:
    from github import GitHub
  except:
    sys.path.append(LibPath.absolute().as_posix())
    from github import GitHub

  import keyring, zlib, base64, json
  raw_config = keyring.get_password("WD_DAI_Apps", 'config')
  dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
  g = GitHub(username=dict_config['ad_username'], password=dict_config['ad_password'])
  print("Getting all DCDDs ...")
  all_dcdds = g.get_jsons_from_zip(url='https://ghe.megaleo.com/DTOE/DCDD_JSON/tree/master/JSONs')
  print(F"Length of all_dcdds: {len(all_dcdds)}")

  # Filter out the DCDDs that are not in the 'HCM' Functional Area
  filtered_dcdds = {k: v for k, v in all_dcdds.items() if 'HCM' in (v.get('metadata', {}).get('FUNCTIONAL AREA', '') or '').split(', ')}
  print(F"Length of all_dcdds after filtering: {len(filtered_dcdds)}")

  # Write DDL file
  d = DDL(dcdds=filtered_dcdds, name='hcm', debug=True)
  d.write_ddl_file(file_path=CurrentPath / '_hcm.sql')

