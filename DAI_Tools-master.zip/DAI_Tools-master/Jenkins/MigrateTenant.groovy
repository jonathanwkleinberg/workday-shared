pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Migrate Stage') {
      steps {
        withCredentials([ sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            println """
            SOURCE_SUV: ${SOURCE_SUV}
            TARGET_SUV: ${TARGET_SUV}
            TENANT_TO_COPY: ${TENANT_TO_COPY}
            RENAME_TENANT: ${RENAME_TENANT}
            NEW_TENANT_CONF_LEVEL: ${NEW_TENANT_CONF_LEVEL}
            PURGE_IF_EXISTS: ${PURGE_IF_EXISTS}
            """
            if (RENAME_TENANT != null && RENAME_TENANT != "") {
              NEW_TENANT = RENAME_TENANT
            } else {
              NEW_TENANT = TENANT_TO_COPY
            }
            println "Migrating Tenant ${TENANT_TO_COPY} (${SOURCE_SUV}) to ${NEW_TENANT} (${TARGET_SUV})"
            export_password = "Workday-${TENANT_TO_COPY}-20.0"
            export_path = "/data/workdaydevqa/suv/suvwmu/exports"
            suv_version = "xx.x"
            suv_version = sh(returnStdout: true, script: '''ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SOURCE_SUV}.workdaysuv.com "sed 's/\\.//g' /root/startup/payload/workday.version" ''').trim()
            export_filename = "Workday-${TENANT_TO_COPY}-${suv_version}.xar"

            sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${SOURCE_SUV}.workdaysuv.com <<ENDSSH
#re-start the ems
/data/workdaydevqa/suv/suvems/start.sh

#verify the ems is running (If the ems had to be restarted then this will cycle through a max of 180 checks until it is up)
/data/workdaydevqa/suv/suvems/verify-up.sh

#Create the properties file for exporting a tenant on the SUV
cat <<EOF > /data/workdaydevqa/suv/suvwmu/input/exportTenant.${TENANT_TO_COPY}.properties
TENANT_NAME=${TENANT_TO_COPY}
DS_ENTRY_DB_NAME=dev_${TENANT_TO_COPY}
EXPORT_FILENAME=${export_filename}
EXPORT_DIRECTORY=${export_path}
EXPORT_PASSWORD=${export_password}
EXPORT_WITHOUT_TAR=N
SHOULD_LOAD_TENANT=Y
BYPASS_BLOB=N
MAX_LARGE_SLAVES=7
MAX_SMALL_SLAVES=7
OTS_NAME=suvots
SET_TENANT_MODE=TRUE
INCLUDE_RIAK=Y
TENANT_CONFIDENCE_LEVEL=${NEW_TENANT_CONF_LEVEL}
EOF
if [ ${TENANT_TO_COPY} = wdsetup ] || [ ${TENANT_TO_COPY} = dapzulu ] || [ ${TENANT_TO_COPY} = dapecho ] || [ ${TENANT_TO_COPY} = daplima ] || [ ${TENANT_TO_COPY} = dapalpha ]; then
  cat <<EOF >> /data/workdaydevqa/suv/suvwmu/input/exportTenant.${TENANT_TO_COPY}.properties
CUSTOMER_BILLING_ID=DEF0000000000007
CUSTOMER_NUMBER=7654321
EOF
else
  cat <<EOF >> /data/workdaydevqa/suv/suvwmu/input/exportTenant.${TENANT_TO_COPY}.properties
CUSTOMER_BILLING_ID=DEF0000000000006
CUSTOMER_NUMBER=1234567
EOF
fi
cat /data/workdaydevqa/suv/suvwmu/input/exportTenant.${TENANT_TO_COPY}.properties
set -x
/data/workdaydevqa/suv/suvwmu/wmu.sh exportTenant /data/workdaydevqa/suv/suvwmu/input/exportTenant.${TENANT_TO_COPY}.properties -v
#rm -rf /data/workdaydevqa/suv/suvwmu/input/exportTenant.${TENANT_TO_COPY}.properties
ENDSSH
            """)
            println "Exported Tenant ${TENANT_TO_COPY} (${SOURCE_SUV}) to ${export_filename}"
            
            // Download XAR file
            println "Downloading XAR ${export_filename} from ${SOURCE_SUV}"
            sh('mkdir -p ./tenant-xars/downloaded/')
            sh("""scp -i '${PK}' -o StrictHostKeyChecking=no root@${SOURCE_SUV}.workdaysuv.com:${export_path}/${export_filename} ./tenant-xars/downloaded/""")

            // Upload XAR file
            println "Uploading XAR ${export_filename} to ${TARGET_SUV}"
            sh("""scp -i '${PK}' -o StrictHostKeyChecking=no ./tenant-xars/downloaded/${export_filename} root@${TARGET_SUV}.workdaysuv.com:${export_path}/""")

            // Check if new tenant exists
            println "Checking if Tenant ${NEW_TENANT} exists on ${TARGET_SUV}"
            // Check if tenant is already loaded
            TENANT_LOADED=sh(returnStdout: true, script: """ssh -i "${PK}" -o StrictHostKeyChecking=no root@${TARGET_SUV}.workdaysuv.com "curl -s -D - https://${TARGET_SUV}.workdaysuv.com/${NEW_TENANT}" """)
            if (TENANT_LOADED.contains("https://community.workday.com") || TENANT_LOADED.contains("503 Service Unavailable") || TENANT_LOADED.contains("Unable to find OTS endpoint") || TENANT_LOADED.contains("Location: https://community.workday.com/invalid-url") ) {
              println "Tenant not loaded, importing it now ..."
            } else if (PURGE_IF_EXISTS == "true") {
              // Purge Tenant on Target SUV
              println "Purging Tenant ${NEW_TENANT} (${TARGET_SUV})"
              sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${TARGET_SUV}.workdaysuv.com <<ENDSSH
#re-start the ems
/data/workdaydevqa/suv/suvems/start.sh

#verify the ems is running (If the ems had to be restarted then this will cycle through a max of 180 checks until it is up)
/data/workdaydevqa/suv/suvems/verify-up.sh

#Create the properties file for purging a tenant on the SUV
cat <<EOF > /data/workdaydevqa/suv/suvwmu/input/purgeTenant.${NEW_TENANT}.properties
TENANT_NAME=${NEW_TENANT}
DS_ENTRY_OMS_SERVER=suvots
SET_TENANT_MODE=TRUE
EOF
# cat /data/workdaydevqa/suv/suvwmu/input/purgeTenant.${NEW_TENANT}.properties
set -x
/data/workdaydevqa/suv/suvwmu/wmu.sh purgeTenant /data/workdaydevqa/suv/suvwmu/input/purgeTenant.${NEW_TENANT}.properties -v
rm -rf /data/workdaydevqa/suv/suvwmu/input/purgeTenant.${NEW_TENANT}.properties
ENDSSH
              """)
              println "Purged Tenant ${NEW_TENANT} (${TARGET_SUV})"
            } else {
              println "Tenant ${NEW_TENANT} already exists on ${TARGET_SUV}, perhaps rename it or run PurgeTenant to remove it"
              error("Tenant ${NEW_TENANT} already exists on ${TARGET_SUV}, perhaps rename it or run PurgeTenant to remove it")
              return
            }

            // Import XAR file
            sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${TARGET_SUV}.workdaysuv.com <<ENDSSH
#re-start the ems
/data/workdaydevqa/suv/suvems/start.sh

#verify the ems is running (If the ems had to be restarted then this will cycle through a max of 180 checks until it is up)
/data/workdaydevqa/suv/suvems/verify-up.sh

#Create the properties file for importing a tenant on the SUV
cat <<EOF > /data/workdaydevqa/suv/suvwmu/input/importTenant.${NEW_TENANT}.properties
TENANT_NAME=${NEW_TENANT}
DS_ENTRY_DB_NAME=dev_${NEW_TENANT}
EXPORT_FILENAME=${export_filename}
EXPORT_PASSWORD=${export_password}
EXPORT_DIRECTORY=${export_path}
EXPORT_WITHOUT_TAR=N
SHOULD_LOAD_TENANT=Y
BYPASS_BLOB=N
MAX_LARGE_SLAVES=7
INCLUDE_RIAK=Y
MAX_SMALL_SLAVES=7
OTS_NAME=suvots
SET_TENANT_MODE=TRUE
TENANT_CONFIDENCE_LEVEL=${NEW_TENANT_CONF_LEVEL}
EOF
if [ ${NEW_TENANT} = wdsetup ] || [ ${NEW_TENANT} = dapzulu ] || [ ${NEW_TENANT} = dapecho ] || [ ${NEW_TENANT} = daplima ] || [ ${NEW_TENANT} = dapalpha ]; then
  cat <<EOF >> /data/workdaydevqa/suv/suvwmu/input/importTenant.${NEW_TENANT}.properties
CUSTOMER_BILLING_ID=DEF0000000000007
CUSTOMER_NUMBER=7654321
EOF
else 
  cat <<EOF >> /data/workdaydevqa/suv/suvwmu/input/importTenant.${NEW_TENANT}.properties
CUSTOMER_BILLING_ID=DEF0000000000006
CUSTOMER_NUMBER=1234567
EOF
fi
cat /data/workdaydevqa/suv/suvwmu/input/importTenant.${NEW_TENANT}.properties
set -x
/data/workdaydevqa/suv/suvwmu/wmu.sh importTenant /data/workdaydevqa/suv/suvwmu/input/importTenant.${NEW_TENANT}.properties -v
#rm -rf /data/workdaydevqa/suv/suvwmu/input/importTenant.${NEW_TENANT}.properties
rm -rf ${export_path}/${export_filename}
rm -rf /tmp/workday-wmu-export-${export_filename}
ENDSSH
            """)
            println "Checking for Imported Tenant ${NEW_TENANT} (${TARGET_SUV})"

            retry_counter=0
            retry_max=100
            // Check if tenant is loaded
            while (retry_counter < retry_max) {
              TENANT_LOADED=sh(returnStdout: true, script: """ssh -i "${PK}" -o StrictHostKeyChecking=no root@${TARGET_SUV}.workdaysuv.com "curl -s -D - https://${TARGET_SUV}.workdaysuv.com/${NEW_TENANT}" """)
              if (TENANT_LOADED.contains("https://community.workday.com") || TENANT_LOADED.contains("503 Service Unavailable") || TENANT_LOADED.contains("Unable to find OTS endpoint") || TENANT_LOADED.contains("Location: https://community.workday.com/invalid-url") ) {
                retry_counter++
                println "Tenant not loaded, retrying (${retry_counter} of ${retry_max}) ..."
                sleep(5)
              } else {
                println "Tenant ${NEW_TENANT} is loaded on ${TARGET_SUV}"
                break
              }
            }
            if (retry_counter == retry_max) {
              error("Tenant ${NEW_TENANT} not loaded on ${TARGET_SUV} after ${retry_max} retries")
              return
            }

          } // End Script
        } // End SSH Agent
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline