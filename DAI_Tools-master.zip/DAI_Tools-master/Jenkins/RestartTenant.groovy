pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Restart Stage') {
      steps {
        withCredentials([ sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            println """
            SUV: ${SUV}
            TENANT_NAMES: ${TENANT_NAMES}
            """
            for (String tenant_name : TENANT_NAMES.split(',')) {
              println "Restarting Tenant Name: ${tenant_name}"
              sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
#re-start the ems
/data/workdaydevqa/suv/suvems/start.sh

#verify the ems is running (If the ems had to be restarted then this will cycle through a max of 180 checks until it is up)
/data/workdaydevqa/suv/suvems/verify-up.sh

#Create the properties file for creating a vacant tenant on the SUV
cat <<EOF > /data/workdaydevqa/suv/suvwmu/input/reloadTenant.${tenant_name}.properties
TENANT_NAME=${tenant_name}
DS_ENTRY_OMS_SERVER=suvots
EOF
# cat /data/workdaydevqa/suv/suvwmu/input/reloadTenant.${tenant_name}.properties
set -x
/data/workdaydevqa/suv/suvwmu/wmu.sh loadTenant /data/workdaydevqa/suv/suvwmu/input/reloadTenant.${tenant_name}.properties -v
rm -rf /data/workdaydevqa/suv/suvwmu/input/reloadTenant.${tenant_name}.properties
ENDSSH
          """)
            } // End Loop
          } // End Script
        } // End SSH Agent
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline