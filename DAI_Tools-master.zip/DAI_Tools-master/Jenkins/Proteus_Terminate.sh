#!/bin/bash

# Authentication string: username:password
auth_string="xxx:xxx"

# Proteus Pool comma-separated string: production-trunk	866, preview-trunk 966	
prot_pools="  866,    966 , 1625   "
prot_description_types=" Launch, WDYW,  HCM,SUV PREP ,rc-2024.05 "

# Kill all SUVs in the pool or only those that match the description types
kill_all=0

declare -a pools
declare -a description_types

function split() {
  local input_string=$1
  local -n array=$2 # Create a reference to the array
  # Split the string into an array
  IFS=, read -ra array <<< ${input_string}

  # Trim each element of the array
  for i in "${!array[@]}"; do
    array[$i]="${array[$i]#"${array[$i]%%[![:space:]]*}"}"  # Remove leading whitespace
    array[$i]="${array[$i]%"${array[$i]##*[![:space:]]}"}"  # Remove trailing whitespace
    # echo ${array[$i]}
  done
}

# Set the Internal Field Separator to a comma
IFS=,

# Split the pool string
split "$prot_pools" pools
echo "Pools(${#pools[@]}): ${pools[*]}"

# Split the description types string
split "$prot_description_types" description_types
echo "Description Types(${#description_types[@]}): ${description_types[*]}"
joined_types=$(printf "|%s" "${description_types[@]}") # regex ORs
# joined_types=$(printf ',"%s"' "${description_types[@]}") # comma-separated in quotes
# joined_types=$(printf ',%s' "${description_types[@]}") # comma-separated (no quotes)
joined_types=${joined_types:1} # Remove the leading comma
echo "Joined Types: ${joined_types}"

# Loop through the pools
for pool in "${pools[@]}"; do
  echo "Parsing Pool: ${pool}"
  # Loop through the description types
  request_uri="https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool}/instances"
  if [ $kill_all -eq 1 ]; then
    echo "Killing all SUVs ..."
    read -ra suvs <<< `curl -su ${auth_string} ${request_uri} | jq -r '[.[] | .instanceId] | join(",")'`
  else
    echo "Killing all SUVs that match the 'type' in their description ..."
    echo "curl -su ${auth_string} ${request_uri} | jq --arg joined_types \"$joined_types\" -r '[.[] | select(.description | test(\"\$joined_types\") ) | .instanceId] | join(\",\")'"
    read -ra suvs <<< `curl -su ${auth_string} ${request_uri} | jq --arg joined_types "$joined_types" -r '[.[] | select(.description | test($joined_types) ) | .instanceId] | join(",")'`
    # echo "curl -su ${auth_string} ${request_uri} | jq --arg joined_types \"$joined_types\" -r '[.[] | select(.description | any(index(\$joined_types | split(\",\")); . != null) ) | .instanceId] | join(\",\")'"
    # read -ra suvs <<< `curl -su ${auth_string} ${request_uri} | jq --arg joined_types "$joined_types" -r '[.[] | select(.description | any(($joined_types | split(",")) | index(.); . != null) ) | .instanceId] | join(",")'`
  fi
  echo "SUVs(${#suvs[@]}): ${suvs[*]}"
  for suv in "${suvs[@]}"; do
    echo "Terminating SUV: ${suv}"
    echo "curl -su USER:PASS -X DELETE ${request_uri}/${suv}"
    # echo `curl -su ${auth_string} -X DELETE ${request_uri}/${suv}`
  done
done