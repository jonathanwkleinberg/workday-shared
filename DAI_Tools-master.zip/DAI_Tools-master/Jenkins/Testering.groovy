// pipeline {
//   // Run on GKE Docker in Docker node
//   agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

//   // Keep 2 builds
//   options { buildDiscarder logRotator(numToKeepStr: '2') }

//   stages {
//     stage('Testering Stage') {
//       steps {
//         withCredentials([ usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user'), 
//                           string(credentialsId: 'SS_TOKEN_JK', variable: 'ss_token'), 
//                           sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
//           script {
//             SUV = sh(returnStdout: true, script: '''
//             curl -su $auth_user:$auth_pass 'https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances' | 
//             jq -r 'first(.[] | select(.wdAdditionalTags.poolName=="dtoe-automation" and .state=="running" and .buildPercentage >= 10 )) | .instanceId'
//             ''').trim()
//             echo "SUV: $SUV"
//             withEnv(["SUV=$SUV"]) { 
//               sh '''
//               ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "curl -s --oauth2-bearer ${ss_token} https://api.smartsheet.com/2.0/search?query=Put_Supplier"
//               '''
//               wats_iid='755\\\$149498'
//               echo wats_iid
//               sh """
//               ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "echo ${wats_iid}"
//               ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'echo ${wats_iid}'
//               """
//               sh 'which python3; python3 -V'
//               //sh 'python3 -c "import urllib3"'
//               //sh 'which groovy'
//             }
//           }
//         }
//       }
//     }
//   }
// }

def buildResult = 'SUCCESS'
def getResult

try {
podTemplate(cloud: 'gke-cloud', inheritFrom: 'gke-agent-c9-dind') { node(POD_LABEL) {
  stage('Results') {
    withCredentials([ usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user'), 
                      string(credentialsId: 'SS_TOKEN', variable: 'ss_token'), 
                      sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
      script {
        SUV = sh(returnStdout: true, script: '''
        curl -su $auth_user:$auth_pass 'https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances' | 
        jq -r 'first(.[] | select(.wdAdditionalTags.poolName=="dtoe-automation" and .state=="running" and .buildPercentage >= 10 )) | .instanceId'
        ''').trim()
        echo "SUV: $SUV"
        withEnv(["SUV=$SUV"]) { 
          sh '''
          ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "curl -s --oauth2-bearer ${ss_token} https://api.smartsheet.com/2.0/search?query=Put_Supplier"
          '''
          wats_iid='755\\\$149498'
          echo wats_iid
          sh """
          ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "echo ${wats_iid}"
          ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'echo ${wats_iid}'
          """
          sh 'which python3; python3 -V'
          //sh 'python3 -c "import urllib3"'
          //sh 'which groovy'
          // Error on Purpose
          sh 'exit 1'
        } // end withEnv
      } // end script
    } // end withCredentials

    getResult = "Testing Complete"

  } // end stage
} } // end node podTemplate

} catch (e) {
  buildResult = "FAILURE"
  getResult = e
//   node {
//     // Got Error / Failure
//     getResult = sh(script: '''\
// #!/bin/bash +x
// tail -20 '${JENKINS_HOME}/jobs/${JOB_NAME}/builds/${BUILD_NUMBER}/log' | sed 's/\\[8mha:.*\\[0m//'
// ''', returnStdout: true,)
//   }
  throw e
} finally {
  // Always Run Post Build or Error
  def result_color = (buildResult == 'FAILURE') ? 'danger' : 'good'
  if (buildResult == 'FAILURE' || buildResult == 'SUCCESS') {
    slackSend tokenCredentialId: 'SLACK_TOKEN', teamDomain: 'workday-dev', channel: '#dai-jenkins-notifications', color: result_color, message: "${env.JOB_NAME} - ${buildResult} after ${currentBuild.durationString} (<${env.BUILD_URL}|#${env.BUILD_NUMBER}> <${env.BUILD_URL}console|Console Output>)\n${getResult}"
  }
}