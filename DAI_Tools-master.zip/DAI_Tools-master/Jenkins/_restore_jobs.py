import requests, json
import keyring, zlib, base64
import pathlib

current_dir = pathlib.Path(__file__).parent
jobs_folder = current_dir / 'Jobs'

raw_config = keyring.get_password("WD_DAI_Apps", 'config')
dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
# dict_config.get('ad_username')
# dict_config.get('ad_password')


job_config_url = 'https://kube-jenkins.kj-gcp.gowday.com/cas-jenkins/job/[JOB]/config.xml'
job_create_url = 'https://kube-jenkins.kj-gcp.gowday.com/cas-jenkins/createItem?name='

job_files = list(jobs_folder.glob('*.xml'))
print(job_files)



print(job_create_url)

jenkins_session = requests.Session() # Use session to keep crumb in cookies

# Get crumb for authentication/security
crumb_url = 'https://kube-jenkins.kj-gcp.gowday.com/cas-jenkins/crumbIssuer/api/json'
r = jenkins_session.get(crumb_url, auth=(dict_config.get('ad_username'), dict_config.get('ad_password')))
crumb_request_field = r.json()['crumbRequestField']
crumb = r.json()['crumb']

# Get last job config.xml
# job_name = job_files[-1].stem
# job_path = job_files[-1]
# job_update_url = job_config_url.replace('[JOB]', job_name)
# job_create_url = F'{job_create_url}{job_name}'

for job_file in job_files:
  job_name = job_file.stem
  job_path = job_file
  job_update_url = job_config_url.replace('[JOB]', job_name)
  job_create_url = F'{job_create_url}{job_name}'
  print(job_update_url)
  print(job_create_url)

  # Update/Restore job config
  headers = {'Content-Type': 'application/xml', crumb_request_field: crumb}
  r = jenkins_session.post(job_create_url, auth=(dict_config.get('ad_username'), dict_config.get('ad_password')), data=job_path.read_text(), headers=headers)
  print(r.text)
