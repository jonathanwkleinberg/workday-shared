pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Update desc/stage Stage') {
      steps {

        println """
        SUV: ${SUV}
        DESCRIPTION: ${DESCRIPTION}
        STAGE: ${STAGE}
        """
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user')]) {
          sh '''
            set +x
            auth_string="${auth_user}:${auth_pass}"

            # Get SUV info
            suv_info=`curl -su ${auth_string} "https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances?instanceId[]=${SUV}&exactMatch=1"`
            if [ "$suv_info" == "[]" ]; then
              echo "SUV not found!"
              exit 1
            fi
            echo "SUV Info: ${suv_info}"

            # Get current stage if not provided
            if [ -z "$STAGE" ]; then
              STAGE=`echo $suv_info | jq -r '.[0] | .poolStage'`
            fi
            echo "toStage: ${STAGE}"

            # Get pool name
            pool_name=`echo $suv_info | jq -r '.[0] | .wdAdditionalTags.poolName'`
            if [ "$pool_name" == "null" ]; then
              echo "No pool listed for SUV!"
              exit 1
            fi
            echo "Pool Name: ${pool_name}"

            # Get pool ID
            pool_id=`curl -su ${auth_string} "https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools" | jq -r ".[] | select(.name==\\\"${pool_name}\\\") | .id"`
            if [ "$pool_id" == "" ]; then
              echo "Pool ID not found!"
              exit 1
            fi
            echo "Pool ID: ${pool_id}"

            set -x
            # Update pool description and stage
            curl -su ${auth_string} -X PUT -H "Content-Type: application/json" -d "{\\\"description\\\":\\\"${DESCRIPTION}\\\",\\\"toStage\\\":\\\"${STAGE}\\\"}" "https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool_id}/instances/${SUV}/push"

          '''
        }
      }
    }
  }
}