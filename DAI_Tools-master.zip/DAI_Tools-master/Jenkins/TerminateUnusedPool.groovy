pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Terminate Stage') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user')]) {
          sh '''
            set +x
            auth_string="${auth_user}:${auth_pass}"
            # Split the string into an array
            IFS="," read -ra pools <<< ${proteus_pool_ids}
            echo "Pools(${#pools[@]}): ${pools[*]}"
            # Loop through the pools
            for pool in "${pools[@]}"; do
              echo "Getting Default Unused Desc and Stage from Pool: ${pool} ..."
              IFS=',' read desc stage <<< `curl -su ${auth_string} https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool} | jq -r '.apiPayload | [.wdDescription, .wdPoolStage] | join(",")'`
              echo "Unused Desc: ${desc}, Unused Stage: ${stage}"
              echo "Getting Unused SUVs from Pool: ${pool} ..."
              IFS="," read -ra suvs <<< `curl -su ${auth_string} -G --data-urlencode "description=${desc}" --data-urlencode "stage[]=${stage}" "https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances?suvPoolId=${pool}&exactMatch=1" | jq -r '[.[] | select(.state=="running" and .buildPercentage == 100 and .completelyBuilt == true) | .instanceId] | join(",")'`
              echo "SUVs(${#suvs[@]}): ${suvs[*]}"
              request_uri="https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool}/instances"
                for suv in "${suvs[@]}"; do
                  echo "Terminating SUV: ${suv} ..."
                  # echo "curl -su USER:PASS -X DELETE ${request_uri}/${suv}"
                  echo `curl -su ${auth_string} -X DELETE ${request_uri}/${suv}`
                done
            done
          '''
        }
      }
    }
  }
}