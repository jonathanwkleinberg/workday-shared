pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage ('Parallel Repos') { parallel {
      stage('ds-central') {
        steps {
          checkout scmGit(branches: [[name: '*/master']], extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'ds-central']], userRemoteConfigs: [[credentialsId: 'BITBUCKET_KEY', url: 'ssh://git@bitbucket.workday.com:7999/dsalm/ds-central.git']])
        } // End Steps
      } // End Stage
      stage('deep-content-pipeline') {
        steps {
          checkout scmGit(branches: [[name: '*/master']], extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'deep-content-pipeline']], userRemoteConfigs: [[credentialsId: 'BITBUCKET_KEY', url: 'ssh://git@bitbucket.workday.com:7999/dsalm/deep-content-pipeline.git']])
        } // End Steps
      } // End Stage
    } } // End Parallel
    stage('FTB Stage') {
      steps {
        withCredentials([ sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            println """
            SUV: ${SUV}
            RECIPE_TYPE: ${RECIPE_TYPE}
            CODE_BASE: ${CODE_BASE}
            """
            println "Foundation Tenant Build for Scenario: ${CODE_BASE}-${RECIPE_TYPE}-execution"
            // Get Tenants from scenariosTenantInfo file
            TENANT_NAMES = sh(returnStdout: true, script: """jq -r 'map(.targetTenant) | unique | join(",")' deep-content-pipeline/pipeline/scripts/deep-files/scenariosTenantInfo/${CODE_BASE}-${RECIPE_TYPE}-execution.json""").trim()
            println "Tenants: ${TENANT_NAMES}"
            HOST_PASSWORD = sh(returnStdout: true, script: '''ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "sed -nr 's/^properties.env.universalPassword=(.*)$/\\1/p' /data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties" ''').trim()

            for (String TENANT_NAME : TENANT_NAMES.split(',')) {
              // Enable DEEP API (Toggle_On_Off 755$220777, DEEP_API_Toggle 9235\$66215)
              WATS_TOGGLE = '755\\\$220777'
              WATS_DEEP_API = '9235\\\$66215'
              sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
#re-start the ems
/data/workdaydevqa/suv/suvems/start.sh

#verify the ems is running (If the ems had to be restarted then this will cycle through a max of 180 checks until it is up)
/data/workdaydevqa/suv/suvems/verify-up.sh

#Create the properties file for switching a toggle of a tenant on the SUV
cat > /data/workdaydevqa/suv/suvwats/my.wats.properties<<'EOF'
wats.dap.customer.tenant=${TENANT_NAME}
wd.wats.dap.toggle.iid=${WATS_DEEP_API}
wd.wats.dap.toggle.status=on
EOF
#Toggle ON the DEEP API
cat /data/workdaydevqa/suv/suvwats/my.wats.properties
cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${TENANT_NAME} wd-developer ${HOST_PASSWORD} DEF '${WATS_TOGGLE}'
rm -rf /data/workdaydevqa/suv/suvwats/my.wats.properties
ENDSSH
              """)
            } // End for loop

            // Run FTB through DEEP Gradle
            sh("""./ds-central/Central-Functional-Tests/gradlew functionalExecutionTest -p=./ds-central/Central-Functional-Tests -Dhost=${SUV}.workdaysuv.com -DhostPassword=${HOST_PASSWORD} -DrecipeType=${RECIPE_TYPE} -DwebServiceVersion=v35.2 -DparallelThreshold=1 -DmigrationFailureThreshold=99.0 -DcodeBase=${CODE_BASE} -DscenariosDefinitionPath=./deep-content-pipeline/pipeline/scripts/deep-files/scenariosDefinition -DscenariosTenantInfoPath=../deep-content-pipeline/pipeline/scripts/deep-files/scenariosTenantInfo
            //""")
          } // End Script
        } // End withCredentials
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline