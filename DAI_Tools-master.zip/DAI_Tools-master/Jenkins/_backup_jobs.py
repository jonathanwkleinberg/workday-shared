import requests, json
import keyring, zlib, base64
import pathlib

current_dir = pathlib.Path(__file__).parent
jobs_folder = current_dir / 'Jobs'

raw_config = keyring.get_password("WD_DAI_Apps", 'config')
dict_config = json.loads(zlib.decompress(base64.b64decode(raw_config)).decode())
# dict_config.get('ad_username')
# dict_config.get('ad_password')

api_url = 'https://kube-jenkins.kj-gcp.gowday.com/cas-jenkins/api/json'

r = requests.get(api_url, auth=(dict_config.get('ad_username'), dict_config.get('ad_password')))

jenkins_json = r.json()

job_urls = [(x.get('name'),x.get('url')) for x in jenkins_json.get('jobs')]

print(job_urls)

# Get first job config.xml
# job_name, job_url = job_urls[0]
# job_config = requests.get(F'{job_url}/config.xml', auth=(dict_config.get('ad_username'), dict_config.get('ad_password')))
# print(job_config.text)


for job_name, job_url in job_urls:
  print(F'Getting {job_name} config.xml ...')
  job_config = requests.get(F'{job_url}/config.xml', auth=(dict_config.get('ad_username'), dict_config.get('ad_password')))
  # Save config to file
  with open(jobs_folder / F'{job_name}.xml', 'w') as f:
    f.write(job_config.text)
    