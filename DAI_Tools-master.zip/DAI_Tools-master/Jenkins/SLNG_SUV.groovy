pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('SUV Tools Stage') {
      steps { retry(5) {
        checkout changelog: false, poll: false, scm: [
          $class: 'GitSCM', 
          branches: [[name: '*/master']], 
          doGenerateSubmoduleConfigurations: false, 
          extensions: [[$class: "UserIdentity", name: "dai", email: "dai@workday.com"], [$class: 'WipeWorkspace'], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'SUV_Tools']], 
          submoduleCfg: [], 
          userRemoteConfigs: [[credentialsId: 'SVC_CAS_JENKINS_USER_KEY', url: 'git@ghe.megaleo.com:DTOE/SUV_Tools.git']]
        ]
      } } // End Retry // End Steps
    } // End Stage
    stage('Get SUV Stage') {
      steps {
        // Setup Artifactory Repo (yum/dnf)
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_ENC_PASS', passwordVariable: 'enc_pass', usernameVariable: 'enc_user')]) {
          sh('''echo "[artifactory-repo-baseos]
name=Artifactory Repository BaseOS
baseurl=https://${enc_user}:${enc_pass}@artifactory.workday.com/artifactory/mirror.stream.centos.org/9-stream/BaseOS/x86_64/os/
enabled=1
gpgcheck=0" | sudo tee /etc/yum.repos.d/artifactory-baseos.repo
echo "[artifactory-repo-appstream]
name=Artifactory Repository AppStream
baseurl=https://${enc_user}:${enc_pass}@artifactory.workday.com/artifactory/mirror.stream.centos.org/9-stream/AppStream/x86_64/os/
enabled=1
gpgcheck=0" | sudo tee -a /etc/yum.repos.d/artifactory-appstream.repo
          ''')
        } // end withcred (enc_user)

        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'PROT_PASSWORD', usernameVariable: 'PROT_USERNAME'), usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_ENC_PASS', passwordVariable: 'WD_ARTIFACTORY_ENC_PWD', usernameVariable: 'WD_ARTIFACTORY_USER'), string(credentialsId: 'SVC_CAS_JENKINS_RO_GHE_TOKEN', variable: 'SVC_CAS_JENKINS_RO_GHE_TOKEN'), sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            sh("""
              if [[ -z '${SUV_HOST}' ]] ; then
                # Prep Python
                sudo dnf -y install python3-pip
                echo `pip3 -V`
                pip3 install requests -i http://artifactory-az.services.wd:8081/artifactory/api/pypi/python-release-virtual/simple/  --trusted-host artifactory-az.services.wd
                python3 SUV_Tools/get_suv_full.kb.py
                cat env_full_suv.properties
              fi
              echo "TOUCHED=touched" >> env_full_suv.properties
              chmod 755 SUV_Tools/SLNG/jenkins_script.kb.sh
            """)
          } // End Script
          withEnv(readFile('env_full_suv.properties').split('\n') as List) {
            script{
              sh("SUV_Tools/SLNG/jenkins_script.kb.sh")
            } // End Script
          } // End withEnv
        } // End withCredentials
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline     