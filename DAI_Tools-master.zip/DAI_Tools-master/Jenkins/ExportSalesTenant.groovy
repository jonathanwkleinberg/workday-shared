pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('S3 to SUV Stage') {
      steps {
        checkout changelog: false, poll: false, scm: [
          $class: 'GitSCM', 
          branches: [[name: '*/master']],  
          doGenerateSubmoduleConfigurations: false, 
          extensions: [[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [[path: 'Jenkins/export_sales_tenant.groovy']]]], 
          submoduleCfg: [], 
          userRemoteConfigs: [[credentialsId: 'SVC_CAS_JENKINS_USER_KEY', url: 'git@ghe.megaleo.com:DTOE/DAI_Tools.git']]
        ]
        withCredentials([ sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK'), string(credentialsId: 'AWS_SECRET', variable: 'aws_secret_key'), string(credentialsId: 'AWS_KEY', variable: 'aws_key') ]) {
          script {
            println """
            SUV: ${SUV}
            AWS_S3_LINK: ${AWS_S3_LINK}
            """
            sh("""scp -i "${PK}" -o StrictHostKeyChecking=no Jenkins/export_sales_tenant.groovy root@${SUV}.workdaysuv.com:/data/workdaydevqa/""")
            println "Downloading tenant from S3 location ${AWS_S3_LINK} and loading it on the suv ${SUV}"
            sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
# Install Groovy
curl -s "https://get.sdkman.io" | bash
source "/root/.sdkman/bin/sdkman-init.sh"
sdk install groovy
groovy -v

# Run the groovy script
# suv_host  aws_key aws_secret_key aws_file_path
groovy /data/workdaydevqa/export_sales_tenant.groovy ${SUV} ${aws_key} ${aws_secret_key} ${AWS_S3_LINK}

ENDSSH
            """)
          } // End Script
        } // End withCredentials
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline