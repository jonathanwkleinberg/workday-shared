pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Terminate Stage') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user')]) {
          sh '''
            set +x
            auth_string="${auth_user}:${auth_pass}"
            # Split the string into an array
            IFS="," read -ra pools <<< ${proteus_pool_ids}
            echo "Pools(${#pools[@]}): ${pools[*]}"
            # Loop through the pools
            for pool in "${pools[@]}"; do
              echo "Getting SUVs from Pool: ${pool} ..."
              request_uri="https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool}/instances"
              IFS="," read -ra suvs <<< `curl -su ${auth_string} ${request_uri} | jq -r '[.[] | .instanceId] | join(",")'`
              echo "SUVs(${#suvs[@]}): ${suvs[*]}"
                for suv in "${suvs[@]}"; do
                  echo "Terminating SUV: ${suv} ..."
                  # echo "curl -su USER:PASS -X DELETE ${request_uri}/${suv}"
                  echo `curl -su ${auth_string} -X DELETE ${request_uri}/${suv}`
                done
            done
          '''
        }
      }
    }
  }
}