#!/usr/bin/env groovy

class Sales_tenant {
/* Usage:
      ./export_sales_tenant.groovy suv_host  aws_key aws_secret_key aws_file_path
      eg: ./export_sales_tenant.groovy i-123 123 456 s3://workday-sales-suv-xars/PHOENIX-akistgms0106v2024r1-2024051401.xar.gz
*/

    static def executeCommand(command, timeoutSeconds = 600) { // Increased default timeout to 10 minutes
        println("Executing cmd: ${command.join(' ')}")
        def process = command.execute()
        def stdout = new StringBuilder()
        def stderr = new StringBuilder()

        // Thread to consume stdout
        def stdoutThread = Thread.start {
            process.consumeProcessOutput(stdout, stderr)
        }

        // Wait for the process to finish, or until timeout
        def timeoutMillis = timeoutSeconds * 1000
        process.waitForOrKill(timeoutMillis)
        // Adding this sleep to give the output thread a little more time to read the output before the process terminates.
        Thread.sleep(200)

        // Ensure the thread is finished
        stdoutThread.join()

        // Explicitly close streams
        process.in.close()
        process.err.close()

        if (process.exitValue() != 0) {
            println("Error executing command:")
            println("Command: ${command.join(' ')}")
            println("Exit code: ${process.exitValue()}")
            println("Stdout: ${stdout}")
            println("Stderr: ${stderr}")
        } else {
            println("Command executed successfully.")
            println("Stdout: ${stdout}")
        }

        return stdout.toString()
    }

    static def getSuvConfidenceLevel() {
        String suvConfigFile = "/root/startup/payload/aws-payload.properties"
        println "Checking the suv confidence level"
        def cmd = ['bash', '-c', "grep ^WD_CONFIDENCE_LEVEL= ${suvConfigFile} | cut -d'=' -f2"]
        String tenantConfidence = executeCommand(cmd)
        println "The SUV confidence level : ${tenantConfidence}"
        tenantConfidence.trim()
    }

    static def createAwsProfile(awsProfile, awsKey, awsSecretKey, awsRegion) {
        def awsConf =  ['bash', '-c', "aws configure --profile ${awsProfile} set aws_access_key_id ${awsKey}" +
                " && aws configure --profile ${awsProfile} set aws_secret_access_key ${awsSecretKey}" +
                " && aws configure --profile ${awsProfile} set region ${awsRegion}"]
        executeCommand(awsConf)
    }

    static def downloadFromS3(awsFilePath, awsProfile, awsTar) {
        def awsDownloadS3 = ['bash', '-c', "aws s3 --profile ${awsProfile} cp ${awsFilePath} /mnt"]
        println "Download from S3 using : ${awsDownloadS3}"
        executeCommand(awsDownloadS3)
        //Unzip the file
        println "Unzipping the file ${awsTar}"
        def unzipTar = ['bash', '-c', "gunzip /mnt/${awsTar}"]
        executeCommand(unzipTar)
    }

    static def createWmuProperties(awsXar, tenant, confidenceLevel, propertiesFileName) {
        def propertiesFilePath = "/data/workdaydevqa/suv/suvwmu/input/${propertiesFileName}"

        def awsFile = awsXar.split(/\./)[0]
        println "AWS file : ${awsFile}"

        // Using a map to define properties makes it more readable and maintainable
        def properties = [
                LOUD_BATCH_JOBS_ENABLED: 'N',
                CREATE_CUSTOMER_RETRY_MAX_WAIT: '30000',
                DS_ENTRY_DB_NAME: "suv_${tenant}",
                DS_ENTRY_OMS_SERVER: 'suvots',
                ENABLE_BDA: 'false',
                ENABLE_SELENIUM_TESTING: 'Y',
                ENABLE_WORKDAY_INSIGHTS: 'Y',
                ENVIRONMENT_NAME: 'suv',
                EXPORT_FILENAME: awsXar,
                EXPORT_PASSWORD: awsFile,
                FAIL_ON_PING_OMS_ERROR: 'Y',
                INCLUDE_RIAK: 'Y',
                IS_ADMIN_TENANT: 'N',
                IS_UPGRADE_TENANT: 'N',
                OTS_WAIT_INCREMENT_SECONDS: '10',
                OTS_WAIT_INIT_SECONDS: '10',
                OTS_WAIT_RETRIES: '15',
                REPORT_ORS_ENABLED: 'N',
                SET_TENANT_MODE: 'TRUE',
                SHOULD_LOAD_TENANT: 'Y',
                SIZE: 'S',
                TAGS: 'Enable Kraken 2.0',
                TENANT_CONFIDENCE_LEVEL: confidenceLevel,
                TENANT_CREATION_MAX_WAIT: '60000',
                TENANT_ASYNC_CREATE_MAX_RETRY: '5',
                TENANT_NAME: tenant,
                TENANT_SECONDARY_LOOKUP: 'Y',
                TENANT_MODE: 'ACTIVE',
                UI_ORS_ENABLED: 'N',
                WORKDAY_INSIGHT_KEY: '1',
                WORKSHEETS_GA: 'true',
                PT_DATABASE_SERVER: 'MYSQL1',
                EXPORT_DIRECTORY: '/mnt',
                KRAKEN_IMPORT_EXPORT_TENANT_ENABLED: 'true',
                KRAKEN_CUSTOMER_CREATION_ENABLED: 'true'
        ]

        // Build the file contents string from the properties map
        def fileContents = properties.collect { key, value -> "$key=$value" }.join('\n')

        new File(propertiesFilePath).write(fileContents)
        println "Creating Import Properties file: $propertiesFileName"
        return propertiesFilePath.trim()
    }

    static def createCredsFile(credsFilePath, awsRegion) {
        println "Creating a new Creds file"
        String credsFile = new File(credsFilePath.toString()).getName()
        String registryId = credsFile.tokenize('.').first()

        def rmFile = "rm -rf ${credsFilePath}"
        executeCommand(rmFile)

        def awsEcr = ['bash', '-c', "aws", "ecr", "get-login", " --no-include-email",
                      "--region ${awsRegion}", " --registry-ids ${registryId}", "> ${credsFilePath}"]
        executeCommand(awsEcr)

        def runEcr = ['bash', '-c', "chmod 600 ${credsFilePath} ; /bin/bash ${credsFilePath}"]
        executeCommand(runEcr)
    }

    static def restartDocker(credsFile, env) {
        println "Stopping docker"
        def stopCmd = ['bash', '-c', "docker stop kraken-engine; docker rm kraken-engine;"]
        executeCommand(stopCmd)
        def creds = credsFile.split('\\.')[0..-2].join('.')
        println "Restarting docker in ${env} environment"
        def dockerCmd = [
                'docker', 'run', '-d',
                '--net=host',
                '--memory=1800m',
                '--env', "wd_environmentId=${env} ",
                '-v', '/usr/local/kraken-engine/logs:/var/log/kraken-engine',
                '-v', '/usr/local/kraken-engine/certs:/usr/share/kraken-engine/certs',
                '-v', '/usr/local/kraken-engine/mysql:/var/lib/mysql',
                '-v', '/usr/local/zulujre_8_21_0_2/lib/security/jssecacerts:/usr/local/zulujdk_8_74_0_18/jre/lib/security/jssecacerts:ro',
                '--health-cmd', 'curl -k --fail --silent https://localhost:9501/app_info/status',
                '--name', 'kraken-engine',
                "${creds}/platsec/kraken-engine:latest"
        ]

        println "Running Docker container: ${dockerCmd}"
        executeCommand(dockerCmd)
    }

    static def cleanupDownloadedTenant(awsXar, wdxProperties) {
        println "Cleaning up downloaded files"
        def removeCmd = ['bash', '-c', "rm -rf /mnt/${awsXar}; rm -rf ${wdxProperties}"]
        executeCommand(removeCmd, 900)
    }

    static def getWdVersionFromSuv() {
        def cmd = ['bash', '-c', "cat /root/startup/payload/workday.version"]
        String out = executeCommand(cmd)
        return out.trim()
    }

    static def registerTenant(tenant, otsConfigFile, otsConfigPersistFile) {
        println "Registering ${tenant} with ots"
        def cmd =  ['bash', '-c', "grep ^properties.oms.load.tenant= ${otsConfigFile} | cut -d'=' -f2"]
        def originallyRegisteredTenants = executeCommand(cmd).trim()
        println "Original list of Tenants : ${originallyRegisteredTenants}";

        def propCmd
        if (originallyRegisteredTenants.isEmpty()) {
            propCmd = ['bash', '-c', "sed -i '/^properties.oms.load.tenant=/s/\$/${tenant.trim()}/' ${otsConfigFile}"]

        } else {
            propCmd = ['bash', '-c', "sed -i '/^properties.oms.load.tenant=/s/\$/,${tenant.trim()}/' ${otsConfigFile}"]
        }
        executeCommand(propCmd)

        def newCmd =  ['bash', '-c', "grep ^properties.oms.load.tenant= ${otsConfigPersistFile} | cut -d'=' -f2"]
        def originallyRegisteredTenantsPersisted = executeCommand(newCmd)

        if (originallyRegisteredTenantsPersisted.isEmpty()) {
            println "Persisting the Tenant in the OMS"
            cmd =  ['bash', '-c', "grep ^properties.oms.load.tenant= ${otsConfigFile}"]
            def tenantList = executeCommand(cmd)
            def tenantListCmd =  ['bash', '-c', "echo '${tenantList.trim()}' >> ${otsConfigPersistFile}"]
            executeCommand(tenantListCmd)
            println "New Tenants persisted"
        } else {
            cmd =  ['bash', '-c', "sed -i '/^properties.oms.load.tenant=/s/\$/,${tenant.trim()}/' ${otsConfigPersistFile}"]
            executeCommand(cmd)
            println "Tenants persisted configuration updated"
        }
        cmd = ['bash', '-c', "grep ^properties.oms.load.tenant= ${otsConfigFile} | cut -d'=' -f2"]
        def currentlyRegisteredTenants = executeCommand(cmd).trim()
        currentlyRegisteredTenants.trim()
    }

    static def manageListOfTenantsAndOts(tenant, successful, version) {
        def tenantInfoDir = "/data/workday"  // Directory path
        def tenantInfoFile = "${tenantInfoDir}/tenantsAdded.info" // Full file path

        if (successful) {
            // Create the directory if it doesn't exist
            new File(tenantInfoDir).mkdirs()

            // Create or append to the file
            new File(tenantInfoFile).with {
                createNewFile() // Create if it doesn't exist

                // Remove any existing entry for the tenant
                def lines = readLines()
                lines.removeAll { it.startsWith(tenant.toString()) }

                // Append the new tenant information
                def newLine = "${new Date().format('yyyy-MM-dd:HH:mm')} ${tenant}=${version}"
                lines << newLine

                // Write the updated lines back to the file
                write(lines.join('\n'))
            }

            println "Tenant information updated in ${tenantInfoFile}"
        }
    }

    static def importTenantWithProperties(tenant, confidenceLevel, awsXar, propertiesFileName) {
        println "Creating Properties file and Importing Tenant  ${tenant}"
        def propsFilePath = createWmuProperties(awsXar, tenant, confidenceLevel, propertiesFileName)

        def importCmd =  ['bash', '-c', "/data/workdaydevqa/suv/suvwmu/wmu.sh importTenant ${propsFilePath}"]
        println "Importing Tenant  ${tenant} using properties file  ${propsFilePath}"
        def out = executeCommand(importCmd,2400)
        println "Import logs : ${out.toString()}"
    }

    static def checkDockerStatus() {
        println "Checking status of kraken"
        def krakenHealth = ['bash', '-c', "docker ps | grep -i kraken-engine"]
        def out = null
        def time = 480
        def timeStart = System.currentTimeMillis()
        boolean krakenRestartSuccessful = false
        while ((System.currentTimeMillis() - timeStart) / 1000 < time && !(out?.contains("healthy"))) {
            out = executeCommand(krakenHealth)
            println "Kraken status: ${out}"
            sleep(20 * 1000) // sleep for 20 seconds
            println "Waiting for Kraken status to become healthy"
        }

        println(out ?: "Kraken is unhealthy!")

        if (out?.contains("(healthy)")) {
            println "Kraken is healthy"

            krakenRestartSuccessful = true
        } else {
            println "Kraken is unhealthy"
            krakenRestartSuccessful = false
        }

        return krakenRestartSuccessful
    }

    static def checkUpdateConfidenceLevel(confidenceLevel, otsConfigFile, otsConfigPersistFile) {
        boolean tenantConfidenceUpdated = false
        println "Checking the OMS confidence level"
        def cmd = ['bash', '-c', "grep '^wd.confidence.level=' ${otsConfigFile} | cut -d'=' -f2"]
        String tenantConfidence = executeCommand(cmd).trim()

        if (tenantConfidence.toString() == confidenceLevel.toString()) {
            println "OMS is in the right Confidence Level"
        } else {
            println "Updating the Tenant confidence level from ${tenantConfidence} to ${confidenceLevel}"
            cmd = ['bash', '-c', "sed -Ei 's/(wd.confidence.level=).*/\\1${confidenceLevel.trim()}/' ${otsConfigFile}"]
            executeCommand(cmd)

            cmd = ['bash', '-c', "grep '^wd.confidence.level=' ${otsConfigFile} | cut -d'=' -f2"]
            tenantConfidence = executeCommand(cmd).trim()
            println "Current Confidence Level is  ${tenantConfidence}"
            cmd = ['bash', '-c', "grep '^wd.confidence.level=' ${otsConfigFile}"]
            def tenantConfidenceConfig = executeCommand(cmd).trim()
            println "Tenant Persisting: ${tenantConfidenceConfig.trim()}"
            def tenantConfidenceConfigCmd = ['bash', '-c', "echo ${tenantConfidenceConfig.trim()} >> ${otsConfigPersistFile}"]
            println "Executing OMS Confidence using :  ${tenantConfidenceConfigCmd}"
            executeCommand(tenantConfidenceConfigCmd)
            tenantConfidenceUpdated = true
        }

        tenantConfidenceUpdated
    }

    static def restartOts() {
        println "Stopping OTS"
        def cmd = ['bash', '-c', "cd /data/workdaydevqa/suv/suvots && ./stop.sh && ./start.sh"]
        def output = executeCommand(cmd)
        println output
        println "Waiting for OTS to start, this can take up to 15 minutes"
        cmd = ['bash', '-c',"cd /data/workdaydevqa/suv/suvots && ./verify-up.sh"]
        executeCommand(cmd)

        println output.trim()
    }

    static def checkArchiveConfidenceLevel(confidenceLevel, awsXar, wdx_Properties) {
        def archiveConfidenceStatus = false
        println "Checking the archive tenants confidence level ${awsXar}"
        def cmd = ['bash', '-c', "tar --extract -C /mnt --file=/mnt/${awsXar} wdx.Properties"]
        executeCommand(cmd)
        cmd =  ['bash', '-c',"grep ^ARCHIVE_CONFIDENCE_LEVEL= ${wdx_Properties} | cut -d'=' -f2"]
        def archiveConfidence = executeCommand(cmd).trim()
        archiveConfidence = archiveConfidence.toLowerCase()
        println "Archive Conf level ${archiveConfidence}"
        if (archiveConfidence.toString() == confidenceLevel.toString()) {
            println "The S3 Archive and the suv are on the same Confidence Level ${confidenceLevel}"
            archiveConfidenceStatus = true
        } else {
            println "The S3 Archive has confidence level ${archiveConfidence}, where as the suv's Confidence Level is ${confidenceLevel}"
        }
        return archiveConfidenceStatus
    }

    static def getAWSCred() {
        String bbfFile = "/data1/bbf/BAMBOOLATOR-BAMBOOLATOR-DOCKERRUNOTS*/bbf-generated/bbf4.properties"
        String dockerReg = "WD_AWS_DOCKER_REGISTRY_URL="
        println "Getting aws creds file"
        def cmd = ['bash', '-c', "grep ${dockerReg} ${bbfFile} | cut -d'=' -f2"]
        String awsCreds = executeCommand(cmd)
        println "AWS Creds: ${awsCreds}"
        return awsCreds.trim()
    }

    static def getStatusFromWmuLogFile(suvHost, tenant, otsConfigFile, otsConfigPersistFile) {
        def wmuLogPath = "/data/workdaydevqa/suv/suvwmu/logs"
        def searchString = "'importTenant completed successfully'"
        def startsWithString = "wmu-import"
        boolean tenantImportSuccessful = false
        def version = getWdVersionFromSuv()

        def dir = new File(wmuLogPath)
        def latestFile = dir.listFiles()
                ?.findAll { it.name.startsWith(startsWithString) }
                ?.sort { -it.lastModified() }
                ?.head()
        def cmd = ['bash', '-c', "stdbuf -oL tail -10 '${latestFile}' | grep ${searchString}"]
        def out = executeCommand(cmd)
        tenantImportSuccessful = out.contains("importTenant completed successfully")

        if (tenantImportSuccessful) {
            def currentlyRegisteredTenants = registerTenant(tenant, otsConfigFile, otsConfigPersistFile)
            println "Registered tenants on the SUV are :  ${currentlyRegisteredTenants}"
            println "Tenant successfully added: https:${suvHost}/${tenant}"
            manageListOfTenantsAndOts(tenant, tenantImportSuccessful, version)
        }
        return tenantImportSuccessful
    }

    static void main(String[] args) {
        def awsProfile = "aws-s3"
        def propertiesFileName = "exportTenant.properties"
        def tenantLoad = false
        def suvHost = args[0]
        def awsKey = args[1]
        def awsSecretKey = args[2]
        def awsFilePath = args[3]
        def otsConfigFile = "/data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties"
        def otsConfigPersistFile = "/data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties.persist"
        def wdxProperties = "/mnt/wdx.Properties"

        def errorMsg = 'Invalid number of parameters. 0 = host, 1 = aws_key, 2 = aws_secret_key, 3 = aws_file_path'
        if (suvHost == null || awsKey == null || awsSecretKey == null) {
            throw new IllegalArgumentException(errorMsg)
        }

        String credsFile = getAWSCred()
        println "Creds File : $credsFile"
        String credsFilePath = "/tmp/${credsFile}"
        println "Creds File Path : ${credsFilePath}"

        def awsRegion = (credsFile =~ /(us-.*?).amazonaws*/)[0][1]

        def awsTar = awsFilePath.split('/').last()

        println "Tar File : $awsTar"

        def awsXar = awsTar.split('\\.')[0..1].join('.')
        println "XAR file : $awsXar"
        def awsFile = awsXar.split('\\.').first()
        println "AWS file : $awsFile"
        def tenant = awsFile.split('-')[1].toLowerCase()
        println "Tenant name : ${tenant}"

        //Get Suv Confidence level
        def confidenceLevel = getSuvConfidenceLevel()

        //Check the confidence level of the OMS, and update it if its incorrect
        def restartOtsNeeded = checkUpdateConfidenceLevel(confidenceLevel, otsConfigFile, otsConfigPersistFile)
        if (restartOtsNeeded) {
            println "SUV OMS Confidence level fixed. Restarting OTS"
            restartOts()
        }
        //Setup a s3 profile
        createAwsProfile(awsProfile, awsKey, awsSecretKey, awsRegion)

        //Download tar from s3 and unzip it
        downloadFromS3(awsFilePath, awsProfile, awsTar)

        // Check the archive confidence level
        def archiveStatus = checkArchiveConfidenceLevel(confidenceLevel, awsXar, wdxProperties)
        if (!archiveStatus) {
            println "Incorrect Tenant Confidence level. Cleaning up downloaded files"
            // Remove the downloaded tenant
            cleanupDownloadedTenant(awsXar, wdxProperties)
            System.exit(1)
        }

        // Create a new Creds file
        createCredsFile(credsFilePath, awsRegion)

        // Restart Kraken in SALES environment
        restartDocker(credsFile, 'SALES')

        // Wait for Kraken to come online
        def krakenRestartStatus = checkDockerStatus()

        if (krakenRestartStatus) {
            // Create a properties file and Import the Tenant
            importTenantWithProperties(tenant, confidenceLevel, awsXar, propertiesFileName)
        }

        // Restart Kraken in XO environment
        restartDocker(credsFile, 'XO')

        // Remove the downloaded tenant
        cleanupDownloadedTenant(awsXar, wdxProperties)

        tenantLoad = getStatusFromWmuLogFile(suvHost, tenant, otsConfigFile, otsConfigPersistFile)


        if (tenantLoad) {
            println "Tenant ${tenant} successfully added to the SUV"
        } else {
            println "FAILED to add Tenant ${tenant} to the SUV"
            System.exit(1)
        }

    }
}