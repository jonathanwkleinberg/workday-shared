auth_user=ds.conf
auth_pass=

# Get Pool Name from scenario
pool_name=`jq -r '.pool' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json`
# pool_name="dtoe-training"
if [ -z "$pool_name" ]; then
    echo "Pool Name not set in scenario_template.json"
    exit 1
fi
echo Pool Name: $pool_name
# Get Pool ID
# pool_id=`curl -su $auth_user:$auth_pass 'https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools' | jq -r '.[] | select(.name=="dtoe-training") | .id'`
pool_id=`curl -su $auth_user:$auth_pass 'https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools' | jq -r --arg pool_name "${pool_name}" '.[] | select(.name==$pool_name) | .id'`
if [ -z "$pool_id" ]; then
    echo "Pool ID not found for pool name: $pool_name"
    exit 1
fi
echo Pool ID: $pool_id
# Get SUV with Scenario Name in the Description
scenario_name=`jq -r '.name' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json`
echo Scenario Name: $scenario_name
# scenario_name="launchhcm"
already_exists_suv=`curl -su $auth_user:$auth_pass -G --data-urlencode "description=${scenario_name}" "https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances?suvPoolId=${pool_id}&exactMatch=1" | jq -r '.[] | .instanceId'`
# If we get an SUV, exit nicely as we already have an SUV with this scenario
if [ -n "$already_exists_suv" ]; then
    echo "SUV already exists for this scenario" $already_exists_suv
    exit 0
fi
# If no SUV found with that description, get a new SUV with the from_ params
from_desc=`jq -r '.from_desc' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json`
# from_desc="UNUSED"
from_stage=`jq -r '.from_stage' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json`
# from_stage="UNUSED"
blank_suv=`curl -su $auth_user:$auth_pass -G --data-urlencode "description=${from_desc}" --data-urlencode "stage=${from_stage}" "https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances?suvPoolId=${pool_id}&exactMatch=1" | jq -r 'first(.[] | select(.state=="running" and .buildPercentage == 100 and .completelyBuilt == true) | .instanceId)'`

# If still no SUV found, then there are no available SUVs for this scenario in this pool. Exit nicely until next rerun.
if [ -z "$blank_suv" ]; then
    echo "No ready unused SUV found for this scenario in this pool"
    exit 0
fi
echo Blank SUV: $blank_suv

# Update description and stage to SUV showing it is in use and prepping

# If we get an SUV, get target tenants of the scenario.
target_tenants=`jq -r '.recipes | map(.target) | unique | .[]' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json`
echo Target Tenants: $target_tenants
for tenant in $target_tenants; do
    echo tenant: $tenant
done

# Get # of recipes
num_recipes=`jq '.recipes | length' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json`
echo Number of Recipes: $num_recipes
for i in $(eval echo {1..$num_recipes}); do
    echo Scenario: $i
    jq -r --argjson i "$i" '.recipes[$i-1]' /mnt/c/Users/andy.parker/Documents/GitHub/DAI_Tools/Jenkins/Scenario/scenario_template.json
done