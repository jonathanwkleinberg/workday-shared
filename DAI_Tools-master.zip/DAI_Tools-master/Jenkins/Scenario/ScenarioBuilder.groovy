pipeline {
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Get SUV') {
      steps {
        // print(json.dumps(json.dumps(SCENARIO))) # To escape the quotes of a json parameter in json using Python
        println """
SCENARIO: ${SCENARIO}
"""
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user')]) { withEnv (['auth_string=${auth_user}:${auth_pass}']) {
          script {
            // Write scenario to file
            writeFile file: 'scenario.json', text: "${SCENARIO}"
            // Get Scenario Name
            scenario_name=sh(returnStdout: true, script:'''jq -r '.name' scenario.json''').trim()
            if (scenario_name.isEmpty()) {
              error "Scenario Name not found in SCENARIO config data"
            }
            println "Scenario Name: ${scenario_name}"
            env.SCENARIO_NAME = scenario_name
            // Get Pool Name
            pool_name=sh(returnStdout: true, script:'''jq -r '.pool'  scenario.json''').trim()
            if (pool_name.isEmpty()) {
              error "Pool Name not found in SCENARIO config data"
            }
            println "Pool Name: ${pool_name}"
            // Get from_desc
            from_desc=sh(returnStdout: true, script:'''jq -r '.from_desc'  scenario.json''').trim()
            println "SUV From Description: ${from_desc}"
            // Get from_stage
            from_stage=sh(returnStdout: true, script:'''jq -r '.from_stage'  scenario.json''').trim()
            println "SUV From Stage: ${from_stage}"

            // Get Pool ID
            pool_id=sh(returnStdout: true, script:"""set +x; curl -su $auth_string 'https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools' | jq -r --arg pool_name "${pool_name}" '.[] | select(.name==\$pool_name) | .id' """).trim()
            if (pool_id.isEmpty()) {
              error "Pool not found in Proteus"
            }
            println "Pool ID: ${pool_id}"
            env.POOL_ID = pool_id

            // Check if SUV (with current scenario) already exists
            println "Checking if SUV with this scenario name already exists in Proteus"
            already_exists_suv=sh(returnStdout: true, script:"""set +x; curl -su $auth_string -G --data-urlencode "description=${scenario_name}" "https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances?suvPoolId=${pool_id}&exactMatch=1" | jq -r '.[] | .instanceId'""").trim()
            if (!already_exists_suv.isEmpty()) {
              currentBuild.result = 'ABORTED'
              error "An SUV with this scenario name already exists in Proteus (${already_exists_suv}), aborting the build."
            }

            // Get a new SUV matching the "from" criteria
            println "Getting a new SUV matching the <from_> criteria (${from_desc}, ${from_stage}) in this pool"
            suv_id=sh(returnStdout: true, script:"""set +x; curl -su $auth_string -G --data-urlencode "description=${from_desc}" --data-urlencode "stage[]=${from_stage}" "https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances?suvPoolId=${pool_id}&exactMatch=1" | jq -r 'first(.[] | select(.state=="running" and .buildPercentage == 100 and .completelyBuilt == true) | .instanceId)' """).trim()
            if (suv_id.isEmpty()) {
              currentBuild.result = 'ABORTED'
              error "No ready unused SUV found matching the <from_> criteria (${from_desc}, ${from_stage}) found for this scenario in this pool, aborting the build."
            }
            println "SUV ID: ${suv_id}"
            env.SUV = suv_id

            // Update description and stage to SUV showing it is in use and prepping
            println "Updating SUV description and stage to show it is in use and prepping ..."
            sh """curl -su ${auth_string} -X PUT -H "Content-Type: application/json" -d "{\\\"description\\\":\\\"${scenario_name}\\\",\\\"toStage\\\":\\\"PREPARING\\\"}" "https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool_id}/instances/${suv_id}/push" """
            // For Testing: Only update stage
            // sh """curl -su ${auth_string} -X PUT -H "Content-Type: application/json" -d "{\\\"toStage\\\":\\\"PREPARING\\\"}" "https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${pool_id}/instances/${suv_id}/push" """

          } // End Script
        }} // End withCredentials
      } // End Steps
    } // End Stage (Get SUV)
    stage('AddVacant') {
      steps {
        script {

          // Get tenants from scenario 
          target_tenants=sh(returnStdout: true, script:"""jq -r '.recipes | map(.target) | unique | .[]' scenario.json""").trim().split('\n')
          println "Target Tenants: ${target_tenants}"
          env.TARGET_TENANTS = target_tenants.join(',')

          // Add tenants to SUV
          println "Adding tenants to SUV (as needed) ..."
          build job: "AddVacant", propagate: true, wait: true, parameters: [
            string(name: 'SUV', value: "${env.SUV}"), 
            // string(name: 'CONFIDENCE_LEVEL', value: "Production"), 
            // booleanParam(name: 'PURGE_TENANTS', value: false),
            string(name: 'TENANT_NAMES', value: "${env.TARGET_TENANTS}")
          ]
        } // End Script
      } // End Steps
    } // End Stage (AddVacant)
    stage ('FTB') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user')]) { withEnv (['auth_string=${auth_user}:${auth_pass}']) {
          script {
            // Get num of recipes from scenario
            int num_recipes=sh(returnStdout: true, script:"""jq '.recipes | length' scenario.json""").trim() as Integer
            println "# of Recipes in Scenario: ${num_recipes}"
            // Loop through recipes
            for (int i = 1; i <= num_recipes; i++) {
              recipe=sh(returnStdout: true, script:"""jq -r '.recipes[${i-1}]' scenario.json""").trim()
              println "Recipe #${i}: ${recipe}"
              // Run FTB recipe
              println "Running recipe #${i}/${num_recipes} ..."
              build job: "FoundationTenantBuild", propagate: true, wait: true, parameters: [
                string(name: 'SUV', value: "${env.SUV}"), 
                booleanParam(name: 'WAIT_UNTIL_FINISHED', value: true),
                string(name: 'SCENARIO', value: "${recipe}")
              ]
            }

            // Set SUV Stage to READY
            println "Setting SUV stage to READY ..."
            sh """curl -su ${auth_string} -X PUT -H "Content-Type: application/json" -d "{\\\"toStage\\\":\\\"READY\\\"}" "https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${env.POOL_ID}/instances/${env.SUV}/push" """

          } // End Script
        }} // End withCredentials
      } // End Steps
    } // End Stage (FTB)
  } // End Stages
  post {
    failure {
      // Update SUV stage to FAILED
      withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'auth_pass', usernameVariable: 'auth_user')]) { withEnv (['auth_string=${auth_user}:${auth_pass}']) {
        script {
          if (!env.SUV.isEmpty() && !env.POOL_ID.isEmpty()) {
            sh """curl -su ${auth_string} -X PUT -H "Content-Type: application/json" -d "{\\\"toStage\\\":\\\"ERROR\\\"}" "https://wd5-suv.megaleo.com/proteus/api/v2/suv_pools/${env.POOL_ID}/instances/${env.SUV}/push" """
          }
        }
      }} // End withCredentials
    }
  }
} // End Pipeline
