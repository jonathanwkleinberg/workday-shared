pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('Change Billing ID Stage') {
      steps {
        withCredentials([ sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            println """
            SUV: ${SUV}
            TENANT_NAME: ${TENANT_NAME}
            BILLING_ID: ${BILLING_ID}
            """
            println "Changing Billing ID for Tenant: ${TENANT_NAME}"
            TENANT_PASSWORD=sh(returnStdout: true, script: '''ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "sed -nr 's/^properties.env.universalPassword=(.*)$/\\1/p' /data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties" ''').trim()
            sh("""ssh -i "${PK}" -Tqo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
#re-start the ems
/data/workdaydevqa/suv/suvems/start.sh

#verify the ems is running (If the ems had to be restarted then this will cycle through a max of 180 checks until it is up)
/data/workdaydevqa/suv/suvems/verify-up.sh

#Create the properties file for changing the billing id of a tenant on the SUV
cat > changeBillingId.properties<< EOF
EMS_HOST=localhost
EMS_PORT=16010
EMS_PASSWORD=${TENANT_PASSWORD}
EMS_TENANT_NAME=ems
EMS_USER=wd-environments
ENVIRONMENT_NAME=suv
CONFIG_PROPERTY_KEY=CUSTOMER_BILLING_ID
CONFIG_PROPERTY_VALUE=${BILLING_ID}
TENANT_EXEC_NAMES=${TENANT_NAME}
EXPORT_DIRECTORY=/data/workdaydevqa/suv/suvwmu/
EXPORT_FILENAME=${TENANT_NAME}
TENANT_NAME=${TENANT_NAME}
EOF
cat changeBillingId.properties
/data/workdaydevqa/suv/suvwmu/wmu.sh exportTenantKrakenKeys changeBillingId.properties -d CUSTOMER_BILLING_ID=DEF0000000000010
/data/workdaydevqa/suv/suvwmu/wmu.sh setPropertyForTenants changeBillingId.properties
/data/workdaydevqa/suv/suvwmu/wmu.sh importTenantKrakenKeys changeBillingId.properties -d CUSTOMER_BILLING_ID=DEF0000000000006
rm -rf changeBillingId.properties
ENDSSH
            """)
          } // End Script
        } // End withCredentials
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline