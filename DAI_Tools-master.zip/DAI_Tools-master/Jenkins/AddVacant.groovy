pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }
  // agent any

  // @wmu_props_path = "/data/workdaydevqa/suv/suvwmu/input"
  // @universal_tenant_xar_path = "/data/workdaydevqa/suv/suvwmu/exports"
  // @universal_customertenant_billing_id = "DEF0000000000006"
  // @universal_customertenant_customer_number = "1234567"
  // @universal_foundrytenant_billing_id = "DEF0000000000007"
  // @universal_foundrytenant_customer_number = "7654321"
  // @tenant_info_path = "/data/workday/"
  // @tenant_info_filename = "tenantsAdded.info"
  // @ots_config_file = "/data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties"
  // @enable_blocking = false
  // @foundries = ["dapzulu", "dapecho", "daplima", "dapalpha", "wdsetup"]


  stages {
    stage('Add Vacant Stage') {
      steps {
        withCredentials([ sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            println """
            SUV: ${SUV}
            CONFIDENCE_LEVEL: ${CONFIDENCE_LEVEL}
            PURGE_TENANTS: ${PURGE_TENANTS}
            TENANT_NAMES: ${TENANT_NAMES}
            """
            // Check if EMS is up
            EMS_UP=sh(returnStdout: true, script: '''ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "/data/workdaydevqa/suv/suvems/verify-up.sh" ''')
            //echo "EMS_UP: $EMS_UP"
            if (EMS_UP.contains("ems 'suvems' is UP")) {
              println "EMS is up!"
            } else {
              println "EMS is down, now starting it"
              sh('''ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "/data/workdaydevqa/suv/suvems/start.sh" ''')
            }
            // Check if wdsetup is loaded
            println "Checking if wdsetup is on this SUV ..."
            WDSETUP=sh(returnStdout: true, script: '''ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "curl -s -D - https://${SUV}.workdaysuv.com/wdsetup" ''')
            if (WDSETUP.contains("https://community.workday.com") || WDSETUP.contains("503 Service Unavailable") || WDSETUP.contains("Unable to find OTS endpoint") || WDSETUP.contains("Location: https://community.workday.com/invalid-url") ) {
              println "wdsetup is not loaded (but continue anyway) ..."
              // load wdsetup?
            } else {
              println "wdsetup loaded, loading the vacant tenants (${TENANT_NAMES}) ..."
            }
            TENANT_PASSWORD=sh(returnStdout: true, script: '''ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "sed -nr 's/^properties.env.universalPassword=(.*)$/\\1/p' /data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties" ''').trim()
            println "TENANT_PASSWORD: ${TENANT_PASSWORD} "
            // Load vacant tenants by looping through param
            for (String tenant_name : TENANT_NAMES.split(',')) {
              println "Loading vacant tenant: ${tenant_name}"
              if (tenant_name.startsWith("wd")) {
                wats_user='wd-environments'
              } else {
                wats_user='wd-developer'
              }
              println "WATS_USER: ${wats_user}"
              // Check if tenant is already loaded
              TENANT_LOADED=sh(returnStdout: true, script: """ssh -i "${PK}" -o StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "curl -s -D - https://${SUV}.workdaysuv.com/${tenant_name}" """)
              if (TENANT_LOADED.contains("https://community.workday.com") || TENANT_LOADED.contains("503 Service Unavailable") || TENANT_LOADED.contains("Unable to find OTS endpoint") || TENANT_LOADED.contains("Location: https://community.workday.com/invalid-url") ) {
                println "Tenant not loaded, loading it now ..."
              } else if (PURGE_TENANTS == "true") {
                println "Tenant already loaded. Purging tenant ..."
                // Purge tenant
                sh("""ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
cat <<EOF > /data/workdaydevqa/suv/suvwmu/input/purge.${tenant_name}.tenant.properties
TENANT_NAME=${tenant_name}
OTS_NAME=suvots
SET_TENANT_MODE=TRUE
EOF
# cat /data/workdaydevqa/suv/suvwmu/input/purge.${tenant_name}.tenant.properties
set -x
/data/workdaydevqa/suv/suvwmu/wmu.sh purgeTenant /data/workdaydevqa/suv/suvwmu/input/purge.${tenant_name}.tenant.properties
ENDSSH""")
                // Create the WATS properties file
              sh("""ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
cat <<EOF > /data/workdaydevqa/suv/suvwats/my.wats.properties
wats.dap.customer.tenant=${tenant_name}
EOF
set -x
cat /data/workdaydevqa/suv/suvwats/my.wats.properties
ENDSSH""")
                // This WATS step seems to ALWAYS fail
                wats_iid='755\\\$261559'
                wats_desc='Deactivate and Purge in CC'
                wats_tenant='customercentral'
                println "Running WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ..."
                try {
                  WATS_OUTPUT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${wats_tenant} ${wats_user} ${TENANT_PASSWORD} DEF ${wats_iid}' """)
                } catch (Exception e) {
                  println 'Exception occurred: ' + e.toString()
                  WATS_OUTPUT=e.toString()
                }
                //println "WATS_OUTPUT (${wats_desc}): ${WATS_OUTPUT}"
                if (WATS_OUTPUT.contains("WATS finish running test cases with exit code 0")) {
                  println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ran successfully!"
                } else {
                  println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) failed!"
                }
              } else {
                println "Tenant already loaded!"
                continue
              }
              // Load tenant
              CREATE_TENANT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
cat <<EOF > /data/workdaydevqa/suv/suvwmu/input/create.${tenant_name}.vacant.tenant.properties
WATS_CONTINUE_ON_FAIL=Y
WATS_REPORT_PATH_ROOT=/data/workdaydevqa/suv/suvwmu/report/BAMBOOLATOR-BAMBOOLATOR-CREATEVACANT-EC2CREATETENANT
BYPASS_BLOB=N
CLOUD_BATCH_JOBS_ENABLED=N
CREATE_CUSTOMER_RETRY_MAX_WAIT=30000
CUSTOMER_NAME=SUVTEST
CUSTOMER_BILLING_ID=DEF0000000000006
CUSTOMER_NUMBER=1234567
DS_ENTRY_DB_NAME=suv_${tenant_name}
OTS_NAME=suvots
ENVIRONMENT_NAME=suv
INCLUDE_RIAK=Y
INITIAL_TENANT_PASSWORD=${TENANT_PASSWORD}
INITIAL_TENANT_USER=${tenant_name}
REPORT_ORS_ENABLED=N
SHOULD_LOAD_TENANT=Y
SET_TENANT_MODE=TRUE
SIZE=S
TENANT_CONFIDENCE_LEVEL=${CONFIDENCE_LEVEL}
TENANT_NAME=${tenant_name}
TENANT_UNLOAD_TIMEOUT=10800000
UI_ORS_ENABLED=N
USE_KMI=N
SEED_WITH_WDSETUP=Y
EOF
set -x
cat /data/workdaydevqa/suv/suvwmu/input/create.${tenant_name}.vacant.tenant.properties
/data/workdaydevqa/suv/suvwmu/wmu.sh createTenant /data/workdaydevqa/suv/suvwmu/input/create.${tenant_name}.vacant.tenant.properties
ENDSSH""")
              println "CREATE_TENANT: ${CREATE_TENANT}"
              if (CREATE_TENANT.contains("createTenant completed")) {
                println "Tenant created successfully!"
              } else {
                println "Tenant creation failed! Continuing to next tenant ..."
                continue
              }
              // Create the WATS properties file
              sh("""ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com <<ENDSSH
cat <<EOF > /data/workdaydevqa/suv/suvwats/my.wats.properties
wats.dap.customer.tenant=${tenant_name}
EOF
set -x
cat /data/workdaydevqa/suv/suvwats/my.wats.properties
ENDSSH""")
              wats_iid='755\\\$149498'
              wats_desc='Create Implementer'
              wats_tenant=tenant_name
              println "Running WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ..."
              try {
                WATS_OUTPUT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${wats_tenant} ${wats_user} ${TENANT_PASSWORD} DEF ${wats_iid}' """)
              } catch (Exception e) {
                println 'Exception occurred: ' + e.toString()
                WATS_OUTPUT=e.toString()
              }
              //println "WATS_OUTPUT (${wats_desc}): ${WATS_OUTPUT}"
              if (WATS_OUTPUT.contains("WATS finish running test cases with exit code 0")) {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ran successfully!"
              } else {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) failed!"
              }

              wats_iid='755\\\$200566'
              wats_desc='Create CC Implementer'
              wats_tenant=tenant_name
              println "Running WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ..."
              try {
                WATS_OUTPUT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${wats_tenant} ${wats_user} ${TENANT_PASSWORD} DEF ${wats_iid}' """)
              } catch (Exception e) {
                println 'Exception occurred: ' + e.toString()
                WATS_OUTPUT=e.toString()
              }
              //println "WATS_OUTPUT (${wats_desc}): ${WATS_OUTPUT}"
              if (WATS_OUTPUT.contains("WATS finish running test cases with exit code 0")) {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ran successfully!"
              } else {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) failed!"
              }

              wats_iid='798\\\$158369'
              wats_desc='Enable Pending Security Changes'
              wats_tenant=tenant_name
              println "Running WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ..."
              try {
                WATS_OUTPUT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${wats_tenant} ${wats_user} ${TENANT_PASSWORD} DEF ${wats_iid}' """)
              } catch (Exception e) {
                println 'Exception occurred: ' + e.toString()
                WATS_OUTPUT=e.toString()
              }
              //println "WATS_OUTPUT (${wats_desc}): ${WATS_OUTPUT}"
              if (WATS_OUTPUT.contains("WATS finish running test cases with exit code 0")) {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ran successfully!"
              } else {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) failed!"
              }

              wats_iid='755\\\$221558'
              wats_desc='Maintain Customer Tenants'
              wats_tenant='customercentral'
              println "Running WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ..."
              try {
                WATS_OUTPUT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${wats_tenant} ${wats_user} ${TENANT_PASSWORD} DEF ${wats_iid}' """)
              } catch (Exception e) {
                println 'Exception occurred: ' + e.toString()
                WATS_OUTPUT=e.toString()
              }
              //println "WATS_OUTPUT (${wats_desc}): ${WATS_OUTPUT}"
              if (WATS_OUTPUT.contains("WATS finish running test cases with exit code 0")) {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ran successfully!"
              } else {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) failed!"
              }

              wats_iid='755\\\$202555'
              wats_desc='Manage Tenant Access'
              wats_tenant='customercentral'
              println "Running WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ..."
              try {
                WATS_OUTPUT=sh(returnStdout: true, script: """ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'cd /data/workdaydevqa/suv/suvwats && ./wats-java.sh http://localhost:12010/ots ${wats_tenant} ${wats_user} ${TENANT_PASSWORD} DEF ${wats_iid}' """)
              } catch (Exception e) {
                println 'Exception occurred: ' + e.toString()
                WATS_OUTPUT=e.toString()
              }
              //println "WATS_OUTPUT (${wats_desc}): ${WATS_OUTPUT}"
              if (WATS_OUTPUT.contains("WATS finish running test cases with exit code 0")) {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) ran successfully!"
              } else {
                println "WATS (${wats_desc}, ${wats_iid}, ${wats_tenant}) failed!"
              }

              // Remove the WATS properties file
              sh("""ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com 'rm -f /data/workdaydevqa/suv/suvwats/my.wats.properties' """)

            }
          }
        }
      }
    }
  }
}