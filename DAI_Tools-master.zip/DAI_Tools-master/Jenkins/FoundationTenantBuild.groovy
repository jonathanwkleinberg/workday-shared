pipeline {
  // Run on GKE Docker in Docker node
  agent { kubernetes { cloud 'gke-cloud' inheritFrom 'gke-agent-c9-dind' } }

  stages {
    stage('dai-gui') {
      steps { retry(5) {
        checkout changelog: false, poll: false, scm: [
          $class: 'GitSCM', 
          branches: [[name: '*/master']],  
          doGenerateSubmoduleConfigurations: false, 
          extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'dai_gui']],
          submoduleCfg: [], 
          userRemoteConfigs: [[credentialsId: 'SVC_CAS_JENKINS_USER_KEY', url: 'git@ghe.megaleo.com:DTOE/GUI.git']]
        ]
      } } // End Retry // End Steps
    } // End Stage
    stage('FTB Stage') {
      steps {

        // Setup Artifactory Repo (yum/dnf)
        withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_ENC_PASS', passwordVariable: 'enc_pass', usernameVariable: 'enc_user')]) {
          sh('''echo "[artifactory-repo-baseos]
name=Artifactory Repository BaseOS
baseurl=https://${enc_user}:${enc_pass}@artifactory.workday.com/artifactory/mirror.stream.centos.org/9-stream/BaseOS/x86_64/os/
enabled=1
gpgcheck=0" | sudo tee /etc/yum.repos.d/artifactory-baseos.repo
echo "[artifactory-repo-appstream]
name=Artifactory Repository AppStream
baseurl=https://${enc_user}:${enc_pass}@artifactory.workday.com/artifactory/mirror.stream.centos.org/9-stream/AppStream/x86_64/os/
enabled=1
gpgcheck=0" | sudo tee -a /etc/yum.repos.d/artifactory-appstream.repo
          ''')
        } // end withcred (enc_user)
        
        
        withCredentials([sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK') ]) {
          script {
            println """
            SUV: ${SUV}
            WAIT_UNTIL_FINISHED: ${WAIT_UNTIL_FINISHED}
            SCENARIO: ${SCENARIO}"""

            // println "Foundation Tenant Build for Tenant: ${TENANT_NAME}"
            HOST_PASSWORD=sh(returnStdout: true, script: '''ssh -i "${PK}" -qo StrictHostKeyChecking=no root@${SUV}.workdaysuv.com "sed -nr 's/^properties.env.universalPassword=(.*)$/\\1/p' /data/workdaydevqa/suv/suvots/tomcat/conf/catalina.properties" ''').trim()
            
            // Create Scenario File and Prep Python
            sh("""set +x
            echo '${SCENARIO}' > ftb_scenario.json
            sudo yum -y install python3-pip
            pip3 install requests -i http://artifactory-az.services.wd:8081/artifactory/api/pypi/python-release-virtual/simple/ --trusted-host artifactory-az.services.wd
            """)

            // Run FTB through Python
            sh("""#!/usr/bin/python3 -u
import json, sys, time
sys.path.insert(0, '${WORKSPACE}/dai_gui/lib/')
from workday import Workday

scenario = json.load(open('ftb_scenario.json'))

name = scenario.get('scenario', 'No Name')
target_tenant = scenario['target']
recipe = scenario['recipe']
tags = [t for c in scenario['categories_tags'] for t in c['tags']]
skip_steps = []

print(F'Running FTB scenario "{name}" for tenant "{target_tenant}" with recipe "{recipe}" and tags {tags}')

w = Workday('https://${SUV}.workdaysuv.com/customercentral/', 'ccu', '${HOST_PASSWORD}')
w.login()
ftb = w.ftb(target_tenant, recipe, tags, skip_steps)
print(ftb)

if '${WAIT_UNTIL_FINISHED}' == 'true':
  # Wait for FTB to complete
  finished_states = ['Completed', 'Failed', 'Skipped', 'Aborted', 'Stopped - Validation Failed', 'Completed With Errors']
  running_states = ['In Progress', 'Not Started', 'Reprocessing', 'Stopped']
  ftb_status = w.get_ftb_status(ftb['url'])
  print(ftb_status)
  while ftb_status['status'] in running_states:
    time.sleep(30)
    ftb_status = w.get_ftb_status(ftb['url'])
    print(ftb_status)
            """)
          } // End Script
        } // End withCredentials
      } // End Steps
    } // End Stage
  } // End Stages
} // End Pipeline