# DCDD SmartSheet Scraper into JSON format
# Converts all DCDDs and the tracking sheet into JSON for later use
# -------------

import smartsheet # smartsheet-python-sdk
import re
import os
import sys
import time
import shutil
import json
import argparse
from threading import Thread, Lock, Semaphore


def parse_arguments():
    parser = argparse.ArgumentParser(description='Filter based on SKUs.')
    parser.add_argument('--filter_by_sku', nargs='+', help='List of SKUs to filter by')
    return parser.parse_args()


def convert_to_snake_case(s):
    return s.lower().replace(' ', '_')


def clear_directory(directory_path):
    for filename in os.listdir(directory_path):
        file_path = os.path.join(directory_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print(f'Failed to delete {file_path}. Reason: {e}')


def write_data_to_file(data, file_path):
    try:
        with open(file_path, 'w') as file:
            json.dump(data, file)
    except Exception as e:
        print(f"An error occurred while writing to the file: {e}")


def read_data_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            return json.load(file)
    except Exception as e:
        print(f"An error occurred while reading from the file: {e}")
        return []


def get_tracking_sheet_data(tracking_sheet_id):
    # Create dictionaries for column indexes and IDs
    tracking_sheet_columns = {x.title:y for y,x in enumerate(tracking_sheet_data.columns)}
    tracking_sheet_columns_ids = {x.title:x.id for x in tracking_sheet_data.columns}
    
    # Define column names
    DCDD_COL = next(c for c in tracking_sheet_columns if c.lower() in ['dcdd', 'dcdds'])
    SKU_COL = next((c for c in tracking_sheet_columns if c.lower() in ['functional area', 'skus', 'sku']), None)
    IN_SCOPE_COL = next((c for c in tracking_sheet_columns if c.lower() in ['dcdd ready', 'in scope for build?', 'in scope']), None) # this is a checkbox - don't use .display_value
    SP_FINAL_COL = next((c for c in tracking_sheet_columns if c.lower() in ['sp final on github (merged)', 'sp approved and merged']), None) # this is a checkbox - don't use .display_value
    ORDER_COL = next((c for c in tracking_sheet_columns if c.lower() in ['load order', 'order', 'priority order']), None)

    tracking_sheet_rows = [{
      **{LINK_ID: (r.cells[tracking_sheet_columns[DCDD_COL]].hyperlink and r.cells[tracking_sheet_columns[DCDD_COL]].hyperlink.url.split('/')[-1].split('?')[0]) or None},
      **{c: r.cells[tracking_sheet_columns[c]].display_value if r.cells[tracking_sheet_columns[c]].display_value else r.cells[tracking_sheet_columns[c]].value for c in tracking_sheet_columns},
      **{"full_url": f"https://app.smartsheet.com/sheets/{(r.cells[tracking_sheet_columns[DCDD_COL]].hyperlink and r.cells[tracking_sheet_columns[DCDD_COL]].hyperlink.url.split('/')[-1].split('?')[0])}"}
    } for r in tracking_sheet_data.rows if r.cells[tracking_sheet_columns[DCDD_COL]].hyperlink and r.cells[tracking_sheet_columns[DCDD_COL]].hyperlink.url and ((r.cells[tracking_sheet_columns[IN_SCOPE_COL]].value if IN_SCOPE_COL else True) or (r.cells[tracking_sheet_columns[SP_FINAL_COL]].value if SP_FINAL_COL else True))]

    # Check if rows are empty
    if not tracking_sheet_rows:
        print("No rows found in the tracking sheet.")
        sys.exit(1)
    
    # Sort Tracking Sheet
    sort_specifier = smartsheet.models.SortSpecifier({
    'sort_criteria': [
        smartsheet.models.SortCriterion({
        'column_id': tracking_sheet_columns_ids['DCDD'],
        'direction': 'ASCENDING' # 'ASCENDING' / 'DESCENDING'
        }),
        smartsheet.models.SortCriterion({
        'column_id': tracking_sheet_columns_ids['Functional Area'],
        'direction': 'ASCENDING' # 'ASCENDING' / 'DESCENDING'
        }),
        smartsheet.models.SortCriterion({
        'column_id': tracking_sheet_columns_ids['DCDD WS Version'],
        'direction': 'ASCENDING' # 'ASCENDING' / 'DESCENDING'
        }),
    ]
    })
    sort_response = smart.Sheets.sort_sheet(tracking_sheet_id, sort_specifier)
    return {
        "tracking_sheet_url_id": tracking_sheet_url_id,
        "data": tracking_sheet_rows,
        "columns": tracking_sheet_columns,
        "DCDD_COL": DCDD_COL,
        "SKU_COL": SKU_COL,
        "SP_FINAL_COL": SP_FINAL_COL,
        "ORDER_COL": ORDER_COL
    }


def process_sku(sku_num, sku, lock, sem, tracking_sheet_rows, SKUs, SKU_COL, DCDD_COL):
    nonalphanumeric = re.compile('[^0-9a-zA-Z]+')

    with sem:            
        with lock:
            print(f"<<<<<<<<< Thread for SKU {sku_num} ({sku}): Starting  >>>>>>>>>>")

        json_file_path = os.path.join(JSONs, sku)  # Directory path for the SKU
        os.makedirs(json_file_path, exist_ok=True)

        # Loop through the DCDDs
        sku_sheets = [x for x in tracking_sheet_rows if sku in [nonalphanumeric.sub('_', y.strip()).strip('_').lower() for y in x[SKU_COL].split(',')] or sku == 'ALL']
        dcdd_count = len(sku_sheets)
        global total_dcdds
        total_dcdds += dcdd_count
        for i,dcdd_sheet in enumerate(sku_sheets,1):
            print(f"Thread  {sku_num}/{len(SKUs)} -- Processing {sku} DCDD {i}/{dcdd_count} -- {dcdd_sheet.get(DCDD_COL, 'N/A')}")
            for i in range(retries):
                try:
                    dcdd_sheet_data = smart.Sheets.get_sheet(dcdd_sheet[LINK_ID])
                    break
                except:
                    if i < retries-1:
                        print("Waiting for results...")
                        time.sleep(i)
                        continue
                    else:
                        raise
            dcdd_sheet_columns = {x.title:y for y,x in enumerate(dcdd_sheet_data.columns)}
        
            dcdd_sheet_rows = [{c: r.cells[dcdd_sheet_columns[c]].display_value if r.cells[dcdd_sheet_columns[c]].display_value else r.cells[dcdd_sheet_columns[c]].value for c in dcdd_sheet_columns} for r in dcdd_sheet_data.rows]

            # Get the column names for 'csv File Name', 'csv header', 'Required/Optional' and 'Type Value'
            csv_file_name_col = 'csv File Name'
            csv_header_col = 'csv Header'
            required_optional_col = 'Required/Optional'
            type_value_col = 'Type Value'

            # Update the 'csv File Name' column
            if not any(row.get(csv_file_name_col) for row in dcdd_sheet_rows):
              first_occurrence = False
              for row in dcdd_sheet_rows:
                  if not row.get(csv_file_name_col) and row.get(csv_header_col):
                      if not first_occurrence and str(row.get(required_optional_col)).lower() in ['required', 'design requirement'] and str(row.get(type_value_col)).lower() != 'reference':
                          row[csv_file_name_col] = 'All CSVs'
                          first_occurrence = True
                      else:
                          row[csv_file_name_col] = dcdd_sheet_data.name.replace('_DCDD', '')

            for i in range(retries):
                try:
                    dcdd_summary_data = smart.Sheets.get_sheet_summary_fields(dcdd_sheet_data.id, include_all=True)
                    break
                except:
                    if i < retries-1:
                        print("Waiting for results...")
                        time.sleep(i)
                        continue
                    else:
                        raise
            
            dcdd_summary = {f.title: str(f.object_value.value).replace(u'\ufeff', '').strip() if f.object_value and hasattr(f.object_value, 'value') else None for f in dcdd_summary_data.data}

            json_file_name = f"{dcdd_sheet[DCDD_COL]}.json"  # JSON file name
            full_json_file_path = os.path.join(json_file_path, json_file_name)  # Full path to the JSON file
            os.makedirs(json_file_path, exist_ok=True)
            print(F"   Writing JSON file: {json_file_name}")
            
            with open(full_json_file_path, 'w', encoding='utf-8') as jf:
                jf.write(json.dumps({
                    "uuid": dcdd_sheet_data.id, # Unique (according to Smartsheet) ID for each sheet
                    "name": dcdd_sheet[DCDD_COL], # Hyperlink (override) name from the tracking sheet / checklist
                    "short_name": dcdd_sheet_data.name, # Name from the actual sheet (limited characters)
                    "full_sheet_id": dcdd_sheet[LINK_ID],
                    "permalink": dcdd_sheet["full_url"],
                    "areas": dcdd_sheet[SKU_COL], # Functional Areas (from the tracking sheet)
                    "metadata": dcdd_summary, # Sheet summary fields 
                    "columns": list(dcdd_sheet_columns.keys()), # Sheet headers/columns
                    "rows": [list(x.values()) for x in dcdd_sheet_rows if any(x.values())] # List of lists of row data in same order as columns
                    }, indent=2))
                global total_json_files
                total_json_files += 1

            # Splitting and writing the second set of JSON files
            files_data = {}
            json_file_path2 = os.path.join(JSONs2, sku)  # Directory path for the SKU
            os.makedirs(json_file_path2, exist_ok=True)

            primary_key = []
            has_csv_file_name = any(row.get(csv_file_name_col) for row in dcdd_sheet_rows)
            for row in dcdd_sheet_rows:
              if has_csv_file_name:
                if not csv_file_name_col in row or not row[csv_file_name_col]:
                  continue # skip rows without a file name when one is present in other rows
                else:
                  json_file_names = row[csv_file_name_col].split(',')
              else:
                json_file_names = [dcdd_sheet_data.name]
              
              for json_file_name in json_file_names:
                json_file_name = json_file_name.replace(".csv","").strip()  # Remove leading/trailing whitespace
                if json_file_name.lower() == "all csvs" and row[csv_header_col]:
                  primary_key.append(row)
                elif json_file_name.lower() != "all csvs" and row[csv_header_col]:
                  data = files_data.setdefault(json_file_name, [])
                  data.append(row)
            if not primary_key: 
              print(F'No primary key(s) {dcdd_sheet_data.name}')
            else:
                
              # Prepend primary key headers and samples to each file data
              first_file = True
              for i, (json_file_name, data) in enumerate(files_data.items()):
                  full_json_file_path2 = os.path.join(json_file_path2, json_file_name + ".json")  # Add a "2" to the end of the file name
                  
                  # Write to the JSON file
                  with open(full_json_file_path2, 'w') as f:
                      if first_file:  # If it's the first file, include the metadata
                          f.write(json.dumps({
                              "uuid": F"{str(dcdd_sheet_data.id)}-{i}",
                              "name": json_file_name, # dcdd_sheet[DCDD_COL],
                              "short_name": dcdd_sheet_data.name,
                              "full_sheet_id": dcdd_sheet[LINK_ID],
                              "permalink": dcdd_sheet["full_url"],
                              "areas": dcdd_sheet[SKU_COL],
                              "metadata": dcdd_summary, 
                              "columns": list(dcdd_sheet_columns.keys()),
                              "rows": [list(x.values()) for x in primary_key + data if any(x.values())]
                          }, indent=2))
                          first_file = False  # Set the flag to False after writing the first file
                      else:  # If it's not the first file, don't include the metadata
                          f.write(json.dumps({
                              "uuid": F"{str(dcdd_sheet_data.id)}-{i}",
                              "name": json_file_name, # dcdd_sheet[DCDD_COL],
                              "short_name": dcdd_sheet_data.name,
                              "full_sheet_id": dcdd_sheet[LINK_ID],
                              "permalink": dcdd_sheet["full_url"],
                              "areas": dcdd_sheet[SKU_COL],
                              "columns": list(dcdd_sheet_columns.keys()),
                              "rows": [list(x.values()) for x in primary_key + data if any(x.values())]
                          }, indent=2))
                  total_json_files += 1

        with lock:
            print(f"<<<<<<<<< Thread for SKU {sku_num} ({sku}): Completed with {dcdd_count} DCDD(s) >>>>>>>>>>")


def main():
    start_time = time.time()
    args = parse_arguments()

    # Normalize input SKUs
    filter_by_sku = [convert_to_snake_case(s).lower().strip() for s in args.filter_by_sku] if args.filter_by_sku else None
    print(f"Filtering by SKUs: {filter_by_sku}")

    tracking_sheet_data = get_tracking_sheet_data(tracking_sheet_id)
    tracking_sheet_rows = tracking_sheet_data["data"]
    tracking_sheet_columns = tracking_sheet_data["columns"]
    DCDD_COL = tracking_sheet_data["DCDD_COL"]
    SKU_COL = tracking_sheet_data["SKU_COL"]
    SP_FINAL_COL = tracking_sheet_data["SP_FINAL_COL"]
    ORDER_COL = tracking_sheet_data["ORDER_COL"]


    # Apply exact match filtering or process all if no filter is specified
    print("Applying exact match filtering to include specific SKUs...")
    if filter_by_sku is None:
        filtered_rows = tracking_sheet_rows  # No filter specified, process all rows
    else:
        filtered_rows = [
            row for row in tracking_sheet_rows
            if any(sku in {sku.strip().lower() for sku in row.get(SKU_COL, '').split(',')} for sku in filter_by_sku)
        ]

    # Debugging output for matched rows
    for row in filtered_rows:
        skus_in_row = [sku.strip().lower() for sku in row.get(SKU_COL, '').split(',')]
        print(f"Matched Row SKUs: {skus_in_row}")

    print(f"Filtered rows count: {len(filtered_rows)}")

    if filter_by_sku:
        # Process only SKUs that were filtered for
        SKUs = filter_by_sku
    else:
        # Process all SKUs found in all rows if no filter is applied
        SKUs = list(set([nonalphanumeric.sub('_', y.strip()).strip('_').lower() for row in tracking_sheet_rows for y in row.get(SKU_COL, '').split(',')]))

    # Writing to JSON file
    CHKLIST_file_path = os.path.join(CHKLIST, 'tracking_sheet_data.json')
    os.makedirs(os.path.dirname(CHKLIST_file_path), exist_ok=True)
    clear_directory(os.path.dirname(CHKLIST_file_path))
    write_data_to_file(tracking_sheet_data, CHKLIST_file_path)  # Write the entire tracking_sheet_data dictionary to the JSON file

    # Lookup Dictionary
    lookup_sheet_columns = {x.title: y for y, x in enumerate(lookup_sheet_data.columns)}
    ACTIVE_COL = next((c for c in lookup_sheet_columns if c.lower() == 'active'), None)  # this is a checkbox - don't use .display_value

    # Preparing row data without repeating LINK_ID in each row
    lookup_sheet_rows = [
        {c: (r.cells[lookup_sheet_columns[c]].display_value if r.cells[lookup_sheet_columns[c]].display_value else r.cells[lookup_sheet_columns[c]].value) 
            if r.cells[lookup_sheet_columns[c]].value is not None else "" 
        for c in lookup_sheet_columns}
        for r in lookup_sheet_data.rows if r.cells[lookup_sheet_columns[ACTIVE_COL]].value
    ]

    # Structuring the JSON output
    lookup_data = {
        LOOKUPDICT_LINK_ID: lookup_sheet_url_id,  # Only appear once at the beginning of the JSON file
        LOOKUPDICT_SHEET_ID: lookup_sheet_id,     # Only appear once at the beginning of the JSON file
        "rows": lookup_sheet_rows      # List of all rows under the key "rows"
    }

    DICT_file_path = os.path.join(DICTS, 'lookup_dictionary_data.json')
    os.makedirs(os.path.dirname(DICT_file_path), exist_ok=True)
    clear_directory(os.path.dirname(DICT_file_path))
    write_data_to_file(lookup_data, DICT_file_path) # Write the structured lookup_data to the JSON file

    # Validation Dictionary
    validation_sheet_columns = {x.title: y for y, x in enumerate(validation_sheet_data.columns)}
    ACTIVE_COL = next((c for c in validation_sheet_columns if c.lower() == 'active'), None)  # this is a checkbox - don't use .display_value

    # Preparing row data without repeating LINK_ID in each row
    validation_sheet_rows = [
        {c: (r.cells[validation_sheet_columns[c]].display_value if r.cells[validation_sheet_columns[c]].display_value else r.cells[validation_sheet_columns[c]].value) 
            if r.cells[validation_sheet_columns[c]].value is not None else "" 
        for c in validation_sheet_columns}
        for r in validation_sheet_data.rows if r.cells[validation_sheet_columns[ACTIVE_COL]].value
    ]

    # Structuring the JSON output
    validation_data = {
        VALDICT_LINK_ID: validation_sheet_url_id,  # Only appear once at the beginning of the JSON file
        VALDICT_SHEET_ID: validation_sheet_id,     # Only appear once at the beginning of the JSON file
        "rows": validation_sheet_rows      # List of all rows under the key "rows"
    }

    VALDICT_file_path = os.path.join(DICTS, 'validation_dictionary_data.json')
    os.makedirs(os.path.dirname(VALDICT_file_path), exist_ok=True)
    # clear_directory(os.path.dirname(VALDICT_file_path)) # Already done for the Lookup Dictionary
    write_data_to_file(validation_data, VALDICT_file_path) # Write the structured validation_data to the JSON file

    # multi-threading
    lock = Lock()
    sem = Semaphore(5)
    threads = []

    for sku_num, sku in enumerate(SKUs, 1):
        thread = Thread(target=process_sku, args=(sku_num, sku, lock, sem, tracking_sheet_rows, SKUs, SKU_COL, DCDD_COL))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    end_time = time.time()
    total_time = end_time - start_time
    hours, rem = divmod(total_time, 3600)
    minutes, seconds = divmod(rem, 60)
    print(f" <-|-|-|-> Total JSON execution time: {int(hours)} hours, {int(minutes)} minutes, and {seconds:.2f} seconds <-|-|-|->")
    print(f" <-|-|-|-> Total count of DCDDs: {total_dcdds} <-|-|-|->")
    print(f" <-|-|-|-> Total count of JSON files: {total_json_files} <-|-|-|->")

if __name__ == "__main__":
    # DEFAULTS
    token = os.getenv("SMARTSHEET_ACCESS_TOKEN") or "MANUALLY_ENTERED_SS_TOKEN" # Access Token
    smart = smartsheet.Smartsheet(token)
    smart.errors_as_exceptions(True)
    CurrentPath = os.path.dirname(__file__)
    JSONs = F"{CurrentPath}/JSONs/"
    JSONs2 = F"{CurrentPath}/JSONs2/"
    CHKLIST = F"{CurrentPath}/CHKLIST/"
    DICTS = F"{CurrentPath}/DICTS/"
    include_comments = False # only affects DDLs
    include_do_not_populate = True # only affects DDLs
    retries = 3
    LINK_ID = LOOKUPDICT_LINK_ID = VALDICT_LINK_ID = "LINK_ID"
    SHEET_ID = LOOKUPDICT_SHEET_ID = VALDICT_SHEET_ID = "SHEET_ID"
    tracking_sheet_id = os.getenv("DCDD_TRACKING_SHEET_ID") or 'FHw3c6hXHpQM2XhHrcFJmMpxJC3r8Cc4JPpvv3r1' # DCDD_Tracking
    # tracking_sheet_id = os.getenv("DCDD_TRACKING_SHEET_ID") or 'vxq2J9PRqPrfCMcfM9R6xV5W4CW3wJc6xqjg3c31' # DCDD_Tracking (copy 20241205)
    lookup_sheet_id = os.getenv("LOOKUP_DICTIONARY_ID") or 'M3jGFJ3gjCWg64wHfFpmX3gP956ggjqqQrcqG841'
    validation_sheet_id = os.getenv("VALIDATION_DICTIONARY_ID") or 'CXhwgf9h9rrm5c9Mrx87f4hCWJxWjXVRqgx8PQP1' # Validation Dictionary
    tracking_sheet_url_id = tracking_sheet_id
    lookup_sheet_url_id = lookup_sheet_id
    validation_sheet_url_id = validation_sheet_id
    total_dcdds = 0
    total_json_files = 0
    re_delim = re.compile("[, \n|&+]+")
    nonalphanumeric = re.compile('[^0-9a-zA-Z]+')

    # Try to get the Tracking sheet data, exit if there's an error
    try:
        tracking_sheet_data = smart.Sheets.get_sheet(tracking_sheet_id)
    except Exception as e:
        print(f"An error occurred: {e}")
        response_content = getattr(e, 'content', {})
        if response_content:
            print(f"Error when getting Tracking Sheet Data... details: {response_content}")
        sys.exit(1)
    tracking_sheet_id = tracking_sheet_data.id # Get real ID (if not already)

    # Try to get the Dictionary sheet data, exit if there's an error
    try:
        lookup_sheet_data = smart.Sheets.get_sheet(lookup_sheet_id)
    except Exception as e:
        print(f"An error occurred: {e}")
        response_content = getattr(e, 'content', {})
        if response_content:
            print(f"Error when getting Lookup Dictionary... details: {response_content}")
        sys.exit(1)
    lookup_sheet_id = lookup_sheet_data.id # Get real ID (if not already)

    # Try to get the Validation sheet data, exit if there's an error
    try:
        validation_sheet_data = smart.Sheets.get_sheet(validation_sheet_id)
    except Exception as e:
        print(f"An error occurred: {e}")
        response_content = getattr(e, 'content', {})
        if response_content:
            print(f"Error when getting Validation Dictionary... details: {response_content}")
        sys.exit(1)
    validation_sheet_id = validation_sheet_data.id # Get real ID (if not already)
    
    os.makedirs(os.path.dirname(JSONs), exist_ok=True)
    clear_directory(os.path.dirname(JSONs))

    main()  #running main script