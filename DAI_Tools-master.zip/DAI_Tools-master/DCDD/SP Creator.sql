-- Version 1.26 Optimized and Enhanced with Comments
-- This procedure generates SQL scripts for loading and transforming data based on the specified web service operation.
-- It dynamically creates necessary tables, indexes, and cleanup scripts.

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_skeletor$$
CREATE PROCEDURE sp_skeletor(webservice_operation VARCHAR(100), source_table VARCHAR(100), key_field VARCHAR(64))
BEGIN
    -- Declare variables
    DECLARE done INT DEFAULT FALSE;
    DECLARE _depth INT DEFAULT 1;
    DECLARE _xpath VARCHAR(1000);
    DECLARE _table VARCHAR(1000);
    DECLARE _l_id VARCHAR(1000);
    DECLARE _l_tablename VARCHAR(1000);
    DECLARE _l_reftable VARCHAR(1000);
    DECLARE _l_xpath VARCHAR(1000);
    DECLARE _inbetween_xpath VARCHAR(1000);
    DECLARE _inbetween_tables VARCHAR(1000);
    DECLARE _inbetween_unions VARCHAR(1000);
    DECLARE _inb_depth INT;
    DECLARE _main_table VARCHAR(1000) DEFAULT (SELECT main_table FROM slng_operations_in_scope WHERE operation = webservice_operation);
    DECLARE _webservice_operation_ref TEXT DEFAULT '';
    DECLARE _webservice_operation_ref_2 TEXT DEFAULT '';

    -- Declare cursors
    DECLARE cur CURSOR FOR 
        SELECT ID, table_name, xpath FROM _targetmodel ORDER BY xpath;

    DECLARE cur_lowesttables CURSOR FOR 
        SELECT DISTINCT a.id, a.table_name, a.referenced_table_name, a.xpath 
        FROM _targetmodel a
        WHERE a.xpath NOT IN (
            SELECT DISTINCT b.referenced_table_xpath 
            FROM _targetmodel b
            WHERE NULLIF(b.referenced_table_xpath, '') IS NOT NULL
        )
        ORDER BY id DESC;

    DECLARE cur_inbetweentables CURSOR FOR 
        SELECT DISTINCT depth, xpath
        FROM _targetmodel_columns
        WHERE depth > (
            SELECT depth 
            FROM _targetmodel_columns
            WHERE source_column_match = key_field
        ) 
        AND xpath IN (
            SELECT referenced_table_xpath 
            FROM _targetmodel_columns
        ) ORDER BY depth DESC;

    -- Handle cursor not found
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Set session variables
    SET SESSION group_concat_max_len = 1000000;

    -- Define reference patterns for web service operations
    SET _webservice_operation_ref = CONCAT('/', _main_table, '%');
    SET _webservice_operation_ref_2 = CONCAT('/wd:', _main_table, '%');

    -- Create index for src_combined_data if it does not exist
    SET @donotcreateindex = (
        SELECT COUNT(*) 
        FROM information_schema.statistics 
        WHERE LOWER(table_name) = 'src_combined_data' 
        AND index_name = 'idx_xpath' 
        AND table_schema = DATABASE()
    );

    SET @sql = IF(@donotcreateindex >= 1 OR (SELECT COUNT(*) FROM information_schema.TABLES WHERE LOWER(table_name) = 'src_combined_data') = 0, 
        'SELECT ''Index Already Exists or Table Does Not Exist''',
        'ALTER TABLE `hellboy`.`src_combined_data`
        CHANGE COLUMN `xpath` `xpath` VARCHAR(500) NULL DEFAULT NULL,
        ADD INDEX `idx_xpath` (`xpath` ASC);'
    );

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    -- Create temporary table _temp_src_dcdd from src_combined_data
    DROP TABLE IF EXISTS _temp_src_dcdd;
    CREATE TABLE _temp_src_dcdd AS
        SELECT src_combined_data.*, 
        SUBSTRING_INDEX(src_combined_data.tmpath, '/', -1) AS SLNG_fieldname
        FROM src_combined_data
        WHERE LOWER(tmpath) LIKE LOWER(_webservice_operation_ref);

    -- Add indexes to _temp_src_dcdd table
    ALTER TABLE `hellboy`.`_temp_src_dcdd` 
    ADD INDEX `idx_xpath` (`xpath`(500) ASC) INVISIBLE,
    ADD INDEX `idx_csv_file_name` (`csv_File_Name`(500) ASC) INVISIBLE,
    ADD INDEX `idx_csv_header` (`csv_Header`(500) ASC) VISIBLE;

    -- Create SQL index for the temporary table
    SET sql_ttable_index = CONCAT(
        'SET @donotcreateindex := (SELECT count(*) FROM information_schema.statistics WHERE table_name = ''temp_', source_table, ''' AND index_name = ''idx_temp_', source_table, '_1'' AND table_schema = database() );',
        'SET @sql := IF(@donotcreateindex >= 1 OR (SELECT COUNT(*) FROM information_schema.TABLES WHERE table_name = ''temp_', source_table, ''') = 0,',
        '''SELECT ''Index Already Exists or Table Does Not Exist''',
        ', ''ALTER TABLE `hellboy`.`temp_', source_table, '`',
        'CHANGE COLUMN `RequestID` `RequestID` VARCHAR(255) NULL DEFAULT NULL,',
        'CHANGE COLUMN `', key_field, '` `', key_field, '` VARCHAR(255) NULL DEFAULT NULL,',
        'ADD INDEX `idx_temp_', source_table, '_1` (`RequestID` ASC),',
        'ADD INDEX `idx_temp_', source_table, '_2` (`', key_field, '` ASC);''',
        ');'
    );

    -- Retrieve and store SQL indexes from meta table
    SET sql_indexes = (SELECT DISTINCT `indexes` FROM src_combined_meta WHERE web_service_operation = webservice_operation);

    -- Create target model hierarchy using a recursive CTE
    DROP TABLE IF EXISTS _targetmodel;
    CREATE TABLE _targetmodel (
        ID INT, 
        TABLE_NAME CHAR(64), 
        REFERENCED_TABLE_NAME CHAR(64), 
        xpath TEXT, 
        referenced_table_xpath TEXT
    );

    INSERT INTO _targetmodel
    WITH RECURSIVE cte (ID, TABLE_NAME, REFERENCED_TABLE_NAME, xpath, referenced_table_xpath) AS (
        SELECT
            1 AS ID,
            TABLE_NAME, 
            REFERENCED_TABLE_NAME,
            CAST(CONCAT('/wd:', TABLE_NAME, '/') AS CHAR(10000)) AS xpath,
            ''
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = 'hellboy'
        AND TABLE_NAME = _main_table
        AND REFERENCED_TABLE_NAME IS NULL
        UNION ALL
        SELECT
            cte.ID + 1,
            KCU.TABLE_NAME, 
            KCU.REFERENCED_TABLE_NAME,
            CAST(CONCAT(cte.xpath, 'wd:', KCU.TABLE_NAME, '/') AS CHAR(10000)) AS xpath,
            ''
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE KCU
        INNER JOIN cte ON KCU.REFERENCED_TABLE_NAME = cte.TABLE_NAME
    )
    SELECT *
    FROM cte;

    -- Update referenced table xpath in _targetmodel
    UPDATE _targetmodel
    SET referenced_table_xpath = CASE 
        WHEN REGEXP_REPLACE(xpath, '/[^/]+/$', '/') = '/' THEN ''
        ELSE REGEXP_REPLACE(xpath, '/[^/]+/$', '/') 
    END;

    -- Add columns to target model hierarchy
    DROP TABLE IF EXISTS _targetmodel_columns;
    CREATE TABLE _targetmodel_columns (
        RequestID INT AUTO_INCREMENT PRIMARY KEY,
        depth INT,
        table_name VARCHAR(100),
        referenced_table_name VARCHAR(100),
        xpath VARCHAR(1000),
        referenced_table_xpath VARCHAR(1000),
        column_name VARCHAR(100),
        ordinal_position INT, 
        source_column_match TEXT,
        formatted_column TEXT,
        csv_file_name VARCHAR(500),
        source_field_name VARCHAR(500),
        required_optional VARCHAR(25)
    );

    INSERT INTO _targetmodel_columns (depth, table_name, referenced_table_name, xpath, referenced_table_xpath, column_name, ordinal_position)
    SELECT t.ID, t.table_name, t.referenced_table_name, t.xpath, 
        CASE 
            WHEN REGEXP_REPLACE(t.xpath, '/[^/]+/$', '/') = '/' THEN '' 
            ELSE REGEXP_REPLACE(t.xpath, '/[^/]+/$', '/') 
        END, 
        i.column_name, i.ordinal_position 
    FROM _targetmodel t
    JOIN information_schema.columns i ON i.table_schema = 'hellboy' 
        AND i.table_name = t.table_name 
        AND column_name <> CASE 
            WHEN ID > 1 THEN 'SLNG_ID' 
            ELSE '' 
        END
    ORDER BY t.xpath, i.ordinal_position;

    -- Update source and target column matches
    UPDATE _targetmodel_columns a, _temp_src_dcdd b
    SET a.formatted_column = b.select, 
        a.source_column_match =  b.csv_header,
        a.required_optional = b.required_optional
    WHERE CONCAT(REPLACE(a.xpath, 'wd:', ''), a.column_name) = b.tmpath
        AND a.column_name = b.slng_fieldname;

    -- Set default values for AutoComplete and RunNow columns
    UPDATE _targetmodel_columns
    SET source_column_match = '''1'''
    WHERE NULLIF(source_column_match, '') IS NULL
        AND column_name = 'AutoComplete';

    UPDATE _targetmodel_columns
    SET source_column_match = '''1'''
    WHERE NULLIF(source_column_match, '') IS NULL
        AND column_name = 'RunNow';

    -- Set RequestID as source column match for primary table SLNG_ID
    UPDATE _targetmodel_columns
    SET source_column_match = 'RequestID'
    WHERE depth = 1 
        AND column_name = 'SLNG_ID';

    -- Set version number based on global config
    UPDATE _targetmodel_columns
    SET source_column_match = CONCAT('(SELECT wsdlVersion FROM slng_global_config LIMIT 1) AS version')
    WHERE depth = 1
        AND column_name = 'version';

    -- Set foreign key inserts for child tables
    UPDATE _targetmodel_columns
    SET source_column_match = CONCAT(referenced_table_name, '.SLNG_ID')
    WHERE depth > 1 
        AND column_name LIKE '%_SLNG_ID'
        AND REPLACE(column_name, '_SLNG_ID', '') = referenced_table_name;

    -- Update csv_file_name for target model columns
    UPDATE _targetmodel_columns
    SET csv_file_name = (
        SELECT DISTINCT REPLACE(LOWER(a.csv_file_name), '_dcdd', '')
        FROM _temp_src_dcdd a
        WHERE LOWER(a.tmpath) LIKE LOWER(_webservice_operation_ref)
            AND LOWER(xpath) LIKE LOWER(_webservice_operation_ref_2)
            AND LOWER(a.tmpath) = LOWER(CONCAT(REPLACE(xpath, 'wd:', ''), column_name))
            AND LOWER(a.csv_file_name) <> 'all csvs'
    );

    -- Select the csv_file_name with the most usage for a target table
    UPDATE _targetmodel_columns
    SET csv_file_name = (
        SELECT csv_file_name 
        FROM (
            SELECT a.csv_file_name
            FROM _targetmodel_columns a
            WHERE a.xpath = xpath
                AND NULLIF(a.csv_file_name, '') IS NOT NULL
            GROUP BY a.csv_file_name 
            ORDER BY COUNT(*) DESC 
            LIMIT 1
        ) AS subquery
    );

    -- Extract the parent key for joining, supporting only 2 levels (Parent-Child) 
    SET @key_string = (SELECT DISTINCT csv_header FROM _temp_src_dcdd WHERE csv_file_name = 'All CSVs');

    -- Create the beginning SQL script for the stored procedure
    SET @sp_name = CONCAT('sp_', TRIM(webservice_operation));

    -- ##### SQL script for creating the procedure #####
    SET sql_begin = CONCAT(
        'USE hellboy;\n',
        'DROP PROCEDURE IF EXISTS `', @sp_name, '`;\n',
        'DELIMITER $$\n',
        'CREATE PROCEDURE `', @sp_name, '`()\n',
        'BEGIN\n\n'
    );

    -- Create staging table from source table
    SET @_source = CONCAT('temp_', source_table);

    IF LEFT(LOWER(source_table), 4) = 'src_' THEN
        SET @_source_table = SUBSTRING(source_table, 5);
    ELSE
        SET @_source_table = source_table;
    END IF;

    SET @_columns = (
        SELECT GROUP_CONCAT(DISTINCT CONCAT('NULLIF(`', csv_header, '`, '''') AS `', csv_header, '`') SEPARATOR ',\n')
        FROM _temp_src_dcdd
        WHERE NULLIF(csv_header, '') IS NOT NULL
            AND LOWER(csv_file_name) IN (
                'all csvs',
                LOWER(@_source_table),
                '',
                CONCAT(LOWER(@_source_table), '_dcdd'),
                CONCAT(LOWER(@_source_table), '.csv')
            )
    );

    -- ##### SQL script for creating the staging table #####
    SET sql_stage = CONCAT(
        'DROP TABLE IF EXISTS ', @_source, ';\n',
        'CREATE TABLE ', @_source, '\n',
        'SELECT\n',
        'DENSE_RANK() OVER (ORDER BY ', key_field, ') AS RequestID,\n',
        @_columns, '\n',
        'FROM ', source_table, ';\n\n'
    );

    -- ##### SQL script for deleting from the main table #####
    SET sql_delete = CONCAT(
        'DELETE FROM ', _main_table, ';\n',
        'ALTER TABLE ', _main_table, ' AUTO_INCREMENT = 1;\n\n'
    );

    -- Assign the depth of the nullif column to determine where to begin coalesce
    SET @_nullifdepth = (
        SELECT depth 
        FROM _targetmodel_columns
        WHERE source_column_match = key_field 
    );

    -- Create insert statements from the staging table into the target model tables
    OPEN cur;
    SET done = FALSE;

    -- Process each row in the cursor
    block1: LOOP
        FETCH cur INTO _depth, _table, _xpath;
        IF done THEN
            LEAVE block1;
        END IF;

        SET @indent = REPEAT('\t', _depth - 1);

        -- Columns to insert
        SET @columns_insert = (
            SELECT GROUP_CONCAT(CONCAT(@indent, '`', column_name, '`') ORDER BY ordinal_position SEPARATOR ',\n')
            FROM _targetmodel_columns 
            WHERE xpath = _xpath
        );

        -- Columns to select
        SET @columns_select = (
            SELECT GROUP_CONCAT(CONCAT(@indent, ',', CASE 
                WHEN NULLIF(formatted_column, '') IS NOT NULL THEN formatted_column 
                ELSE 
                    CASE 
                        WHEN NULLIF(source_column_match, '') IS NOT NULL THEN source_column_match
                        ELSE 'NULL' 
                    END 
                END, ' -- ', column_name, '\n') ORDER BY ordinal_position SEPARATOR '')
            FROM _targetmodel_columns 
            WHERE xpath = _xpath
        );

        -- Remove the first comma
        SET @columns_select = INSERT(@columns_select, 1, INSTR(@columns_select, ','), @indent); 

        -- Determine the source select statement
        SET @source_select = (
            SELECT DISTINCT csv_file_name
            FROM _targetmodel_columns
            WHERE xpath = _xpath
        );

        -- Concatenate the joins for the CSV tables
        IF NULLIF(@source_select, '') IS NULL OR @source_select = 'All CSVs' OR @source_select = ' ' THEN 
            SET @source_select = CONCAT(@_source, ' t');
        ELSEIF LOWER(CONCAT('src_', @source_select)) = LOWER(source_table) THEN
            SET @source_select = CONCAT(@_source, ' t');
        ELSE
            SET @source_select = CONCAT(@_source, ' t\n', @indent, 'JOIN src_', @source_select, ' ON src_', @source_select, '.', @key_string, ' = t.', @key_string);
        END IF;

        -- Combine the insert statement
        SET sql_inserts = CONCAT_WS('', sql_inserts, @indent, 'INSERT INTO ', _table, '(\n', @columns_insert, '\n', @indent, ')\n', @indent, 'SELECT DISTINCT\n', @columns_select, @indent, 'FROM ', @source_select);

        -- Create SQL join statements for deeper levels
        IF _depth > 1 THEN
            DROP TABLE IF EXISTS stage_sql_joins;
            CREATE TABLE stage_sql_joins
            WITH RECURSIVE cte AS (
                SELECT ID, table_name, referenced_table_name, xpath
                FROM _targetmodel
                WHERE xpath = REPLACE(_xpath, CONCAT('/wd:', _table, '/'), '/') 
                UNION ALL
                SELECT t.ID, t.table_name, t.referenced_table_name, t.xpath
                FROM _targetmodel t
                JOIN cte ON t.xpath = REPLACE(cte.xpath, CONCAT('/wd:', cte.table_name, '/'), '/')
            ),
            cte2 AS (
                SELECT *, CASE 
                    WHEN ID = 1 THEN CONCAT(@indent, 'JOIN ', table_name, ' ON ', table_name, '.SLNG_ID = RequestID')
                    ELSE CONCAT(@indent, 'JOIN ', table_name, ' ON ', table_name, '.', referenced_table_name, '_SLNG_ID = ', referenced_table_name, '.SLNG_ID')
                END AS _sql_join
                FROM cte
            )
            SELECT * 
            FROM cte2;

            SET @sql_joins = (
                SELECT GROUP_CONCAT(_sql_join ORDER BY ID SEPARATOR '\n') 
                FROM stage_sql_joins
            );

            SET sql_inserts = CONCAT_WS('', sql_inserts, '\n', @sql_joins);
        END IF;  -- Close _depth > 1

        -- Finalize the insert statement
        SET sql_inserts = CONCAT_WS('', sql_inserts, ';\n\n');
    END LOOP block1;

    CLOSE cur;

    -- Process lowest level tables for cleanup
    OPEN cur_lowesttables;
    SET done = FALSE;

    block2: LOOP
        FETCH cur_lowesttables INTO _l_id, _l_tablename, _l_reftable, _l_xpath;
        IF done THEN
            LEAVE block2;
        END IF;

        -- Generate column names for cleanup
        SET @_l_columns = (
            SELECT GROUP_CONCAT(DISTINCT CONCAT(
                CASE 
                    WHEN NULLIF(column_name, '') IS NOT NULL THEN CONCAT_WS('', 'NULLIF(`', column_name, '`, '''')\n', @indent, ' ,') 
                END) ORDER BY ordinal_position SEPARATOR '')
            FROM _targetmodel_columns 
            WHERE xpath = _l_xpath
                AND LOWER(column_name) NOT LIKE '%_type'
                AND LOWER(column_name) NOT LIKE '%slng_id%'
        );

        -- Create the cleanup script for the table
        SET @_l_cleanup = (
            SELECT DISTINCT CONCAT('DELETE FROM ', _l_tablename, '\n',
                @indent, 'WHERE `SLNG_ID` IS NOT NULL AND `', _l_reftable, '_SLNG_ID` IS NOT NULL \n',
                @indent, 'AND COALESCE(', @_l_columns)
        );

        SET @_l_cleanup = LEFT(@_l_cleanup, LENGTH(@_l_cleanup) - 1);                

        -- Add the cleanup script if it exists
        IF NULLIF(@_l_cleanup, '') IS NOT NULL THEN
            SET sql_cleanup = CONCAT_WS('', sql_cleanup, '\n', @indent, @_l_cleanup, ') IS NULL; \n');
        END IF;

        SET @_l_dup = _l_tablename;
    END LOOP block2;

    CLOSE cur_lowesttables;

    -- Process in-between tables for cleanup
    OPEN cur_inbetweentables;
    SET done = FALSE;

    block3: LOOP
        FETCH cur_inbetweentables INTO _inb_depth, _inbetween_xpath;
        IF done THEN
            LEAVE block3;
        END IF;

        -- Generate table names for cleanup
        SET _inbetween_tables = (
            SELECT DISTINCT table_name 
            FROM _targetmodel_columns 
            WHERE xpath = _inbetween_xpath
        );

        SET @reftablename = (
            SELECT DISTINCT referenced_table_name 
            FROM _targetmodel_columns 
            WHERE xpath = _inbetween_xpath
        );

        -- Create the first part of the cleanup script
        SET @string_1 = (
            SELECT DISTINCT CONCAT_WS('', @indent, 'DELETE FROM ', _inbetween_tables, '\n', @indent, ' WHERE `SLNG_ID` IS NOT NULL \n', @indent, ' AND `', @reftablename, '_SLNG_ID` IS NOT NULL\n')
        );

        -- Create the second part of the cleanup script
        SET @string_2 = CONCAT(@indent, ' AND COALESCE(\n', (
            SELECT GROUP_CONCAT(
                DISTINCT CONCAT('', @indent, '  NULLIF(`', column_name, '`, '''')') SEPARATOR ',\n') 
            FROM _targetmodel_columns 
            WHERE table_name = _inbetween_tables
                AND LOWER(column_name) NOT LIKE '%type'
                AND LOWER(column_name) NOT LIKE '%slng_id%'
        ), ') IS NULL\n');

        -- Combine the cleanup strings
        SET sql_combine_strings = CONCAT_WS('', '\n', @string_1, @string_2);

        -- Create the union select statements
        SET sql_union = (
            SELECT GROUP_CONCAT(
                DISTINCT CONCAT(@indent, '  SELECT `', _inbetween_tables, '_SLNG_ID` FROM ', table_name) 
                SEPARATOR ' UNION\n') 
            FROM _targetmodel_columns 
            WHERE referenced_table_name = _inbetween_tables
        );

        -- Combine the cleanup script for in-between tables
        SET sql_cleanup_2 = CONCAT_WS('', sql_cleanup_2, sql_combine_strings, @indent, ' AND `SLNG_ID` NOT IN (\n', sql_union, ');');
    END LOOP block3;

    CLOSE cur_inbetweentables;

    -- Combine all SQL parts into the final stored procedure script
    SET sql_sp = CONCAT_WS('',
        sql_begin,        -- Begin string
        sql_stage,        -- Create staging table with requestid as first field
        sql_ttable_index, -- Create index for the main temp table
        sql_indexes,      -- Add indexes
        sql_delete,       -- Create top request table with auto_increment
        sql_inserts,      -- All inserts into target model tables
        sql_cleanup_text, -- Text string to indicate where lowest tables cleanup starts
        sql_cleanup,      -- All delete to remove children with no data
        sql_cleanup_text_2, -- Text string to indicate where all parent tables cleanup starts
        sql_cleanup_2,    -- All delete to remove parents of children that have no data
        sql_end           -- End string
    );

    -- Output the final stored procedure script
    SELECT sql_sp;

END$$

DELIMITER ;

-- Sample calls
-- call sp_skeletor('manage_lesson', 'src_manage_lesson', 'Learning_Lesson_Data_ID');
CALL sp_skeletor('submit_supplier', 'src_submit_supplier', 'Supplier_ID');    