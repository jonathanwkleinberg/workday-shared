import os
import csv
from io import StringIO
import requests
import argparse
import shutil
import pandas as pd
from requests.auth import HTTPBasicAuth
from multiprocessing import Pool

# Define the list of data centers
DATA_CENTERS = {
    'Atlanta': 'wd2-impl-services1.workday.com',
    'Portland': 'wd5-impl-services1.workday.com',
    'Dublin': 'wd3-impl-services1.workday.com',
    'Canada AWS': 'impl-enterprise-services1.wd10.myworkday.com',
    'US AWS': 'impl-enterprise-services1.wd12.myworkday.com',
    'AWS 102': 'impl-services1.wd102.myworkday.com',
    'AWS 103': 'impl-services1.wd103.myworkday.com',
    'AWS GOV 104': 'impl-enterprise-services1.wd104.myworkdaygov.com',
    'AWS GOV 105': 'impl-enterprise-services1.wd105.myworkday.com',
    'AWS 501': 'impl-enterprise-services1.wd501.myworkday.com'
}


def clear_directory(path):
    # Get the directory of the current script and Join the script directory with the path
    script_dir = os.path.dirname(os.path.realpath(__file__))
    full_path = os.path.join(script_dir, path)
    
    # Check if the directory exists
    if os.path.exists(full_path) and os.path.isdir(full_path):
        # Remove the directory and all its contents
        shutil.rmtree(full_path)
        
    # Recreate the directory
    os.makedirs(full_path)


def clean_data(data):
    # Create a new CSV reader that reads from a string (the input data)
    reader = csv.reader(StringIO(data))
    
    # We'll write the cleaned data into this list
    cleaned_data = []
    
    for row in reader:
        # Replace line breaks within a field with semicolons and keep the field inside of quotes
        cleaned_row = ','.join(f'"{";".join(field.splitlines())}"' for field in row)
        cleaned_data.append(cleaned_row)
    
    # Join the rows with line breaks
    return '\n'.join(cleaned_data)


def remove_duplicates(csv_file_path):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file_path)
    
    # Drop duplicates
    df.drop_duplicates(inplace=True)
    
    # Write the DataFrame back to the CSV file
    df.to_csv(csv_file_path, index=False)


def url_response(data):
    path, url, u, p = data
    print(f"Downloading... {path}")
    try:
        r = requests.get(url, auth=HTTPBasicAuth(u, p))
        r.raise_for_status()  # Raises stored HTTPError, if one occurred.
        
        # Decode the content of the response before writing it to a file
        content = r.content.decode('utf-8')

        # Clean the data before writing it to a file
        cleaned_content = clean_data(content)

        # Get the directory of the current script
        script_dir = os.path.dirname(os.path.realpath(__file__))

        # Join the script directory with the path
        full_path = os.path.join(script_dir, path)
        
        # Create the directory if it doesn't exist
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(cleaned_content)

        # Remove duplicates from the CSV file after it's produced
        remove_duplicates(full_path)
    except Exception as e:
        print(f"Error downloading {path}. Error: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--report_name', default='Web_Service_Operations_Details, Web_Service_Details_2')
    parser.add_argument('--username', default='jkleinberg-impl')
    parser.add_argument('--password', default='Welcome123!')
    parser.add_argument('--data_center', default='Atlanta')
    parser.add_argument('--tenant_name', default='wdprofservices_ldp1')

    args = parser.parse_args()
    
    # Collecting the necessary user inputs
    base_url = DATA_CENTERS.get(args.data_center)
    
    u = args.username
    p = args.password
    tenant = args.tenant_name

    # Clear the 'download' directory before running the script
    clear_directory('download')
    
    # Split report names into a list and generate URLs for each report
    report_names = [name.strip() for name in args.report_name.split(',')]
    urls = [(f"download/{report_name}.csv", f"https://{base_url}/ccx/service/customreport2/{tenant}/{u}/{report_name}?format=csv", u, p) for report_name in report_names]
    
    print("Start")

    # Pool allows parallel downloading
    pool = Pool(processes=3)
    pool.map(url_response, urls)
    pool.close()
    pool.join()

    print("Finished")