import pathlib
import json
import csv
import shutil
import time
from threading import Thread, Lock, Semaphore

# Global variables for counting and timing
total_csv_files_written = 0
csv_file_count_lock = Lock()

def shorten_filename(filename):
  # Define replacements as a list of tuples
  replacements = [
    ("Reference", "Ref"), ("Supplier", "SUPP"), ("Payment", "Pay"),
    ("Payroll","PAY"), ("Deduction","DED"),
    ("Account", "Acct"), ("Customer", "Cust"), ("Employee", "Emp"),
    ("Enrollment", "Enroll"), ("Election", "Elect"), ("Professional", "Prof"),
    ("Allocation", "Alloc"), ("Organization", "Org"),
    ("Collective", "Coll"), ("Agreement", "Agree"), ("Schedule", "Sched"),
    ("Government", "Gov"), ("Information", "Info"), ("Assignment", "Assign"),
    ("Assignments", "Assign"), ("Requisition", "REQ"), ("Learning", "LRN"),
    ("Accounting", "Acctng"), ("Amendment", "Amndmnt"), ("Transactions", "Trnxs"),
    ("Student", "STU"), ("Employment", "Empl"), ("Eligibility","Eligib"),
    ("Probation", "Probtn"), ("Membership","Membrshp"),("Settlement","Stlmt"),
  ]

  # Break out the individual files separated by commas and process them
  parts = filename.split(',')
  shortened_parts = []
  for part in parts:
    part = part.strip()  # Remove leading or trailing whitespaces
    loop_counter = 0

    # Remove "_DCDD" if within the specific length range
    if 31 < len(part) < 37 and part.endswith("_DCDD"):
      part = part[:-5]

    # Shorten using replacements if length is still too long
    if len(part) >= 37:
      for long_word, short_word in replacements:
        part = part.replace(long_word, short_word)
    
    # Further abbreviation if still too long
    while len(part) > 31 and loop_counter <= 5:
      words = part.split('_')
      if len(words) > 1:
        # Start abbreviating from the end
        for i in range(-2, -len(words) - 1, -1):
          words[i] = words[i][0]
        part = '_'.join(words)
      else:
        part = part[:31]  # Fallback to hard cutoff if no underscores
      loop_counter += 1
    
    shortened_parts.append(part)
  
  return ','.join(shortened_parts)


def clean_line_breaks(data):
    for row in data['rows']:
        for i, value in enumerate(row):
            if isinstance(value, str):  # Only perform replace operation on string values
                row[i] = value.replace('\n', ' ').replace('\r', ' ')  # Replace newline and carriage return with space
    return data


def get_select_mapping(index, json_data):
  REQUIRED_COL = 'Required/Optional'
  HEADER_COL = 'csv Header'
  HEADER_IDX = json_data['columns'].index(HEADER_COL)
  TYPE_COL = 'Type Value'
  FILENAME_COL = 'csv File Name'
  MAIN_FILENAME = json_data['name']
    
  field = dict(zip(json_data['columns'], json_data['rows'][index]))
  prev_field = dict(zip(json_data['columns'], json_data['rows'][index-1])) if index > 0 else {}
  
  header_col = field.get(HEADER_COL, '')
  header_col_lower = header_col.lower()
  found_lookup = None
  filename_col = (field.get(FILENAME_COL, '') or '').lower()
  MAIN_FILENAME = 'src_' + MAIN_FILENAME[:-5].lower()

  if filename_col:
    if ',' in filename_col:
        # Split the string by the comma and take the first table
        filename_col = 'src_'+filename_col.split(',')[0].strip()  
    else:    
        filename_col = 'src_'+filename_col
  else:
    filename_col = MAIN_FILENAME

  if filename_col:
    # Check if the value ends with '_DCDD'
    if filename_col.endswith('_dcdd'):
        # Remove '_DCDD' and add '.'
        filename_col = filename_col[:-5] + '.'
    # Check if the value ends with '.csv'
    elif filename_col.endswith('.csv'):
        # Remove 'csv'
        filename_col = filename_col[:-3]
    else:
        # Add '.' at the end
        filename_col += '.'

  # If filename_col is the same as the DCDD name then this is the main file and should start with t.
  if filename_col == MAIN_FILENAME+'.' or filename_col == 'src_all csvs':
        filename_col = 't.'  

  #print('>> '+filename_col+'\n')

  # need a fully encompassing IF statement so that fields that does not fall into the categories outlined below should simply append the current csv filename as opposed to ''
  # required column is reference or header column ref id (variations)
  # Search through DCDD Lookup Dictionary 
  if header_col and (((field.get(REQUIRED_COL, '') or '').lower() != 'reference') or not any(a in header_col_lower for a in ['reference_id_type', 'ref_id_type', 'refid_type', 'reference_id_parent_type', 'ref_id_parent_type'])):
    found_lookup = F"{filename_col}`{header_col}`"
    if header_col and ((field.get(FILENAME_COL, '') or '') and (field.get(FILENAME_COL, '') or '').lower() == 'all csvs'):
      found_lookup = F"t.`{header_col}`"

  if header_col and (((field[REQUIRED_COL] or '').lower() == 'reference') or any(a in header_col_lower for a in ['reference_id_type','ref_id_type','refid_type', 'reference_id_parent_type','ref_id_parent_type'])):  
    # REFERENCE, CURRENCY
    if all(y.lower() in header_col_lower for y in ['Currency', 'Ref', 'Type']) and all(z.lower() not in header_col_lower for z in ['Currency_Rate_Type_Reference_ID_Type']):
        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN {filename_col}`{prev_field.get(HEADER_COL, '')}` REGEXP '^[0-9]+$' THEN 'Currency_Numeric_Code' ELSE 'Currency_ID' END ELSE NULL END"""
    # REFERENCE, CURRENCY_RATE_TYPE
    elif all(y.lower() in header_col_lower for y in ['Currency_Rate_Type_Reference_ID_Type']):
        found_lookup = F"""{filename_col}`{prev_field.get(HEADER_COL, '')}`"""
    # REFERENCE, COUNTRY
    elif all(y.lower() in header_col_lower for y in ['Country', 'Ref', 'Type']) and all(z.lower() not in header_col_lower for z in ['Region','City','Code']):
        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL AND NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN {filename_col}`{prev_field.get(HEADER_COL, '')}` REGEXP '^[0-9]+$' THEN 'ISO_3166-1_Numeric-3_Code' WHEN length({filename_col}`{prev_field.get(HEADER_COL, '')}`) > 2 THEN 'ISO_3166-1_Alpha-3_Code' ELSE 'ISO_3166-1_Alpha-2_Code' END ELSE {filename_col}`{header_col}` END"""
    # REFERENCE, REGION
    elif all(y.lower() in header_col_lower for y in ['Country', 'Region', 'Ref', 'Type']):
        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL AND NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN length({filename_col}`{prev_field.get(HEADER_COL, '')}`) > 2 THEN 'Country_Region_ID' ELSE 'ISO_3166-2_Code' END ELSE {filename_col}`{header_col}` END"""
    # REFERENCE, CTRYCITYPAR
    elif all(y.lower() in header_col_lower for y in ['Country', 'City', 'Ref', 'Type', 'parent']) and all(z.lower() not in header_col_lower for z in ['Region']):
        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL AND NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN {filename_col}`{prev_field.get(HEADER_COL, '')}` REGEXP '^[0-9]+$' THEN 'ISO_3166-1_Numeric-3_Code' WHEN length({filename_col}`{prev_field.get(HEADER_COL, '')}`) > 2 THEN 'ISO_3166-1_Alpha-3_Code' ELSE 'ISO_3166-1_Alpha-2_Code' END ELSE {filename_col}`{header_col}` END"""

    # Check for default Type Value
    if not found_lookup and field[TYPE_COL]:
      types = [type.strip() for type in field[TYPE_COL].split(',')]
      if ',' not in field[TYPE_COL]: # Single value
          if field[TYPE_COL].lower() == 'text':
           found_lookup = F"'{field[TYPE_COL]}'"
          else:
           found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL THEN '{types[0]}' ELSE {filename_col}`{header_col}` END END"""
      else: # Have multiple types
        
        if 'Employee_ID' in types:
            found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL THEN 'Employee_ID' ELSE {filename_col}`{header_col}` END END"""
        elif 'Position_ID' in types:
            found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}{header_col},'') IS NULL THEN 'Position_ID' ELSE {filename_col}{header_col} END END"""
        elif 'Organization_Reference_ID' in types:
            found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}{header_col},'') IS NULL THEN 'Organization_Reference_ID' ELSE {filename_col}{header_col} END END"""
        elif 'Customer_Reference_ID' in types:
            found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}{header_col},'') IS NULL THEN 'Customer_Reference_ID' ELSE {filename_col}{header_col} END END"""
        elif 'Supplier_Reference_ID' in types:
            found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}{header_col},'') IS NULL THEN 'Supplier_Reference_ID' ELSE {filename_col}{header_col} END END"""
        else:
            # If neither are present, use the first type as the default
            found_lookup = F"""CASE WHEN NULLIF({filename_col}`{prev_field.get(HEADER_COL, '')}`,'') IS NOT NULL THEN CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL THEN '{types[0]}' ELSE {filename_col}`{header_col}` END END"""
  

    elif field[TYPE_COL] and field[TYPE_COL].lower() == 'boolean':
        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NOT NULL THEN CASE WHEN LEFT(UPPER(IFNULL({filename_col}`{header_col}`,'')),1) IN ('Y','T','1') THEN '1' WHEN LEFT(UPPER(IFNULL({filename_col}`{header_col}`,'')),1) IN ('N','F','0') THEN '0' ELSE {filename_col}`{header_col}` END ELSE '' END"""

    elif header_col and all(a in header_col_lower for a in ['effective','date']) and not any(ex in h.lower() for ex in ['worker','employee','contingent','person','position'] for h in [r[HEADER_IDX].strip().replace(' ','_') for r in json_data['rows'] if r[HEADER_IDX]] ):
        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL THEN '1900-01-01' ELSE {filename_col}`{header_col}` END"""

  header = (field.get(HEADER_COL, '') or '').lower().strip().replace(' ', '_')
  if all(a in header for a in ['usage', 'type', 'ref', 'id']) and not any(ex in header for ex in ['worker', 'employee', 'contingent', 'person', 'position', 'role', 'use_for']) and header.endswith('type') and header.count('address') == 1:
      found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL THEN 'Communication_Usage_Type_ID' ELSE {filename_col}`{header_col}` END"""

#    header = (field.get(HEADER_COL, '') or '').lower().strip().replace(' ', '_')
#     elif all(a in header for a in ['usage', 'type', 'ref', 'id']) and not any(ex in header for ex in ['worker', 'employee', 'contingent', 'person', 'position', 'role', 'use_for']) and header.endswith('type') and header.count('address') == 1:
#        found_lookup = F"""CASE WHEN NULLIF({filename_col}`{header_col}`,'') IS NULL THEN 'Communication_Usage_Type_ID' ELSE {filename_col}`{header_col}` END"""
#     else:
#    found_lookup = F"{filename_col}`{header_col}`"

  return found_lookup





def get_indexes(data, all_tables):
  indexes = ''
  HEADER_IDX = data.get("columns", []).index('csv Header')
  REQUIRED_IDX = data.get("columns", []).index('Required/Optional')
  CSV_FILE_NAME_IDX = data.get("columns", []).index('csv File Name')
  rows = data.get("rows", [])
  
  for table_name in all_tables:
    if all_tables:
      keys = [r[HEADER_IDX] for r in rows if r[HEADER_IDX] and r[HEADER_IDX][-5:].lower() != '_type' and any('all csv' in x or x == table_name for x in [f.strip().lower() for f in (r[CSV_FILE_NAME_IDX] or '').split(',')])] # ALL CSVs
    else:
      keys = [ next((r[HEADER_IDX] for r in rows if r[HEADER_IDX] and r[REQUIRED_IDX] in ['Required', 'Design Requirement']), None) ] # First Required or Optional Field
      keys = [k for k in keys if k is not None]

    indexes += F"""SET @donotcreateindex := (SELECT count(*) FROM information_schema.statistics WHERE table_name = '{table_name}' AND index_name = 'idx_{table_name}_1' AND table_schema = database() );
  SET @sql := if(@donotcreateindex >= 1 OR (SELECT count(*) FROM information_schema.TABLES WHERE table_name = '{table_name}') = 0, 
    'SELECT ''Index Already Exists or Table Does Not Exist''',
    'ALTER TABLE `hellboy`.`{table_name}`"""
    for key in keys:
      indexes += F"""\n    CHANGE COLUMN `{key}` `{key}` VARCHAR({'155' if 'date' in key.lower() else '255'}) NULL DEFAULT NULL,"""
    index_lines = []
    for i, key in enumerate(keys, 1): 
      index_lines.append(F"""\n    ADD INDEX `idx_{table_name}_{i}` (`{key}` ASC),""")
    if index_lines: index_lines[-1] = index_lines[-1][:-1] # Remove last comma
    indexes += ' '.join(index_lines)
    indexes += F""";'
    );
  PREPARE stmt FROM @sql; EXECUTE stmt;"""
  return indexes

def process_json_file(file_path, csv_dir):
  with open(file_path, 'r') as f:
    data = json.load(f)
  data = clean_line_breaks(data)
  original_columns = data.get("columns", [])
  rows = data.get("rows", [])
  metadata = data.get("metadata", {})
  
  # Get default CSV file name from metadata FULL NAME or use filename
  default_csv_name = (metadata.get('FULL NAME') or 'Unnamed_Dataset').replace(" ", "_")
  # if default_csv_name.endswith('_DCDD'):
  #   default_csv_name = default_csv_name[:-5]
  # default_csv_name += "_DCDD.csv"
  default_csv_name += ".csv"

  columns = ['DCDD_Name'] + original_columns + ['TM_Table', 'SLNG_Table', 'Key', 'Select', 'Workbook_Mapping']
  
  # Dictionary to hold CSV data by filename
  csv_data = {
    default_csv_name: {
      'headers': columns,
      'rows': []
    }
  }

  CSV_FILE_NAME_IDX = original_columns.index('csv File Name')
  all_tables = sorted(set(F"src_{y.strip().lower().replace('.csv','').replace('src_','').replace('_dcdd','')}" for r in rows if r[CSV_FILE_NAME_IDX] for y in r[CSV_FILE_NAME_IDX].split(',') if y.strip() != 'All CSVs'))
  
  first_occurrence = False
  for i, row in enumerate(rows):
    row_dict = dict(zip(original_columns, row))

    if row_dict['csv File Name']:
      csv_file_name = row_dict.get('csv File Name', default_csv_name).replace('.csv','')
      if row_dict['csv File Name'] == 'All CSVs' or len(row_dict['csv File Name']) < 32:
        workbook_mapping = csv_file_name
      else:
        workbook_mapping = shorten_filename(csv_file_name)
    elif not row_dict['csv File Name'] and not row_dict['csv Header']:
      workbook_mapping = ""
    else:
      workbook_mapping = default_csv_name.replace('.csv','')

    select_mapping = get_select_mapping(i, data) or F"""`{row_dict['csv Header']}`""" if row_dict['csv Header'] else None

    tmtable = pathlib.PurePosixPath(row_dict['TMPATH']).parent.name if row_dict['TMPATH'] else None
        
    if 'csv File Name' in row_dict and not row_dict['csv File Name'] and row_dict['csv Header']:
      if row_dict['csv File Name'] and row_dict['csv File Name'].lower().endswith('.csv'):
        row_dict['csv File Name'] = row_dict['csv File Name'][:-4]
      if not first_occurrence and row_dict['Type Value'] and row_dict['Type Value'] not in ["Reference", "Do Not Populate", "Constant"] and row_dict['Required/Optional'] in ['Required', 'Design Requirement']:
        row_dict['csv File Name'] = 'All CSVs'
        workbook_mapping = 'All CSVs'
        first_occurrence = True
      elif not row_dict['csv File Name']:
        # row_dict['csv File Name'] = default_csv_name.replace('.csv','').replace('_DCDD','')
        row_dict['csv Header'] = ''
        workbook_mapping = default_csv_name.replace('.csv','')

    key = 'PRIMARY' if row_dict['csv File Name'] == 'All CSVs' else 'SECONDARY' if row_dict['csv File Name'] and ',' in row_dict['csv File Name'] else None
    
    if row_dict['csv Header']:
      if not row_dict['csv File Name']:
        slngtable = F"src_{default_csv_name.lower().replace('.csv','').replace('_dcdd','')}"  
      elif row_dict['csv File Name'] == 'All CSVs':
        slngtable = ', '.join(all_tables) 
      else:
        slngtable = F"src_{row_dict['csv File Name'].lower().replace('.csv','').replace('_dcdd','')}"  
    else: slngtable = None

    ordered_row = [default_csv_name[:-4]] + [row_dict[h] for h in original_columns] + [tmtable, slngtable, key, select_mapping, workbook_mapping]
    csv_data[default_csv_name]['rows'].append(ordered_row)

  # Write data to files
  for csv_file_name, data_value in csv_data.items():
    csv_file_path = csv_dir / csv_file_name
    write_csv(data_value['headers'], data_value['rows'], csv_file_path)
  
  impl_component = impl_components_dict.get(metadata.get("WEB SERVICE OPERATION")) or (None, None)
  if not impl_components_dict.get(metadata.get("WEB SERVICE OPERATION")):
    print(F'No WSOD match found for {metadata.get("WEB SERVICE OPERATION")}')
  metadata['Impl_Component'] = impl_component[0]
  metadata['Impl_Types'] = impl_component[1]

  indexes = get_indexes(data, all_tables)
  metadata['Indexes'] = indexes

  # After processing rows for the main CSV, process metadata
  base_name = default_csv_name.rsplit('.', 1)[0]
  metadata_csv_file_path = csv_dir / F"{base_name}_META.csv"
  write_metadata_to_csv(metadata, metadata_csv_file_path)


def write_csv(headers, rows, csv_file_path):
  csv_file_path.parent.mkdir(parents=True, exist_ok=True)
  with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(headers)
    for row in rows:
        writer.writerow(row)
  with csv_file_count_lock:
    global total_csv_files_written
    total_csv_files_written += 2  # Increment by 2, considering both main and metadata CSVs
  print(f"CSV written: {csv_file_path}")
    

def write_metadata_to_csv(metadata, csv_file_path):
  csv_file_path.parent.mkdir(parents=True, exist_ok=True)
  with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    # Write keys as headers
    writer.writerow(metadata.keys())
    # Write corresponding values as a single row
    writer.writerow(metadata.values())
  print(f"Metadata CSV written: {csv_file_path}")


def clear_directory(directory_path):
  for file_path in directory_path.iterdir():
    try:
      if file_path.is_file() or file_path.is_symlink():
        file_path.unlink()
      elif file_path.is_dir():
        shutil.rmtree(file_path)
    except Exception as e:
      print(f'Failed to delete {file_path}. Reason: {e}')

def process_sku(sku_folder, sem):
  with sem:  # Use the semaphore to limit concurrency
    json_dir = JSONs / sku_folder
    csv_dir = CSVs / sku_folder
    csv_dir.mkdir(exist_ok=True)
    for file_path in json_dir.iterdir():
      if file_path.suffix == '.json':
        process_json_file(file_path, csv_dir)
    # Write the all_sku_combined.csv
    with open(csv_dir / F'all_{sku_folder}_combined.csv', 'w', newline='', encoding='utf-8') as all_file:
      all_writer = csv.writer(all_file)
      initial = True
      for f in csv_dir.rglob('*_DCDD*.csv'):
        with open(f, encoding='utf-8') as f_file:
          f_reader = csv.reader(f_file)
          header = next(f_reader)
          if initial:
            all_writer.writerow(header)
            initial = False
          all_writer.writerows(f_reader)
    # Write the all_sku_combined.csv
    with open(csv_dir / F'all_{sku_folder}_combined_meta.csv', 'w', newline='', encoding='utf-8') as all_file:
      all_writer = csv.writer(all_file)
      initial = True
      for f in csv_dir.rglob('*_DCDD*_META.csv'):
        with open(f, encoding='utf-8') as f_file:
          f_reader = csv.reader(f_file)
          header = next(f_reader)
          if initial:
            all_writer.writerow(header)
            initial = False
          all_writer.writerows(f_reader)

    print(f"Finished processing SKU: {sku_folder}")  # Optional: for tracking progress

def parse_impl_components(path):
  if not path.is_file():
    return {}
  with open(path) as f:
    csvr = csv.reader(f)
    header = next(csvr)
    return {r[3].strip().replace(' ', '_'):(r[2],r[7]) for r in csvr}

def main():
  start_time = time.time()  # Start timing
  sem = Semaphore(5)  # Limiting number of concurrent threads to 5
  threads = []
  for sku_folder in JSONs.iterdir():
    if sku_folder.is_dir():
      thread = Thread(target=process_sku, args=(sku_folder.name, sem,))
      threads.append(thread)
      thread.start()

  for thread in threads:
    thread.join()

  # Write the all_combined.csv
  with open(CSVs / F'all_combined.csv', 'w', newline='', encoding='utf-8') as all_file:
    all_writer = csv.writer(all_file)
    initial = True
    for f in sorted(CSVs.rglob('all_*_combined.csv')):
      sku_name = f.parent.name
      with open(f, encoding='utf-8') as f_file:
        f_reader = csv.reader(f_file)
        #header = next(f_reader)
        if initial:
          #all_writer.writerow(header)
          header = next(f_reader)
          all_writer.writerow(['SKU'] + header)
          initial = False
        #all_writer.writerows(f_reader)
        for row in f_reader:
          all_writer.writerow([sku_name] + row) 
          
  # Write the all_meta_combined.csv
  with open(CSVs / F'all_combined_meta.csv', 'w', newline='', encoding='utf-8') as all_file:
    all_writer = csv.writer(all_file)
    initial = True
    for f in sorted(CSVs.rglob('all_*_combined_meta.csv')):
      with open(f, encoding='utf-8') as f_file:
        f_reader = csv.reader(f_file)
        header = next(f_reader)
        if initial:
          all_writer.writerow(header)
          initial = False
        all_writer.writerows(f_reader)

  end_time = time.time()  # End timing
  total_time = end_time - start_time  # Calculate total runtime
  print(f"<-|-> Total CSVDEF files written: {total_csv_files_written} <-|->")
  print(f"<-|-> Total CSVDEF execution time: {total_time:.2f} seconds <-|->")

if __name__ == "__main__":
  CurrentPath = pathlib.Path(__file__).parent
  JSONs = CurrentPath / "JSONs"
  CSVs = CurrentPath / "CSV_DEFs"
  WSOD = CurrentPath / "download/Web_Service_Operations_Details.csv"
  impl_components_dict = parse_impl_components(WSOD)
  
  CSVs.mkdir(exist_ok=True)
  clear_directory(CSVs)

  main()  # Running main script