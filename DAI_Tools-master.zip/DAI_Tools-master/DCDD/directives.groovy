import groovy.json.JsonSlurper
import groovy.json.JsonOutput

class DirectiveGenerator {

    static void main(String[] args) {
        String inputPath = "C:/GitHub/DCDD_JSON/JSONs/hcm/Put_Applicant_DCDD_COMPLEX.json"
        String outputBasePath = "C:/GitHub/DCDD_JSON/DIRECTIVES"

        File inputFile = new File(inputPath)
        if (inputFile.isFile()) {
            processFile(inputFile, inputFile.getParentFile(), outputBasePath)
        } else {
            println "Invalid file path or file is not a JSON file."
        }
    }

    static void processFile(File file, File rootInputDir, String outputBasePath) {
        def jsonData = new JsonSlurper().parseText(file.text)

        // Step 1: Identify parent and child tables
        def tableElementTypes = identifyTablesAndDetermineNormalization(jsonData.rows, jsonData.columns)

        // Step 2: Generate directives, ensuring normalization is done only once per child table
        def directives = []
        def normalizedTables = [] // Track which tables have already been normalized

        jsonData.rows.each { row ->
            def directive = generateDirective(row, jsonData.columns, tableElementTypes, normalizedTables)
            if (directive) {
                directives << directive
            }
        }

        // Output
        String relativePath = rootInputDir.toURI().relativize(file.toURI()).getPath()
        String outputFilePath = outputBasePath + "/" + relativePath.replace(".json", "_Directive.json")
        File outputFile = new File(outputFilePath)
        outputFile.getParentFile().mkdirs()

        outputFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(directives))
        println "Processed: ${file.name} -> ${outputFilePath}"
    }

    static Map identifyTablesAndDetermineNormalization(List rows, List columns) {
        def tableMap = [:]
        def firstTableEncountered = ""
        def childTables = []
        
        rows.each { row ->
            def csvFileName = getValue(row, columns, "csv File Name")
            def requiredOptional = getValue(row, columns, "Required/Optional")
            
            if (csvFileName) {
                // Determine the parent table and skip "All CSVs"
                if (!firstTableEncountered && csvFileName != "All CSVs") {
                    firstTableEncountered = csvFileName
                    tableMap['parentTable'] = csvFileName
                } else if (csvFileName != firstTableEncountered && !childTables.contains(csvFileName) && requiredOptional != "Do Not Populate") {
                    // Add to child tables if it's not the parent table
                    childTables.add(csvFileName)
                }
            }
        }
        
        tableMap['childTables'] = childTables
        return tableMap
    }

    static String determineCommonElement(String xpath) {
        if (!xpath) return null
        def parts = xpath.split("/")
        if (parts.size() > 3 && parts[parts.size() - 1].contains("ID")) {
            return parts[parts.size() - 3].replace("wd:", "")
        } else if (parts.size() > 2) {
            return parts[parts.size() - 2].replace("wd:", "")
        }
        return null
    }

    static Map generateDirective(List row, List columns, Map tableElementTypes, List normalizedTables) {
        def directive = [:]
        def wdFieldName = getValue(row, columns, "WD Field Name")
        def csvFileName = getValue(row, columns, "csv File Name")
        def requiredOptional = getValue(row, columns, "Required/Optional")
        def xpath = getValue(row, columns, "XPATH")

        if (!csvFileName || csvFileName == "All CSVs") return null

        // Handle normalization, but only once per table
        if (tableElementTypes['childTables'].contains(csvFileName) && !normalizedTables.contains(csvFileName)) {
            def elementType = determineCommonElement(xpath)
            directive.type = "NORMALIZE"
            directive.elementType = elementType
            normalizedTables.add(csvFileName) // Mark this table as normalized
            return directive
        }

        // Handle hidden fields
        if (requiredOptional == "Do Not Populate") {
            def elementType = determineCommonElement(xpath)
            directive.type = "DENORMALIZE"
            directive.elementType = elementType
            directive.hiddenElementNames = [wdFieldName]
            return directive
        }

        return null
    }

    static String getValue(List row, List columns, String columnName) {
        def index = columns.indexOf(columnName)
        return index != -1 ? row[index] : null
    }
}
