import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox

DEFAULT_SOURCES = [
    r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\JSONs", 
    r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\JSONs2",
    r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\CSVs",
    r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\CSV_DEFs"
]
DEFAULT_TARGETS = [
    r"C:\GitHub\DCDD_JSON\JSONs", 
    r"C:\GitHub\DCDD_JSON\JSONs2",
    r"C:\GitHub\DCDD_Outputs\CSVs",
    r"C:\GitHub\DCDD_Outputs\CSV_DEFs"
]

def move_and_overwrite(src_folder, dst_folder, remove_source):
    if not os.path.exists(src_folder):
        print(f"Source folder {src_folder} does not exist.")
        return
    
    if not os.path.exists(dst_folder):
        os.makedirs(dst_folder)
    
    for item in os.listdir(src_folder):
        src_item = os.path.join(src_folder, item)
        dst_item = os.path.join(dst_folder, item)
        if os.path.isdir(src_item):
            if os.path.exists(dst_item):
                shutil.rmtree(dst_item)
            shutil.copytree(src_item, dst_item)
            if remove_source:
                shutil.rmtree(src_item)
        else:
            if os.path.exists(dst_item):
                os.remove(dst_item)
            shutil.copy2(src_item, dst_item)
            if remove_source:
                os.remove(src_item)

def select_folder(title):
    folder_selected = filedialog.askdirectory(title=title)
    return folder_selected

def create_form():
    def on_submit():
        sources = []
        targets = []
        
        if use_defaults_var.get():
            sources.extend(DEFAULT_SOURCES)
            targets.extend(DEFAULT_TARGETS)
        else:
            src1 = source1_entry.get()
            tgt1 = target1_entry.get()
            src2 = source2_entry.get()
            tgt2 = target2_entry.get()
            
            if src1 and tgt1:
                sources.append(src1)
                targets.append(tgt1)
            if src2 and tgt2:
                sources.append(src2)
                targets.append(tgt2)
        
        if not sources or not targets:
            messagebox.showerror("Error", "Please provide source and target folders.")
            return
        
        remove_source = move_files_var.get()
        
        for src_folder, dst_folder in zip(sources, targets):
            move_and_overwrite(src_folder, dst_folder, remove_source)
            print(f"{'Moved' if remove_source else 'Copied'} and overwrote contents of {src_folder} to {dst_folder}")
        
        messagebox.showinfo("Success", f"Files {'moved' if remove_source else 'copied'} successfully!")
        root.destroy()

    def browse_source1():
        folder = select_folder("Select Source Folder 1")
        source1_entry.delete(0, tk.END)
        source1_entry.insert(0, folder)

    def browse_target1():
        folder = select_folder("Select Target Folder 1")
        target1_entry.delete(0, tk.END)
        target1_entry.insert(0, folder)

    def browse_source2():
        folder = select_folder("Select Source Folder 2")
        source2_entry.delete(0, tk.END)
        source2_entry.insert(0, folder)

    def browse_target2():
        folder = select_folder("Select Target Folder 2")
        target2_entry.delete(0, tk.END)
        target2_entry.insert(0, folder)

    root = tk.Tk()
    root.title("Move Files")
    
    use_defaults_var = tk.BooleanVar(value=True)
    move_files_var = tk.BooleanVar(value=False)

    use_defaults_checkbox = tk.Checkbutton(root, text="Use Default Paths", variable=use_defaults_var)
    use_defaults_checkbox.grid(row=0, column=0, columnspan=2, pady=10)

    move_files_checkbox = tk.Checkbutton(root, text="Move Files (Remove Source)", variable=move_files_var)
    move_files_checkbox.grid(row=1, column=0, columnspan=2, pady=10)

    tk.Label(root, text="Source Folder 1:").grid(row=2, column=0, sticky="e")
    source1_entry = tk.Entry(root, width=50)
    source1_entry.grid(row=2, column=1)
    source1_button = tk.Button(root, text="Browse...", command=browse_source1)
    source1_button.grid(row=2, column=2)

    tk.Label(root, text="Target Folder 1:").grid(row=3, column=0, sticky="e")
    target1_entry = tk.Entry(root, width=50)
    target1_entry.grid(row=3, column=1)
    target1_button = tk.Button(root, text="Browse...", command=browse_target1)
    target1_button.grid(row=3, column=2)

    tk.Label(root, text="Source Folder 2:").grid(row=4, column=0, sticky="e")
    source2_entry = tk.Entry(root, width=50)
    source2_entry.grid(row=4, column=1)
    source2_button = tk.Button(root, text="Browse...", command=browse_source2)
    source2_button.grid(row=4, column=2)

    tk.Label(root, text="Target Folder 2:").grid(row=5, column=0, sticky="e")
    target2_entry = tk.Entry(root, width=50)
    target2_entry.grid(row=5, column=1)
    target2_button = tk.Button(root, text="Browse...", command=browse_target2)
    target2_button.grid(row=5, column=2)

    submit_button = tk.Button(root, text="Submit", command=on_submit)
    submit_button.grid(row=6, column=0, columnspan=3, pady=20)

    root.mainloop()


def main(sources, targets, remove_source):
    for src_folder, dst_folder in zip(sources, targets):
        move_and_overwrite(src_folder, dst_folder, remove_source)
        print(f"{'Moved' if remove_source else 'Copied'} and overwrote contents of {src_folder} to {dst_folder}")


if __name__ == "__main__":
    create_form()



# Calling from Another Script
# from move_files import main

# custom_sources = [
#     r"C:\Your\Custom\Source\Path1",
#     r"C:\Your\Custom\Source\Path2"
# ]

# custom_targets = [
#     r"C:\Your\Custom\Target\Path1",
#     r"C:\Your\Custom\Target\Path2"
# ]

# # Call the main function with the custom sources and targets, and set remove_source to True to move files
# main(sources=custom_sources, targets=custom_targets, remove_source=True)