import os
import json
import datetime
import time
import csv
from threading import Thread, Lock, Semaphore

# Global variables for counting and timing
total_files_written = 0
json_file_count_lock = Lock()

# Function to read the CSV file and create a lookup dictionary for implementation types
def load_implementation_types(file_path):
    implementation_types = {}
    with open(file_path, mode='r', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            key = row['Reference_ID_Value'].strip().replace(" ", "_").replace("-", "_")
            implementation_types[key] = row['Implementation_Types'].strip()
    return implementation_types

# Function to create set definition JSON
def create_set_definition(sku_folder, file_name, implementation_type):
    set_definition = {
        "setName": f"Demo Set Advanced Load for {sku_folder} - {datetime.datetime.now()}",
        "setDefinition": {
            "sourceType": "json",
            "content": [
                {
                    "order": "a",
                    "fileName": file_name,
                    "implementationType": implementation_type,
                    "version": "v41.0"
                }
            ]
        }
    }
    return set_definition

def process_sku(sku_folder, sem, implementation_types):
    with sem:  # Use the semaphore to limit concurrency
        json_dir = os.path.join(JSONs, sku_folder)
        set_definitions = []

        for root, dirs, files in os.walk(json_dir):
            for file in files:
                if file.endswith('.json'):  # Process JSON files
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r') as json_file:
                        data = json.load(json_file)
                        metadata = data.get('metadata', {})
                        web_service_operation = metadata.get('WEB SERVICE OPERATION', '').strip().replace(" ", "_").replace("-", "_")
                        full_name = metadata.get('FULL NAME', '').strip()
                        if full_name and web_service_operation:
                            implementation_type = implementation_types.get(web_service_operation, "Unknown Implementation Type")
                            file_name = f"{full_name}.xlsx"
                            set_definition = create_set_definition(sku_folder, file_name, implementation_type)
                            set_definitions.append(set_definition)
                            
                            with json_file_count_lock:
                                global total_files_written
                                total_files_written += 1

        if set_definitions:
            packaged_set_definition = {
                "setName": f"Demo Set Package for {sku_folder} - {datetime.datetime.now()}",
                "sets": set_definitions
            }
            output_file_path = os.path.join(OUTPUT, f"{sku_folder}_set_definitions_package.json")
            with open(output_file_path, 'w') as output_file:
                json.dump(packaged_set_definition, output_file, indent=4)
            print(f"Packaged JSON file written: {output_file_path}")

        print(f"Finished processing SKU: {sku_folder}")

def main():
    start_time = time.time()
    sem = Semaphore(5)  # Limiting number of concurrent threads to 5
    threads = []
    
    # Load the implementation types from the CSV file
    csv_path = os.path.join(CurrentPath, "download", "Web_Service_Operations_Details.csv")
    implementation_types = load_implementation_types(csv_path)

    for sku_folder in os.listdir(JSONs):
        if os.path.isdir(os.path.join(JSONs, sku_folder)):
            thread = Thread(target=process_sku, args=(sku_folder, sem, implementation_types))
            threads.append(thread)
            thread.start()

    for thread in threads:
        thread.join()

    end_time = time.time()
    total_time = end_time - start_time
    print(f"<-|[]|-> Total files written: {total_files_written} <-|[]|->")
    print(f"<-|[]|-> Total execution time: {total_time:.2f} seconds <-|[]|->")

if __name__ == "__main__":
    CurrentPath = os.path.dirname(__file__)
    JSONs = os.path.join(CurrentPath, "JSONs")
    OUTPUT = os.path.join(CurrentPath, "SETDEFs")
    
    os.makedirs(OUTPUT, exist_ok=True)

    main()  # Running main script