import os
import sys
import subprocess
import concurrent.futures
import time
import argparse

# Parse command line arguments to get SKUs to filter
parser = argparse.ArgumentParser(description="Run orchestrator with SKU filtering.")
parser.add_argument('--no_move_files', action='store_true', help='Do not run the move_files function')    # Add an argument for controlling the move_files function
args = parser.parse_args()

current_dir = os.path.dirname(os.path.realpath(__file__))   # Get the directory of the currently running script
sys.path.append(current_dir)    # Append the move_files module directory to the system path

# Only call the main function if the --no_move_files argument was NOT provided
if not args.no_move_files:
    # Call the main function with the custom sources and targets, and set remove_source to True to move files
    from move_files import main

    custom_sources = [
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\JSONs", 
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\JSONs2",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\CSVs",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\CSV_DEFs",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\SQLs",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\DDLs",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\CHKLIST",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\DICTS",
        r"C:\GitHub\DCDD_Tools\Tools\JK-WIP\download"
    ]

    custom_targets = [
        r"C:\GitHub\DCDD_JSON\JSONs", 
        r"C:\GitHub\DCDD_JSON\JSONs2",
        r"C:\GitHub\DCDD_Outputs\CSVs",
        r"C:\GitHub\DCDD_Outputs\CSV_DEFs",
        r"C:\GitHub\DCDD_Outputs\SQLs",
        r"C:\GitHub\DCDD_Outputs\DDLs",
        r"C:\GitHub\DCDD_Outputs\CHKLIST",
        r"C:\GitHub\DCDD_Outputs\DICTS",
        r"C:\GitHub\DCDD_Outputs\download"
    ]

    # Call the main function with the custom sources and targets, and set remove_source to True to move files
    main(sources=custom_sources, targets=custom_targets, remove_source=True)