import warnings
import smartsheet
import os
from datetime import datetime
import re

# Suppress specific warnings
warnings.filterwarnings("ignore", module='.*crypto.*')

# Configuration
token = os.getenv("SMARTSHEET_ACCESS_TOKEN") or "MANUALLY_ENTERED_SS_TOKEN"
use_testoring = os.getenv("USE_TESTORING", 'True').lower() in ['true', '1', 'yes', 'y', 't']
create_jira = os.getenv("CREATE_JIRA", 'False').lower() in ['true', '1', 'yes', 'y', 't']
testing_mode = True  # Toggle this variable to enable/disable testing mode

# Sheet IDs
production_intake_sheet_id = 'pCrC93fXVCVCW8CGVqxCxx4vwQMcfwqqWCp44f91'
test_intake_sheet_id = '3Rh3j7Cc9X7w83m54FxjxVWpV6qJgvxRXC2wP551'
production_tracking_sheet_id = 'FHw3c6hXHpQM2XhHrcFJmMpxJC3r8Cc4JPpvv3r1'
test_tracking_sheet_id = 'FhjgRCv4mHPMHCWCp5hJJv5fRJRHQ6HGMJG9Grx1'
production_approver_sheet_id = 'p9xvRWrwx3V6JxCp9QhqC6R3qcgRmWj59xP7WgC1'

# Initialize Smartsheet client
smart = smartsheet.Smartsheet(token)

# Function to load sheet data
def load_sheet_data(sheet_id):
    try:
        sheet = smart.Sheets.get_sheet(sheet_id)
        return sheet, sheet.id
    except Exception as e:
        print(f"Error loading sheet data: {e}")
        return None, None

# Function to get approvers
def get_approvers(sheet_data, approver_sheet_columns, criteria):
    return [
        (r.cells[approver_sheet_columns['DC FA Approver Contact']['IDX']].display_value, r.cells[approver_sheet_columns['DC FA Approver Contact']['IDX']].value)
        for r in sheet_data.rows
        if r.cells[approver_sheet_columns['DC FA Approver Contact']['IDX']].value and
           r.cells[approver_sheet_columns['Functional Area']['IDX']].value and
           criteria in r.cells[approver_sheet_columns['Functional Area']['IDX']].value and
           not r.cells[approver_sheet_columns['DC FA Approver Inactive']['IDX']].value
    ]

# Function to update a row
def update_row(sheet_id, row_id, cells):
    if testing_mode:
        print(f"[Testing Mode] Would update row {row_id} on sheet {sheet_id} with cells: {cells}")
        return
    try:
        return smart.Sheets.update_rows(sheet_id, [smartsheet.models.Row({'id': row_id, 'cells': cells})])
    except Exception as e:
        print(f"Error updating row {row_id}: {e}")
        return None

# Function to find the corresponding tracking row
def find_tracking_row(intake_row, tracking_sheet_rows):
    def normalize_name(name):
        return name.strip().lower() if name else ''

    intake_dcdd_name = normalize_name(intake_row['DCDD Name'][0])
    for tracking_row in tracking_sheet_rows:
        tracking_dcdd_name = normalize_name(tracking_row['DCDD'][0])
        if intake_dcdd_name == tracking_dcdd_name:
            return tracking_row

    return None

# Function to handle initial submission and approver assignment
def handle_initial_submission(intake_row, intake_sheet_columns, tracking_sheet_rows, approver_sheet_columns, approver_sheet_data, default_approvers, intake_sheet_id):
    row_id = intake_row['ID']
    request_type = intake_row['Request Type'][0]
    change_type = intake_row['Change Type'][0]
    functional_area = intake_row['Functional Area'][1] if intake_row['Functional Area'][1] else 'NONE'

    if request_type in ['DCDD', 'BOTH']:
        approvers = get_approvers(approver_sheet_data, approver_sheet_columns, functional_area) or default_approvers
    elif request_type == 'Stored Procedure':
        approvers = default_approvers

    if intake_row['Prioritization'][0] == 'Urgent':
        urgent_approvers = get_approvers(approver_sheet_data, approver_sheet_columns, 'URGENT')
        for ua in urgent_approvers:
            if ua not in approvers:
                approvers.append(ua)

    approvers = [a for a in approvers if a[1] != intake_row['Requested By'][1]]
    if not approvers:
        approvers = default_approvers

    if request_type == 'Stored Procedure' and change_type in ['Create', 'Fix']:
        approvers = [('Auto Approve', 'auto.approve@workday.com')]
    elif request_type == 'DCDD' and change_type == 'Create':
        approvers = [('Auto Approve', 'auto.approve@workday.com')]

    new_cell = smartsheet.models.Cell({
        'column_id': intake_sheet_columns['Approver']['ID'],
        'strict': False,
        'object_value': smartsheet.models.MultiContactObjectValue({'values': [smartsheet.models.ContactObjectValue({'name': c[0], 'email': c[1]}) for c in approvers]})
    })
    update_row(intake_sheet_id, row_id, [new_cell])
    print(f"Assigned approver(s) for row {intake_row['ROW_NUM']}: {approvers}")

# Function to handle duplicate requests
def handle_duplicate_requests(intake_row, intake_sheet_columns, intake_sheet_rows, tracking_sheet_rows, intake_sheet_id):
    row_id = intake_row['ID']
    dcdd_name = intake_row['DCDD Name'][0]
    request_type = intake_row['Request Type'][0]
    change_type = intake_row['Change Type'][0]

    for row in intake_sheet_rows:
        # Check if the DCDD Name matches and automation is not complete
        if row['DCDD Name'][0] == dcdd_name and not row['Automation Complete'][0]:
            # Further check if the request type matches and is not marked as complete
            if (row['Request Type'][0] == request_type) or (row['Request Type'][0] == 'BOTH'):
                # Handle DCDD requests
                if request_type == 'DCDD' and change_type == 'Create':
                    if testing_mode:
                        print(f"[Testing Mode] Would auto-reject duplicate DCDD create request for row {intake_row['ROW_NUM']} with DCDD Name {dcdd_name}.")
                    else:
                        new_cells = [
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Approval']['ID'],
                                'value': 'Declined',
                                'strict': False
                            }),
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Approver Comments']['ID'],
                                'value': "Duplicate request detected.",
                                'strict': False
                            }),
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Approver']['ID'],
                                'strict': False,
                                'object_value': smartsheet.models.MultiContactObjectValue({
                                    'values': [smartsheet.models.ContactObjectValue({'name': 'Auto Reject', 'email': 'missing@workday.com'})]
                                })
                            }),
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Automation Complete']['ID'],
                                'strict': True,
                                'value': True
                            })
                        ]
                        update_row(intake_sheet_id, row_id, new_cells)
                        print(f"Auto-rejected duplicate DCDD create request for row {intake_row['ROW_NUM']}.")
                    return True

                # Handle Stored Procedure create requests
                elif request_type == 'Stored Procedure' and change_type == 'Create':
                    if testing_mode:
                        print(f"[Testing Mode] Would auto-reject duplicate Stored Procedure create request for row {intake_row['ROW_NUM']} with DCDD Name {dcdd_name}.")
                    else:
                        new_cells = [
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Approval']['ID'],
                                'value': 'Declined',
                                'strict': False
                            }),
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Approver Comments']['ID'],
                                'value': "Duplicate SP create request detected.",
                                'strict': False
                            }),
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Approver']['ID'],
                                'strict': False,
                                'object_value': smartsheet.models.MultiContactObjectValue({
                                    'values': [smartsheet.models.ContactObjectValue({'name': 'Auto Reject', 'email': 'missing@workday.com'})]
                                })
                            }),
                            smartsheet.models.Cell({
                                'column_id': intake_sheet_columns['Automation Complete']['ID'],
                                'strict': True,
                                'value': True
                            })
                        ]
                        update_row(intake_sheet_id, row_id, new_cells)
                        print(f"Auto-rejected duplicate SP create request for row {intake_row['ROW_NUM']}.")
                    return True

    return False


# Function to link Original DCDD for Update or Fix requests
def link_original_dcdd(intake_row, intake_sheet_columns, tracking_sheet_rows, intake_sheet_id):
    if intake_row['Request Type'][0] == 'DCDD' and intake_row['Change Type'][0] in ['Update', 'Fix']:
        tracking_row = find_tracking_row(intake_row, tracking_sheet_rows)
        if tracking_row:
            orig_name_cell = smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Original DCDD']['ID'],
                'value': tracking_row['DCDD'][0],
                'strict': False,
                'hyperlink': smartsheet.models.Hyperlink({'sheet_id': tracking_row['LINK_ID']})
            })
            update_row(intake_sheet_id, intake_row['ID'], [orig_name_cell])
            print(f"Linked Original DCDD for row {intake_row['ROW_NUM']}.")

# Function to handle approved requests
def handle_approved_requests(intake_row, intake_sheet_columns, tracking_sheet_columns, intake_sheet_id, tracking_sheet_rows):
    row_id = intake_row['ID']
    request_type = intake_row['Request Type'][0]
    change_type = intake_row['Change Type'][0]
    tracking_row = find_tracking_row(intake_row, tracking_sheet_rows)

    if request_type == 'DCDD' and change_type == 'Create':
        new_dev_dcdd = create_new_dcdd_from_template(intake_row, intake_sheet_columns, intake_sheet_id)
        update_dev_dcdd_link(intake_row, intake_sheet_columns, new_dev_dcdd, intake_sheet_id)
    elif request_type == 'DCDD' and change_type in ['Update', 'Fix']:
        if tracking_row:
            new_dev_dcdd = copy_existing_dcdd_to_dev(intake_row, intake_sheet_columns, tracking_row, intake_sheet_id)
            update_dev_dcdd_link(intake_row, intake_sheet_columns, new_dev_dcdd, intake_sheet_id)

    assign_developer(intake_row, intake_sheet_columns, intake_sheet_id)

# Function to create new DCDD from template
def create_new_dcdd_from_template(intake_row, intake_sheet_columns, intake_sheet_id):
    dev_folder_id = 227890882209668
    dcdd_template_id = 8678320964429700
    new_name = re.sub(r"[^\w\s]", "", intake_row['DCDD Name'][0]).title().replace(" ", "_") + "_DCDD"
    response = smart.Sheets.copy_sheet(dcdd_template_id, smartsheet.models.ContainerDestination({'destination_type': 'folder', 'destination_id': dev_folder_id, 'new_name': new_name}), include=['filters'])
    print(f"Creating new DCDD from Blank Template to DEV Folder: {response.message}")
    return response.result.id

# Function to copy existing DCDD to DEV folder
def copy_existing_dcdd_to_dev(intake_row, intake_sheet_columns, tracking_row, intake_sheet_id):
    dev_folder_id = 227890882209668
    response = smart.Sheets.copy_sheet(tracking_row['LINK_ID'], smartsheet.models.ContainerDestination({'destination_type': 'folder', 'destination_id': dev_folder_id, 'new_name': tracking_row['DCDD'][0]}), include=['data', 'filters'])
    print(f"Copying DCDD to DEV Folder: {response.message}")
    return response.result.id

# Function to update Development DCDD link
def update_dev_dcdd_link(intake_row, intake_sheet_columns, new_dev_dcdd_id, intake_sheet_id):
    dev_name_cell = smartsheet.models.Cell({
        'column_id': intake_sheet_columns['Development DCDD']['ID'],
        'value': intake_row['DCDD Name'][0],
        'strict': False,
        'hyperlink': smartsheet.models.Hyperlink({'sheet_id': new_dev_dcdd_id})
    })
    update_row(intake_sheet_id, intake_row['ID'], [dev_name_cell])
    print(f"Updated Development DCDD link for row {intake_row['ROW_NUM']}.")

# Function to handle development completion and moving sheets
def handle_development_complete(intake_row, intake_sheet_columns, tracking_sheet_columns, intake_sheet_id, tracking_sheet_id, tracking_sheet_rows):
    row_id = intake_row['ID']
    request_type = intake_row['Request Type'][0]
    change_type = intake_row['Change Type'][0]
    tracking_row = find_tracking_row(intake_row, tracking_sheet_rows)

    if request_type == 'DCDD':
        if change_type in ['Update', 'Fix']:
            move_dcdd_to_release(intake_row, intake_sheet_columns, intake_sheet_id)
            update_tracking_sheet_with_new_dcdd(intake_row, tracking_row, tracking_sheet_columns, tracking_sheet_id)
        elif change_type == 'Create':
            move_dcdd_to_release(intake_row, intake_sheet_columns, intake_sheet_id)
            insert_new_dcdd_into_tracking_sheet(intake_row, tracking_sheet_columns, tracking_sheet_id)

        mark_automation_complete(intake_row, intake_sheet_columns, intake_sheet_id)

    if request_type == 'Stored Procedure':
        mark_sp_as_created(tracking_row, tracking_sheet_columns, tracking_sheet_id)

# Function to move DCDD to release folder
def move_dcdd_to_release(intake_row, intake_sheet_columns, intake_sheet_id):
    rel_folder_id = 8393978237216644
    dev_link_id = intake_row['DEV_LINK_ID']
    response = smart.Sheets.move_sheet(dev_link_id, smartsheet.models.ContainerDestination({'destination_type': 'folder', 'destination_id': rel_folder_id}))
    print(f"Moving DCDD from DEV to REL Folder: {response.message}")

# Function to update tracking sheet with new DCDD link
def update_tracking_sheet_with_new_dcdd(intake_row, tracking_row, tracking_sheet_columns, tracking_sheet_id):
    new_cell = smartsheet.models.Cell({
        'column_id': tracking_sheet_columns['DCDD']['ID'],
        'value': tracking_row['DCDD'][0],
        'strict': False,
        'hyperlink': smartsheet.models.Hyperlink({'sheet_id': intake_row['DEV_LINK_ID']})
    })
    update_row(tracking_sheet_id, tracking_row['ID'], [new_cell])
    print(f"Updated Tracking Sheet with new DCDD link for row {tracking_row['ID']}.")

# Function to insert new DCDD into tracking sheet
def insert_new_dcdd_into_tracking_sheet(intake_row, tracking_sheet_columns, tracking_sheet_id):
    new_row = smartsheet.models.Row()
    new_row.to_top = True
    new_row.cells.append(smartsheet.models.Cell({
        'column_id': tracking_sheet_columns['DCDD']['ID'],
        'value': intake_row['DCDD Name'][0],
        'strict': False,
        'hyperlink': smartsheet.models.Hyperlink({'sheet_id': intake_row['DEV_LINK_ID']})
    }))
    update_row(tracking_sheet_id, new_row)
    print(f"Inserted new DCDD into Tracking Sheet for row {intake_row['ROW_NUM']}.")

# Function to mark SP as created
def mark_sp_as_created(tracking_row, tracking_sheet_columns, tracking_sheet_id):
    new_cells = [
        smartsheet.models.Cell({'column_id': tracking_sheet_columns['SP Update Approved']['ID'], 'value': True, 'strict': False}),
        smartsheet.models.Cell({'column_id': tracking_sheet_columns['SP Update Required']['ID'], 'value': False, 'strict': False})
    ]
    update_row(tracking_sheet_id, tracking_row['ID'], new_cells)
    print(f"Marked SP as created in Tracking Sheet for row {tracking_row['ID']}.")

# Function to mark automation as complete
def mark_automation_complete(intake_row, intake_sheet_columns, intake_sheet_id):
    try:
        new_cells = [
            smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Automation Complete']['ID'],
                'strict': True,
                'value': True
            }),
            smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Published Date']['ID'],
                'strict': False,
                'value': datetime.now().strftime('%Y-%m-%d')
            })
        ]
        update_row(intake_sheet_id, intake_row['ID'], new_cells)
        print(f"Marked automation as complete for row {intake_row['ROW_NUM']}.")
    except Exception as e:
        print(f"Error marking automation complete for row {intake_row['ROW_NUM']}: {e}")

# Function to handle declines
def handle_decline(intake_row, intake_sheet_columns, intake_sheet_id):
    try:
        row_id = intake_row['ID']
        
        # Set the approval status to 'Declined'
        new_cells = [
            smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Approval']['ID'],
                'value': 'Declined',
                'strict': False  # Use especially in case of picklist (where it has to match an option if not False)
            }),
            smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Approver Comments']['ID'],
                'value': "Request was declined.",
                'strict': False  # Use especially in case of picklist (where it has to match an option if not False)
            }),
            smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Approver']['ID'],
                'strict': False,
                'object_value': smartsheet.models.MultiContactObjectValue({
                    'values': [smartsheet.models.ContactObjectValue({'name': 'Auto Reject', 'email': 'missing@workday.com'})]
                })
            })
        ]
        update_row(intake_sheet_id, intake_row['ID'], new_cells)
        
        # Mark automation as complete
        mark_automation_complete(intake_row, intake_sheet_columns, intake_sheet_id)
        print(f"Row {intake_row['ROW_NUM']} was declined and marked as complete.")
    except Exception as e:
        print(f"Error handling decline for row {intake_row['ROW_NUM']}: {e}")

# Function to assign a developer
def assign_developer(intake_row, intake_sheet_columns, intake_sheet_id):
    try:
        if not intake_row['Developer'][1]:  # Check if a developer is already assigned
            default_developers = [
                ('John Lau', 'john.lau@workday.com'), 
                ('George Sam', 'george.sam@workday.com'), 
                ('Jonathan Kleinberg', 'jonathan.kleinberg@workday.com'),
                ('Robert Gordon', 'robert.gordon@workday.com'),
            ]
            new_cell = smartsheet.models.Cell({
                'column_id': intake_sheet_columns['Developer']['ID'],
                'strict': False,
                'object_value': smartsheet.models.MultiContactObjectValue({
                    'values': [smartsheet.models.ContactObjectValue({'name': c[0], 'email': c[1]}) for c in default_developers]
                })
            })
            update_row(intake_sheet_id, intake_row['ID'], [new_cell])
            print(f"Assigned developer for row {intake_row['ROW_NUM']}.")
        else:
            print(f"Developer already assigned for row {intake_row['ROW_NUM']}.")
    except Exception as e:
        print(f"Error assigning developer for row {intake_row['ROW_NUM']}: {e}")

# Main function to process intake requests
def process_intake_requests(intake_sheet_id, tracking_sheet_id, approver_sheet_id):
    print(f"Process all intake requests from the intake sheet `{intake_sheet_id}`.")
    intake_sheet_data, intake_sheet_real_id = load_sheet_data(intake_sheet_id)
    tracking_sheet_data, tracking_sheet_real_id = load_sheet_data(tracking_sheet_id)
    approver_sheet_data, approval_sheet_real_id = load_sheet_data(approver_sheet_id)
    
    if not intake_sheet_data or not tracking_sheet_data or not approver_sheet_data:
        print("Error loading sheet data. Exiting.")
        return

    # Get approver sheet columns
    approver_sheet_columns = {x.title: {'IDX': y, 'ID': x.id} for y, x in enumerate(approver_sheet_data.columns)}

    # Get default and urgent approvers
    default_approvers = get_approvers(approver_sheet_data, approver_sheet_columns, 'NONE')
    urgent_approvers = get_approvers(approver_sheet_data, approver_sheet_columns, 'URGENT')
    print(f"Loaded Sheet: {approver_sheet_data.name}")

    # Process intake sheet rows
    intake_sheet_columns = {x.title: {'IDX': y, 'ID': x.id} for y, x in enumerate(intake_sheet_data.columns)}
    intake_sheet_rows = [
        {
            **{
                'ID': r.id,
                'ROW_NUM': r.row_number,
                'ORIG_URL': (r.cells[intake_sheet_columns['Original DCDD']['IDX']].hyperlink and r.cells[intake_sheet_columns['Original DCDD']['IDX']].hyperlink.url) or None,
                'ORIG_LINK_ID': (r.cells[intake_sheet_columns['Original DCDD']['IDX']].hyperlink and r.cells[intake_sheet_columns['Original DCDD']['IDX']].hyperlink.sheet_id) or None,
                'DEV_URL': (r.cells[intake_sheet_columns['Development DCDD']['IDX']].hyperlink and r.cells[intake_sheet_columns['Development DCDD']['IDX']].hyperlink.url) or None,
                'DEV_LINK_ID': (r.cells[intake_sheet_columns['Development DCDD']['IDX']].hyperlink and r.cells[intake_sheet_columns['Development DCDD']['IDX']].hyperlink.sheet_id) or None,
            },
            **{c: (r.cells[intake_sheet_columns[c]['IDX']].display_value, r.cells[intake_sheet_columns[c]['IDX']].value) for c in intake_sheet_columns}
        } for r in intake_sheet_data.rows if r.cells[intake_sheet_columns['Requested By']['IDX']].display_value and not r.cells[intake_sheet_columns['Automation Complete']['IDX']].value
    ]
    if not intake_sheet_rows:
        print("No rows to process. All rows are marked as Automation Complete.")
        return
    print(f"Loaded Sheet: {intake_sheet_data.name}, with [", len(intake_sheet_rows), "] rows...")

    tracking_sheet_columns = {x.title: {'IDX': y, 'ID': x.id} for y, x in enumerate(tracking_sheet_data.columns)}
    tracking_sheet_rows = [
        {
            **{
                'ID': r.id,
                'URL': (r.cells[tracking_sheet_columns['DCDD']['IDX']].hyperlink and r.cells[tracking_sheet_columns['DCDD']['IDX']].hyperlink.url) or None,
                'LINK_ID': (r.cells[tracking_sheet_columns['DCDD']['IDX']].hyperlink and r.cells[tracking_sheet_columns['DCDD']['IDX']].hyperlink.sheet_id) or None
            },
            **{c: (r.cells[tracking_sheet_columns[c]['IDX']].display_value, r.cells[tracking_sheet_columns[c]['IDX']].value) for c in tracking_sheet_columns}
        } for r in tracking_sheet_data.rows
    ]
    print(f"Loaded Sheet: {tracking_sheet_data.name}, with [", len(tracking_sheet_rows), "] rows...")

    for intake_row in intake_sheet_rows:
        if handle_duplicate_requests(intake_row, intake_sheet_columns, intake_sheet_rows, tracking_sheet_rows, intake_sheet_real_id):
            continue
        handle_initial_submission(intake_row, intake_sheet_columns, tracking_sheet_rows, approver_sheet_columns, approver_sheet_data, default_approvers, intake_sheet_real_id)
        link_original_dcdd(intake_row, intake_sheet_columns, tracking_sheet_rows, intake_sheet_real_id)
        
        if intake_row['Approval'][0] == 'Approved':
            handle_approved_requests(intake_row, intake_sheet_columns, tracking_sheet_columns, intake_sheet_real_id, tracking_sheet_rows)
        elif intake_row['Approval'][0] == 'Declined':
            handle_decline(intake_row, intake_sheet_columns, intake_sheet_real_id)
        elif intake_row['Development Complete'][0]:
            handle_development_complete(intake_row, intake_sheet_columns, tracking_sheet_columns, intake_sheet_real_id, tracking_sheet_real_id, tracking_sheet_rows)

if __name__ == "__main__":
    intake_sheet_id = test_intake_sheet_id if use_testoring else production_intake_sheet_id
    tracking_sheet_id = test_tracking_sheet_id if use_testoring else production_tracking_sheet_id
    approver_sheet_id = production_approver_sheet_id
    process_intake_requests(intake_sheet_id, tracking_sheet_id, approver_sheet_id)