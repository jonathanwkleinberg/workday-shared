import pathlib
import json
import shutil
import time
import logging
from threading import Thread, Lock, Semaphore

# Global variables for counting and timing
total_files_written = 0
csv_file_count_lock = Lock()

def clear_directory(directory):
  if not directory.exists():
    return
  try:
    shutil.rmtree(directory)
    directory.mkdir(exist_ok=True)
  except Exception as e:
    logging.error(f'Failed to clear {directory}. Reason: {e}')

def get_tracking_sheet_id():
  tracking_sheet_path = CHKLIST / 'tracking_sheet_data.json'
  # Check if the specific file exists
  if tracking_sheet_path.is_file():
    with open(tracking_sheet_path, 'r') as f:
      data = json.load(f)
    
    # If data is a list, iterate over its elements (which should be dictionaries)
    if isinstance(data, list):
      return [item.get('tracking_sheet_url_id', '') for item in data]
    
    # If data is a dictionary, just get the 'tracking_sheet_url_id'
    elif isinstance(data, dict):
      return data.get('tracking_sheet_url_id', '')
      
  # If the specific file does not exist, find any other JSON file in the folder
  else:
    json_files = list(CHKLIST.glob('*.json'))
    # If there is only one JSON file, proceed with it
    if len(json_files) == 1:
      with open(json_files[0], 'r') as f:
        data = json.load(f)
      return data.get('tracking_sheet_url_id', '')
    # If there are more than one JSON files, fail gracefully
    elif len(json_files) > 1:
      print("Error: Multiple JSON files found in the CHKLIST directory. Unable to determine which one to use.")
      return None
    # If there are no JSON files, fail gracefully
    else:
      print("Error: No JSON files found in the CHKLIST directory.")
      return None


def format_slng_table_name(filename):
  return f"src_{filename.lower().replace('.sql','').replace('.csv','').replace('_dcdd','').replace('_DCDD','').strip()}"

def process_json_to_files(file_path, dir_path, directory):
  with open(file_path, 'r') as f:
    data = json.load(f)
  #logging.debug(f"Data read from {file_path}: {data}")

  columns = data.get("columns", [])
  rows = data.get("rows", [])
  metadata = data.get("metadata", {})
  meta_headers = list(metadata.keys())
  meta_rows = [[value] for value in metadata.values()]
  full_sheet_id = data.get('full_sheet_id', '')  # Extract full_sheet_id from data
  
  # Get default dcdd name from metadata FULL NAME or use filename
  default_dcdd_name = (metadata.get('FULL NAME') or 'Unnamed_Dataset').replace(" ", "_")
  if '_DCDD' not in default_dcdd_name:
    default_dcdd_name += "_DCDD"
  default_dcdd_name += ".sql"

  # Dictionary to hold data by filename
  dcdd_data = {
    default_dcdd_name: {
      'headers': columns,
      'rows': rows,
      'meta_headers': meta_headers,
      'meta_rows': meta_rows,
      'full_sheet_id': full_sheet_id
    }
  }

  # Write data to files
  for file_name, data in dcdd_data.items():
    table_name = pathlib.Path(file_path).stem # remove suffix/extension
    if len(table_name) > 64:
      print(F'    ERROR: The table name "{table_name}" is too long (> 64) and will be skipped!')
      continue
    if directory == SQLs:
      file_path = dir_path / file_name
      write_sql_file(meta_headers, meta_rows, columns, rows, file_path, full_sheet_id)
    elif directory == DDLs:
      return dcdd_data
  return dcdd_data

def write_sql_file(meta_headers, meta_rows, data_headers, data_rows, file_path, full_sheet_id):
  file_path.parent.mkdir(exist_ok=True)
  with open(file_path, 'w', encoding='utf-8', newline='') as jf:
    table_name = pathlib.Path(file_path).stem # remove suffix/extension
    meta_table_name = table_name.replace("_DCDD", "_META")
    newline = ",\n  "
    
    # Write metadata table creation and insertion
    jf.write(F'''/*
    DCDD Table: {table_name}     
    Version: AutoCreated     
    Comments: SQL created from https://app.smartsheet.com/sheets/{full_sheet_id}?view=grid
*/

DROP TABLE IF EXISTS `{meta_table_name}`;
CREATE TABLE `{meta_table_name}`(
  {newline.join([F'`{x}` TEXT' for x in meta_headers])}
);
INSERT INTO `{meta_table_name}`
  ({', '.join([F'`{x}`' for x in meta_headers])})
  VALUES
  ({', '.join([F"""'{x.replace("'","''")}'""" if x else 'NULL' for row in meta_rows for x in row])})
;''')

    # Write main table creation
    jf.write(F'''

DROP TABLE IF EXISTS `{table_name}`;
CREATE TABLE `{table_name}`(
  {newline.join([F'`{x}` TEXT' for x in data_headers])}
);
INSERT INTO `{table_name}`
  ({', '.join([F'`{x}`' for x in data_headers])})
  VALUES''')

    # Write insert statements for each row in main table
    for i, row in enumerate(data_rows):
      jf.write(F'''
  ({', '.join([F"""'{x.replace("'","''")}'""" if x else 'NULL' for x in row])})''')
    jf.write('\n;\n')

  with csv_file_count_lock:
    global total_files_written
    total_files_written += 1
  print(f"SQL file written: {file_path}")


def write_ddl_file(all_dcdd_data, dir_path, sku_folder, tracking_sheet_id):
  print(F'Writing slng_ddl_{sku_folder}.sql ...')
  dir_path.mkdir(exist_ok=True)
  file_path = dir_path / F'slng_ddl_{sku_folder}.sql'
  with open(file_path, 'a', encoding='utf-8') as f:
    f.write(F"""/*
    Staging Table: {sku_folder}
    Version: AutoCreated
    Comments: DDL created from https://app.smartsheet.com/sheets/{tracking_sheet_id}?view=grid
*/

/* NO LONGER SETTING UP AS AN SP
USE hellboy;     
DROP PROCEDURE IF EXISTS `sp_slng_ddl_{sku_folder}`;
-- DELIMITER $$   -- *** Comment out the delimiter declaration to load via SLNG *** -- 
CREATE DEFINER=`slng_user`@`%` PROCEDURE `sp_slng_ddl_{sku_folder}`()
  STAGING:BEGIN
*/\n""")
  
    # Loop through all the data and write it to the file
    #logging.debug("Starting to write DDL file")
    for dcdd_data in all_dcdd_data:
      if isinstance(dcdd_data, dict):
        for filename, data_details in dcdd_data.items():
          #meta_headers = data_details.get('meta_headers', [])
          #meta_rows = data_details.get('meta_rows', [])
          data_headers = data_details.get('headers', [])
          data_rows = data_details.get('rows', [])
          full_sheet_id = data_details.get('full_sheet_id', '')
          slng_dcdd_files_set = set()
          formatted_slng_filename = format_slng_table_name(filename)
          
          if 'csv File Name' in data_headers:  # multiple tables
            csv_fn_index = data_headers.index('csv File Name')
            valid_csv_files = [row[csv_fn_index].strip() for row in data_rows if row[csv_fn_index] and row[csv_fn_index].strip()]
            
            if valid_csv_files:  # Check if there are any valid csv filenames
              for csv_files in valid_csv_files:
                for csv_file in [x.strip() for x in csv_files.split(',')]:
                  if csv_file.lower() != 'all csvs':
                    slng_dcdd_files_set.add(format_slng_table_name(csv_file))
            else:  # If no valid csv filenames, use the formatted filename from JSON file
              slng_dcdd_files_set.add(formatted_slng_filename)
          else:  # If the csv File Name column does not exist
            slng_dcdd_files_set.add(formatted_slng_filename)
          
          slng_dcdd_files = sorted([x for x in slng_dcdd_files_set if 'all csv' not in x.lower()])

          f.write(f"\n/*** Start of {pathlib.Path(filename).stem} Section created from https://app.smartsheet.com/sheets/{full_sheet_id}?view=grid ***/\n")
          for slng_dcdd_file in slng_dcdd_files:
            f.write(f"\nDROP TABLE IF EXISTS `{slng_dcdd_file}`;\nCREATE TABLE `{slng_dcdd_file}`(\n")
            if 'csv Header' in data_headers:
              csv_headers_index = data_headers.index('csv Header')
              csv_fn_index = data_headers.index('csv File Name')
              csv_headers = [row[csv_headers_index] for row in data_rows if row[csv_headers_index] and row[csv_headers_index] is not None and row[csv_fn_index] is not None and (slng_dcdd_file.replace("src_", "") in [x.lower().replace('.sql','').replace('.csv','').strip() for x in row[csv_fn_index].split(',')] or 'all csv' in row[csv_fn_index].lower())]
              temp_str = ""
              for csv_header in csv_headers:
                temp_str += F"""  `{csv_header}` TEXT,\n"""
              temp_str = temp_str[:-2] + "\n"
              f.write(temp_str)
            f.write(") ENGINE=InnoDB ENCRYPTION='Y' COMMENT '';\n\n")
          f.write(F"""/*** End of {pathlib.Path(filename).stem} Section ***/\n\n""")
      else:
        print(f"Error: Expected dcdd data in a dictionary format, received {type(dcdd_data)}")
    f.write("""\n/* NO LONGER SETTING UP AS AN SP\nSET autocommit=1;\nEND STAGING;\n*/""")
    f.close()
    print(f"DDL file written: slng_ddl_{sku_folder}.sql")
    
  with csv_file_count_lock:
      global total_files_written
      total_files_written += 1


def process_sku(json_dir, sem, tracking_sheet_id):
  with sem:  # Use the semaphore to limit concurrency
    sku_folder = json_dir.name
    directories = [SQLs, DDLs]
    all_dcdd_data = []
    for directory in directories:
      if directory == DDLs:
        dir_path = directory
      else:
        dir_path = directory / sku_folder
      dir_path.mkdir(exist_ok=True)

      for file_path in json_dir.glob('*.json'):
        dcdd_data = process_json_to_files(file_path, dir_path, directory)
        #logging.debug(f"DCDD data from {file_path} to be added: {dcdd_data}")
        if isinstance(dcdd_data, dict):
          all_dcdd_data.append(dcdd_data)
        else:
          logging.error("Received non-dictionary DCDD data")

      if directory == DDLs:
        all_dcdd_data = [json.loads(t) for t in set([json.dumps(d) for d in all_dcdd_data])]    #remove DUPs
        all_dcdd_data.sort(key=lambda item: list(item.keys())[0])   #sort them
        write_ddl_file(all_dcdd_data, dir_path, sku_folder, tracking_sheet_id)  #process them

    print(f"Finished processing SKU: {sku_folder}") 

def main():
  start_time = time.time()
  sem = Semaphore(5)  # Limiting number of concurrent threads to 5
  threads = []
  tracking_sheet_id = get_tracking_sheet_id()  # Get tracking_sheet_id
  for sku_folder in [x for x in JSONs.iterdir() if x.is_dir()]:
    thread = Thread(target=process_sku, args=(sku_folder, sem, tracking_sheet_id))
    threads.append(thread)
    thread.start()

  for thread in threads:
    thread.join()

  end_time = time.time()
  total_time = end_time - start_time
  print(f"<-|[]|-> Total files written: {total_files_written} <-|[]|->")
  print(f"<-|[]|-> Total execution time: {total_time:.2f} seconds <-|[]|->")

if __name__ == "__main__":
  CurrentPath = pathlib.Path(__file__).parent
  CHKLIST = CurrentPath /  "CHKLIST"
  JSONs = CurrentPath / "JSONs"
  SQLs = CurrentPath / "SQLs"
  DDLs = CurrentPath / "DDLs"
  
  # List of directories to be created
  directories = [SQLs, DDLs]

  # Check if JSONs directory exists
  if not JSONs.exists():
    print("Error: The directory 'JSONs' does not exist. Please run the JSON creator scripts.")
    exit(1)

  for directory in directories:
    directory.mkdir(exist_ok=True)
    clear_directory(directory)

  logging.basicConfig(filename='app.log', filemode='w', level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s')

  main()  # Running main script