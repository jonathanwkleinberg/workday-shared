def buildResult = 'SUCCESS'
def getResult

try {
podTemplate(cloud: 'gke-cloud', inheritFrom: 'gke-agent-c9-dind') { node(POD_LABEL) {
  def branchedStages = [:]

  branchedStages["DAI_Tools"] = { stage("DAI_Tools") { retry(5) {
    checkout changelog: false, poll: false, scm: [
    $class: 'GitSCM', 
    branches: [[name: '*/master']], 
    doGenerateSubmoduleConfigurations: false, 
    extensions: [[$class: "UserIdentity", name: "dai", email: "dai@workday.com"], [$class: 'WipeWorkspace'], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'DAI_Tools']], 
    submoduleCfg: [], 
    userRemoteConfigs: [[credentialsId: 'SVC_CAS_JENKINS_USER_KEY', url: 'git@ghe.megaleo.com:DTOE/DAI_Tools.git']]
    ]
  }}}
  
  branchedStages["DCDD_JSON"] = { stage("DCDD_JSON") { retry(5) {
    checkout changelog: false, poll: false, scm: [
    $class: 'GitSCM', 
    branches: [[name: '*/master']], 
    doGenerateSubmoduleConfigurations: false, 
    extensions: [[$class: "UserIdentity", name: "dai", email: "dai@workday.com"], [$class: 'WipeWorkspace'], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'DCDD_JSON']], 
    submoduleCfg: [], 
    userRemoteConfigs: [[credentialsId: 'SVC_CAS_JENKINS_USER_KEY', url: 'git@ghe.megaleo.com:DTOE/DCDD_JSON.git']]
    ]
  }}}
  
  branchedStages["DCDD_Outputs"] = { stage("DCDD_Outputs") { retry(5) {
    checkout changelog: false, poll: false, scm: [
    $class: 'GitSCM', 
    branches: [[name: '*/master']], 
    doGenerateSubmoduleConfigurations: false, 
    extensions: [[$class: "UserIdentity", name: "dai", email: "dai@workday.com"], [$class: 'WipeWorkspace'], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'DCDD_Outputs']], 
    submoduleCfg: [], 
    userRemoteConfigs: [[credentialsId: 'SVC_CAS_JENKINS_USER_KEY', url: 'git@ghe.megaleo.com:DTOE/DCDD_Outputs.git']]
    ]
  }}}

  parallel branchedStages

  stage('Results') {
    withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_PASS', passwordVariable: 'PROT_PASSWORD', usernameVariable: 'PROT_USERNAME')]) {
      SUV = sh(returnStdout: true, script: '''
        curl -su $PROT_USERNAME:$PROT_PASSWORD 'https://wd5-suv.megaleo.com/proteus/api/v2/search/suv/instances' | 
        jq -r 'first(.[] | select(.wdAdditionalTags.poolName=="dtoe-automation" and .state=="running" and .buildPercentage >= 10 )) | .instanceId'
      ''').trim()
      echo "SUV: $SUV"
    }

    // Setup Artifactory Repo (yum/dnf)
    withCredentials([usernamePassword(credentialsId: 'SVC_CAS_JENKINS_USER_ENC_PASS', passwordVariable: 'enc_pass', usernameVariable: 'enc_user')]) {
      sh('''echo "[artifactory-repo-baseos]
name=Artifactory Repository BaseOS
baseurl=https://${enc_user}:${enc_pass}@artifactory.workday.com/artifactory/mirror.stream.centos.org/9-stream/BaseOS/x86_64/os/
enabled=1
gpgcheck=0" | sudo tee /etc/yum.repos.d/artifactory-baseos.repo
echo "[artifactory-repo-appstream]
name=Artifactory Repository AppStream
baseurl=https://${enc_user}:${enc_pass}@artifactory.workday.com/artifactory/mirror.stream.centos.org/9-stream/AppStream/x86_64/os/
enabled=1
gpgcheck=0" | sudo tee -a /etc/yum.repos.d/artifactory-appstream.repo
      ''')
    } // end withcred (enc_user)

    withEnv(["SUV=$SUV"]) { withCredentials([string(credentialsId: 'SVC_CAS_JENKINS_GHE_TOKEN', variable: 'GHE_TOKEN'), sshUserPrivateKey(credentialsId: 'SVC_CAS_JENKINS_USER_KEY', keyFileVariable: 'PK'), string(credentialsId: 'SS_TOKEN', variable: 'SS_TOKEN')]) {
      sh('''\
sudo yum install -y rsync

git config --global user.email "dai@workday.com"
git config --global user.name "dai"

git -C DCDD_JSON checkout master
git -C DCDD_Outputs checkout master

rm -rf DAI_Tools/DCDD/*/

rm -rf DCDD_JSON/JSONs
rm -rf DCDD_JSON/JSONs2
rm -rf DCDD_JSON/CHKLIST
rm -rf DCDD_JSON/download
rm -rf DCDD_JSON/DICTS

rm -rf DCDD_Outputs/SQLs
rm -rf DCDD_Outputs/CSVs
rm -rf DCDD_Outputs/CSV_DEFs
rm -rf DCDD_Outputs/CHKLIST
rm -rf DCDD_Outputs/DDLs
rm -rf DCDD_Outputs/DICTS
rm -rf DCDD_Outputs/download

rsync -avzhe "ssh -i '${PK}' -o StrictHostKeyChecking=no" --no-p --no-o --no-g --delete DAI_Tools root@"${SUV}.workdaysuv.com:~/"
ssh -i "${PK}" -o StrictHostKeyChecking=no root@"${SUV}.workdaysuv.com" "bash -xes" <<ENDSSH
  yum install -y python3
  pip3 install smartsheet-python-sdk
  pip3 install pandas
  rm -rf ~/DAI_Tools/DCDD/*/
  export SMARTSHEET_ACCESS_TOKEN=${SS_TOKEN}
  python3 -u ~/DAI_Tools/DCDD/DCDD_Scraper_Orchestrator.py --no_move_files
ENDSSH
rsync -acvzhe "ssh -i '${PK}' -o StrictHostKeyChecking=no" --no-p --no-o --no-g --checksum root@"${SUV}.workdaysuv.com:~/DAI_Tools/" ./DAI_Tools/

cp -r DAI_Tools/DCDD/JSONs DCDD_JSON/
cp -r DAI_Tools/DCDD/JSONs2 DCDD_JSON/
cp -r DAI_Tools/DCDD/CHKLIST DCDD_JSON/
cp -r DAI_Tools/DCDD/download DCDD_JSON/
cp -r DAI_Tools/DCDD/DICTS DCDD_JSON/

cp -r DAI_Tools/DCDD/SQLs DCDD_Outputs/
cp -r DAI_Tools/DCDD/CSVs DCDD_Outputs/
cp -r DAI_Tools/DCDD/CSV_DEFs DCDD_Outputs/
cp -r DAI_Tools/DCDD/CHKLIST DCDD_Outputs/
cp -r DAI_Tools/DCDD/DDLs DCDD_Outputs/
cp -r DAI_Tools/DCDD/DICTS DCDD_Outputs/
cp -r DAI_Tools/DCDD/download DCDD_Outputs/

git -C DCDD_JSON add . 
git -C DCDD_Outputs add . 

if [[ -n $(git -C DCDD_JSON status --porcelain) ]]
then
  git -C DCDD_JSON commit -m "Auto Update at $(date)" && git -C DCDD_JSON push https://Jenkins:${GHE_TOKEN}@ghe.megaleo.com/DTOE/DCDD_JSON.git master
  echo "Commited changes! (DCDD_JSON)" > env.job_message_New_Scraper
  git -C DCDD_JSON show --shortstat | tail -n 3 >> env.job_message_New_Scraper
else
  echo "Nothing to commit! (DCDD_JSON)" > env.job_message_New_Scraper
fi

if [[ -n $(git -C DCDD_Outputs status --porcelain) ]]
then
  git -C DCDD_Outputs commit -m "Auto Update at $(date)" && git -C DCDD_Outputs push https://Jenkins:${GHE_TOKEN}@ghe.megaleo.com/DTOE/DCDD_Outputs.git master
  echo "Commited changes! (DCDD_Outputs)" >> env.job_message_New_Scraper
  git -C DCDD_Outputs show --shortstat | tail -n 3 >> env.job_message_New_Scraper
else
  echo "Nothing to commit! (DCDD_Outputs)" >> env.job_message_New_Scraper
fi
      ''')
    } } // end ghe & ssh withcreds // end withenv (suv)
  
    // Get the output of the file
    getResult = readFile('env.job_message_New_Scraper').trim()

  } // end stage
} } // end node podTemplate

} catch (e) {
  // Got Error / Failure
  buildResult = "FAILURE"
  getResult = e
  throw e
//   getResult = sh(script: '''\
// #!/bin/bash +x
// tail -20 '${JENKINS_HOME}/jobs/${JOB_NAME}/builds/${BUILD_NUMBER}/log' | sed 's/\\[8mha:.*\\[0m//'
// ''', returnStdout: true,)
} finally {
  // Always Run Post Build or Error
  def result_color = (buildResult == 'FAILURE') ? 'danger' : 'good'
  if (buildResult == 'FAILURE' || (buildResult == 'SUCCESS' && getResult.contains('Commited changes!'))) {
    slackSend tokenCredentialId: 'SLACK_TOKEN', teamDomain: 'workday-dev', channel: '#dai-jenkins-notifications', color: result_color, message: "${env.JOB_NAME} - ${buildResult} after ${currentBuild.durationString} (<${env.BUILD_URL}|#${env.BUILD_NUMBER}> <${env.BUILD_URL}console|Console Output>)\n${getResult}"
  }
}

