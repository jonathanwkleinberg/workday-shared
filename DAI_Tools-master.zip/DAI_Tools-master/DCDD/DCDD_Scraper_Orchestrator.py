import os
import sys
import subprocess
import concurrent.futures
import time
import argparse

def run_script(script_name, args=None):
    current_dir = os.path.dirname(os.path.realpath(__file__))
    script_path = os.path.join(current_dir, script_name)
    command = ['python', script_path]
    if args:
        command.extend(args)  # Add additional arguments to the command
    subprocess.run(command, check=True)

# Parse command line arguments to get SKUs to filter
parser = argparse.ArgumentParser(description="Run orchestrator with SKU filtering.")
parser.add_argument('--SKUs_to_Filter', nargs='+', help='List of SKUs to filter by')
parser.add_argument('--no_move_files', action='store_true', help='Do not run the move_files function')    # Add an argument for controlling the move_files function
args = parser.parse_args()

# Start the timer
start_time = time.time()

# Arguments for the DCDD scraper script
scraper_args = ['--filter_by_sku'] + args.SKUs_to_Filter if args.SKUs_to_Filter else None

# Run the DCDD scraper script first with SKU filters if provided
run_script('DCDD_Scraper_to_JSON.py', scraper_args)
run_script('DCDD_ImplComponentRptRunner.py')
scripts = ['DCDD_Scraper_JSON_to_CSV.py', 'DCDD_Scraper_JSON_to_CSVDEFS.py', 'DCDD_Scraper_JSON_to_SQL.py']

with concurrent.futures.ThreadPoolExecutor() as executor:
    executor.map(lambda script: run_script(script), scripts)

# End the timer
end_time = time.time()

# Calculate the total execution time
total_time = end_time - start_time

# Convert the total time from seconds to minutes and seconds
minutes, seconds = divmod(total_time, 60)
print(f"Total orchestrator execution time: {int(minutes)} minutes and {int(seconds)} seconds")

current_dir = os.path.dirname(os.path.realpath(__file__))   # Get the directory of the currently running script
sys.path.append(current_dir)    # Append the move_files module directory to the system path

# Only call the main function if the --no_move_files argument was NOT provided
if not args.no_move_files:
    # Call the main function with the custom sources and targets, and set remove_source to True to move files
    from move_files import main

    custom_sources = [
        R"C:\GitHub\DAI_Tools\DCDD\JSONs", 
        R"C:\GitHub\DAI_Tools\DCDD\JSONs2",
        R"C:\GitHub\DAI_Tools\DCDD\CSVs",
        R"C:\GitHub\DAI_Tools\DCDD\CSV_DEFs",
        R"C:\GitHub\DAI_Tools\DCDD\SQLs",
        R"C:\GitHub\DAI_Tools\DCDD\DDLs",
        R"C:\GitHub\DAI_Tools\DCDD\CHKLIST",
        R"C:\GitHub\DAI_Tools\DCDD\DICTS",
        R"C:\GitHub\DAI_Tools\DCDD\download"
    ]

    custom_targets = [
        R"C:\GitHub\DCDD_JSON\JSONs", 
        R"C:\GitHub\DCDD_JSON\JSONs2",
        R"C:\GitHub\DCDD_Outputs\CSVs",
        R"C:\GitHub\DCDD_Outputs\CSV_DEFs",
        R"C:\GitHub\DCDD_Outputs\SQLs",
        R"C:\GitHub\DCDD_Outputs\DDLs",
        R"C:\GitHub\DCDD_Outputs\CHKLIST",
        R"C:\GitHub\DCDD_Outputs\DICTS",
        R"C:\GitHub\DCDD_Outputs\download"
    ]

    # Call the main function with the custom sources and targets, and set remove_source to True to move files
    main(sources=custom_sources, targets=custom_targets, remove_source=True)