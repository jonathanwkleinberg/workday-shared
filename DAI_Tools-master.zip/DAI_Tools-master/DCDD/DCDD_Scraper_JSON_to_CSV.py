import os
import json
import csv
import shutil
import time
import re
import pathlib
from multiprocessing import Pool, Manager

CurrentPath = pathlib.Path(__file__).parent
JSONs = CurrentPath / "JSONs"
CSVs = CurrentPath / "CSVs"
subdirs = ['FULL', 'SEQUENTIAL', 'HIGHVOL', 'BLANK', 'MINIMAL']
HIGHVOL = 10

def find_index(columns, header_name):
    """ Find the index of a given header name in columns, handling case insensitivity. """
    header_name_lower = header_name.lower()
    return next((i for i, col in enumerate(columns) if col.lower() == header_name_lower), None)

def is_number(s):
    try:
        if s is not None:
            int(s)
            return True
        else:
            return False
    except ValueError:
        return False

def is_boolean(s):
    return str(s).lower() in ['true', 'false', 'none']

def process_json_file(args):
    file_path, sku, total_csv_files_written = args
    print(f"Processing file: {file_path}")
    with open(file_path, 'r') as f:
        json_dcdd = json.load(f)

    metadata = json_dcdd.get('metadata', {})
    default_csv_name = (metadata.get('FULL NAME') or 'Unnamed_Dataset').replace(" ", "_")
    
    if default_csv_name.endswith('_DCDD'):
        default_csv_name = default_csv_name[:-5]
    default_csv_name += ".csv"

    columns = json_dcdd.get("columns", [])
    rows = json_dcdd.get("rows", [])

    csv_header_index = find_index(columns, "csv Header")
    sample_value_index = find_index(columns, "Sample Value")
    required_optional_index = find_index(columns, "required/optional")
    file_name_index = find_index(columns, "csv File Name")

    primary_keys = {'headers': [], 'required_optionals': [], 'samples': []}
    files_data = {}
    has_csv_file_name = file_name_index is not None and any(row[file_name_index] for row in rows)

    for row_num, row in enumerate(rows):
        if not csv_header_index or not row[csv_header_index]: continue # Can't do anything without a csv Header
        if has_csv_file_name and not row[file_name_index]: continue # Skip rows without a csv file name if there is one in any other row
        csv_file_names = row[file_name_index].split(',') if file_name_index is not None and row[file_name_index] else [default_csv_name]
        header = (row_num, row[csv_header_index] if csv_header_index is not None and csv_header_index < len(row) else "")
        sample = (row_num, row[sample_value_index] if sample_value_index is not None and sample_value_index < len(row) else "")
        required_optional = (row_num, row[required_optional_index] if required_optional_index is not None and required_optional_index < len(row) else "")

        for csv_file_name in csv_file_names:
            csv_file_name = csv_file_name.strip().lower()  # Remove leading/trailing whitespace and set to lowercase
            if not csv_file_name == "all csvs":
              if not csv_file_name.endswith('.csv'):
                  csv_file_name += ".csv"
              # Remove DCDD if there
              if csv_file_name.split('.')[0].endswith('_dcdd'):
                  csv_file_name = '.'.join([csv_file_name.split('.')[0][:-5], csv_file_name.split('.')[1]])

            if csv_file_name == "all csvs":
                primary_keys['headers'].append(header)
                primary_keys['required_optionals'].append(required_optional)
                primary_keys['samples'].append(sample)
            else:
                data = files_data.setdefault(csv_file_name, {'headers': [], 'required_optionals': [], 'samples': []})
                data['headers'].append(header)
                data['required_optionals'].append(required_optional)
                data['samples'].append(sample)

    # Prepend primary key headers and samples to each file data
    print(file_path.name, files_data.keys())
    for csv_file_name, data in files_data.items():
        full_headers = [x[1] for x in sorted(primary_keys['headers'] + data['headers'])]
        full_required_optionals = [x[1] for x in sorted(primary_keys['required_optionals'] + data['required_optionals'])]
        full_samples = [x[1] for x in sorted(primary_keys['samples'] + data['samples'])]

        for subdir in subdirs:
            csv_dir = CSVs / subdir / sku
            csv_file_path = csv_dir / csv_file_name
        
            if subdir in ['BLANK']:
                write_csv(csv_file_path, full_headers, counter=total_csv_files_written)
            elif subdir in ['MINIMAL']:
                write_csv(csv_file_path, full_headers, full_samples, counter=total_csv_files_written)
            elif subdir in ['FULL']:
                write_csv(csv_file_path, full_headers, full_required_optionals, full_samples, counter=total_csv_files_written)
            elif subdir in ['SEQUENTIAL']:
                seq_sample_1 = []
                seq_sample_2 = []
                seq_sample_3 = []
                seq_headers = [f"{x if x else header}_(#{i+1})" for i, (x, header) in enumerate(zip(full_headers, full_samples))]
                
                for i, (header, sample) in enumerate(zip(full_headers, full_samples)):
                    if header and sample is not None and not is_boolean(sample):
                        if is_number(sample):
                            if len(str(int(sample))) > 1:  # Check if it's a multi-digit integer
                                seq_sample_1.append(str(int(sample) + 1))
                                seq_sample_2.append(str(int(sample) + 2))
                                seq_sample_3.append(str(int(sample) + 3))
                            else:
                                seq_sample_1.append(str(int(sample)))
                                seq_sample_2.append(str(int(sample)))
                                seq_sample_3.append(str(int(sample)))
                        elif re.match(r'^[ECPJA]{1,3}[^A-Za-z]*\d{2}$', sample) and len(sample) >= 4:
                            last_two_digits = int(sample[-2:])
                            new_sample = sample[:-2] + str(last_two_digits + 1).zfill(2)
                            seq_sample_1.append(new_sample)
                            new_sample = sample[:-2] + str(last_two_digits + 2).zfill(2)
                            seq_sample_2.append(new_sample)
                            new_sample = sample[:-2] + str(last_two_digits + 3).zfill(2)
                            seq_sample_3.append(new_sample)
                        else:
                            seq_sample_1.append(sample)
                            seq_sample_2.append(sample)
                            seq_sample_3.append(sample)
                    elif header and sample is not None and is_boolean(sample):  # Append 'True' or 'False' when sample is a boolean
                        seq_sample_1.append(str(sample))  
                        seq_sample_2.append(str(sample))
                        seq_sample_3.append(str(sample))
                    elif header and sample is None:   # Append an empty string when there is no sample, but still a header
                        seq_sample_1.append('')
                        seq_sample_2.append('')
                        seq_sample_3.append('')
                additional_rows = []
                if seq_sample_1: additional_rows.append(seq_sample_1)
                if seq_sample_2: additional_rows.append(seq_sample_2)
                if seq_sample_3: additional_rows.append(seq_sample_3)
                write_csv(csv_file_path, full_headers, seq_headers, full_samples, additional_rows, counter=total_csv_files_written)
            elif subdir in ['HIGHVOL']:
                raw_data = []
                additional_rows = []
                for hv in range(1, HIGHVOL + 1):
                    raw_row = []
                    for i, (header, sample, req_opt) in enumerate(zip(full_headers, full_samples, full_required_optionals), start=1):
                        if sample:
                            raw_row.append(sample)
                        else:
                            # Only use the specific placeholder if the required/optional value is not 'Reference' or 'Do Not Populate'
                            if req_opt not in ["Reference", "Do Not Populate"]:
                                #raw_row.append(f'FIELD_(#{i})')
                                raw_row.append(f'{header}_(#{i})') 
                            else:
                                raw_row.append('')  # Leave the field empty
                    if raw_row:
                        raw_row[0] = f"ID{str(hv).zfill(5)}_(#1)"  # Ensuring the ID field is always populated
                        raw_data.append(raw_row)
                write_csv(csv_file_path, full_headers, full_required_optionals, full_samples, additional_rows=raw_data, counter=total_csv_files_written)
            else:
                print(f"Subdir not found: {subdir}")
                write_csv(csv_file_path, full_headers, full_required_optionals, full_samples, counter=total_csv_files_written)


def write_csv(csv_file_path, headers, required_optional=[], samples=[], additional_rows=[], force_write=False, counter=None):
    if force_write:
        filtered_data = list(zip(headers, required_optional, samples))
    else: 
        # Filter out rows where the header is empty or all values are empty
        if "BLANK" in csv_file_path.parts:
            # For BLANK, write headers only if they exist.
            filtered_data = [(header, '', '', '') for header in headers if header]
        elif "MINIMAL" in csv_file_path.parts:
            # For MINIMAL, require headers and required_optional, ignore samples.
            filtered_data = [
                (header, req_opt, '', '') 
                for header, req_opt in zip(headers, required_optional) 
                if header and req_opt and req_opt not in ["Reference", "Do Not Populate"]
            ]
        else:
            # For other types, use existing logic.
            filtered_data = [
                (header, req_opt, sample, *additional_row) 
                for header, req_opt, sample, *additional_row in zip(headers, required_optional, samples, *additional_rows) 
                if header and (req_opt or sample)
            ]

    # If all headers are empty, skip writing this file
    if not filtered_data:
        print(f"No data to write for: {csv_file_path}")
        return
    
    filtered_headers, filtered_required_optional, filtered_samples, *filtered_additional_rows = zip(*filtered_data)
    
    if not csv_file_path.suffix.lower() == '.csv':
        csv_file_path = csv_file_path.with_suffix(".csv")
    if csv_file_path.stem.lower().endswith('_dcdd'):
        csv_file_path = csv_file_path.with_stem(csv_file_path.stem[:5])
    csv_file_path.parent.mkdir(exist_ok=True)
    with open(csv_file_path, 'a', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(filtered_headers)
        if "BLANK" not in csv_file_path.parts and filtered_required_optional:
            writer.writerow(filtered_required_optional)
        if "BLANK" not in csv_file_path.parts and "MINIMAL" not in csv_file_path.parts and filtered_samples:
            writer.writerow(filtered_samples)
        if additional_rows:
            writer.writerows(filtered_additional_rows)

    # Increment the global counter within a lock to ensure thread safety
    if counter: 
        with counter.lock: counter.value += 1

    print(f"CSV written ({counter.value if counter else 'not counted'}): {csv_file_path}")


def clear_directory(directory_path):
    for file_path in directory_path.iterdir():
        if file_path.is_file() or file_path.is_symlink():
            file_path.unlink()
        elif file_path.is_dir():
            shutil.rmtree(file_path)

def main():
    # Global variables for counting and timing
    mgr = Manager()
    total_csv_files_written = mgr.Namespace()
    total_csv_files_written.value = 0
    total_csv_files_written.lock = mgr.Lock()

    start_time = time.time()
    print("Creating CSV Directories")
    CSVs.mkdir(exist_ok=True)
    clear_directory(CSVs)
    for subdir in subdirs:
        new_dir = CSVs / subdir
        if not new_dir.exists():
            new_dir.mkdir()
    pool = Pool(5)
    # tasks = []
    print('Compiling tasks ...')
    # for sku_folder in JSONs.iterdir():
    #     if sku_folder.is_dir():
    #         json_dir = sku_folder
    #         for file_path in json_dir.iterdir():
    #             if file_path.suffix == '.json':
    #                 tasks.append((file_path, sku_folder.name, total_csv_files_written))
    tasks = [(x, x.parent.name, total_csv_files_written) for x in sorted(JSONs.rglob('*.json'))]
    if tasks is None:
        print("No tasks to process.")
    else:
        print(F'Processing {len(tasks)} tasks ...', tasks)
        pool.map(process_json_file, tasks)
    pool.close()
    pool.join()

    end_time = time.time()
    print(f"<-||-> Total CSV files written: {total_csv_files_written.value} <-||->")
    print(f"<-||-> Total CSV execution time: {end_time - start_time:.2f} seconds <-||->")

if __name__ == "__main__":
    main()